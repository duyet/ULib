-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 21, 2015 at 09:29 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ULib`
--

-- --------------------------------------------------------

--
-- Table structure for table `AccessLogs`
--

DROP TABLE IF EXISTS `AccessLogs`;
CREATE TABLE IF NOT EXISTS `AccessLogs` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `access_time` datetime NOT NULL,
  `access_type` varchar(10) DEFAULT NULL,
  `log_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Authors`
--

DROP TABLE IF EXISTS `Authors`;
CREATE TABLE IF NOT EXISTS `Authors` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` text,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Books`
--

DROP TABLE IF EXISTS `Books`;
CREATE TABLE IF NOT EXISTS `Books` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `publisher_id` int(11) DEFAULT NULL,
  `authors_id` int(11) NOT NULL,
  `number` int(11) NOT NULL DEFAULT '0',
  `description` text,
  `available_number` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Categories`
--

DROP TABLE IF EXISTS `Categories`;
CREATE TABLE IF NOT EXISTS `Categories` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `loan_time` int(11) DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Languages`
--

DROP TABLE IF EXISTS `Languages`;
CREATE TABLE IF NOT EXISTS `Languages` (
`id` int(11) NOT NULL,
  `key` varchar(2) NOT NULL,
  `name` varchar(45) NOT NULL DEFAULT '',
  `description` varchar(250) DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `LoanDetails`
--

DROP TABLE IF EXISTS `LoanDetails`;
CREATE TABLE IF NOT EXISTS `LoanDetails` (
`id` int(11) NOT NULL,
  `loan_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `time_return` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `is_return` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Loans`
--

DROP TABLE IF EXISTS `Loans`;
CREATE TABLE IF NOT EXISTS `Loans` (
`id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `time_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Permissions`
--

DROP TABLE IF EXISTS `Permissions`;
CREATE TABLE IF NOT EXISTS `Permissions` (
`id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Publisher`
--

DROP TABLE IF EXISTS `Publisher`;
CREATE TABLE IF NOT EXISTS `Publisher` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` text,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ReturnDetails`
--

DROP TABLE IF EXISTS `ReturnDetails`;
CREATE TABLE IF NOT EXISTS `ReturnDetails` (
`id` int(11) NOT NULL,
  `return_id` int(11) DEFAULT NULL,
  `loan_detail_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Returns`
--

DROP TABLE IF EXISTS `Returns`;
CREATE TABLE IF NOT EXISTS `Returns` (
`id` int(11) NOT NULL,
  `loan_id` int(11) NOT NULL,
  `time_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Sessions`
--

DROP TABLE IF EXISTS `Sessions`;
CREATE TABLE IF NOT EXISTS `Sessions` (
`id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `login_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Staff`
--

DROP TABLE IF EXISTS `Staff`;
CREATE TABLE IF NOT EXISTS `Staff` (
`id` int(11) NOT NULL,
  `username` varchar(16) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone_number` varchar(45) DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `Staff`
--

INSERT INTO `Staff` (`id`, `username`, `email`, `password`, `phone_number`, `create_time`, `status`) VALUES
(11, 'lvduit', 'lvduit08@gmail.com', '$2a$08$DPd0cw/Dtccoclhv3ySXquq67JuHWytNVm1xsieq4I481H5WHnr/K', NULL, '2015-03-22 03:24:24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `StaffRoles`
--

DROP TABLE IF EXISTS `StaffRoles`;
CREATE TABLE IF NOT EXISTS `StaffRoles` (
`id` int(11) NOT NULL,
  `key` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Students`
--

DROP TABLE IF EXISTS `Students`;
CREATE TABLE IF NOT EXISTS `Students` (
`student_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `subject` varchar(45) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=705000501 ;

--
-- Dumping data for table `Students`
--

INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(520110, 'Phạm Huỳnh Đức Huy', 'Kỹ thuật máy tính'),
(4010528, 'Nguyễn Ngọc Hợp', ''),
(4050036, 'Nguyễn Bỉnh  Khiêm', 'Đào tạo từ xa'),
(4050055, 'Traàn Vaên  Dö', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(4050089, 'Nguyễn Cao  Trường', 'Đào tạo từ xa'),
(4050465, 'Huỳnh Thị Kim  Sinh', 'Đào tạo từ xa'),
(5050012, 'Nguyeãn Vuõ Lam Hoàng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6050006, 'Nguyeãn Coâng Chöùc', 'Đào tạo từ xa'),
(6050012, 'Phaïm Thò Nhö Duyeân', 'Đào tạo từ xa'),
(6520001, 'Hồ Ngọc An', 'Khoa học máy tính'),
(6520002, 'Lê Nguyễn Thúy An', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520004, 'Lê Thanh An', 'Hệ thống thông tin'),
(6520005, 'Nguyễn Lê Phú An', 'Khoa học máy tính'),
(6520006, 'Nguyễn Thanh An', 'Khoa học máy tính'),
(6520007, 'Võ Nguyên Minh An', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520008, 'Nguyễn Minh Ân', 'Khoa học máy tính'),
(6520009, 'Phạm Đình Ân', 'Khoa học máy tính'),
(6520011, 'Châu Việt Anh', 'Kỹ thuật máy tính'),
(6520012, 'Huỳnh Tuấn Anh', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520013, 'Huỳnh Tuấn Anh', 'Khoa học máy tính'),
(6520015, 'Nguyễn Khắc Bảo Anh', 'Hệ thống thông tin'),
(6520016, 'Nguyễn Ngọc Lan Anh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520017, 'Nguyễn Phương Anh', 'Công nghệ phần mềm'),
(6520018, 'Phạm Tuấn Anh', 'Cử nhân tài năng'),
(6520019, 'Phạm Võ  Hoài Anh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520020, 'Phạm Hồng Ảnh', 'Hệ thống thông tin'),
(6520022, 'Lê Đình Bằng', 'Khoa học máy tính'),
(6520023, 'Nguyễn Huy Bảo', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520024, 'Trần Hoàng Vĩnh Bảo', 'Hệ thống thông tin'),
(6520025, 'Đỗ Đình Biên', 'Khoa học máy tính'),
(6520026, 'Nguyễn Phước Biển', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520027, 'Hồ Thanh Bình', 'Mạng máy tính & truyền thông'),
(6520028, 'Lê Thái Bình', 'Kỹ thuật máy tính'),
(6520029, 'Nguyễn Thái Bình', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520030, 'Nguyễn Thái Bình', 'Mạng máy tính & truyền thông'),
(6520031, 'Võ Khải Hoàng Ca', 'Mạng máy tính & truyền thông'),
(6520032, 'Bùi Thái Chánh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520033, 'Lê Minh Chánh', 'Cử nhân tài năng'),
(6520034, 'Đinh Hồng Châu', 'Công nghệ phần mềm'),
(6520035, 'Lê Văn Minh Châu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520037, 'Hà Thị Thùy Chi', 'Hệ thống thông tin'),
(6520038, 'Lê Thị Phương Chi', 'Hệ thống thông tin'),
(6520039, 'Nguyễn Linh Chi', 'Hệ thống thông tin'),
(6520040, 'Vũ Thị Lan Thi', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520042, 'Nguyễn Thế Chiến', 'Khoa học máy tính'),
(6520043, 'Đỗ Ngọc Kiều Chinh', 'Hệ thống thông tin'),
(6520044, 'Nguyễn Duy Chinh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520045, 'Trần Đức Thịnh', 'Cử nhân tài năng'),
(6520046, 'Trần Viễn Chinh', 'Mạng máy tính & truyền thông'),
(6520048, 'Bùi Văn Chương', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520049, 'Đỗ Hoàng Chương', 'Mạng máy tính & truyền thông'),
(6520051, 'Lê Thành Công', 'Kỹ thuật máy tính'),
(6520052, 'Lê Thành Công', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520053, 'Ngô Chí Công', 'Công nghệ phần mềm'),
(6520054, 'Nguyễn Văn Cúc', 'Khoa học máy tính'),
(6520056, 'Nguyễn Kim Cương', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520057, 'Nguyễn Kim Cương', 'Hệ thống thông tin'),
(6520059, 'Nguyễn Phú Cường', 'Hệ thống thông tin'),
(6520060, 'Nguyễn Phước Cường', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520061, 'Nguyễn Quốc Cường', 'Mạng máy tính & truyền thông'),
(6520062, 'Trần Huy Cường', 'Mạng máy tính & truyền thông'),
(6520063, 'Trần Quốc Cường', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520065, 'Nguyễn Quốc Đại', 'Mạng máy tính & truyền thông'),
(6520066, 'Huỳnh Công Danh', 'Khoa học máy tính'),
(6520067, 'Tô Trọng Danh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520068, 'Trần Công Danh', 'Công nghệ phần mềm'),
(6520069, 'Đỗ Quang Đạt', 'Mạng máy tính & truyền thông'),
(6520070, 'Hồ Anh Đạt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520071, 'Lê Huy Bảo Đạt', 'Mạng máy tính & truyền thông'),
(6520072, 'Mai Minh Đạt', 'Kỹ thuật máy tính'),
(6520073, 'Nguyễn Minh Đạt', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520075, 'Phạm Văn Đạt', 'Kỹ thuật máy tính'),
(6520076, 'Trần Văn Đạt', 'Kỹ thuật máy tính'),
(6520077, 'Vũ Tiến Đạt', 'Khoa học máy tính'),
(6520078, 'Nguyễn Mạnh Điền', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520080, 'Phạm Khắc Điệp', 'Khoa học máy tính'),
(6520081, 'Phạm Quý Định', 'Kỹ thuật máy tính'),
(6520082, 'Huỳnh Trần Đoàn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520086, 'Phan Đông', 'Mạng máy tính & truyền thông'),
(6520087, 'Huỳnh Minh Đức', 'Công nghệ phần mềm'),
(6520088, 'Lâm Hữu Đức', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520089, 'Lê Phước Phát Đạt Đức', 'Kỹ thuật máy tính'),
(6520090, 'Nguyễn Xuân Đức', 'Mạng máy tính & truyền thông'),
(6520091, 'Trần Ngọc Đức', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520092, 'Đoàn Thị Thanh Dung', ''),
(6520093, 'Bùi Tiến Dũng', 'Khoa học máy tính'),
(6520094, 'Đỗ Văn Dũng', 'Khoa học máy tính'),
(6520095, 'Huỳnh Quốc Dũng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520097, 'Nguyễn Tiến Dũng', 'Khoa học máy tính'),
(6520098, 'Nguyễn Tiến Dũng', 'Hệ thống thông tin'),
(6520099, 'Trần Khải Dũng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520100, 'Trần Quốc Dũng', 'Mạng máy tính & truyền thông'),
(6520101, 'Đào Bá Dương', 'Hệ thống thông tin'),
(6520102, 'Đào Mạnh Dương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520104, 'Ngô Thị Thùy Dương', 'Hệ thống thông tin'),
(6520107, 'Đinh Diệp Duy', 'Cử nhân tài năng'),
(6520108, 'Đoàn Khương Duy', 'Khoa học máy tính'),
(6520109, 'Ngô Nguyên Duy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520110, 'Phạm Ngọc Duy', 'Kỹ thuật máy tính'),
(6520111, 'Phan Đình Duy', 'Kỹ thuật máy tính'),
(6520112, 'Võ Đinh Duy', 'Công nghệ phần mềm'),
(6520113, 'Võ Minh Duy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520114, 'Hàng Kim Duyên', 'Công nghệ phần mềm'),
(6520116, 'Nguyễn Trần Duyệt', 'Hệ thống thông tin'),
(6520118, 'Hoàng Trường Giang', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520120, 'Nguyễn Lê Trúc Giang', 'Mạng máy tính & truyền thông'),
(6520121, 'Nguyễn Thu Giang', 'Mạng máy tính & truyền thông'),
(6520122, 'Nguyễn Văn Giang', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520123, 'Võ Trường Giang', 'Mạng máy tính & truyền thông'),
(6520124, 'Lê Hoàng Hòa', 'Kỹ thuật máy tính'),
(6520126, 'Nguyễn Ngọc Hà', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520127, 'Nguyễn Thị Vũ Hà', 'Mạng máy tính & truyền thông'),
(6520129, 'Nguyễn Việt Hà', 'Hệ thống thông tin'),
(6520131, 'Phan Việt Hà', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520134, 'Hồng Việt Hải', 'Kỹ thuật máy tính'),
(6520135, 'Lê Đăng Hải', 'Công nghệ phần mềm'),
(6520136, 'Lê Minh Hải', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520138, 'Nguyễn Khương Hải', 'Mạng máy tính & truyền thông'),
(6520139, 'Nguyễn Minh Hải', 'Mạng máy tính & truyền thông'),
(6520140, 'Phạm Minh Hải', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520142, 'Võ Nguyễn Đăng Hải', 'Công nghệ phần mềm'),
(6520144, 'Đặng Ngọc Hạnh', 'Kỹ thuật máy tính'),
(6520145, 'Nguyễn Dương Hào', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520147, 'Trần Nguyên Hào', 'Khoa học máy tính'),
(6520148, 'Đào Minh Hậu', 'Kỹ thuật máy tính'),
(6520149, 'Phan Văn Hậu', 'Kỹ thuật máy tính'),
(6520150, 'Đặng Trung Hiền', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520151, 'Đỗ Thị Ngọc Hiền', 'Kỹ thuật máy tính'),
(6520152, 'Nguyễn Trung Hi', 'Kỹ thuật máy tính'),
(6520153, 'Nguyễn Văn Hiền', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520154, 'Nguyễn Hoàng Hiển', 'Mạng máy tính & truyền thông'),
(6520155, 'Nghiêm Xuân Hiệp', 'Mạng máy tính & truyền thông'),
(6520156, 'Nguyễn Hoàng Hiệp', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520160, 'Bùi Minh Hiếu', 'Mạng máy tính & truyền thông'),
(6520161, 'Bùi Quang Hiếu', 'Kỹ thuật máy tính'),
(6520162, 'Đoàn Thế Hiếu', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520163, 'Huỳnh Trung Hiếu', 'Khoa học máy tính'),
(6520164, 'Lê Minh Hiếu', 'Khoa học máy tính'),
(6520166, 'Trần Trung Hiếu', 'Công nghệ phần mềm'),
(6520168, 'Trịnh Minh Hiếu', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520169, 'Nguyễn Đức Hiệu', 'Công nghệ phần mềm'),
(6520170, 'Nguyễn Văn Hiệu', 'Công nghệ phần mềm'),
(6520172, 'Phan Vũ Tiến Hoà', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520174, 'Nguyễn Huy Khánh Hoà', 'Hệ thống thông tin'),
(6520175, 'Đặng Lê Hoài', 'Hệ thống thông tin'),
(6520176, 'Phan Hoài', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520177, 'Dương Thị Kim Hoàng', 'Kỹ thuật máy tính'),
(6520180, 'Nguyễn Hữu Hoàng', 'Kỹ thuật máy tính'),
(6520181, 'Nguyễn Thái Hoàng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520182, 'Nguyễn Thanh Hoàng', 'Công nghệ phần mềm'),
(6520183, 'Nguyễn Tuấn Hoàng', 'Khoa học máy tính'),
(6520186, 'Châu Kim Hùng', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520187, 'Liêu Đức Hùng', 'Mạng máy tính & truyền thông'),
(6520188, 'Ngeou Siêu Hùng', 'Kỹ thuật máy tính'),
(6520189, 'Nguyễn Minh Hùng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520191, 'Phan Xuân Hùng', 'Mạng máy tính & truyền thông'),
(6520192, 'Cao Văn Hưng', 'Kỹ thuật máy tính'),
(6520193, 'Huỳnh Kim Hưng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520194, 'Nguyễn Thuận Hưng', 'Công nghệ phần mềm'),
(6520195, 'Tống Hải Hưng', 'Mạng máy tính & truyền thông'),
(6520196, 'Trịnh Gia Hưng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520197, 'Vũ Ngọc Hưng', 'Công nghệ phần mềm'),
(6520199, 'Trần Thị Hường', 'Hệ thống thông tin'),
(6520200, 'Nguyễn Hữu Hữu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520201, 'Huỳnh Văn Huy', 'Mạng máy tính & truyền thông'),
(6520202, 'Lê Quang Huy', 'Kỹ thuật máy tính'),
(6520203, 'Ngô Đạo Huy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520204, 'Nguyễn Đình Huy', 'Mạng máy tính & truyền thông'),
(6520206, 'Nguyễn Thanh Huy', 'Hệ thống thông tin'),
(6520207, 'Nguyễn Tuấn Huy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520208, 'Nguyễn Vũ Huy', 'Cử nhân tài năng'),
(6520209, 'Phạm Trương Quang Huy', 'Kỹ thuật máy tính'),
(6520210, 'Trương Quang Huy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520211, 'Phạm Thị Thanh Huyền', 'Khoa học máy tính'),
(6520212, 'Cao Văn Huỳnh', 'Mạng máy tính & truyền thông'),
(6520213, 'Đinh Nam Kha', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520215, 'Nguyễn Vĩnh Kha', 'Công nghệ phần mềm'),
(6520216, 'Đào Ngọc Khải', 'Khoa học máy tính'),
(6520217, 'Nguyễn Tuấn Khải', 'Kỹ thuật máy tính'),
(6520218, 'Hà Minh Khánh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520219, 'Nguyễn Hồng Khánh', 'Hệ thống thông tin'),
(6520220, 'Trần Long Khánh', 'Kỹ thuật máy tính'),
(6520221, 'Vũ Duy Khánh', 'Công nghệ phần mềm'),
(6520222, 'Huỳnh Thiện Kiêm', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520224, 'Cao Đăng Khoa', 'Hệ thống thông tin'),
(6520225, 'Lê Nguyễn Khoa', 'Kỹ thuật máy tính'),
(6520226, 'Lê Tấn Khoa', 'Khoa học máy tính'),
(6520227, 'Lưu Thái Đăng Khoa', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520228, 'Ngô Tự Đăng Khoa', 'Kỹ thuật máy tính'),
(6520230, 'Nguyễn Việt Khoa', 'Công nghệ phần mềm'),
(6520231, 'Trần Tiến Khoa', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520233, 'Nguyễn Nguyên Khôi', 'Hệ thống thông tin'),
(6520234, 'Phan Thanh Khuyên', 'Hệ thống thông tin'),
(6520235, 'Hồ Trung Kiên', 'Kỹ thuật máy tính'),
(6520236, 'Lưu Chí Kiên', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520237, 'Lưu Hoàng Kiên', 'Kỹ thuật máy tính'),
(6520238, 'Nguyễn Trung Kiên', 'Công nghệ phần mềm'),
(6520239, 'Phan Trung Kiên', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520240, 'Bùi Thanh Kim', 'Khoa học máy tính'),
(6520241, 'Nguyễn Kim', 'Kỹ thuật máy tính'),
(6520242, 'Nguyễn Đình Kin', 'Kỹ thuật máy tính'),
(6520243, 'Lê Quí Kỵ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520244, 'Lê Văn La', 'Kỹ thuật máy tính'),
(6520245, 'Hoàng Thế Lan', 'Công nghệ phần mềm'),
(6520247, 'Phan Đình Lâm', 'Công nghệ phần mềm'),
(6520248, 'Võ Sơn Lâm', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520249, 'Nguyễn Duy Lân', 'Mạng máy tính & truyền thông'),
(6520250, 'Đỗ Nhất Linh', 'Kỹ thuật máy tính'),
(6520251, 'Nguyễn Đức Linh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520252, 'Nguyễn Ngọc Khánh Linh', 'Công nghệ phần mềm'),
(6520254, 'Trần Việt Linh', 'Kỹ thuật máy tính'),
(6520255, 'Phạm Quỳnh Loan', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520256, 'Tôn Thị Kim Loan', 'Mạng máy tính & truyền thông'),
(6520257, 'Đào Xuân Lộc', 'Mạng máy tính & truyền thông'),
(6520258, 'Võ Bá Lộc', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520259, 'Huỳnh Nguyễn Bảo Long', 'Kỹ thuật máy tính'),
(6520260, 'Lê Hoàng Long', 'Hệ thống thông tin'),
(6520261, 'Lê Quang Long', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520262, 'Nguyễn Bá Hoàng Long', 'Công nghệ phần mềm'),
(6520263, 'Nguyễn Đăng Bửu Long', 'Kỹ thuật máy tính'),
(6520265, 'Nguyễn Hải Long', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520266, 'Nguyễn Hoàng Long', 'Mạng máy tính & truyền thông'),
(6520267, 'Nguyễn Phạm Hoàng Long', 'Hệ thống thông tin'),
(6520268, 'Nguyễn Tiến Long', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520269, 'Nguyễn Văn Long', 'Mạng máy tính & truyền thông'),
(6520270, 'Vũ Hoàng Long', 'Hệ thống thông tin'),
(6520271, 'Hứa Minh Luân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520272, 'Nguyễn Thành Luân', 'Kỹ thuật máy tính'),
(6520273, 'Đoàn Trường Luật', 'Khoa học máy tính'),
(6520274, 'Vũ Hồng Luật', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520275, 'Nguyễn Đình Lưu', 'Kỹ thuật máy tính'),
(6520276, 'Nguyễn Trung Lưu', 'Công nghệ phần mềm'),
(6520277, 'Nguyễn Công Lý', 'Công nghệ phần mềm'),
(6520278, 'Lê Hoàng Mai', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520279, 'Lê Trần Thanh Mai', 'Kỹ thuật máy tính'),
(6520280, 'Đỗ Văn Mãn', 'Hệ thống thông tin'),
(6520281, 'Huỳnh Tấn Mẫn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520282, 'Vương Hà Thanh Mẫn', 'Công nghệ phần mềm'),
(6520285, 'Đoàn Quang Minh', 'Công nghệ phần mềm'),
(6520287, 'Nguyễn Cao Minh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520288, 'Nguyễn Công Minh', 'Hệ thống thông tin'),
(6520289, 'Nguyễn Hải Quang Minh', 'Mạng máy tính & truyền thông'),
(6520290, 'Nguyễn Hồng Minh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520291, 'Nguyễn Hữu Cát Minh', 'Mạng máy tính & truyền thông'),
(6520292, 'Nguyễn Nguyệt Minh', 'Kỹ thuật máy tính'),
(6520294, 'Trần Công Minh', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520296, 'Trịnh Anh Minh', 'Hệ thống thông tin'),
(6520297, 'Trương Nhật Minh', 'Mạng máy tính & truyền thông'),
(6520298, 'Võ Hồng Minh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520299, 'Đặng Đình Mùi', 'Công nghệ phần mềm'),
(6520302, 'Đoàn Ngọc Nam', 'Công nghệ phần mềm'),
(6520304, 'Nguyễn Huỳnh Nam', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520305, 'Nguyễn Ngọc Nam', 'Mạng máy tính & truyền thông'),
(6520307, 'Nguyễn Thành Nam', 'Hệ thống thông tin'),
(6520308, 'Nhữ Đình Hoài Nam', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520309, 'Phạm Đức Nam', 'Kỹ thuật máy tính'),
(6520310, 'Trần Hoàng Nam', 'Mạng máy tính & truyền thông'),
(6520311, 'Trần Hồng Nghi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520312, 'Dương Tấn Nghĩa', 'Công nghệ phần mềm'),
(6520313, 'Hồ Dư Trọng Nghĩa', 'Khoa học máy tính'),
(6520314, 'Lê Trọng Nghĩa', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520315, 'Ngô Ngọc Nghĩa', 'Công nghệ phần mềm'),
(6520316, 'Nguyễn Tiến Nghĩa', 'Mạng máy tính & truyền thông'),
(6520317, 'Nguyễn Trọng Nghĩa', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520318, 'Thân Hữu Nghĩa', 'Kỹ thuật máy tính'),
(6520319, 'Nguyễn Thị Bích Ngọc', 'Khoa học máy tính'),
(6520320, 'Lâm Phước Nguyên', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520321, 'Lý Thái Nguyên', 'Kỹ thuật máy tính'),
(6520322, 'Nguyễn Đinh Nguyên', 'Kỹ thuật máy tính'),
(6520323, 'Lê Thị Ánh Nguyệt', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520326, 'Lê Duy Đắc Nhân', 'Khoa học máy tính'),
(6520327, 'Lê Hồng Hải Nhân', 'Công nghệ phần mềm'),
(6520329, 'Mai Hoài Nhân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520331, 'Huỳnh Bá Nhẫn', 'Hệ thống thông tin'),
(6520332, 'Lê Minh Nhật', 'Mạng máy tính & truyền thông'),
(6520333, 'Nguyễn Xuân Nhật', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520334, 'Lưu Lê Qui Nhơn', 'Mạng máy tính & truyền thông'),
(6520335, 'Trần Lễ Nhơn', 'Công nghệ phần mềm'),
(6520336, 'Bùi Thị Mỹ Như', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520337, 'Đỗ Mạnh Như', 'Kỹ thuật máy tính'),
(6520339, 'Hồ Thanh Nhựt', 'Mạng máy tính & truyền thông'),
(6520341, 'Đồng Tấn Pha', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520342, 'Đặng Quang Phát', 'Công nghệ phần mềm'),
(6520343, 'Nguyễn Hữu Phát', 'Công nghệ phần mềm'),
(6520344, 'Ngô Bình Phương Phi Vân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520345, 'Nguyễn Văn Phong', 'Mạng máy tính & truyền thông'),
(6520346, 'Phạm Duy Phong', 'Công nghệ phần mềm'),
(6520347, 'Trần Nguyên Phong', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520348, 'Trần Đình Phú', 'Công nghệ phần mềm'),
(6520349, 'Vũ Thiên Phú', 'Khoa học máy tính'),
(6520351, 'Tiết Tấn Phúc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520353, 'Nguyễn Lộc Phước', 'Mạng máy tính & truyền thông'),
(6520354, 'Huỳnh Nhật Phương', 'Công nghệ phần mềm'),
(6520355, 'Lê Như Phương', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520356, 'Nguyễn Hoài Phương', 'Mạng máy tính & truyền thông'),
(6520357, 'Nguyễn Minh Phương', 'Công nghệ phần mềm'),
(6520358, 'Nguyễn Ngọc Phương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520359, 'Trần Minh Phương', 'Hệ thống thông tin'),
(6520360, 'Võ Hoàng Phương', 'Công nghệ phần mềm'),
(6520361, 'Vũ Thị Phương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520362, 'Đinh Văn Phượng', 'Mạng máy tính & truyền thông'),
(6520363, 'Bùi Minh Quân', 'Mạng máy tính & truyền thông'),
(6520364, 'Lê Hoàng Quân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520365, 'Phạm Minh Quân', 'Khoa học máy tính'),
(6520366, 'Trương Trọng Quân', 'Công nghệ phần mềm'),
(6520367, 'Lê Quang', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520368, 'Lê Phú Quý', 'Mạng máy tính & truyền thông'),
(6520369, 'Phạm Thanh Quốc', 'Công nghệ phần mềm'),
(6520370, 'Phan Duy Quốc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520371, 'Bùi Duy Qúy', 'Khoa học máy tính'),
(6520372, 'Nguyễn Vũ Ngọc Quyên', 'Hệ thống thông tin'),
(6520373, 'Lý Quốc Quyền', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520374, 'Nguyễn Thị Như Quỳnh', 'Công nghệ phần mềm'),
(6520375, 'Lê Trường Sa', 'Kỹ thuật máy tính'),
(6520376, 'Nguyễn Echam Samuel', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520377, 'Ngô Vũ Sang', 'Hệ thống thông tin'),
(6520378, 'Nguyễn Xuân Sang', 'Công nghệ phần mềm'),
(6520379, 'Trần Minh Sang', 'Cử nhân tài năng'),
(6520380, 'Võ Thanh Sanh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520381, 'Võ Tiến Sĩ', 'Hệ thống thông tin'),
(6520382, 'Lê Anh Sơn', 'Khoa học máy tính'),
(6520383, 'Lưu Nguyễn Quốc Sơn', 'Công nghệ phần mềm'),
(6520384, 'Nguyễn Hải Sơn', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520385, 'Nguyễn Ngọc Sơn', 'Kỹ thuật máy tính'),
(6520386, 'Nguyễn Trung Sơn', 'Mạng máy tính & truyền thông'),
(6520387, 'Nguyễn Văn Sơn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520388, 'Nguyễn Viết Sơn', 'Kỹ thuật máy tính'),
(6520389, 'Nguyễn Vũ Trường Sơn', 'Mạng máy tính & truyền thông'),
(6520390, 'Phan Đức Sơn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520392, 'Trần Thế Sơn', 'Công nghệ phần mềm'),
(6520393, 'Vũ Hoàng Hải Sơn', 'Kỹ thuật máy tính'),
(6520395, 'Vũ Thị Hoài Sơn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520396, 'Trần Thị Minh Sương', 'Mạng máy tính & truyền thông'),
(6520399, 'Bùi Anh Tài', 'Hệ thống thông tin'),
(6520400, 'Hồ Quốc Tài', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520401, 'Huỳnh Lê Tấn Tài', 'Mạng máy tính & truyền thông'),
(6520402, 'Lê Văn Tài', 'Hệ thống thông tin'),
(6520403, 'Lê Công Tài', 'Hệ thống thông tin'),
(6520404, 'Trần Văn Tài', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520406, 'Đỗ Minh Tâm', 'Mạng máy tính & truyền thông'),
(6520407, 'Dương Chí Tâm', 'Công nghệ phần mềm'),
(6520408, 'Dương Thanh Tâm', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520409, 'Huỳnh Hữu Tâm', 'Hệ thống thông tin'),
(6520410, 'Vũ Hồng Tâm', 'Kỹ thuật máy tính'),
(6520411, 'Đoàn Thanh Tân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520412, 'Nguyễn Minh Tân', 'Mạng máy tính & truyền thông'),
(6520414, 'Nguyễn Anh Tấn', 'Công nghệ phần mềm'),
(6520416, 'Lê Hà Xuân Thái', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520417, 'Vũ Minh Thái', 'Hệ thống thông tin'),
(6520418, 'Nguyễn Ngọc Thân', 'Hệ thống thông tin'),
(6520420, 'Đặng Văn Thắng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520421, 'Diệp Vương Thắng', 'Công nghệ phần mềm'),
(6520422, 'Đinh Xuân Thắng', 'Mạng máy tính & truyền thông'),
(6520424, 'Lê Duy Thắng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520426, 'Phan Xuân Thắng', 'Hệ thống thông tin'),
(6520427, 'Trần Tất Thắng', 'Mạng máy tính & truyền thông'),
(6520428, 'Đặng Xuân Thanh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520429, 'Hồ Nguyễn Xuân Thanh', 'Khoa học máy tính'),
(6520430, 'Nguyễn Chí Thanh', 'Kỹ thuật máy tính'),
(6520432, 'Nguyễn Văn Thanh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520434, 'Bùi Trung Thành', 'Mạng máy tính & truyền thông'),
(6520435, 'Cao Bá Thành', 'Hệ thống thông tin'),
(6520436, 'Lâm Văn Thành', 'Khoa học máy tính'),
(6520437, 'Lê Tiến Thành', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520439, 'Nguyễn Công Thành', 'Kỹ thuật máy tính'),
(6520440, 'Nguyễn Tiến Thành', 'Kỹ thuật máy tính'),
(6520441, 'Vũ Văn Thành', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520442, 'Lê Tấn Thạnh', 'Công nghệ phần mềm'),
(6520443, 'Lương Văn Thao', ''),
(6520444, 'Bùi Minh Thảo', 'Mạng máy tính & truyền thông'),
(6520446, 'Võ Đức Thảo', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520447, 'Nguyễn Hữu Thế', 'Mạng máy tính & truyền thông'),
(6520448, 'Nguyễn Đình Thi', 'Mạng máy tính & truyền thông'),
(6520449, 'Đàm Văn Thiện', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520450, 'Đào Văn Thiện', 'Kỹ thuật máy tính'),
(6520451, 'Trịnh Đức Thiện', 'Kỹ thuật máy tính'),
(6520452, 'Hồ Quang Thịnh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520453, 'Nguyễn Quốc Thịnh', 'Cử nhân tài năng'),
(6520454, 'Nguyễn Văn Thịnh', 'Công nghệ phần mềm'),
(6520455, 'Nguyễn Lê Trường Thọ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520457, 'Nguyễn Đức Thông', 'Kỹ thuật máy tính'),
(6520458, 'Nguyễn Hồng Thông', 'Kỹ thuật máy tính'),
(6520459, 'Phạm Quang Thông', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520460, 'Trần Minh Thông', 'Cử nhân tài năng'),
(6520461, 'Trần Thế Thông', 'Công nghệ phần mềm'),
(6520462, 'Nguyễn Ngọc Hoài Thu', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520463, 'Huỳnh Trần Thư', 'Hệ thống thông tin'),
(6520464, 'Trần Quang Văn Thư', 'Khoa học máy tính'),
(6520465, 'Nguyễn Đình Lê Thuần', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520466, 'Lê Ngọc Thuận', 'Mạng máy tính & truyền thông'),
(6520467, 'Nguyễn Hoà Thuận', 'Công nghệ phần mềm'),
(6520468, 'Phan Khánh Thuận', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520469, 'Vũ Minh Thức', 'Hệ thống thông tin'),
(6520470, 'Phạm Công Thưởng', 'Công nghệ phần mềm'),
(6520471, 'Phạm Thị Thanh Thuý', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520473, 'Nguyễn Thị Thuý', 'Mạng máy tính & truyền thông'),
(6520474, 'Nguyễn Thị Thúy', 'Hệ thống thông tin'),
(6520475, 'Lê Cao Thùy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520476, 'Đỗ Văn Tiến', 'Công nghệ phần mềm'),
(6520477, 'Đoàn Ngọc Tiến', 'Cử nhân tài năng'),
(6520478, 'Nguyễn Đức Tiến', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520479, 'Nguyễn Duy Tiến', 'Công nghệ phần mềm'),
(6520480, 'Nguyễn Thái Phước Tiến', 'Mạng máy tính & truyền thông'),
(6520481, 'Nguyễn Việt Tiến', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520482, 'Bùi Trọng Tin', 'Hệ thống thông tin'),
(6520483, 'Nguyễn Chánh Tín', 'Hệ thống thông tin'),
(6520484, 'Nguyễn Thanh Tín', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520485, 'Phan Quốc Tín', 'Cử nhân tài năng'),
(6520486, 'Phan Thành Tín', 'Kỹ thuật máy tính'),
(6520487, 'Trần Nguyên Ngọc Tín', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520489, 'Đặng Hồng Tịnh', 'Kỹ thuật máy tính'),
(6520491, 'Vũ Văn Toan', 'Kỹ thuật máy tính'),
(6520492, 'Nguyễn Hữu Toàn', 'Hệ thống thông tin'),
(6520493, 'Nguyễn Minh Toàn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520494, 'Trần Quốc Toàn', 'Hệ thống thông tin'),
(6520495, 'Trần Thanh Toản', 'Khoa học máy tính'),
(6520496, 'Hoàng Thị Thúy Trà', 'Hệ thống thông tin'),
(6520499, 'Lê Viết Tri', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520500, 'Hồ Thanh Trí', 'Khoa học máy tính'),
(6520501, 'Lê Minh Trí', 'Công nghệ phần mềm'),
(6520502, 'Lương Minh Trí', 'Kỹ thuật máy tính'),
(6520503, 'Nguyễn Hữu Trí', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520504, 'Nguyễn Phi Minh Trí', 'Cử nhân tài năng'),
(6520505, 'Phùng Văn Trí', 'Công nghệ phần mềm'),
(6520506, 'Hồ Ngọc Minh Triết', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520507, 'Phạm Sử Tiến Trình', 'Cử nhân tài năng'),
(6520508, 'Tô Cẩm Trình', 'Hệ thống thông tin'),
(6520510, 'Lê Thanh Trọng', 'Cử nhân tài năng'),
(6520511, 'Lê Trữ', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520512, 'Đoàn Nhật Trực', 'Công nghệ phần mềm'),
(6520513, 'Lê Quang Trực', 'Kỹ thuật máy tính'),
(6520516, 'Nguyễn Thành Trung', 'Kỹ thuật máy tính'),
(6520518, 'Phạm Thành Trung', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520519, 'Tăng Văn Thanh Trung', 'Mạng máy tính & truyền thông'),
(6520520, 'Hồ Nhật Trường', 'Khoa học máy tính'),
(6520522, 'Nguyễn Nhựt Trường', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520523, 'Tạ Xuân Trường', 'Kỹ thuật máy tính'),
(6520525, 'Nguyễn Lâm Tú', 'Công nghệ phần mềm'),
(6520526, 'Nguyễn Ngọc Tú', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520527, 'Phạm Ngọc Tú', 'Mạng máy tính & truyền thông'),
(6520529, 'Đỗ Anh Tuấn', 'Hệ thống thông tin'),
(6520530, 'Đỗ Việt Tuấn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520531, 'Lê Anh Tuấn', 'Mạng máy tính & truyền thông'),
(6520532, 'Lê Mạnh Tuấn', 'Mạng máy tính & truyền thông'),
(6520533, 'Lê Trần Quốc Tuấn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520534, 'Nguyễn Anh Tuấn', 'Khoa học máy tính'),
(6520535, 'Nguyễn Thanh Tuấn', 'Hệ thống thông tin'),
(6520537, 'Phạm Anh Tuấn', 'Hệ thống thông tin'),
(6520539, 'Tạ Anh Tuấn', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520541, 'Trần Đức Anh Tuấn', 'Công nghệ phần mềm'),
(6520542, 'Trần Ngọc Tuấn', 'Kỹ thuật máy tính'),
(6520543, 'Trần Văn Tuấn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520545, 'Huỳnh Thanh Tùng', 'Kỹ thuật máy tính'),
(6520546, 'Huỳnh Thanh Tùng', 'Mạng máy tính & truyền thông'),
(6520551, 'Phạm Hoàng Tùng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520552, 'Phạm Thanh Tòng', 'Khoa học máy tính'),
(6520553, 'Võ Thanh Tùng', 'Kỹ thuật máy tính'),
(6520555, 'Nguyễn Xuân Tường', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520556, 'Tạ Văn Tưởng', 'Mạng máy tính & truyền thông'),
(6520557, 'Nguyễn Văn Tuyển', 'Mạng máy tính & truyền thông'),
(6520558, 'Hồ Long Vân', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520560, 'Nguyễn Bích Vân', 'Cử nhân tài năng'),
(6520561, 'Phạm Long Vân', 'Công nghệ phần mềm'),
(6520562, 'Quách Hải Vân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520563, 'Nguyễn Đào Viên', 'Mạng máy tính & truyền thông'),
(6520564, 'Ngô Quốc Việt', 'Hệ thống thông tin'),
(6520565, 'Nguyễn Hoàng Việt', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520566, 'Nguyễn Hồng Việt', 'Công nghệ phần mềm'),
(6520568, 'Phan Lâm Hoàng Việt', 'Công nghệ phần mềm'),
(6520569, 'Võ Quốc Việt', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520570, 'Lê Hữu Vinh', 'Mạng máy tính & truyền thông'),
(6520571, 'Nguyễn Chí Vinh', 'Khoa học máy tính'),
(6520572, 'Nguyễn Đức Vinh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520573, 'Phan Đăng Vinh', 'Khoa học máy tính'),
(6520574, 'Võ Như Vinh', 'Hệ thống thông tin'),
(6520575, 'Vũ Xuân Vinh', 'Công nghệ phần mềm'),
(6520576, 'Nguyễn Văn Vỉnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520578, 'Lê Đăng Vũ', 'Hệ thống thông tin'),
(6520579, 'Nguyễn Hoàng Vũ', 'Kỹ thuật máy tính'),
(6520580, 'Đoàn Khắc Vương', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520581, 'Lê Tuấn Vương', 'Khoa học máy tính'),
(6520582, 'Nguyễn Thế Trần Vương', 'Công nghệ phần mềm'),
(6520583, 'Phạm Hoàng Vương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520584, 'Phan Thịnh Vượng', 'Mạng máy tính & truyền thông'),
(6520585, 'Phan Thanh Vy', 'Mạng máy tính & truyền thông'),
(6520586, 'Bùi Quốc Vinh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(6520587, 'Phùng Hoàng Vỹ', 'Kỹ thuật máy tính'),
(6520588, 'Nguyễn Đức Đoàn', 'Kỹ thuật máy tính'),
(6520998, 'Student', 'Công nghệ phần mềm'),
(6520999, 'Nguyễn Văn Toàn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7050078, 'Tröông tueä Thuyeân', 'Đào tạo từ xa'),
(7520001, 'Trương Quốc An', 'Cử nhân tài năng'),
(7520002, 'Nguyễn Tuấn An', 'Công nghệ phần mềm'),
(7520003, 'Huỳnh Xuân An', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520004, 'Phạm Nguyễn Trường An', 'Cử nhân tài năng'),
(7520005, 'Võ Hoài An', 'Cử nhân tài năng'),
(7520006, 'Lê Quang An', 'Hệ thống thông tin'),
(7520007, 'Lê Huy Hải An', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520008, 'Lê Đức Anh', 'Kỹ thuật máy tính'),
(7520009, 'Trần Hưng Quốc Anh', 'Mạng máy tính & truyền thông'),
(7520010, 'Trần Hoàng Anh', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520011, 'Nguyễn Tuấn Anh', 'Mạng máy tính & truyền thông'),
(7520012, 'Trần Tuấn Anh', 'Kỹ thuật máy tính'),
(7520013, 'Nguyễn Quốc Anh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520014, 'Lê Đức Anh', 'Kỹ thuật máy tính'),
(7520015, 'Võ Văn Hoàng Anh', 'Mạng máy tính & truyền thông'),
(7520016, 'Nguyễn Thế Anh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520017, 'Lê Hoàng Anh', 'Công nghệ phần mềm'),
(7520018, 'Nguyễn Thiên Ân', 'Hệ thống thông tin'),
(7520019, 'Bùi Thiên Ân', 'Công nghệ phần mềm'),
(7520020, 'Đặng Bảo Ân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520021, 'Phí Thị Hải Âu', 'Kỹ thuật máy tính'),
(7520022, 'Hoàng Nguyên Bảo', 'Khoa học máy tính'),
(7520023, 'Nguyễn Đình Huy Bảo', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520024, 'Hồ Thị Bé', 'Kỹ thuật máy tính'),
(7520025, 'Huỳnh Minh Bình', 'Khoa học máy tính'),
(7520026, 'Trần Văn Bình', 'Công nghệ phần mềm'),
(7520027, 'Nguyễn Huy Bình', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520028, 'Nguyễn Thanh Bình', 'Công nghệ phần mềm'),
(7520029, 'Nguyễn Văn Bốn', 'Hệ thống thông tin'),
(7520030, 'Nguyễn Minh Chiến', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520031, 'Nguyễn Bá Chung', 'Công nghệ phần mềm'),
(7520032, 'Phạm Bảo Chung', 'Công nghệ phần mềm'),
(7520033, 'Nguyễn Văn Công', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520034, 'Trần Văn Cương', 'Chương trình tiên tiến'),
(7520035, 'Nguyễn Tiến Kiên Cường', 'Khoa học máy tính'),
(7520036, 'Hoàng Mạnh Cường', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520037, 'Đỗ Vũ Hữu Cường', 'Kỹ thuật máy tính'),
(7520038, 'Hoàng Cao Cường', 'Công nghệ phần mềm'),
(7520039, 'Nguyễn Ngọc Cường', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520040, 'Hoàng Đặng Vĩnh Cường', 'Kỹ thuật máy tính'),
(7520041, 'Phạm Minh Cường', 'Công nghệ phần mềm'),
(7520042, 'Nguyễn Hoàng Cường', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520043, 'Nguyễn Hồng Danh', 'Hệ thống thông tin'),
(7520044, 'Mai Quý Danh', 'Hệ thống thông tin'),
(7520045, 'Nguyễn Thị Ngọc Diễm', ''),
(7520046, 'Phạm Quang Diệu', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520047, 'Nguyễn Văn Du', 'Kỹ thuật máy tính'),
(7520048, 'Nguyễn Quang Du', 'Kỹ thuật máy tính'),
(7520050, 'Phạm Khương Duy', 'Công nghệ phần mềm'),
(7520051, 'Nguyễn Bảo Huy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520052, 'Đoàn Văn Duy', 'Mạng máy tính & truyền thông'),
(7520053, 'Lê Duy', 'Cử nhân tài năng'),
(7520054, 'Lưu Quốc Minh Duy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520055, 'Hồ Nguyễn Duy', 'Mạng máy tính & truyền thông'),
(7520056, 'Nguyễn Duy', 'Công nghệ phần mềm'),
(7520058, 'Nguyễn Anh Duy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520059, 'Phan Phạm Hoài Duy', 'Mạng máy tính & truyền thông'),
(7520060, 'Trần Nguyễn Ngọc Duy', 'Mạng máy tính & truyền thông'),
(7520061, 'Trần Nguyễn Ái Duyên', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520062, 'Nguyễn Hoàng Dũng', 'Mạng máy tính & truyền thông'),
(7520063, 'Vũ Tiến Dũng', 'Hệ thống thông tin'),
(7520064, 'Vũ Đình Dũng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520065, 'Nguyễn Xuân Dũng', 'Khoa học máy tính'),
(7520066, 'Đỗ Anh Dũng', 'Mạng máy tính & truyền thông'),
(7520067, 'Hoàng Minh Dũng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520068, 'Thái Minh Dũng', 'Công nghệ phần mềm'),
(7520069, 'Nguyễn Trí Dũng', 'Mạng máy tính & truyền thông'),
(7520070, 'Trần Đại Dương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520071, 'Nguyễn Thành Đại', 'Mạng máy tính & truyền thông'),
(7520072, 'Nguyễn Tấn Đạo', 'Mạng máy tính & truyền thông'),
(7520074, 'Văn Đỗ Phước Đạt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520075, 'Phùng Thế Đạt', 'Công nghệ phần mềm'),
(7520076, 'Lê Nguyễn Tấn Đạt', 'Công nghệ phần mềm'),
(7520077, 'Bùi Minh Đạt', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520078, 'Lê Tiến Đạt', 'Mạng máy tính & truyền thông'),
(7520079, 'Đặng Tiến Đạt', 'Công nghệ phần mềm'),
(7520080, 'Lê Phạm Quang Đẩu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520081, 'Nguyễn Lê Hải Đăng', 'Kỹ thuật máy tính'),
(7520082, 'Trần Huỳnh Đăng', 'Hệ thống thông tin'),
(7520083, 'Thái Bình Hải Đăng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520084, 'Dương Xuân Điển', 'Khoa học máy tính'),
(7520085, 'Nguyễn Toàn Định', 'Công nghệ phần mềm'),
(7520086, 'Lê Phan Thịnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520087, 'Nguyễn Huy Đô', 'Hệ thống thông tin'),
(7520088, 'Lê Văn Đông', 'Mạng máy tính & truyền thông'),
(7520089, 'Nguyễn Thành Đồng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520091, 'Lê Hải Đường', 'Công nghệ phần mềm'),
(7520092, 'Quách Hồng Đức', 'Cử nhân tài năng'),
(7520093, 'Thái Văn Sĩ Em', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520094, 'Đỗ Trường Giang', 'Công nghệ phần mềm'),
(7520095, 'Nguyễn Trường Giang', 'Mạng máy tính & truyền thông'),
(7520096, 'Nguyễn Văn Hanh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520097, 'Lê Hoàng Hòa', 'Hệ thống thông tin'),
(7520098, 'Hoàng Thái Hà', 'Hệ thống thông tin'),
(7520099, 'Nguyễn Hải Hà', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520102, 'Nguyễn Cảnh Hà', 'Mạng máy tính & truyền thông'),
(7520103, 'Nguyễn Xuân Hàm', 'Mạng máy tính & truyền thông'),
(7520104, 'Trịnh Thế Hào', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520105, 'Nguyễn Hoàng Hải', 'Mạng máy tính & truyền thông'),
(7520106, 'Hoàng Nam Hải', 'Công nghệ phần mềm'),
(7520107, 'Nguyễn Hữu Hải', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520108, 'Đỗ Hồng Hải', 'Công nghệ phần mềm'),
(7520109, 'Phạm Hồng Hải', 'Mạng máy tính & truyền thông'),
(7520110, 'Nguyễn Hồng Hải', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520111, 'Đặng Xuân Hạnh', 'Hệ thống thông tin'),
(7520112, 'Đoàn Hữu Hạnh', 'Công nghệ phần mềm'),
(7520113, 'Nguyễn Minh Hạnh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520114, 'Nguyễn Đức Hạnh', 'Công nghệ phần mềm'),
(7520115, 'Phạm Văn Hân', 'Kỹ thuật máy tính'),
(7520116, 'Nguyễn Đức Hiến', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520117, 'Nguyễn Minh Hiếu', 'Hệ thống thông tin'),
(7520118, 'Nguyáťn HoĂ ng Hiáşżu', 'Khoa háťc mĂĄy tĂ­nh'),
(7520119, 'Lê Trọng Hiếu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520120, 'Lê Minh Hiếu', 'Mạng máy tính & truyền thông'),
(7520121, 'Lê Vũ Minh Hiếu', 'Kỹ thuật máy tính'),
(7520122, 'Trần Minh Hiếu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520123, 'Nguyễn Ngọc Hiển', 'Kỹ thuật máy tính'),
(7520124, 'Lưu Nghĩa Hiệp', 'Khoa học máy tính'),
(7520125, 'Vũ Văn Hiệu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520126, 'Nguyễn Thị Hoa', 'Hệ thống thông tin'),
(7520127, 'Võ Tiến Hóa', 'Công nghệ phần mềm'),
(7520128, 'Bạch Thanh Hoàn', 'Khoa học máy tính'),
(7520129, 'Trương Thanh Hoàng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520130, 'Nguyễn Thái Hoàng', 'Mạng máy tính & truyền thông'),
(7520131, 'Nguyễn Hoàng', 'Mạng máy tính & truyền thông'),
(7520132, 'Nguyễn Minh Hoàng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520133, 'Nguyễn Thiện Hoàng', 'Mạng máy tính & truyền thông'),
(7520134, 'Võ Minh Hoàng', 'Khoa học máy tính'),
(7520135, 'Trần Duy Hoàng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520136, 'Nguyễn Ngọc Hoàng', 'Kỹ thuật máy tính'),
(7520137, 'Nguyễn Kế Hoạch', 'Công nghệ phần mềm'),
(7520138, 'Đinh Quốc Hòa', 'Kỹ thuật máy tính'),
(7520139, 'Lê An Hòa', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520140, 'Tô Trung Hòa', 'Công nghệ phần mềm'),
(7520142, 'Nguyễn Hòang Hổ', 'Hệ thống thông tin'),
(7520143, 'Lê Huy Tiên Hội', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520144, 'Phạm Quang Hợp', 'Hệ thống thông tin'),
(7520145, 'Đặng Trần Huân', ''),
(7520146, 'Lê Đức Phước Huệ', 'Công nghệ phần mềm'),
(7520147, 'Bùi Quốc Huy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520148, 'Nguyễn Thanh Huy', 'Mạng máy tính & truyền thông'),
(7520149, 'Lê Nhật Huy', 'Hệ thống thông tin'),
(7520150, 'Nguyễn Xuân Huy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520151, 'Trương Đình Huy', 'Mạng máy tính & truyền thông'),
(7520152, 'Đỗ Minh Huy', 'Công nghệ phần mềm'),
(7520153, 'Nguyễn Văn Huy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520154, 'Nguyễn Minh Huy', 'Mạng máy tính & truyền thông'),
(7520155, 'Lê Đình Huy', 'Khoa học máy tính'),
(7520156, 'Nguyễn Quốc Huy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520157, 'Nguyễn Anh Huy', 'Công nghệ phần mềm'),
(7520158, 'Thái Bảo Huy', 'Mạng máy tính & truyền thông'),
(7520159, 'Trương Quốc Hùng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520160, 'Tào Quang Hùng', 'Hệ thống thông tin'),
(7520161, 'Nguyễn Anh Hùng', 'Khoa học máy tính'),
(7520162, 'Hàn Đức Hùng', 'Hệ thống thông tin'),
(7520163, 'Phạm Minh Hùng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520164, 'Võ Trung Hưng', 'Mạng máy tính & truyền thông'),
(7520165, 'Trương Lê Hưng', 'Cử nhân tài năng'),
(7520166, 'Trần Viết Hưng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520167, 'Đỗ Huy Hưng', 'Mạng máy tính & truyền thông'),
(7520168, 'Trần Thị Thanh Hương', 'Hệ thống thông tin'),
(7520169, 'Nguyễn Minh Kha', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520170, 'Nguyễn Quang Gia Khang', 'Mạng máy tính & truyền thông'),
(7520171, 'Trần Minh Khang', 'Hệ thống thông tin'),
(7520172, 'Trần Nguyễn Khánh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520174, 'Huỳnh Trọng Khánh', 'Khoa học máy tính'),
(7520175, 'Trương Quang Khánh', 'Hệ thống thông tin'),
(7520176, 'Hoàng Trần Quang Khải', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520177, 'Trần Tiến Khiêm', 'Hệ thống thông tin'),
(7520178, 'Lâm Anh Khoa', 'Khoa học máy tính'),
(7520179, 'Nguyễn Đăng Khoa', 'Hệ thống thông tin'),
(7520180, 'Nguyễn Anh Khoa', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520181, 'Trần Duy Khương', 'Mạng máy tính & truyền thông'),
(7520182, 'Hồ Mạng Khương', 'Khoa học máy tính'),
(7520183, 'Nguyễn Tuấn Kiệt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520184, 'Trương Thị Thanh Kiều', 'Khoa học máy tính'),
(7520185, 'Trần Huỳnh Nam Lai', 'Công nghệ phần mềm'),
(7520186, 'Nguyễn Thanh Lâm', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520187, 'Nguyễn Thành Lâm', 'Hệ thống thông tin'),
(7520188, 'Đào Kim Lập', 'Mạng máy tính & truyền thông'),
(7520189, 'Cao Sỹ Lê', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520190, 'Nguyễn Đức Lê', 'Công nghệ phần mềm'),
(7520191, 'Hạ Hữu Liêm', 'Công nghệ phần mềm'),
(7520192, 'Nguyễn Duy Lin', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520193, 'Nguyễn Anh Linh', 'Mạng máy tính & truyền thông'),
(7520194, 'Nguyễn Ngọc Linh', 'Hệ thống thông tin'),
(7520195, 'Hoàng Linh', 'Cử nhân tài năng'),
(7520196, 'Trần Chí Linh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520197, 'Phạm Thanh Loan', 'Hệ thống thông tin'),
(7520198, 'Nguyễn Thăng Long', 'Công nghệ phần mềm'),
(7520199, 'Nguyễn Khoa Hải Long', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520200, 'Nguyễn Hoàng Long', 'Kỹ thuật máy tính'),
(7520201, 'Dương Phi Long', 'Hệ thống thông tin'),
(7520202, 'Nguyễn Hoàng Long', 'Khoa học máy tính'),
(7520203, 'Nguyễn Đức Long', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520204, 'Trần Văn Long', 'Công nghệ phần mềm'),
(7520205, 'Nguyễn Hữu Việt Long', 'Cử nhân tài năng'),
(7520206, 'Vũ Kim Long', 'Công nghệ phần mềm'),
(7520207, 'Đỗ Hà Lộc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520208, 'Nguyễn Phước Lộc', 'Hệ thống thông tin'),
(7520209, 'Đặng Tấn Lộc', 'Mạng máy tính & truyền thông'),
(7520210, 'Nguyễn Văn Lộc', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520211, 'Phạm Hoài Lộc', 'Hệ thống thông tin'),
(7520212, 'Trần Hữu Lộc', 'Kỹ thuật máy tính'),
(7520213, 'Bùi Đức Lợi', 'Kỹ thuật máy tính'),
(7520214, 'Lê Minh Luân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520215, 'Nguyễn Thành Luân', 'Công nghệ phần mềm'),
(7520216, 'Nguyễn Xuân Lục', 'Mạng máy tính & truyền thông'),
(7520217, 'Lê Văn Lưu', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520219, 'Vũ Thị Thanh Mai', 'Hệ thống thông tin'),
(7520220, 'Đỗ Tiến Mạnh', 'Mạng máy tính & truyền thông'),
(7520221, 'Nguyễn Khắc Mẫn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520222, 'Lê Đình Mẫn', 'Kỹ thuật máy tính'),
(7520223, 'Nguyễn Nghiêm Minh', 'Khoa học máy tính'),
(7520224, 'Trần Quang Anh Minh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520225, 'Võ Trần Nhật Minh', 'Hệ thống thông tin'),
(7520226, 'Trần Quang Minh', 'Kỹ thuật máy tính'),
(7520227, 'Nguyễn Huệ Minh', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520228, 'Trần Công Minh', 'Mạng máy tính & truyền thông'),
(7520229, 'Nguyễn Hoàng Minh', 'Công nghệ phần mềm'),
(7520230, 'Nguyễn Văn Mỹ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520231, 'Trần Hồ Phương Nam', 'Mạng máy tính & truyền thông'),
(7520232, 'Lê Nhựt Nam', 'Kỹ thuật máy tính'),
(7520233, 'Lê Hoài Nam', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520235, 'Hoàng Phương Nam', 'Mạng máy tính & truyền thông'),
(7520236, 'Trần Thành Nam', 'Khoa học máy tính'),
(7520237, 'Võ Hoàng Nam', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520238, 'Nguyễn Huỳnh Hải Nam', 'Mạng máy tính & truyền thông'),
(7520239, 'Đinh Văn Nam', 'Công nghệ phần mềm'),
(7520240, 'Ngô Thị Hồng Ngân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520241, 'Trần Thị Kim Ngân', 'Hệ thống thông tin'),
(7520243, 'Le Khanh Nghi', 'Mạng máy tính & truyền thông'),
(7520244, 'Trần Phan Minh Nghi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520245, 'Trần Hưng Nghiệp', 'Hệ thống thông tin'),
(7520246, 'Quang Tấn Nghĩa', 'Hệ thống thông tin'),
(7520247, 'Đoàn Trung Nghĩa', 'Khoa học máy tính'),
(7520248, 'Trương Đình Nghĩa', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520249, 'Hồ Trọng Nghĩa', 'Mạng máy tính & truyền thông'),
(7520250, 'Trần Hữu Nghị', 'Kỹ thuật máy tính'),
(7520251, 'Nguyễn Phúc Nguyên', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520252, 'Phạm Anh Vũ Nguyên', 'Kỹ thuật máy tính'),
(7520253, 'Lương Chí Nguyên', 'Công nghệ phần mềm'),
(7520254, 'Nguyễn Văn Nhàn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520255, 'Cao Phương Nhã', 'Kỹ thuật máy tính'),
(7520256, 'Nguyễn Hữu Nhân', 'Kỹ thuật máy tính'),
(7520257, 'Trần Thị Thu Nhân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520258, 'Chu Hoàng Nhật', 'Công nghệ phần mềm'),
(7520260, 'Dương Tấn Nhu', 'Công nghệ phần mềm'),
(7520261, 'Trịnh Lâm Trinh Nhựt', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520262, 'Huỳnh Thanh Nhựt', 'Kỹ thuật máy tính'),
(7520263, 'Huỳnh Thanh Sơn', 'Hệ thống thông tin'),
(7520264, 'Võ Tấn Phát', 'Kỹ thuật máy tính'),
(7520265, 'Huỳnh Vinh Phát', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520266, 'Lê Võ Hoàng Phi', 'Mạng máy tính & truyền thông'),
(7520267, 'Trần Thanh Phi', 'Hệ thống thông tin'),
(7520268, 'Võ Nhân Phong', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520269, 'Nguyễn Thanh Phong', 'Hệ thống thông tin'),
(7520270, 'Nguyễn Hồng Phong', 'Mạng máy tính & truyền thông'),
(7520271, 'Ngô Quốc Phong', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520272, 'Trần Thanh Phong', 'Công nghệ phần mềm'),
(7520273, 'Hứa Đại Phong', 'Hệ thống thông tin'),
(7520274, 'Hoàng Bảo Phú', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520275, 'Nguyễn Xuân Phú', 'Mạng máy tính & truyền thông'),
(7520276, 'Hồ Hữu Phúc', 'Kỹ thuật máy tính'),
(7520277, 'Lâm Vĩnh Phúc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520278, 'Đoàn Đình Phúc', 'Hệ thống thông tin'),
(7520279, 'Đỗ Duy Phúc', 'Cử nhân tài năng'),
(7520280, 'Trần Minh Tôn Vĩnh Phúc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520281, 'Nguyễn Trí Phúc', 'Cử nhân tài năng'),
(7520282, 'Nguyễn Ngọc Phúc', 'Hệ thống thông tin'),
(7520284, 'Hà Thị Minh Phương', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520285, 'Nguyễn Thành Phương', 'Hệ thống thông tin'),
(7520286, 'Nguyễn Đông Phương', 'Mạng máy tính & truyền thông'),
(7520287, 'Lê Quang Phương', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520290, 'Hà Văn Phước', 'Hệ thống thông tin'),
(7520291, 'Ôn Hà Chung Phước', 'Hệ thống thông tin'),
(7520292, 'Phạm Hoài Phước', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520293, 'Đậu Nhật Quang', 'Khoa học máy tính'),
(7520295, 'Nguyễn Phương Quang', 'Công nghệ phần mềm'),
(7520296, 'Nguyễn Triệu Quốc', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520297, 'Vũ Bảo Quốc', 'Mạng máy tính & truyền thông'),
(7520298, 'Trần Văn Quý', 'Mạng máy tính & truyền thông'),
(7520300, 'Cao Thị Huyền Sa', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520302, 'Lê Tự Thạch Sinh', 'Công nghệ phần mềm'),
(7520303, 'Trương Viết Sơn', 'Kỹ thuật máy tính'),
(7520304, 'Trần Minh Sơn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520305, 'Nguyễn Tùng Sơn', 'Hệ thống thông tin'),
(7520306, 'Nguyễn Thanh Sơn', 'Mạng máy tính & truyền thông'),
(7520308, 'Nguyễn Thanh Tâm', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520309, 'Võ Huy Tâm', 'Khoa học máy tính'),
(7520311, 'Vòng Xịt Tầy', 'Kỹ thuật máy tính'),
(7520312, 'Nguyễn Chí Thanh', 'Hệ thống thông tin'),
(7520313, 'Nguyễn Đăng Thái', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520314, 'Nguyễn Anh Thái', 'Mạng máy tính & truyền thông'),
(7520315, 'Nguyễn Duy Thái', 'Công nghệ phần mềm'),
(7520316, 'Nguyễn Thế Thành', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520317, 'Trương Trung Thành', 'Mạng máy tính & truyền thông'),
(7520319, 'Nguyễn Trung Thành', 'Công nghệ phần mềm'),
(7520320, 'Lê Phước Thành', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520322, 'Trần Thạch Thảo', 'Kỹ thuật máy tính'),
(7520323, 'Thái Thị Thu Thảo', 'Mạng máy tính & truyền thông'),
(7520324, 'Trương Quang Thạnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520326, 'Vũ Đức Thắng', 'Hệ thống thông tin'),
(7520327, 'Phạm Ngọc Thắng', 'Mạng máy tính & truyền thông'),
(7520328, 'Nguyễn Đắc Thắng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520329, 'Đỗ Nam Thế', 'Mạng máy tính & truyền thông'),
(7520330, 'Nguyễn Minh Thi', 'Mạng máy tính & truyền thông'),
(7520331, 'Phạm Minh Thiện', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520332, 'Nguyễn Hoàng Thịnh', 'Hệ thống thông tin'),
(7520333, 'Võ Quang Thịnh', 'Hệ thống thông tin'),
(7520334, 'Lê Đức Thịnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520335, 'Phan Quốc Thịnh', 'Kỹ thuật máy tính'),
(7520336, 'Lê Phát Thọ', 'Công nghệ phần mềm'),
(7520337, 'Võ Như Thông', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520338, 'Ngô Duy Thông', 'Mạng máy tính & truyền thông'),
(7520339, 'Phan Văn Thổ', 'Công nghệ phần mềm'),
(7520340, 'Ngô Ngọc Thơ', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520341, 'Trần Quang Tuấn', 'Mạng máy tính & truyền thông'),
(7520343, 'Huỳnh Minh Thuận', 'Kỹ thuật máy tính'),
(7520344, 'Trần Quang Thuận', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520345, 'Nguyễn Đức Thuận', 'Hệ thống thông tin'),
(7520346, 'Lê Công Minh Thuận', 'Công nghệ phần mềm'),
(7520347, 'Thi Minh Tuyễn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520348, 'Trần Thị Kim Thuý', 'Hệ thống thông tin'),
(7520349, 'Nguyễn Thị Thuý', 'Mạng máy tính & truyền thông'),
(7520350, 'Dương Châu Vĩnh Phúc', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520351, 'Nguyễn Tấn Thương', 'Hệ thống thông tin'),
(7520352, 'Mai Hoàng Hoài Thương', 'Cử nhân tài năng'),
(7520353, 'Phan Thương Thương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520354, 'Trần Huy Tiến', 'Mạng máy tính & truyền thông'),
(7520355, 'Nguyễn Trung Tiến', 'Cử nhân tài năng'),
(7520356, 'Nguyễn Quang Tiến', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520357, 'Trần Minh Tiến', 'Kỹ thuật máy tính'),
(7520358, 'Nguyễn Nhật Tiến', 'Công nghệ phần mềm'),
(7520359, 'Trần Quang Tín', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520361, 'Võ Chí Tính', 'Mạng máy tính & truyền thông'),
(7520362, 'Trần Minh Tính', 'Kỹ thuật máy tính'),
(7520363, 'Khương Sĩ Toàn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520364, 'Hồ Minh Toàn', 'Kỹ thuật máy tính'),
(7520365, 'Nguyễn Vũ Toàn', 'Mạng máy tính & truyền thông'),
(7520368, 'Hoàng Thị Bích Trân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520369, 'Thái Kim Triều', 'Mạng máy tính & truyền thông'),
(7520370, 'Le Cao Trí', 'Mạng máy tính & truyền thông'),
(7520371, 'Nguyễn Trọng Đăng Trình', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520372, 'Võ Thanh Hoàng Trung', 'Hệ thống thông tin'),
(7520373, 'Nguyễn Bảo Trung', 'Công nghệ phần mềm'),
(7520374, 'Lê Thành Trung', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520375, 'Lê Trần Tiến Trung', 'Công nghệ phần mềm'),
(7520376, 'Lương Vũ Trúc', 'Hệ thống thông tin'),
(7520377, 'Nguyễn Xuân Trường', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520378, 'Nguyễn Duy Trường', 'Hệ thống thông tin'),
(7520379, 'Ngô Nhật Trường', 'Khoa học máy tính'),
(7520381, 'Hồ Nhật Trường', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520383, 'Nguyễn Ngọc Tường', 'Hệ thống thông tin'),
(7520385, 'Trịnh Văn Tuân', 'Mạng máy tính & truyền thông'),
(7520386, 'Phạm Trương Hoàng Tuấn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520387, 'Nguyễn Thành Tuấn', 'Mạng máy tính & truyền thông'),
(7520388, 'Võ Hoàng Tuấn', 'Mạng máy tính & truyền thông'),
(7520389, 'Nguyễn Minh Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520390, 'Võ Minh Tuấn', 'Mạng máy tính & truyền thông'),
(7520392, 'Trần Anh Tuấn', 'Công nghệ phần mềm'),
(7520393, 'Nguyễn Văn Tuyển', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520394, 'Cao Viễn Tú', 'Khoa học máy tính'),
(7520395, 'Nguyễn Mạnh Tú', 'Mạng máy tính & truyền thông'),
(7520396, 'Nguyễn Ngọc Sơn Tùng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520397, 'Phạm Thanh Tùng', 'Mạng máy tính & truyền thông'),
(7520398, 'Trương Thanh Tùng', 'Công nghệ phần mềm'),
(7520399, 'Lê Phương Tùng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520400, 'Võ Lê Thanh Tùng', 'Mạng máy tính & truyền thông'),
(7520401, 'Lê Hoàng Tùng', 'Khoa học máy tính'),
(7520402, 'Hoàng Ngọc Tùng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520403, 'Nguyễn Thanh Tùng', 'Khoa học máy tính'),
(7520404, 'Lê Thanh Tùng', 'Công nghệ phần mềm'),
(7520405, 'Lê Xuân Tùng', 'Công nghệ phần mềm'),
(7520406, 'Trần Thanh Tùng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520407, 'Nguyễn Quốc Uy', 'Khoa học máy tính'),
(7520408, 'Lương Chấn Viễn', 'Cử nhân tài năng'),
(7520409, 'Nguyễn Quốc Việt', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520410, 'Nguyễn Như Việt', 'Công nghệ phần mềm'),
(7520411, 'Mai Hoàng Việt', 'Công nghệ phần mềm'),
(7520412, 'Nguyễn Âu Quang Vinh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520413, 'Đặng Thành Vinh', 'Kỹ thuật máy tính'),
(7520415, 'Trần Nguyễn Hoàng Vũ', 'Công nghệ phần mềm'),
(7520417, 'Lê Hoàng Vũ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520419, 'Trần Minh Vũ', 'Kỹ thuật máy tính'),
(7520420, 'Thái Quang Phú', 'Mạng máy tính & truyền thông'),
(7520421, 'Dương Tiến Vương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520422, 'Trần Công Vương', 'Công nghệ phần mềm'),
(7520423, 'Lê Quốc Vương', 'Hệ thống thông tin'),
(7520424, 'Nguyễn Lương Yến Vy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520425, 'Mai Đức An', 'Mạng máy tính & truyền thông'),
(7520427, 'Lâm Tú Bình', 'Hệ thống thông tin'),
(7520428, 'Nguyễn Kim Dung', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520429, 'Trần Hải Đăng', 'Mạng máy tính & truyền thông'),
(7520430, 'Triệu Minh Đức', 'Hệ thống thông tin'),
(7520431, 'Trương Cần Em', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520432, 'Lê Trung Trường Giang', 'Mạng máy tính & truyền thông'),
(7520433, 'Hữu Thiên Hòa', 'Hệ thống thông tin'),
(7520434, 'Nguyễn Bảo Khôi', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520435, 'Trần Trường Kỷ', 'Khoa học máy tính'),
(7520436, 'Tô Thái Nghĩa', 'Mạng máy tính & truyền thông'),
(7520437, 'Nguyễn Hữu Nhật', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520438, 'Nguyễn Trí Phát', 'Kỹ thuật máy tính'),
(7520439, 'Trần Minh Phát', 'Kỹ thuật máy tính'),
(7520440, 'Nguyễn Thanh Phong', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520441, 'Lê Vũ Phương', 'Mạng máy tính & truyền thông'),
(7520442, 'Mai Thế Sơn', 'Công nghệ phần mềm'),
(7520444, 'Lê Võ Hữu Tài', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520445, 'Lê Duy Tân', 'Công nghệ phần mềm'),
(7520448, 'Trần Trung Tính', 'Khoa học máy tính'),
(7520449, 'Trần Bảo Trung', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520450, 'Nguyễn Minh Tuấn', 'Công nghệ phần mềm'),
(7520452, 'Nguyễn Phạm Vi', 'Công nghệ phần mềm'),
(7520453, 'Nguyễn Thị Như Ý', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520454, 'Trần Triệu Hoàng Anh', 'Mạng máy tính & truyền thông'),
(7520455, 'Nguyễn Lê Anh', 'Công nghệ phần mềm'),
(7520456, 'Võ Đình Chinh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520457, 'Trần Trung Chính', 'Kỹ thuật máy tính'),
(7520458, 'Nguyễn Kim Duân', 'Hệ thống thông tin'),
(7520459, 'Trương Duy', 'Công nghệ phần mềm'),
(7520460, 'Lê Hữu Duy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520461, 'Nguyễn Tấn Dũng', 'Công nghệ phần mềm'),
(7520464, 'Phạm Trịnh Đồng', 'Công nghệ phần mềm'),
(7520465, 'Võ Hoàng Hải', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520466, 'Lê Thanh Hải', 'Mạng máy tính & truyền thông'),
(7520467, 'Bùi Tá Hậu', 'Công nghệ phần mềm'),
(7520468, 'Nguyễn Trung Hiếu', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520469, 'Huỳnh Nhi Hiếu', 'Kỹ thuật máy tính'),
(7520470, 'Trần Đức Hitachi', 'Công nghệ phần mềm'),
(7520471, 'Trần Công Hoan', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520472, 'Phạm Nguyên Huy', 'Mạng máy tính & truyền thông'),
(7520473, 'Nguyễn Quốc Hưng', 'Hệ thống thông tin'),
(7520474, 'Lê Việt Khánh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520475, 'Nguyễn Thịnh Khả', 'Công nghệ phần mềm'),
(7520476, 'Lê Huỳnh Khương', 'Mạng máy tính & truyền thông'),
(7520477, 'Phạm Trung Kiên', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520478, 'Tăng Xuân Linh', 'Khoa học máy tính'),
(7520479, 'Nguyễn Mậu Lĩnh', 'Kỹ thuật máy tính'),
(7520480, 'Lê Minh Lộc', 'Hệ thống thông tin'),
(7520481, 'Phạm Duy Lộc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520482, 'Nguyễn Trần Duy Mạnh', 'Công nghệ phần mềm'),
(7520483, 'Huỳnh Trí Minh', 'Công nghệ phần mềm'),
(7520484, 'Võ Văn Mỹ', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520485, 'Đậu Văn Nguyên', 'Kỹ thuật máy tính'),
(7520486, 'Mai Trà Nguyên', 'Khoa học máy tính'),
(7520487, 'Hoàng Công Nguyện', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520488, 'Nguyễn Hữu Nhật', 'Kỹ thuật máy tính'),
(7520489, 'Đoàn Duy Ninh', 'Mạng máy tính & truyền thông'),
(7520490, 'Lê Thanh Quang', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520491, 'Nguyễn Trọng Quốc', 'Chương trình tiên tiến'),
(7520492, 'Trịnh Hoàng Việt Quốc', 'Cử nhân tài năng'),
(7520493, 'Nguyễn Thị Kim Quy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520494, 'Cao Nguyễn Trung Sang', 'Mạng máy tính & truyền thông'),
(7520496, 'Phạm Việt Sơn', 'Công nghệ phần mềm'),
(7520497, 'Bùi Thành Tâm', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520498, 'Trần Thị Thanh Tâm', 'Kỹ thuật máy tính'),
(7520499, 'Lương Vĩnh Thảo', 'Mạng máy tính & truyền thông'),
(7520500, 'Ngô Văn Thi', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520501, 'Nguyễn Khánh Thuật', 'Mạng máy tính & truyền thông'),
(7520502, 'Nguyễn Văn Trường', 'Công nghệ phần mềm'),
(7520503, 'Diệp Anh Tuấn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520504, 'Bùi Nguyễn Diệp Tú', 'Hệ thống thông tin'),
(7520505, 'Huỳnh Tùng', 'Hệ thống thông tin'),
(7520506, 'Phan Quốc Văn', 'Khoa học máy tính'),
(7520507, 'Phạm Ngọc Viên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520508, 'Nguyễn Quốc Việt', 'Mạng máy tính & truyền thông'),
(7520509, 'Nguyễn Hoàng Vũ', 'Cử nhân tài năng'),
(7520510, 'Từ Hồng Vương', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520511, 'Nguyễn Minh Vương', 'Mạng máy tính & truyền thông'),
(7520512, 'Nguyễn Thế Anh', 'Mạng máy tính & truyền thông'),
(7520514, 'Nguyễn Duy Bằng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520515, 'Nguyễn Quốc Bảo', 'Mạng máy tính & truyền thông'),
(7520516, 'Phạm Diễm Ngọc Bích', 'Khoa học máy tính'),
(7520519, 'Nguyễn Quốc Bình', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520520, 'Trần Bá Chỉnh', 'Kỹ thuật máy tính'),
(7520521, 'Hoàng Mạnh Cường', 'Khoa học máy tính'),
(7520522, 'Lê Quý Quốc Cường', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520523, 'Phùng Vũ Cường', 'Khoa học máy tính'),
(7520524, 'Lê Thị Duy Đan', 'Cử nhân tài năng'),
(7520525, 'Dương Trung Đức', 'Hệ thống thông tin'),
(7520526, 'Nguyễn Văn Dũng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520527, 'Thái Hoàng Dũng', 'Hệ thống thông tin'),
(7520528, 'Nguyễn Viết Dương', 'Hệ thống thông tin'),
(7520530, 'Nguyễn Văn Duy', 'Khoa học máy tính'),
(7520531, 'Phạm Ngọc Duy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520532, 'Nguyễn Tuấn Duyệt', 'Kỹ thuật máy tính'),
(7520535, 'Trần Tuyết Hạnh', 'Mạng máy tính & truyền thông'),
(7520537, 'Đặng Đức Hiệp', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520539, 'Nguyễn Đức Hiếu', 'Kỹ thuật máy tính'),
(7520542, 'Lê Xuân Hoàn', 'Khoa học máy tính'),
(7520543, 'Đinh Tiên Hoàng', 'Kỹ thuật máy tính'),
(7520544, 'Trần Đức Hùng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520545, 'Nguyễn Văn Hữu', 'Khoa học máy tính'),
(7520546, 'Nguyễn Quốc Huy', 'Hệ thống thông tin'),
(7520547, 'Phạm Hoàng Huy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520549, 'Trương Quang Huy', 'Mạng máy tính & truyền thông'),
(7520550, 'Mai Tân Thuyên', 'Hệ thống thông tin'),
(7520551, 'Võ Nguyên Khải', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520554, 'Phạm Xuân Linh', 'Kỹ thuật máy tính'),
(7520555, 'Vương Hoàng Linh', 'Mạng máy tính & truyền thông'),
(7520556, 'Huỳnh Minh Lộc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520557, 'Nguyễn Đại Lộc', 'Công nghệ phần mềm'),
(7520558, 'Huỳnh Thanh Long', 'Kỹ thuật máy tính'),
(7520559, 'La Bảo Long', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520562, 'Huỳnh Phạm Tuấn Minh', 'Kỹ thuật máy tính'),
(7520563, 'Trịnh Ngọc Minh', 'Mạng máy tính & truyền thông'),
(7520564, 'Nguyễn Thị Lệ My', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520567, 'Phạm Thị Lan Phương', 'Khoa học máy tính'),
(7520570, 'Phạm Văn Quân', 'Kỹ thuật máy tính'),
(7520572, 'Nguyễn Xuân Quang', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520574, 'Nguyễn Trung Quốc', 'Khoa học máy tính'),
(7520575, 'Đậu Đức Quỳnh', 'Mạng máy tính & truyền thông'),
(7520576, 'Huỳnh Chí Tài', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520577, 'Đào Ngọc Thạch', 'Mạng máy tính & truyền thông'),
(7520579, 'Hoàng Minh Thắng', 'Mạng máy tính & truyền thông'),
(7520584, 'Trần Minh Thành', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520585, 'Nguyễn Minh Thào', 'Khoa học máy tính'),
(7520587, 'Nguyễn Xuân Thảo', 'Mạng máy tính & truyền thông'),
(7520589, 'Nguyễn Viễn Thiên', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520590, 'Uông Thị Thoa', 'Khoa học máy tính'),
(7520593, 'Nguyễn Duy Tiệp', 'Kỹ thuật máy tính'),
(7520594, 'Nguyễn Thị Thu Trang', 'Cử nhân tài năng'),
(7520597, 'Trần Trung', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520599, 'Phạm Sơn Trường', 'Kỹ thuật máy tính'),
(7520600, 'Đặng Anh Tú', 'Hệ thống thông tin'),
(7520602, 'Lê Hoàng Tuấn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520603, 'Trần Phước Việt', 'Công nghệ phần mềm'),
(7520604, 'Kiều Trần Vũ', 'Khoa học máy tính'),
(7520605, 'Lê Diệp Nguyên Vũ', 'Hệ thống thông tin'),
(7520606, 'Lê Văn Vui', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520607, 'Nguyễn Ngọc Vương', 'Khoa học máy tính'),
(7520608, 'Đào Thị Thu Vy', 'Mạng máy tính & truyền thông'),
(7520609, 'Trần Lê Vy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(7520610, 'Võ Thành Xuyên', 'Kỹ thuật máy tính'),
(7520611, 'Huỳnh Thịnh', 'Kỹ thuật máy tính'),
(8040064, 'Nguyễn Trần  Kiển', 'Đào tạo từ xa'),
(8040077, 'Nguyễn Khắc Minh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8100069, 'Hoàng Đức Thiện', 'Đào tạo từ xa'),
(8520001, 'Cao Văn An', 'Công nghệ phần mềm'),
(8520002, 'Trình Thanh An', 'Kỹ thuật máy tính'),
(8520003, 'Nguyễn Thị Diễm An', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520004, 'Lê Đỗ Trường An', 'Công nghệ phần mềm'),
(8520005, 'Nguyễn Tuấn Anh', 'Khoa học máy tính'),
(8520008, 'Trần Thế Anh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520009, 'Lưu Việt Tuấn Anh', 'Hệ thống thông tin'),
(8520010, 'Trần Tuấn Anh', 'Mạng máy tính & truyền thông'),
(8520011, 'Lý Tuấn Anh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520013, 'Dương Trung Việt Anh', 'Mạng máy tính & truyền thông'),
(8520014, 'Trần Nhật Anh', 'Mạng máy tính & truyền thông'),
(8520015, 'Vũ Duy Anh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520016, 'Lê Tuấn Anh', 'Mạng máy tính & truyền thông'),
(8520017, 'Nguyễn Thế Anh', 'Hệ thống thông tin'),
(8520018, 'Nguyễn Duy Anh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520019, 'Nguyễn Lê Vân Ánh', 'Công nghệ phần mềm'),
(8520020, 'Trần Đức Ân', 'Kỹ thuật máy tính'),
(8520021, 'Äáť Tráťng Ăn', 'Khoa háťc mĂĄy tĂ­nh');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520022, 'Hoàng Quốc Bảo', 'Mạng máy tính & truyền thông'),
(8520023, 'Vương Ngọc Bảo', 'Kỹ thuật máy tính'),
(8520024, 'Lê Đình Bảo', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520025, 'Nguyễn Đinh Đình Bảo', 'Công nghệ phần mềm'),
(8520026, 'Hoàng Trọng Quốc Bảo', 'Mạng máy tính & truyền thông'),
(8520027, 'Bùi Văn Bằng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520029, 'Ung Quốc Bình', 'Hệ thống thông tin'),
(8520031, 'Huỳnh Thái Bình', 'Kỹ thuật máy tính'),
(8520032, 'Đặng Tiểu Bình', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520034, 'Lê Chí Cảnh', 'Cử nhân tài năng'),
(8520035, 'Nguyễn Ngọc Cân', 'Kỹ thuật máy tính'),
(8520036, 'Lê Hoàng Chánh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520037, 'Nguyễn Thị Diễm Châu', 'Khoa học máy tính'),
(8520038, 'Lại Ngọc Thái Châu', 'Công nghệ phần mềm'),
(8520039, 'Nguyễn Ngọc Chi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520040, 'Nguyễn Hứu Chiến', 'Công nghệ phần mềm'),
(8520041, 'Phạm Minh Chiến', 'Công nghệ phần mềm'),
(8520042, 'Nguyễn Văn Chí', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520043, 'Mai Hữu Chung', 'Hệ thống thông tin'),
(8520044, 'Võ Văn Chương', 'Công nghệ phần mềm'),
(8520045, 'Nguyễn Hoàng Văn Chương', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520046, 'Trần Quốc Công', 'Công nghệ phần mềm'),
(8520047, 'Trịnh Xuân Công', 'Mạng máy tính & truyền thông'),
(8520048, 'Lê Thế Công', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520049, 'Tạ Hào Cơ', 'Khoa học máy tính'),
(8520050, 'Dương Nguyễn Khánh Cường', 'Hệ thống thông tin'),
(8520051, 'Nguyễn Tuấn Cường', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520052, 'Nguyễn Hùng Cường', 'Mạng máy tính & truyền thông'),
(8520054, 'Đinh Dương Kiên Cường', 'Công nghệ phần mềm'),
(8520055, 'Nguyễn Hồng Danh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520056, 'Nguyễn Ngọc Danh', 'Công nghệ phần mềm'),
(8520057, 'Dương Thân Dân', 'Công nghệ phần mềm'),
(8520058, 'Châu Minh Di', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520059, 'Lưu Văn Diệp', 'Công nghệ phần mềm'),
(8520060, 'Từ Tự Do', 'Công nghệ phần mềm'),
(8520061, 'Hà Phú Doanh', 'Khoa học máy tính'),
(8520062, 'Chung Ngọc Minh Duy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520064, 'Trương Công Duy', 'Mạng máy tính & truyền thông'),
(8520066, 'Phạm Thế Duy', 'Kỹ thuật máy tính'),
(8520068, 'Phan Thế Duy', 'Công nghệ phần mềm'),
(8520070, 'Đoàn Duy', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520071, 'Nguyễn Hồng Duy', 'Mạng máy tính & truyền thông'),
(8520072, 'Phan Hứa Hữu Duy', 'Kỹ thuật máy tính'),
(8520073, 'Đoàn Việt Dũng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520074, 'Đặng Công Dũng', 'Hệ thống thông tin'),
(8520075, 'Hồ Thanh Dũng', 'Khoa học máy tính'),
(8520076, 'Nguyễn Minh Dũng', 'Cử nhân tài năng'),
(8520078, 'Nguyễn Ngọc Đại', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520079, 'Đỗ Quang Đại', 'Hệ thống thông tin'),
(8520081, 'Trà Lê Tiến Đạt', 'Công nghệ phần mềm'),
(8520082, 'Trần Quốc Đạt', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520083, 'Hoàng Kim Đạt', 'Công nghệ phần mềm'),
(8520084, 'Nguyễn Tuấn Đạt', 'Công nghệ phần mềm'),
(8520086, 'Lục Văn Đăng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520087, 'Võ Ngọc Hải Đăng', 'Kỹ thuật máy tính'),
(8520088, 'Vũ Trọng Đắc', 'Mạng máy tính & truyền thông'),
(8520090, 'Huỳnh Công Định', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520091, 'Nguyễn Phượng Đôn', 'Kỹ thuật máy tính'),
(8520092, 'Lê Phước Đông', 'Mạng máy tính & truyền thông'),
(8520094, 'Trần Hữu Đức', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520095, 'Nguyễn Thành Đức', 'Kỹ thuật máy tính'),
(8520096, 'Hồ Quang Đức', 'Mạng máy tính & truyền thông'),
(8520097, 'Đặng Minh Đức', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520098, 'Lê Quang Đức', 'Kỹ thuật máy tính'),
(8520099, 'Nguyáťn HoĂ ng ÄáťŠc', 'CĂ´ng ngháť pháş§n máťm'),
(8520100, 'Nguyễn Chí Duy Đức', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520102, 'Nguyễn Kim Giáp', 'Mạng máy tính & truyền thông'),
(8520103, 'Ninh Viết Hà', 'Khoa học máy tính'),
(8520104, 'Trần Hồng Hà', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520105, 'Hoàng Minh Hải', 'Kỹ thuật máy tính'),
(8520106, 'Nguyễn Văn Hải', 'Mạng máy tính & truyền thông'),
(8520107, 'Nguyễn Thanh Hải', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520108, 'Bùi Huy Hải', 'Mạng máy tính & truyền thông'),
(8520113, 'Bùi Trung Hiếu', 'Công nghệ phần mềm'),
(8520114, 'Huỳnh Trọng Hiếu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520116, 'Phạm Minh Trung Hiếu', 'Công nghệ phần mềm'),
(8520117, 'Tạ Trung Hiển', 'Cử nhân tài năng'),
(8520118, 'Nguyễn Vinh Hiển', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520119, 'Huỳnh Hoàng Hiệp', 'Kỹ thuật máy tính'),
(8520120, 'Phạm Văn Hiệp', 'Kỹ thuật máy tính'),
(8520121, 'Nguyễn Thành Hiệp', 'Hệ thống thông tin'),
(8520122, 'Võ Hòa Hiệp', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520123, 'Nguyễn Hinh', 'Mạng máy tính & truyền thông'),
(8520124, 'Bành Liệt Hành', 'Kỹ thuật máy tính'),
(8520125, 'Tôn Thất Hiền', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520126, 'Nguyễn Văn Hoan', 'Kỹ thuật máy tính'),
(8520127, 'Ngô Đình Thế Hoàn', 'Khoa học máy tính'),
(8520128, 'Nguyễn Hoàn', 'Kỹ thuật máy tính'),
(8520129, 'Trần Xuân Hoàng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520130, 'Nguyễn Minh Hoàng', 'Hệ thống thông tin'),
(8520131, 'Trương Phi Hoàng', 'Công nghệ phần mềm'),
(8520132, 'Nguyễn Minh Hoàng', 'Hệ thống thông tin'),
(8520134, 'Trần Đình Vĩnh Hoàng', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520135, 'Trần Huy Hoàng', 'Hệ thống thông tin'),
(8520136, 'Võ Văn Hòa', 'Cử nhân tài năng'),
(8520137, 'Trịnh Phước Hoàng', 'Kỹ thuật máy tính'),
(8520139, 'Phan Hữu Huy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520140, 'Lê Quang Huy', 'Công nghệ phần mềm'),
(8520141, 'Đặng Văn Huy', 'Công nghệ phần mềm'),
(8520142, 'Ngô Việt Khánh Huy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520143, 'Trịnh Quốc Huy', 'Mạng máy tính & truyền thông'),
(8520144, 'Tạ Hồng Phúc Huy', 'Kỹ thuật máy tính'),
(8520145, 'Trần Quang Huy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520146, 'Phạm Đức Huy', 'Khoa học máy tính'),
(8520147, 'Nguyễn Nguyên Huy', 'Hệ thống thông tin'),
(8520148, 'Nguyễn Công Huy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520150, 'Nguyễn Đăng Hùng', 'Công nghệ phần mềm'),
(8520152, 'Trương Vũ Ngọc Hùng', 'Khoa học máy tính'),
(8520153, 'Tôn Thanh Hùng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520154, 'Hà Thanh Hùng', 'Kỹ thuật máy tính'),
(8520155, 'Võ Tấn Hùng', 'Kỹ thuật máy tính'),
(8520157, 'Nguyễn Đăng Hùng', ''),
(8520158, 'Nguyễn Vũ Hùng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520159, 'Nguyễn Mạnh Hùng', 'Hệ thống thông tin'),
(8520160, 'Đào Lương Hùng', 'Khoa học máy tính'),
(8520161, 'Phan Quốc Hùng', 'Hệ thống thông tin'),
(8520162, 'Cao Gia Hưng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520163, 'Hoàng Thái Hưng', 'Công nghệ phần mềm'),
(8520164, 'Phan Thanh HĆ°ng', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(8520165, 'Hoàng Mạnh Hưng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520166, 'Nguyễn Nghĩa Hưng', 'Công nghệ phần mềm'),
(8520167, 'Lê Thị Hoa Hường', 'Kỹ thuật máy tính'),
(8520168, 'Nguyễn Văn Hữu', 'Công nghệ phần mềm'),
(8520169, 'Nguyễn Quang Kha', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520171, 'Hoàng Nguyên Khang', 'Kỹ thuật máy tính'),
(8520172, 'Nguyễn Huỳnh Trường Khang', 'Khoa học máy tính'),
(8520173, 'Vũ Hoàng Khanh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520174, 'Nguyễn Việt Mai Khanh', 'Hệ thống thông tin'),
(8520175, 'Trần Cảnh Khánh', 'Mạng máy tính & truyền thông'),
(8520176, 'Nguyễn Hồng Nguyên Khoa', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520178, 'Hồ Đăng Khoa', 'Công nghệ phần mềm'),
(8520179, 'Phạm Vũ Đăng Khoa', 'Chương trình tiên tiến'),
(8520180, 'Phạm Anh Khoa', 'Khoa học máy tính'),
(8520181, 'Cù Duy Khoa', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520182, 'Nguyễn Thế Khôi', 'Kỹ thuật máy tính'),
(8520184, 'Nguyễn Trung Kiên', 'Mạng máy tính & truyền thông'),
(8520185, 'Lê Ngọc Cao Kim', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520187, 'Lê Quang Lãm', 'Khoa học máy tính'),
(8520188, 'Huỳnh Thanh Lâm', 'Công nghệ phần mềm'),
(8520189, 'Phạm Phú Lâm', 'Kỹ thuật máy tính'),
(8520191, 'Phạm Văn Lâm', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520193, 'Nguyễn Văn Lâm', 'Hệ thống thông tin'),
(8520194, 'Nguyễn Lâm', 'Mạng máy tính & truyền thông'),
(8520195, 'Huỳnh Hoàng Lâm', 'Công nghệ phần mềm'),
(8520196, 'Lê Văn Lăng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520197, 'Nguyễn Trần Lê', 'Kỹ thuật máy tính'),
(8520198, 'Bùi Thanh Liêm', 'Kỹ thuật máy tính'),
(8520199, 'Trương Quang Liêm', 'Kỹ thuật máy tính'),
(8520200, 'Hồ Duy Nhật Linh', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520201, 'Nguyễn Thế Quang Linh', 'Hệ thống thông tin'),
(8520202, 'Trịnh Anh Linh', 'Công nghệ phần mềm'),
(8520203, 'Trần Hàn Linh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520204, 'Nguyễn Hữu Linh', 'Kỹ thuật máy tính'),
(8520205, 'Nguyễn Hồng Linh', 'Mạng máy tính & truyền thông'),
(8520206, 'Nguyễn Vũ Long', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520208, 'Nguyễn Hoàng Long', 'Công nghệ phần mềm'),
(8520209, 'Phan Bá Long', 'Công nghệ phần mềm'),
(8520210, 'Trịnh Thanh Long', 'Hệ thống thông tin'),
(8520211, 'Nguyễn Văn Long', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520212, 'Nguyễn Hữu Lộc', 'Công nghệ phần mềm'),
(8520213, 'Cao Huỳnh Lộc', 'Công nghệ phần mềm'),
(8520214, 'Nguyễn Phúc Lộc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520215, 'Trần Xuân Lộc', 'Công nghệ phần mềm'),
(8520216, 'Nguyễn Thế Luân', 'Khoa học máy tính'),
(8520217, 'Trần Thành Luân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520218, 'Nguyễn Thành Luân', 'Công nghệ phần mềm'),
(8520219, 'Phan Ngọc Minh Luân', 'Hệ thống thông tin'),
(8520220, 'Hoàng Hải Luân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520221, 'Trần Hoàng Luân', 'Kỹ thuật máy tính'),
(8520224, 'Lê Tấn Luật', 'Công nghệ phần mềm'),
(8520225, 'Nguyễn Văn Lực', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520228, 'Nguyễn Võ Hùng Mạnh', 'Khoa học máy tính'),
(8520229, 'Nguyễn Thế Mẫn', 'Kỹ thuật máy tính'),
(8520230, 'Hồng Quốc Minh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520231, 'Trần Hoàng Minh', 'Công nghệ phần mềm'),
(8520234, 'Phạm Nhật Minh', 'Mạng máy tính & truyền thông'),
(8520235, 'Văn Ngọc Minh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520236, 'Nguyễn Văn Minh', 'Mạng máy tính & truyền thông'),
(8520240, 'Đặng Thành Nam', 'Kỹ thuật máy tính'),
(8520241, 'Hoàng Đình Nam', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520242, 'Nguyễn Hoài Nam', 'Kỹ thuật máy tính'),
(8520244, 'Lê Trần Hoài Nam', 'Kỹ thuật máy tính'),
(8520245, 'Mai Phương Nam', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520247, 'Nguyễn Đặng Thành Nam', 'Công nghệ phần mềm'),
(8520248, 'Lê Bá Nam', 'Hệ thống thông tin'),
(8520253, 'Phạm Trọng Nghĩa', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520254, 'Nguyễn Anh Ngọc', 'Công nghệ phần mềm'),
(8520255, 'Dương Đức Ngọc', 'Kỹ thuật máy tính'),
(8520256, 'Nguyễn Lương Anh Ngọc', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520257, 'Trần Trung Ngôn', 'Kỹ thuật máy tính'),
(8520258, 'Bùi Thành Nguyên', 'Công nghệ phần mềm'),
(8520259, 'Phạm Trung Nguyên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520260, 'Nguyễn Thọ Nguyên', 'Mạng máy tính & truyền thông'),
(8520261, 'Nguyễn Đông Nguyên', 'Mạng máy tính & truyền thông'),
(8520262, 'Dương Hồng Nguyên', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520263, 'Trần Thế Thanh Nhàn', 'Công nghệ phần mềm'),
(8520265, 'Trương Công Nhân', 'Mạng máy tính & truyền thông'),
(8520267, 'Nguyễn Thành Nhân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520269, 'Thái Minh Nhật', 'Kỹ thuật máy tính'),
(8520270, 'Phạm Siêu Nhiên', 'Khoa học máy tính'),
(8520272, 'Võ Thị Bích Nhung', 'Hệ thống thông tin'),
(8520273, 'Hồ Thị Xuân Ni', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520274, 'Lê Xuân Ninh', 'Công nghệ phần mềm'),
(8520275, 'Nguyễn Văn Oanh', 'Kỹ thuật máy tính'),
(8520276, 'Nguyễn Đình Pháp', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520279, 'Lê Ngọc Phi', 'Mạng máy tính & truyền thông'),
(8520280, 'Hoàng Văn Phong', 'Hệ thống thông tin'),
(8520282, 'Nguyễn Vũ Phong', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520283, 'Đặng Thanh Phú', 'Công nghệ phần mềm'),
(8520284, 'Nguyễn Đức Phú', 'Kỹ thuật máy tính'),
(8520285, 'Đoàn Vũ Bình Phú', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520286, 'Nguyễn Đức Phú', 'Công nghệ phần mềm'),
(8520288, 'Ngô Trần Vĩnh Phúc', 'Mạng máy tính & truyền thông'),
(8520289, 'Nguyễn Hữu Phúc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520290, 'Võ Xuân Thiên Phúc', 'Mạng máy tính & truyền thông'),
(8520291, 'Bùi Hạnh Phúc', 'Kỹ thuật máy tính'),
(8520292, 'Phạm Phú Phúc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520293, 'Trương Toàn Phương', 'Mạng máy tính & truyền thông'),
(8520294, 'Lưu Đức Phương', 'Mạng máy tính & truyền thông'),
(8520295, 'Nguyễn Lê Hoài Phương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520296, 'Huỳnh Hữu Phương', 'Hệ thống thông tin'),
(8520297, 'Nguyễn Tam Phương', 'Khoa học máy tính'),
(8520298, 'Nguyễn Bá Phước', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520299, 'Võ Tấn Phước', 'Chương trình tiên tiến'),
(8520301, 'Cao Thị Bích Phượng', 'Kỹ thuật máy tính'),
(8520302, 'Lê Văn Quang', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520303, 'Lương Xuân Quang', 'Kỹ thuật máy tính'),
(8520304, 'Cao Nhật Quang', 'Mạng máy tính & truyền thông'),
(8520305, 'Nguyễn Minh Quang', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520306, 'Lê Anh Quân', 'Kỹ thuật máy tính'),
(8520307, 'Ông Lê Quân', 'Khoa học máy tính'),
(8520308, 'Nguyễn Minh Quân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520310, 'Trần Minh Quân', 'Mạng máy tính & truyền thông'),
(8520311, 'Bùi Minh Sang', 'Kỹ thuật máy tính'),
(8520312, 'Nguyễn Tuấn Sang', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520313, 'Sẳm Mộc Sầu', 'Kỹ thuật máy tính'),
(8520314, 'Nguyễn Duy Sỹ', 'Hệ thống thông tin'),
(8520315, 'Trần Thanh Sơn', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520317, 'Phạm Ngọc Sơn', 'Mạng máy tính & truyền thông'),
(8520318, 'Nguyễn Ngọc Trường Sơn', 'Kỹ thuật máy tính'),
(8520319, 'Phạm Thế Sơn', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520320, 'Nguyễn Hùng Sơn', 'Kỹ thuật máy tính'),
(8520321, 'Trần Ngọc Sự', 'Khoa học máy tính'),
(8520322, 'Nguyễn Nhựt Tài', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520323, 'Ngô Tấn Tài', 'Mạng máy tính & truyền thông'),
(8520325, 'Nguyễn Trương Thành Tâm', 'Hệ thống thông tin'),
(8520326, 'Huỳnh Xuân Tâm', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520327, 'Đặng Hà Tâm', 'Công nghệ phần mềm'),
(8520329, 'Nguyễn Thanh Tâm', 'Hệ thống thông tin'),
(8520330, 'Tống Văn Tân', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520332, 'Phạm Thanh Tân', 'Mạng máy tính & truyền thông'),
(8520333, 'Đoàn Minh Tân', 'Công nghệ phần mềm'),
(8520334, 'Phạm Hồng Tân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520335, 'Nguyễn Minh Tân', 'Công nghệ phần mềm'),
(8520336, 'Phạm Ngọc Tân', 'Khoa học máy tính'),
(8520337, 'Nguyễn Công Tấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520338, 'Nguyễn Chí Thanh', 'Mạng máy tính & truyền thông'),
(8520339, 'Vũ Tiến Thái', 'Hệ thống thông tin'),
(8520340, 'Đặng Quốc Thái', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520341, 'Bùi Đình Phát', 'Khoa học máy tính'),
(8520342, 'Nguyễn Quốc Thái', 'Chương trình tiên tiến'),
(8520343, 'Võ Công Thành', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520344, 'Dương Công Thành', 'Kỹ thuật máy tính'),
(8520345, 'Lê Khánh Thành', 'Kỹ thuật máy tính'),
(8520346, 'Lê Hữu Thành', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520347, 'Nguyễn Thành', 'Mạng máy tính & truyền thông'),
(8520348, 'Lý Đạt Thành', 'Khoa học máy tính'),
(8520349, 'Nguyễn Tất Thành', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520350, 'Chu Văn Thành', 'Công nghệ phần mềm'),
(8520351, 'Trần Hữu Thành', 'Kỹ thuật máy tính'),
(8520352, 'Trần Ngọc Thành', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520353, 'Nguyễn Huỳnh Đại Thành', 'Công nghệ phần mềm'),
(8520354, 'Nguyễn Tiến Thành', 'Mạng máy tính & truyền thông'),
(8520355, 'Võ Đức Thành', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520356, 'Nguyễn Văn Thành', 'Kỹ thuật máy tính'),
(8520357, 'Nguyễn Tấn Thành', 'Mạng máy tính & truyền thông'),
(8520358, 'Đỗ Công Thành', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520359, 'Nguyễn Thành', 'Cử nhân tài năng'),
(8520360, 'Nguyễn Xuân Thảo', 'Công nghệ phần mềm'),
(8520361, 'Mai Thị Bích Thảo', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520363, 'Trần Văn Thắng', 'Mạng máy tính & truyền thông'),
(8520364, 'Võ Quốc Thắng', 'Kỹ thuật máy tính'),
(8520365, 'Lương Văn Thắng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520366, 'Huỳnh Quyết Thắng', 'Mạng máy tính & truyền thông'),
(8520367, 'Trần Tất Thắng', 'Kỹ thuật máy tính'),
(8520368, 'Nguyễn Minh Thắng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520369, 'Hoàng Đức Thắng', 'Kỹ thuật máy tính'),
(8520370, 'Mẫn Văn Thắng', 'Mạng máy tính & truyền thông'),
(8520371, 'Đỗ Quyết Thắng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520372, 'Ngô Xuân Thể', 'Kỹ thuật máy tính'),
(8520373, 'Lê Thị Thu Thi', 'Hệ thống thông tin'),
(8520374, 'Huỳnh Nguyễn Tường Thi', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520375, 'Võ Trường Thi', 'Công nghệ phần mềm'),
(8520376, 'Hoàng Thiện', 'Kỹ thuật máy tính'),
(8520378, 'Nguyễn Tấn Thiện', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520379, 'Trần Ngọc Thiện', 'Công nghệ phần mềm'),
(8520381, 'Lý Văn Thìn', 'Khoa học máy tính'),
(8520382, 'Trầm Phúc Thịnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520383, 'Phan Tiến Thịnh', 'Công nghệ phần mềm'),
(8520384, 'Hồ Quốc Thịnh', 'Cử nhân tài năng'),
(8520385, 'Trần Vũ Đức Thịnh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520386, 'Phạm Minh Thịnh', 'Mạng máy tính & truyền thông'),
(8520387, 'Trịnh Hồng Thịnh', 'Công nghệ phần mềm'),
(8520388, 'Trần Ngọc Thịnh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520389, 'Võ Văn Thọ', 'Kỹ thuật máy tính'),
(8520390, 'Phạm Vũ Thanh Thông', 'Công nghệ phần mềm'),
(8520391, 'Dương Sơn Thông', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520392, 'Phan Văn Thông', 'Hệ thống thông tin'),
(8520393, 'Nguyễn Chí Thống', 'Công nghệ phần mềm'),
(8520394, 'Nguyễn Đình Thuận', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520395, 'Tạ Châu Thuận', 'Kỹ thuật máy tính'),
(8520396, 'Hoàng Sơn Thủy', 'Công nghệ phần mềm'),
(8520397, 'Nguyễn Thị Thương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520398, 'Nguyễn Hoài Thương', 'Cử nhân tài năng'),
(8520399, 'Nguyễn Mạnh Thường', 'Kỹ thuật máy tính'),
(8520400, 'Lê Thị Cẩm Tiên', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520401, 'Phạm Minh Tiến', 'Cử nhân tài năng'),
(8520402, 'Võ Văn Tiến', 'Kỹ thuật máy tính'),
(8520403, 'Thái Duy Tiến', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520404, 'Lê Xuân Tiến', 'Công nghệ phần mềm'),
(8520405, 'Nguyễn Đình Tiến', 'Công nghệ phần mềm'),
(8520406, 'Nguyễn Khắc Tiệp', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520407, 'Nguyễn Hữu Tín', 'Mạng máy tính & truyền thông'),
(8520408, 'Bùi Quang Tín', 'Công nghệ phần mềm'),
(8520410, 'Nguyễn Gia Toàn', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520414, 'Nguyễn Văn Toàn', 'Công nghệ phần mềm'),
(8520415, 'Nguyễn Phương Toàn', 'Công nghệ phần mềm'),
(8520416, 'Nguyễn Công Toàn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520417, 'Hồ Thiện Thanh Toàn', 'Khoa học máy tính'),
(8520418, 'Phạm Công Toại', 'Kỹ thuật máy tính'),
(8520419, 'Lê Ngọc Trai', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520420, 'Nguyễn Quang Duy Trang', 'Kỹ thuật máy tính'),
(8520422, 'Phạm Hải Triều', 'Công nghệ phần mềm'),
(8520423, 'La Đặng Thanh Triều', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520424, 'Ngô Minh Trị', 'Kỹ thuật máy tính'),
(8520425, 'Lương Hoàng Trọng', 'Công nghệ phần mềm'),
(8520426, 'Nguyễn Tấn Trọng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520427, 'Hà Huy Trọng', 'Mạng máy tính & truyền thông'),
(8520428, 'Phan Ngọc Trung', 'Kỹ thuật máy tính'),
(8520429, 'Phạm Minh Trung', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520431, 'Nguyễn Việt Trung', 'Chương trình tiên tiến'),
(8520432, 'Nguyễn Đức Trung', 'Mạng máy tính & truyền thông'),
(8520433, 'Nguyễn Trung', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520434, 'Đào Văn Trung', 'Kỹ thuật máy tính'),
(8520435, 'Nguyễn Thành Trung', 'Mạng máy tính & truyền thông'),
(8520437, 'Bùi Công Tuấn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520438, 'Dương Hoàng Tuấn', 'Kỹ thuật máy tính'),
(8520439, 'Nguyễn Mạnh Tuấn', 'Mạng máy tính & truyền thông'),
(8520441, 'Nguyễn Ngọc Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520442, 'Phù Hoàn Tuấn', 'Khoa học máy tính'),
(8520443, 'Nguyễn Nghĩa Tuấn', 'Mạng máy tính & truyền thông'),
(8520444, 'Nguyễn Minh Tuấn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520447, 'Nguyễn Thanh Tuấn', 'Khoa học máy tính'),
(8520448, 'Nguyễn Lâm Vũ Tuấn', 'Chương trình tiên tiến'),
(8520449, 'Đỗ Quang Tuấn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520451, 'Chạc Hồng Tú', 'Công nghệ phần mềm'),
(8520452, 'Nguyễn Hữu Tú', 'Mạng máy tính & truyền thông'),
(8520453, 'Trần Minh Tú', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520455, 'Trần Thanh Tùng', 'Hệ thống thông tin'),
(8520456, 'Trần Thanh Tùng', 'Công nghệ phần mềm'),
(8520457, 'Nguyễn Thanh Tùng', 'Khoa học máy tính'),
(8520458, 'Mai Lê Thanh Tùng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520459, 'Phan An Tùng', 'Chương trình tiên tiến'),
(8520460, 'Nguyễn Văn Tư', 'Kỹ thuật máy tính'),
(8520461, 'Lý Vĩnh Tường', 'Công nghệ phần mềm'),
(8520462, 'Huỳnh Ngô Văn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520463, 'Ngô Gia Văn', 'Công nghệ phần mềm'),
(8520464, 'Đinh Hoàng Việt', 'Mạng máy tính & truyền thông'),
(8520466, 'Nguyễn Việt', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520467, 'Bạch Sỹ Đức Vinh', 'Hệ thống thông tin'),
(8520468, 'Nguyễn Trung Vinh', 'Hệ thống thông tin'),
(8520470, 'Trương Văn Vĩ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520471, 'Lưu Hoàng Triệu Vĩ', 'Công nghệ phần mềm'),
(8520472, 'Dương Phương Vũ', 'Kỹ thuật máy tính'),
(8520473, 'Phạm Hoàn Vũ', 'Kỹ thuật máy tính'),
(8520475, 'Phạm Hoàng Vũ', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520476, 'Nguyễn An Vũ', 'Công nghệ phần mềm'),
(8520477, 'Đặng Vũ', 'Công nghệ phần mềm'),
(8520478, 'Nguyễn Anh Vũ', 'Hệ thống thông tin'),
(8520479, 'Trần Quang Vũ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520480, 'Lê Trần Thái Vũ', 'Khoa học máy tính'),
(8520481, 'Lê Xuân Vũ', 'Mạng máy tính & truyền thông'),
(8520482, 'Phan Thành Vũ', 'Khoa học máy tính'),
(8520483, 'Lương Thanh Vũ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520484, 'Vũ Minh Vương', 'Kỹ thuật máy tính'),
(8520485, 'Võ Minh Vương', 'Hệ thống thông tin'),
(8520486, 'Cáp Duy Vương', 'Kỹ thuật máy tính'),
(8520488, 'Lê Thị Xuyến', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520489, 'Lương Phạm Thái An', 'Công nghệ phần mềm'),
(8520491, 'Hồ Lê Khả Duy', 'Kỹ thuật máy tính'),
(8520492, 'Quách Hải Đăng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520493, 'Hoàng Ngọc Giao', 'Mạng máy tính & truyền thông'),
(8520494, 'Dương Lê Hoàng', 'Khoa học máy tính'),
(8520495, 'Trần Ngọc Huy', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520496, 'Vũ Quốc Tú Hùng', 'Kỹ thuật máy tính'),
(8520498, 'Lưu Xuân Khoa', 'Mạng máy tính & truyền thông'),
(8520499, 'Chung Văn Kiệt', 'Công nghệ phần mềm'),
(8520500, 'Huỳnh Lâm', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520501, 'Đặng Thị Ngọc Loan', 'Hệ thống thông tin'),
(8520503, 'Sơn Dương Thế Nhựt', 'Khoa học máy tính'),
(8520504, 'Nguyễn Võ An Phú', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520505, 'Phạm Hoàng Phúc', 'Công nghệ phần mềm'),
(8520506, 'Nguyễn Hoàn Song', 'Hệ thống thông tin'),
(8520507, 'Phùng Văn Tài', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520508, 'Nguyễn Quốc Thắng', 'Khoa học máy tính'),
(8520509, 'Nguyễn Hữu Thọ', 'Kỹ thuật máy tính'),
(8520510, 'Trương Vũ Thuật', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520511, 'Trương Thiên Toàn', 'Mạng máy tính & truyền thông'),
(8520513, 'Nguyễn Quốc Trí', 'Công nghệ phần mềm'),
(8520514, 'Lương Anh Tuấn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520515, 'Châu Sơn Tuyển', 'Hệ thống thông tin'),
(8520516, 'Hoàng Vũ Xuyên', 'Kỹ thuật máy tính'),
(8520517, 'Nguyễn Vũ An', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520518, 'Trương Hồng Anh', 'Công nghệ phần mềm'),
(8520519, 'Lê Việt Anh', 'Công nghệ phần mềm'),
(8520520, 'Đỗ Trần Bình', 'Công nghệ phần mềm'),
(8520521, 'Phan Công Cảnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520522, 'Trần Xuân Chiến', 'Công nghệ phần mềm'),
(8520524, 'Võ Văn Chức', 'Công nghệ phần mềm'),
(8520525, 'Nguyễn Chí Công', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520526, 'Lâm Thanh Cường', 'Cử nhân tài năng'),
(8520528, 'Nguyễn Lê Duy', 'Công nghệ phần mềm'),
(8520530, 'Trương Thị Thùy Duyên', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520531, 'Nguyễn Xuân Dương', 'Công nghệ phần mềm'),
(8520532, 'Phan Phước Đại', 'Khoa học máy tính'),
(8520533, 'Lâm Vinh Đạo', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520534, 'Trần Đình Đoàn', 'Công nghệ phần mềm'),
(8520536, 'Phạm Đủ', 'Hệ thống thông tin'),
(8520537, 'Ngô Anh Đức', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520538, 'Trần Văn Giới', 'Mạng máy tính & truyền thông'),
(8520541, 'Nguyễn Bạch Hiền', 'Chương trình tiên tiến'),
(8520542, 'Nguyễn Tấn Huân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520543, 'Trần Đức Huy', 'Mạng máy tính & truyền thông'),
(8520544, 'Bùi Ngọc Huy', 'Công nghệ phần mềm'),
(8520546, 'Trương Viết Hùng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520547, 'Lê Văn Hùng', 'Công nghệ phần mềm'),
(8520548, 'Lê Kim Hùng', 'Mạng máy tính & truyền thông'),
(8520549, 'Nguyễn Anh Hùng', 'Khoa học máy tính'),
(8520551, 'Lê Nguyên Khang', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520552, 'Trần Quang Khánh', 'Mạng máy tính & truyền thông'),
(8520553, 'Đỗ Đức Khải', 'Mạng máy tính & truyền thông'),
(8520554, 'Phan Văn Khiêm', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520555, 'Võ Tấn Khoa', 'Công nghệ phần mềm'),
(8520556, 'Nguyễn Tấn Khôi', 'Cử nhân tài năng'),
(8520557, 'Huỳnh Ngọc Khuê', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520558, 'Trần Minh Kỳ', 'Mạng máy tính & truyền thông'),
(8520559, 'Văn Phước Lâm', 'Công nghệ phần mềm'),
(8520560, 'Võ Thái Liêm', 'Hệ thống thông tin'),
(8520561, 'Võ Duy Linh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520562, 'Vũ Thanh Long', 'Kỹ thuật máy tính'),
(8520563, 'Đào Phi Minh', 'Mạng máy tính & truyền thông'),
(8520564, 'Ngô Văn Minh', 'Kỹ thuật máy tính'),
(8520565, 'Nguyễn Hữu Nghĩa', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520566, 'Huỳnh Công Nghĩa', 'Công nghệ phần mềm'),
(8520567, 'Nguyễn Đức Bình Nguyên', 'Công nghệ phần mềm'),
(8520568, 'Nguyễn Sinh Nguyên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520569, 'Nguyễn Viết Nguyên', 'Công nghệ phần mềm'),
(8520570, 'Nguyễn Hồng Nguyên', 'Kỹ thuật máy tính'),
(8520571, 'Nguyễn Thái Nhân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520572, 'Vũ Thế Nhân', 'Công nghệ phần mềm'),
(8520575, 'Nguyễn Duy Phú', 'Kỹ thuật máy tính'),
(8520576, 'Phạm Văn Qua', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520579, 'Lê Đặng Quang', 'Mạng máy tính & truyền thông'),
(8520580, 'Nguyễn Thành Quân', 'Cử nhân tài năng'),
(8520581, 'Nguyễn Việt Quốc', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520582, 'Nguyễn Hữu Ru', 'Mạng máy tính & truyền thông'),
(8520583, 'Nguyễn Trọng Sang', 'Công nghệ phần mềm'),
(8520584, 'Trần Văn Tuấn Sinh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520585, 'Trần Văn Sĩ', 'Khoa học máy tính'),
(8520587, 'Châu Ngọc Hoàng Tâm', 'Khoa học máy tính'),
(8520588, 'Nguyễn Đức Tâm', 'Khoa học máy tính'),
(8520589, 'Nguyễn Hữu Tâm', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520590, 'Hồ Nhật Tân', ''),
(8520591, 'Trần Minh Thái', 'Hệ thống thông tin'),
(8520593, 'Bành Lê Vũ Thân', 'Công nghệ phần mềm'),
(8520594, 'Trần Ngọc Thắng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520595, 'Lê Minh Thiện', 'Công nghệ phần mềm'),
(8520596, 'Nguyễn Văn Thiệu', 'Mạng máy tính & truyền thông'),
(8520597, 'Võ Qang Thiều', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520598, 'LĂŞ ÄáťŠc ThĂ´ng', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(8520599, 'Lê Văn Thương', 'Mạng máy tính & truyền thông'),
(8520600, 'Nguyễn Ngọc Tiến', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520601, 'Nguyễn Cao Tiến', 'Mạng máy tính & truyền thông'),
(8520602, 'Trần Minh Toàn', 'Công nghệ phần mềm'),
(8520603, 'Huỳnh Dương Trí Toàn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520604, 'Trần Thế Toàn', 'Cử nhân tài năng'),
(8520605, 'Phan Văn Trai', 'Kỹ thuật máy tính'),
(8520606, 'Đỗ Xuân Triều', 'Kỹ thuật máy tính'),
(8520607, 'Võ Anh Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520608, 'Lê Ngọc Tuấn', 'Công nghệ phần mềm'),
(8520609, 'Trần Thị Bích Tuyền', 'Kỹ thuật máy tính'),
(8520610, 'Lâm Văn Tú', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520611, 'Nguyễn Mạnh Tường', 'Công nghệ phần mềm'),
(8520612, 'Nguyễn Lý Tưởng', 'Hệ thống thông tin'),
(8520613, 'Lê Văn', 'Kỹ thuật máy tính'),
(8520614, 'Huỳnh Trúc Viên', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520615, 'Nguyễn Tùng Việt', 'Công nghệ phần mềm'),
(8520616, 'Huỳnh Thanh Việt', 'Kỹ thuật máy tính'),
(8520617, 'Đỗ Trung Vinh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520618, 'Nguyễn Thành Vinh', 'Mạng máy tính & truyền thông'),
(8520619, 'Võ Duy Vinh', 'Chương trình tiên tiến'),
(8520621, 'Võ Duy Vũ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520622, 'Vương Trường Vũ', 'Mạng máy tính & truyền thông'),
(8520623, 'Cáp Văn Vũ', 'Công nghệ phần mềm'),
(8520624, 'Nguyễn Tuấn Vũ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520625, 'Lăng Song Vũ', 'Công nghệ phần mềm'),
(8520626, 'Hà Nguyễn Vĩnh Hoàng', 'Kỹ thuật máy tính'),
(8520629, 'Nguyễn Quang Đại', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520630, 'Trương Trọng Hiếu', 'Hệ thống thông tin'),
(8520631, 'Lê Nguyễn Hào Hiệp', 'Hệ thống thông tin'),
(8520635, 'Lê Trung Thực', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520637, 'Phạm Thị Diễm Mi', 'Hệ thống thông tin'),
(8520638, 'Hoàng Quốc Vượng', 'Hệ thống thông tin'),
(8520642, 'Nguyễn Thị Mỹ Dung', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520646, 'Ngô Văn Điệp', 'Khoa học máy tính'),
(8520648, 'Lê Xuân Hùng', 'Khoa học máy tính'),
(8520649, 'Lý Ngọc Hùng', 'Cử nhân tài năng'),
(8520653, 'Đinh Quang Huy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8520654, 'Nguyễn Phước Lộc', 'Cử nhân tài năng'),
(8520655, 'Trần Văn Thủy', 'Khoa học máy tính'),
(8520656, 'Trầm Ngọc Đăng Khoa', 'Chương trình tiên tiến'),
(8520999, 'Student', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8720001, 'Đoàn Chiều Ân', 'Đào tạo từ xa'),
(8720002, 'Lê Công Bằng', 'Đào tạo từ xa'),
(8720009, 'Nguyễn Thiên Chung', 'Đào tạo từ xa'),
(8720018, 'Dương Văn Duyên', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8720019, 'Nguyễn Trường  Giang', 'Đào tạo từ xa'),
(8720021, 'Phan Thị Hằng', 'Đào tạo từ xa'),
(8720029, 'Nguyễn Cữu Phi Hùng', 'Đào tạo từ xa'),
(8720032, 'Thạch Kha', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8720035, 'Nguyễn Thành Lập', 'Đào tạo từ xa'),
(8720039, 'Đàm Quãng Long', 'Đào tạo từ xa'),
(8720040, 'Trần Thế Lương', 'Đào tạo từ xa'),
(8720044, 'Trịnh Duy Minh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8720045, 'Lương Nguyễn Việt Nam', 'Đào tạo từ xa'),
(8720047, 'Lâm Đại Nghĩa', 'Đào tạo từ xa'),
(8720051, 'Lê Văn Phát', 'Đào tạo từ xa'),
(8720053, 'Huỳnh Thái Phong', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8720054, 'Trần Thái Phong', 'Đào tạo từ xa'),
(8720055, 'Trương Phi Phúc', 'Đào tạo từ xa'),
(8720058, 'Võ Văn Quốc', 'Đào tạo từ xa'),
(8720059, 'Võ Văn Sáng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8720064, 'Phan Minh Thi', 'Đào tạo từ xa'),
(8720066, 'Đào Minh Thôn', 'Đào tạo từ xa'),
(8720071, 'Nguyễn Trung Trực', 'Đào tạo từ xa'),
(8720073, 'Nguyễn Thanh Tùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(8720074, 'Trần Hoàng Tùng', 'Đào tạo từ xa'),
(9020301, 'Nguyễn Bích Hà', 'Đào tạo từ xa'),
(9030004, 'Đặng Việt Anh', 'Đào tạo từ xa'),
(9030005, 'Dương Tuấn Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030007, 'Trần Tuấn Anh', 'Đào tạo từ xa'),
(9030008, 'Phạm Đức Anh', 'Đào tạo từ xa'),
(9030009, 'Nguyễn Thị Ngọc Ánh', 'Đào tạo từ xa'),
(9030010, 'Đồng Trung Bắc', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030014, 'Đinh Văn Cảnh', 'Đào tạo từ xa'),
(9030015, 'Nguyễn Cao Cường', 'Đào tạo từ xa'),
(9030017, 'Nguyễn Tiến Đạt', 'Đào tạo từ xa'),
(9030018, 'Ngô Tiến Đạt', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030019, 'Trần Cơ Đạt', 'Đào tạo từ xa'),
(9030025, 'Nguyễn Văn Dũng', 'Đào tạo từ xa'),
(9030026, 'Bùi Thuỳ Dung', 'Đào tạo từ xa'),
(9030030, 'Phùng Hoàng Giang', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030033, 'Nguyễn Thu Hằng', 'Đào tạo từ xa'),
(9030034, 'Nguyễn Thuý Hằng', 'Đào tạo từ xa'),
(9030037, 'Mông Thanh Hiệp', 'Đào tạo từ xa'),
(9030039, 'Nguyễn Hữu Hiếu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030041, 'Hà Nguyệt Hoa', 'Đào tạo từ xa'),
(9030042, 'Trần Thị Hoa', 'Đào tạo từ xa'),
(9030045, 'Đinh Đức Hoàng', 'Đào tạo từ xa'),
(9030047, 'Trần Huy Hoàng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030048, 'Nguyễn Văn Hoàng', 'Đào tạo từ xa'),
(9030049, 'Nguyễn Văn Huấn', 'Đào tạo từ xa'),
(9030050, 'Nguyễn Hữu Hùng', 'Đào tạo từ xa'),
(9030052, 'Nguyễn Tiến Hùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030056, 'Trương Ngọc Khánh', 'Đào tạo từ xa'),
(9030057, 'Lê Nguyên Khôi', 'Đào tạo từ xa'),
(9030058, 'Phùng Văn Kiên', 'Đào tạo từ xa'),
(9030059, 'Nguyễn Văn Lập', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030060, 'Nguyễn Thị Thuỳ Linh', 'Đào tạo từ xa'),
(9030062, 'Phạm Diệu Linh', 'Đào tạo từ xa'),
(9030064, 'Nguyễn Phúc Lộc', 'Đào tạo từ xa'),
(9030065, 'Nguyễn Đức Lợi', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030067, 'Trần Văn Mạnh', 'Đào tạo từ xa'),
(9030069, 'Nguyễn Đức Mạnh', 'Đào tạo từ xa'),
(9030070, 'Nguyễn Quốc Mạnh', 'Đào tạo từ xa'),
(9030071, 'Nguyễn Tiến Mạnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030073, 'Lê Thị Minh', 'Đào tạo từ xa'),
(9030075, 'Đinh Văn Nam', 'Đào tạo từ xa'),
(9030076, 'Trần Thị Út Ngà', 'Đào tạo từ xa'),
(9030077, 'Nguyễn Thị Ngân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030078, 'Nguyễn Đắc Ngọ', 'Đào tạo từ xa'),
(9030079, 'Đặng Văn Ngọc', 'Đào tạo từ xa'),
(9030082, 'Nguyễn Tuấn Ngọc', 'Đào tạo từ xa'),
(9030085, 'Đào Hồng  Nhung', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030089, 'Mai Minh Quân', 'Đào tạo từ xa'),
(9030090, 'Vũ Mạnh Quân', 'Đào tạo từ xa'),
(9030092, 'Tạ Văn Quang', 'Đào tạo từ xa'),
(9030093, 'Nguyễn Công Quý', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030095, 'Vương Như Quỳnh', 'Đào tạo từ xa'),
(9030097, 'Nguyễn Đình Rồng', 'Đào tạo từ xa'),
(9030099, 'Vũ Hồng Sơn', 'Đào tạo từ xa'),
(9030102, 'Vũ Minh Tạo', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030104, 'Nguyễn Ngọc Thắng', 'Đào tạo từ xa'),
(9030109, 'Đỗ Hùng Thiện', 'Đào tạo từ xa'),
(9030110, 'Lương Sỹ Thiệp', 'Đào tạo từ xa'),
(9030111, 'Nguyễn Văn Thiết', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030114, 'Đặng Thị Bích  Thuỳ', 'Đào tạo từ xa'),
(9030118, 'Nguyễn Thị Thu Trang', 'Đào tạo từ xa'),
(9030124, 'Mai Minh Tuấn', 'Đào tạo từ xa'),
(9030126, 'Lê Minh Tuân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030128, 'Nguyễn Sơn Tùng', 'Đào tạo từ xa'),
(9030129, 'Phạm Thanh Tùng', 'Đào tạo từ xa'),
(9030130, 'Nguyễn Mạnh Tùng', 'Đào tạo từ xa'),
(9030131, 'Phạm Đình Tuyên', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9030132, 'Đinh Bá Ưng', 'Đào tạo từ xa'),
(9030133, 'Nguyễn Tuấn Vũ', 'Đào tạo từ xa'),
(9030134, 'Nguyễn Thị Yến', 'Đào tạo từ xa'),
(9040001, 'Lê Tuấn  Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040002, 'Nguyễn Tuấn  Anh', 'Đào tạo từ xa'),
(9040005, 'Phạm Tiến  Công', 'Đào tạo từ xa'),
(9040006, 'Dương Văn  Điệp', 'Đào tạo từ xa'),
(9040007, 'Lê Quý Điệp', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040008, 'Hoàng Minh  Đông', 'Đào tạo từ xa'),
(9040010, 'Bùi Thành  Dư', 'Đào tạo từ xa'),
(9040011, 'Hoàng Văn  Đức', 'Đào tạo từ xa'),
(9040012, 'Ngô Anh  Đức', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040013, 'Đào Thành  Dũng', 'Đào tạo từ xa'),
(9040015, 'Đoàn Quang  Duy', 'Đào tạo từ xa'),
(9040018, 'Trần Mạnh  Hà', 'Đào tạo từ xa'),
(9040019, 'Lê Văn  Hải', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040020, 'Vũ Tuấn  Hải', 'Đào tạo từ xa'),
(9040022, 'Nguyễn Văn  Hạo', 'Đào tạo từ xa'),
(9040023, 'Hoàng  Hiệp', 'Đào tạo từ xa'),
(9040024, 'Nguyễn Mạnh Hiệp', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040025, 'Ngô Thị  Hoa', 'Đào tạo từ xa'),
(9040027, 'Phạm Văn  Hoan', 'Đào tạo từ xa'),
(9040030, 'Cao Thị  Hường', 'Đào tạo từ xa'),
(9040032, 'Phạm Văn  Khiển', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040034, 'Vũ Trọng  Khương', 'Đào tạo từ xa'),
(9040037, 'Nguyễn Văn  Luân', 'Đào tạo từ xa'),
(9040038, 'Vũ Văn  Lũng', 'Đào tạo từ xa'),
(9040040, 'Lê Văn  Mạnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040042, 'Lê Hải  Nam', 'Đào tạo từ xa'),
(9040043, 'Vũ Thị Thanh Nga', 'Đào tạo từ xa'),
(9040044, 'Ngô Thị Ngọc', 'Đào tạo từ xa'),
(9040045, 'Nguyễn Tiến Nguyên', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040050, 'Nguyễn Nhữ Phương', 'Đào tạo từ xa'),
(9040051, 'Trần Duy Quý', 'Đào tạo từ xa'),
(9040052, 'Nguyễn Đỗ  Quyền', 'Đào tạo từ xa'),
(9040054, 'Hà Xuân  Quỳnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040055, 'Đặng Văn  Sơn', 'Đào tạo từ xa'),
(9040057, 'Nguyễn Văn  Sỹ', 'Đào tạo từ xa'),
(9040058, 'Nguyễn Tất  Thắng', 'Đào tạo từ xa'),
(9040059, 'Nguyễn Thế  Thắng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040061, 'Trần Thị  Thu', 'Đào tạo từ xa'),
(9040062, 'Đinh Văn  Thuận', 'Đào tạo từ xa'),
(9040065, 'Đỗ Thành  Tôn', 'Đào tạo từ xa'),
(9040070, 'Vũ  Hữu  Trường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040073, 'Vũ Văn  Tuấn', 'Đào tạo từ xa'),
(9040074, 'Nguyễn Thanh  Tùng', 'Đào tạo từ xa'),
(9040077, 'Trần Văn Úy', 'Đào tạo từ xa'),
(9040078, 'Đặng Thị  Vân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040079, 'Hà Tuấn  Việt', 'Đào tạo từ xa'),
(9040080, 'Trần Thị Hải  Yến', 'Đào tạo từ xa'),
(9040081, 'Phạm Lê Hưng', 'Đào tạo từ xa'),
(9040082, 'Vũ Tuấn  Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040083, 'Vũ Đức Anh', 'Đào tạo từ xa'),
(9040084, 'Phạm Văn Bình', 'Đào tạo từ xa'),
(9040090, 'Vũ Ngọc  Nam', 'Đào tạo từ xa'),
(9040091, 'Vũ Văn  Quang', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040094, 'Lại Minh Trường', 'Đào tạo từ xa'),
(9040096, 'Trần Mạnh  Tuấn', 'Đào tạo từ xa'),
(9040097, 'Nguyễn Đức  Văn', 'Đào tạo từ xa'),
(9040099, 'Nguyễn Phương Đức', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9040100, 'Nguyễn Đức  Việt', 'Đào tạo từ xa'),
(9040101, 'Hoàng Lâm', 'Đào tạo từ xa'),
(9040102, 'Hoàng Việt Cường', 'Đào tạo từ xa'),
(9040103, 'Nguyễn Quốc Huy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9050001, 'Nguyễn Tuấn Anh', 'Đào tạo từ xa'),
(9050002, 'Nguyễn Công Bằng', 'Đào tạo từ xa'),
(9050005, 'Tưởng Văn Đạt', 'Đào tạo từ xa'),
(9050007, 'Nguyễn Văn Hòa', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9050011, 'Dương Hoàng Long', 'Đào tạo từ xa'),
(9050012, 'Nguyễn Văn Luận', 'Đào tạo từ xa'),
(9050013, 'Trần Thị Ly', 'Đào tạo từ xa'),
(9050017, 'Huỳnh Long Thăng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9050019, 'Đỗ Thị Xuân Thoa', 'Đào tạo từ xa'),
(9050025, 'Voõõ thị Tuyết Trinh', 'Đào tạo từ xa'),
(9050026, 'Nguyễn Thaønh Trung', 'Đào tạo từ xa'),
(9100001, 'Chu Đức An', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9100003, 'Tạ Tuấn Anh', 'Đào tạo từ xa'),
(9100004, 'Trần Việt  Anh', 'Đào tạo từ xa'),
(9100006, 'Phạm Văn  Công', 'Đào tạo từ xa'),
(9100013, 'Đỗ Quang Duy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9100016, 'Nguyễn Văn Giáp', 'Đào tạo từ xa'),
(9100017, 'Vũ Thị Thu Hà', 'Đào tạo từ xa'),
(9100019, 'Phạm Văn Hậu', 'Đào tạo từ xa'),
(9100024, 'Nguyễn Tuấn Hướng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9100026, 'Đinh Quang  Huy', 'Đào tạo từ xa'),
(9100027, 'Phạm Quang Huy', 'Đào tạo từ xa'),
(9100028, 'Lê Thị  Huyên', 'Đào tạo từ xa'),
(9100030, 'Phạm Tùng  Lâm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9100031, 'Hà Thị Lan', 'Đào tạo từ xa'),
(9100033, 'Lê Mai Long', 'Đào tạo từ xa'),
(9100035, 'Đào Đức Nam', 'Đào tạo từ xa'),
(9100038, 'Ngô Văn Sáng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9100042, 'Nguyễn Văn Thiều', 'Đào tạo từ xa'),
(9100043, 'Nguyễn Tiến Thịnh', 'Đào tạo từ xa'),
(9100047, 'Hoàng Thị  Thủy', 'Đào tạo từ xa'),
(9100054, 'Đoàn Công Văn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9100058, 'Nguyễn Quang Vinh', 'Đào tạo từ xa'),
(9100059, 'Nguyễn Hải Vũ', 'Đào tạo từ xa'),
(9120005, 'Nguyeãn Thò Vaân Anh', 'Đào tạo từ xa'),
(9120006, 'Traàn Hoaøng Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120012, 'Trương Văn  Chiểu', 'Đào tạo từ xa'),
(9120013, 'Buøi Vaên Truùc', 'Đào tạo từ xa'),
(9120014, 'Leâ Hoàng  Cöôøng', 'Đào tạo từ xa'),
(9120021, 'Trònh Haûi Ñaêng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120022, 'Voõ Minh Ñaêng', 'Đào tạo từ xa'),
(9120026, 'Quaùch Taán  Ñaït', 'Đào tạo từ xa'),
(9120027, 'Hoà Hoaøng Dieäu', 'Đào tạo từ xa'),
(9120028, 'Nguyeãn Vaên  Ñoä', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120029, 'Nguyeãn Phöông  Ñoâng', 'Đào tạo từ xa'),
(9120030, 'Huyønh Thanh Ñoàng', 'Đào tạo từ xa'),
(9120031, 'Trang Huyønh Du', 'Đào tạo từ xa'),
(9120032, 'Ñoaøn Vaên Döï', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120033, 'Tieát Thanh Ñöùc', 'Đào tạo từ xa'),
(9120035, 'Traàn Vaên  Döông', 'Đào tạo từ xa'),
(9120036, 'Phan Truøng  Dương', 'Đào tạo từ xa'),
(9120037, 'Nguyeãn Minh Döông', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120039, 'Nguyeãn Thaønh  Döông', 'Đào tạo từ xa'),
(9120042, 'Vöông Hoaøng Duy', 'Đào tạo từ xa'),
(9120043, 'Phaïm Leâ Duy', 'Đào tạo từ xa'),
(9120044, 'Döông Tuyeát Duy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120045, 'Toâ Vaên  Giaõ', 'Đào tạo từ xa'),
(9120047, 'Phaïm Hoàng Haûi', 'Đào tạo từ xa'),
(9120048, 'Phan Minh Haûi', 'Đào tạo từ xa'),
(9120049, 'Phaïm Haûi', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120051, 'Ñoaøn Trung  Haäu', 'Đào tạo từ xa'),
(9120052, 'Nguyeãn Thò Hieàn', 'Đào tạo từ xa'),
(9120054, 'Ñoã Coâng  Hoan', 'Đào tạo từ xa'),
(9120058, 'Ñoaøn Vaên Hoaønh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120059, 'Buøi Minh  Hoàng', 'Đào tạo từ xa'),
(9120060, 'Quaùch Thanh Huøng', 'Đào tạo từ xa'),
(9120061, 'Huyønh Leâ  Huøng', 'Đào tạo từ xa'),
(9120064, 'Toáng Xuaân  Höõu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120065, 'Trònh Xuaân Huyeàn', 'Đào tạo từ xa'),
(9120067, 'Traàn Vaên Khaûi', 'Đào tạo từ xa'),
(9120069, 'Ñoã Quoác  Khaùnh', 'Đào tạo từ xa'),
(9120070, 'Traàn Vieät Khaùnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120071, 'Nguyeãn Quoác Khaùnh', 'Đào tạo từ xa'),
(9120072, 'Hoaøng Minh  Khaùnh', 'Đào tạo từ xa'),
(9120073, 'Nguyeãn Ñaêng  Khoa', 'Đào tạo từ xa'),
(9120074, 'Phaïm Trung  Kieân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120077, 'Quaùch Thanh Laâm', 'Đào tạo từ xa'),
(9120078, 'Nguyeãn Vieät Laøo', 'Đào tạo từ xa'),
(9120079, 'Ñoã Vaên  Laäp', 'Đào tạo từ xa'),
(9120080, 'Nguyeãn Thuyø  Linh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120081, 'Ñoã Nhaát  Linh', 'Đào tạo từ xa'),
(9120082, 'Nguyeãn Chí Linh', 'Đào tạo từ xa'),
(9120084, 'Voõ Chuùc  Linh', 'Đào tạo từ xa'),
(9120085, 'Thaùi Caåm  Linh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120087, 'Leâ Phöông Loan', 'Đào tạo từ xa'),
(9120089, 'Mai Vaên  Löûa', 'Đào tạo từ xa'),
(9120090, 'Nguyeãn Minh Luaân', 'Đào tạo từ xa'),
(9120091, 'Voõ Taán  Löïc', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120092, 'Phaïm Thanh Löông', 'Đào tạo từ xa'),
(9120095, 'Ñinh Vaên  Maïnh', 'Đào tạo từ xa'),
(9120096, 'Chaâu Phöôùc  Minh', 'Đào tạo từ xa'),
(9120097, 'Lê Kiều  My', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120098, 'Nguyeãn Vaên  Myõ', 'Đào tạo từ xa'),
(9120099, 'Döông Huyønh Nga', 'Đào tạo từ xa'),
(9120100, 'Leâ Thuyø  Ngaân', 'Đào tạo từ xa'),
(9120102, 'Leâ Thanh Nghò', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120103, 'Nguyeãn Vaên  Nghóa', 'Đào tạo từ xa'),
(9120104, 'Tröông Truùc Ngoan', 'Đào tạo từ xa'),
(9120106, 'Nguyeãn Vaên Ngon', 'Đào tạo từ xa'),
(9120107, 'Nguyeãn Vaên Nguyeân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120109, 'Löông Toaïi Nguyeän', 'Đào tạo từ xa'),
(9120110, 'Nguyeãn Bích  Nhö', 'Đào tạo từ xa'),
(9120113, 'Nguyeãn Hữu Phi', 'Đào tạo từ xa'),
(9120115, 'Trònh Quoác Phong', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120117, 'Nguyeãn Minh Höõu Phuùc', 'Đào tạo từ xa'),
(9120118, 'Nguyeãn Hoaøng Phuïc', 'Đào tạo từ xa'),
(9120120, 'Phaïm Vieät Phöông', 'Đào tạo từ xa'),
(9120121, 'Trònh Haûi Quaân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120122, 'La Minh Quoác', 'Đào tạo từ xa'),
(9120123, 'Phaïm Vaên Quí', 'Đào tạo từ xa'),
(9120129, 'Traàn Baûo Saét', 'Đào tạo từ xa'),
(9120130, 'Nguyeãn Quoác Só', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120131, 'Laâm Tröôøng Sôn', 'Đào tạo từ xa'),
(9120136, 'Nguyeãn Vaên  Teøo', 'Đào tạo từ xa'),
(9120138, 'Nguyeãn Vieät Thaéng', 'Đào tạo từ xa'),
(9120141, 'Nguyeãn Taán  Thaønh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120142, 'Nguyeãn Anh Thi', 'Đào tạo từ xa'),
(9120143, 'Trònh Hoaøng  Thònh', 'Đào tạo từ xa'),
(9120145, 'Traàn Thò Minh Thö', 'Đào tạo từ xa'),
(9120146, 'Voõ Hoaøng Thöông', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120151, 'Hoà Thieän Tính', 'Đào tạo từ xa'),
(9120154, 'Buøi Thò  Trang', 'Đào tạo từ xa'),
(9120160, 'Ñinh Ngoïc  Trieàu', 'Đào tạo từ xa'),
(9120163, 'Buøi Thanh  Trung', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120166, 'Phaïm Tuaân', 'Đào tạo từ xa'),
(9120167, 'Traàn Quoác Tuaán', 'Đào tạo từ xa'),
(9120170, 'Nguyeãn Vaên  Tuyeån', 'Đào tạo từ xa'),
(9120171, 'Nguyeãn Vaên  UÙt', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120172, 'Nguyeãn Thò UÙt', 'Đào tạo từ xa'),
(9120175, 'Phaïm Quoác Vieät', 'Đào tạo từ xa'),
(9120176, 'Nguyeãn Quang Vinh', 'Đào tạo từ xa'),
(9120177, 'Nguyeãn Phi  Vuõ', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9120178, 'Nguyeãn Duy Cöôøng', 'Đào tạo từ xa'),
(9190280, 'Nguyễn Ngọc Lân', 'Đào tạo từ xa'),
(9520001, 'Hồ Trần Bắc An', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520002, 'Phan Tuấn Anh', 'Kỹ thuật máy tính'),
(9520003, 'Nguyễn Đức Anh', 'Mạng máy tính & truyền thông'),
(9520004, 'Nguyễn Đình Anh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520005, 'Phạm Tuấn Anh', 'Công nghệ phần mềm'),
(9520006, 'Nguyễn Thế Anh', 'Khoa học máy tính'),
(9520007, 'Nguyễn Hoàng Anh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520008, 'Nguyễn Hoàng Tuấn Anh', 'Hệ thống thông tin'),
(9520009, 'Đàm Minh Tuấn Anh', 'Công nghệ phần mềm'),
(9520011, 'Lê Huy Ánh', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520013, 'Nguyễn Văn Bình', 'Công nghệ phần mềm'),
(9520014, 'Dương Đức Bình', 'Cử nhân tài năng'),
(9520016, 'Bạch Đình Cao', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520017, 'Lê Trung Chánh', 'Mạng máy tính & truyền thông'),
(9520018, 'Nguyễn Trung Chánh', 'Kỹ thuật máy tính'),
(9520019, 'Nguyễn Đăng Châu', 'Cử nhân tài năng'),
(9520020, 'Đàm Thị Mỹ Châu', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520021, 'Võ Hoàng Chiêu', 'Công nghệ phần mềm'),
(9520022, 'Đinh Văn Chinh', 'Công nghệ phần mềm'),
(9520024, 'Đoàn Minh Chính', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520025, 'Huỳnh Ngọc Chung', 'Kỹ thuật máy tính'),
(9520026, 'Nguyễn Thành Chung', 'Công nghệ phần mềm'),
(9520027, 'Nguyễn Trần Chung', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520029, 'Lê Quang Công', 'Mạng máy tính & truyền thông'),
(9520030, 'Nguyễn Thế Cường', 'Mạng máy tính & truyền thông'),
(9520031, 'Phạm Quốc Cường', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520032, 'Nguyễn Quý Danh', 'Mạng máy tính & truyền thông'),
(9520033, 'Võ Tuấn Danh', 'Khoa học máy tính'),
(9520034, 'Đặng Nguyên Duy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520035, 'Phan Hoàng Duy', 'Công nghệ phần mềm'),
(9520036, 'Phan Duy', 'Kỹ thuật máy tính'),
(9520037, 'Phạm Tuấn Duy', 'Kỹ thuật máy tính'),
(9520038, 'Phan Văn Dũng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520039, 'Đinh Văn Dũng', 'Mạng máy tính & truyền thông'),
(9520040, 'Trần Ngọc Dũng', 'Mạng máy tính & truyền thông'),
(9520041, 'Phạm Bao Hoàng Dũng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520043, 'Nguyễn Trần Anh Dũng', 'Mạng máy tính & truyền thông'),
(9520044, 'Đồng Tiến Dũng', 'Mạng máy tính & truyền thông'),
(9520045, 'Bùi Mạnh Dũng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520046, 'Trần Phi Dũng', 'Chương trình tiên tiến'),
(9520047, 'Phạm Ánh Dương', 'Công nghệ phần mềm'),
(9520048, 'Nguyễn Đại Dương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520049, 'Huỳnh Thái Dương', 'Mạng máy tính & truyền thông'),
(9520050, 'Trịnh Đình Dương', 'Công nghệ phần mềm'),
(9520051, 'Bùi Ngọc Dự', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520052, 'Nguyễn Giang Đảo', 'Khoa học máy tính'),
(9520053, 'Nguyễn Đức Đại', 'Khoa học máy tính'),
(9520054, 'Khương Minh Đại', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520055, 'Nguyễn Văn Đại', 'Mạng máy tính & truyền thông'),
(9520057, 'Lê Phúc Đạt', 'Hệ thống thông tin'),
(9520058, 'Trần Đình Đạt', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520061, 'Lê Tiến Đình', 'Công nghệ phần mềm'),
(9520062, 'Nguyễn Văn Định', 'Công nghệ phần mềm'),
(9520063, 'Nhữ Duy Đoàn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520064, 'Nguyễn Văn Đồng', 'Hệ thống thông tin'),
(9520065, 'Nguyễn Văn Đồng', 'Công nghệ phần mềm'),
(9520066, 'Huỳnh Văn Đức', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520067, 'Trần Trung Đức', 'Công nghệ phần mềm'),
(9520068, 'Trinh Minh Đức', 'Mạng máy tính & truyền thông'),
(9520069, 'Nguyễn Đình Trọng Đức', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520071, 'Nguyễn Kiên Giang', 'Mạng máy tính & truyền thông'),
(9520072, 'Phạm Văn Giáp', 'Công nghệ phần mềm'),
(9520074, 'Hoàng Văn Hà', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520075, 'Cù Phi Quang Hào', 'Mạng máy tính & truyền thông'),
(9520076, 'Nguyễn Thị Hải', 'Mạng máy tính & truyền thông'),
(9520077, 'Trần Trương Long Hải', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520078, 'Đặng Hoàng Hải', 'Công nghệ phần mềm'),
(9520079, 'Nguyễn Lưu Hạnh', 'Mạng máy tính & truyền thông'),
(9520080, 'Phan Đức Hân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520081, 'Phan Thị Ngọc Hân', 'Mạng máy tính & truyền thông'),
(9520082, 'Lê Huỳnh Trung Hậu', 'Công nghệ phần mềm'),
(9520083, 'Trần Thiện Hậu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520084, 'Nguyễn Đình Hiếu', 'Mạng máy tính & truyền thông'),
(9520085, 'Trần Lê Trung Hiếu', 'Công nghệ phần mềm'),
(9520086, 'Lê Văn Hiếu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520087, 'Nguyễn Hồ Vỹ Hiển', 'Mạng máy tính & truyền thông'),
(9520089, 'Lê Văn Hiệp', 'Khoa học máy tính'),
(9520090, 'Phạm Văn Hinh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520091, 'Vương Đức Hiền', 'Cử nhân tài năng'),
(9520092, 'Trần Quang Hòa', 'Chương trình tiên tiến'),
(9520093, 'Võ Trọng Hoài', 'Kỹ thuật máy tính'),
(9520094, 'Bùi Đức Hoàn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520095, 'Huỳnh Vũ Phương Hoàng', 'Mạng máy tính & truyền thông'),
(9520096, 'Nguyễn Huy Hoàng', 'Khoa học máy tính'),
(9520097, 'Diệp Hữu Hoàng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520099, 'Trần Nguyễn Khánh Hoàng', 'Mạng máy tính & truyền thông'),
(9520100, 'Nguyễn Văn Hòa', 'Công nghệ phần mềm'),
(9520101, 'Nguyễn Đức Hòa', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520102, 'LĂŞ VĂľ Thanh Háťng', 'CĂ´ng ngháť pháş§n máťm'),
(9520103, 'Trần Huy Hông', 'Mạng máy tính & truyền thông'),
(9520104, 'Lý Bảo Huy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520105, 'Phan Quốc Huy', 'Công nghệ phần mềm'),
(9520106, 'Phan Thanh Huy', 'CĂ´ng ngháť pháş§n máťm'),
(9520107, 'Nguyễn Tấn Huy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520108, 'Phạm Xuân Huy', 'Công nghệ phần mềm'),
(9520109, 'Nguyễn Hoàng Huy', 'Khoa học máy tính'),
(9520110, 'Phạm Huỳnh Đức Huy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520111, 'Nguyễn Ngọc Huy', 'Khoa học máy tính'),
(9520112, 'Huỳnh Đức Huy', 'Hệ thống thông tin'),
(9520113, 'Dương Quang Huynh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520114, 'Hoàng Anh Hùng', 'Công nghệ phần mềm'),
(9520115, 'Vũ Văn Hùng', 'Kỹ thuật máy tính'),
(9520117, 'Nguyễn Viết Hùng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520118, 'Cao Đại Hoàng Hùng', 'Mạng máy tính & truyền thông'),
(9520119, 'Bùi Thanh Hùng', 'Kỹ thuật máy tính'),
(9520120, 'Mạch Vĩnh Hưng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520121, 'Võ Hồ Tiến Hưng', 'Chương trình tiên tiến'),
(9520122, 'Lê Quốc Hưng', 'Kỹ thuật máy tính'),
(9520123, 'Trần Nguyên Hướng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520124, 'Nguyễn Văn Hưởng', 'Hệ thống thông tin'),
(9520125, 'Đinh Quang Hưởng', 'Kỹ thuật máy tính'),
(9520126, 'Nguyễn Hoàng Kha', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520127, 'Nguyễn Văn Khang', 'Khoa học máy tính'),
(9520128, 'Đinh Thuận Khánh', 'Kỹ thuật máy tính'),
(9520130, 'Võ Đoàn Như Khánh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520131, 'Nguyễn Văn Khánh', 'Hệ thống thông tin'),
(9520132, 'Lê Duy Khánh', 'Hệ thống thông tin'),
(9520133, 'Mai Văn Khải', ''),
(9520134, 'Lê Quang Khải', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520135, 'Trần Đăng Khoa', 'Mạng máy tính & truyền thông'),
(9520136, 'Đoàn Ngọc Đăng Khoa', 'Công nghệ phần mềm'),
(9520137, 'Sầm Viết Anh Khoa', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520140, 'Nguyễn Duy Khương', 'Chương trình tiên tiến'),
(9520141, 'Vũ Trung Kiên', 'Mạng máy tính & truyền thông'),
(9520142, 'Trương Hoàng Kiệt', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520143, 'Đỗ Thị Hương Lan', 'Mạng máy tính & truyền thông'),
(9520144, 'Trần Trương Thanh Lâm', 'Khoa học máy tính'),
(9520145, 'Lê Đình Lâm', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520146, 'Lý Tiểu Lâm', 'Mạng máy tính & truyền thông'),
(9520147, 'Dương Văn Lâm', 'Hệ thống thông tin'),
(9520148, 'Nguyễn Trường Lâm', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520149, 'Nguyễn Phan Tùng Lâm', 'Công nghệ phần mềm'),
(9520150, 'Nguyễn Lập', 'Khoa học máy tính'),
(9520151, 'Trần Huỳnh Bảo Linh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520152, 'Hoàng Văn Linh', 'Công nghệ phần mềm'),
(9520153, 'Nguyễn Hoàng Long', 'Chương trình tiên tiến'),
(9520154, 'Triệu Huy Long', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520155, 'Trần Ngọc Long', 'Khoa học máy tính'),
(9520156, 'Lê Thành Long', 'Chương trình tiên tiến'),
(9520157, 'Nguyễn Vĩnh Lộc', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520158, 'Nguyễn Tấn Lộc', 'Công nghệ phần mềm'),
(9520159, 'Đinh Tất Lợi', 'Mạng máy tính & truyền thông'),
(9520160, 'Trương Vĩnh Lợi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520161, 'Đoàn Thắng Lợi', 'Cử nhân tài năng'),
(9520162, 'Hồ Đức Lợi', 'Công nghệ phần mềm'),
(9520163, 'Nguyễn Thành Luân', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520164, 'Nguyễn Gia Luân', 'Mạng máy tính & truyền thông'),
(9520165, 'Võ Duy Luyện', 'Công nghệ phần mềm'),
(9520166, 'Trần Quốc Lưu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520167, 'Lê Đình Tuấn Lưu', 'Chương trình tiên tiến'),
(9520168, 'Lê Xuân Lực', 'Công nghệ phần mềm'),
(9520169, 'Đinh Ngọc Mạnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520170, 'Nguyễn Mạnh', 'Hệ thống thông tin'),
(9520171, 'Lý Văn Thanh Mẫn', 'Mạng máy tính & truyền thông'),
(9520172, 'Nguyễn Võ Cao Minh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520173, 'Phạm Lê Minh', 'Chương trình tiên tiến'),
(9520174, 'Lương Hữu Minh', 'Công nghệ phần mềm'),
(9520175, 'Nguyễn Quang Minh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520176, 'Đinh Thế Minh', 'Mạng máy tính & truyền thông'),
(9520177, 'Lê Nhựt Minh', 'Công nghệ phần mềm'),
(9520178, 'Hồ Hữu Mỹ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520179, 'Lê Đình Nam', 'Mạng máy tính & truyền thông'),
(9520180, 'Nguyễn Văn Nam', 'Khoa học máy tính'),
(9520183, 'Trần Hoài Nam', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520184, 'Phạm Văn Nghệ', 'Khoa học máy tính'),
(9520185, 'Bùi Trọng Nghĩa', 'Công nghệ phần mềm'),
(9520186, 'Lương Trọng Nghĩa', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520187, 'Vương Trọng Nghĩa', 'Chương trình tiên tiến'),
(9520188, 'Bùi Văn Nghĩa', 'Công nghệ phần mềm'),
(9520189, 'Hoàng Trọng Nghịch', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520190, 'Văn Đức Ngọ', 'Chương trình tiên tiến'),
(9520192, 'Nguyễn Phạm Cao Nguyên', 'Mạng máy tính & truyền thông'),
(9520193, 'Trần Võ Khôi Nguyên', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520194, 'Đinh Lê Cao Nguyên', 'Mạng máy tính & truyền thông'),
(9520195, 'Phạm Đức Nguyên', 'Kỹ thuật máy tính'),
(9520196, 'Thái Nguyễn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520197, 'Huỳnh Phan Nhân', 'Chương trình tiên tiến'),
(9520198, 'Võ Thành Nhân', 'Công nghệ phần mềm'),
(9520199, 'Nguyễn Thị Thu Nhi', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520200, 'Đinh Thành Nhơn', 'Công nghệ phần mềm'),
(9520201, 'Võ Minh Phát', 'Mạng máy tính & truyền thông'),
(9520202, 'Lê Trọng Phát', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520203, 'Nguyễn Văn Phong', 'Mạng máy tính & truyền thông'),
(9520204, 'Nguyễn Hồng Phong', 'Cử nhân tài năng'),
(9520205, 'Võ Thượng Phong', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520206, 'Hồ Thanh Phong', 'Kỹ thuật máy tính'),
(9520207, 'Đặng Văn Phú', 'Mạng máy tính & truyền thông'),
(9520208, 'Thái Hông Phúc', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520209, 'Trần Ngọc Kiến Phúc', 'Mạng máy tính & truyền thông'),
(9520210, 'Võ Văn Phúc', 'Công nghệ phần mềm'),
(9520211, 'Bùi Nguyễn Hồng Phúc', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520213, 'Nguyễn Tấn Phúc', 'Công nghệ phần mềm'),
(9520214, 'Lê Bạch Phục', 'Công nghệ phần mềm'),
(9520215, 'Trần Minh Phụng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520217, 'Đinh Duy Phương', 'Công nghệ phần mềm'),
(9520218, 'Nguyễn Anh Phước', 'Công nghệ phần mềm'),
(9520219, 'Đoàn Bá Phước', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520220, 'Lâm Đại Phước', 'Công nghệ phần mềm'),
(9520221, 'Lê Tự Phứơc', 'Khoa học máy tính'),
(9520223, 'Hồ Nhật Quang', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520225, 'Trần Minh Quang', 'Công nghệ phần mềm'),
(9520226, 'Trần Văn Quang', 'Kỹ thuật máy tính'),
(9520227, 'Phạm Đình Thanh Quang', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520228, 'Đoàn Hữu Quang', 'Kỹ thuật máy tính'),
(9520229, 'Phạm Thanh Hoàng Quân', 'Công nghệ phần mềm'),
(9520230, 'Lê Hồng Quân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520232, 'Hồ Minh Quân', 'Hệ thống thông tin'),
(9520234, 'Phan ThiĂŞn Quáťc', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(9520235, 'Lê Cao Anh Quốc', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520236, 'Bùi Thị Lệ Quyên', 'Mạng máy tính & truyền thông'),
(9520237, 'Nguyễn Bá Quyết', 'Công nghệ phần mềm'),
(9520239, 'Trần Đình Quý', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520240, 'Phạm Phú Quý', 'Mạng máy tính & truyền thông'),
(9520241, 'Đinh Ngọc Quý', 'Khoa học máy tính'),
(9520242, 'Ngô Tấn Quý', 'Kỹ thuật máy tính'),
(9520243, 'Nguyáťn HĂšng QuĂ˝', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520244, 'Hoàng Trọng Quý', 'Công nghệ phần mềm'),
(9520245, 'Hồ Minh Sang', 'Kỹ thuật máy tính'),
(9520246, 'Phạm Giang Sang', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520247, 'Phạm Tiến Sĩ', 'Mạng máy tính & truyền thông'),
(9520248, 'Phạm Công Sơn', 'Công nghệ phần mềm'),
(9520249, 'Hoàng Sơn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520250, 'Phạm Linh Sơn', 'Mạng máy tính & truyền thông'),
(9520251, 'Trần Thanh Sơn', 'Công nghệ phần mềm'),
(9520252, 'Phạm Xuân Sơn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520253, 'Nguyễn Trường Sơn', 'Mạng máy tính & truyền thông'),
(9520254, 'Nguyễn Hồng Sơn', 'Mạng máy tính & truyền thông'),
(9520255, 'Phan Thanh Sương', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520256, 'Hoàng Vinh Sử', 'Kỹ thuật máy tính'),
(9520257, 'Đinh Tiến Sỹ', 'Công nghệ phần mềm'),
(9520258, 'Nguyễn Phát Tài', 'Công nghệ phần mềm'),
(9520259, 'Trần Trung Tâm', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520260, 'Trịnh Hữu Tâm', 'Khoa học máy tính'),
(9520261, 'Nguyễn Minh Tâm', 'Công nghệ phần mềm'),
(9520262, 'Lê Văn Tân', 'Công nghệ phần mềm'),
(9520263, 'Trần Đình Tân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520264, 'Lê Anh Tân', 'Khoa học máy tính'),
(9520265, 'Trương Minh Tân', 'Công nghệ phần mềm'),
(9520266, 'Trần Huỳnh Minh Tân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520268, 'Phạm Hoàng Nhật Thanh', 'Công nghệ phần mềm'),
(9520269, 'Phan Văn Thái', 'Khoa học máy tính'),
(9520270, 'Nguyễn Trung Thái', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520271, 'Nguyễn Văn Thái', 'Mạng máy tính & truyền thông'),
(9520272, 'Ngô Phan Tuấn Thành', 'Công nghệ phần mềm'),
(9520273, 'Vũ Văn Thành', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520274, 'Phạm Văn Thành', 'Công nghệ phần mềm'),
(9520275, 'Hồ Công Thành', 'Khoa học máy tính'),
(9520276, 'Trần Ngô Hoàng Thành', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520277, 'Nguyễn Long Thành', 'Kỹ thuật máy tính'),
(9520278, 'Nguyễn Đình Thảo', 'Chương trình tiên tiến'),
(9520279, 'Đặng Ngọc Thạch', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520280, 'Trần Minh Thắng', 'Công nghệ phần mềm'),
(9520281, 'Kiều Thắng', 'Khoa học máy tính'),
(9520282, 'Phan Anh Thắng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520283, 'Nguyễn Chiến Thắng', 'Công nghệ phần mềm'),
(9520284, 'Lê Minh Thiện', 'Công nghệ phần mềm'),
(9520285, 'Nguyễn Quốc Thịnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520286, 'Trần Văn Thịnh', 'Công nghệ phần mềm'),
(9520288, 'Lê Phạm Minh Thông', 'Công nghệ phần mềm'),
(9520289, 'Phạm Duy Thông', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520290, 'Phạm Xuân Thông', 'Khoa học máy tính'),
(9520292, 'Nguyễn Hữu Thuần', 'Mạng máy tính & truyền thông'),
(9520293, 'Phạm Bá Thuận', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520294, 'Nguyễn Ngọc Thuận', 'Kỹ thuật máy tính'),
(9520295, 'Huỳnh Minh Thuận', 'Công nghệ phần mềm'),
(9520296, 'Lê Thị Ngọc Thúy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520297, 'Doãn Thị Phương Thúy', 'Công nghệ phần mềm'),
(9520298, 'Phan Sinh Thưởng', 'Mạng máy tính & truyền thông'),
(9520299, 'Huỳnh Thị Thủy Tiên', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520300, 'Trần Khắc Tiến', 'Công nghệ phần mềm'),
(9520301, 'Nguyễn Ngọc Tiến', 'Cử nhân tài năng'),
(9520302, 'Lao Công Tiến', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520303, 'Nguyễn Anh Tiến', 'Khoa học máy tính'),
(9520304, 'Lữ Phước Tiền', 'Mạng máy tính & truyền thông'),
(9520305, 'Lê Văn Trung Tín', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520306, 'Lê Chánh Tín', 'Công nghệ phần mềm'),
(9520307, 'Bùi Trọng Tín', 'Công nghệ phần mềm'),
(9520308, 'Phạm Văn Tình', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520310, 'Đỗ Văn Toán', 'Mạng máy tính & truyền thông'),
(9520311, 'Diệp Quốc Toàn', 'Khoa học máy tính'),
(9520312, 'Nguyễn Xuân Toàn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520313, 'Trịnh Tiến Toàn', 'Kỹ thuật máy tính'),
(9520314, 'Hoàng Huy Toản', 'Hệ thống thông tin'),
(9520315, 'Phạm Đức Đoàn Trang', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520316, 'Nguyễn Xuân Triễn', 'Kỹ thuật máy tính'),
(9520318, 'Nguyễn Minh Trí', 'Công nghệ phần mềm'),
(9520319, 'Võ Minh Trí', ''),
(9520320, 'Trương Mai Thanh Trí', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520321, 'Phan Hoài Minh Trí', 'Mạng máy tính & truyền thông'),
(9520322, 'Trần Quốc Trung', 'Kỹ thuật máy tính'),
(9520323, 'Nguyễn Khắc Trung', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520324, 'Lê Thành Trung', 'Mạng máy tính & truyền thông'),
(9520325, 'Nguyễn Đan Trường', 'Công nghệ phần mềm'),
(9520326, 'Trịnh Hồng Trường', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520328, 'Phạm Công Trứ', 'Kỹ thuật máy tính'),
(9520329, 'Nguyễn Trọng Tuân', 'Mạng máy tính & truyền thông'),
(9520330, 'Lê Hoàng Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520331, 'Nguyễn Anh Tuấn', 'Hệ thống thông tin'),
(9520332, 'Đặng Anh Tuấn', 'Mạng máy tính & truyền thông'),
(9520333, 'Vũ Minh Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520334, 'Nguyễn Quốc Tuấn', 'Công nghệ phần mềm'),
(9520335, 'Hà Văn Tuyên', 'Công nghệ phần mềm'),
(9520336, 'Lê Thanh Tú', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520337, 'Nguyễn Ngọc Tú', 'Khoa học máy tính'),
(9520338, 'Hoàng Anh Tú', 'Mạng máy tính & truyền thông'),
(9520339, 'Trần Ngọc Tùng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520340, 'Nguyễn Duy Tùng', 'Mạng máy tính & truyền thông'),
(9520341, 'Nguyễn Ngọc Nguyên Tùng', 'Kỹ thuật máy tính'),
(9520342, 'Hoàng Mạnh Tùng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520343, 'Bùi Văn Tùng', 'Kỹ thuật máy tính'),
(9520344, 'Nguyễn Trúc Tùng', 'Mạng máy tính & truyền thông'),
(9520345, 'Nguyễn Thanh Tùng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520346, 'Lê Văn Tùng', 'Hệ thống thông tin'),
(9520347, 'Đồng Nam Tước', 'Kỹ thuật máy tính'),
(9520348, 'Lê Trọng Tường', 'Công nghệ phần mềm'),
(9520349, 'Nguyễn Xuân Tự', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520350, 'Võ Thanh Văn', 'Mạng máy tính & truyền thông'),
(9520351, 'Nguyễn Đức Viển', 'Công nghệ phần mềm'),
(9520352, 'Nguyễn Tuấn Việt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520353, 'Hoàng Việt', 'Mạng máy tính & truyền thông'),
(9520354, 'Nguyễn Văn Vinh', 'Công nghệ phần mềm'),
(9520355, 'Trương Xuân Vinh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520356, 'Lâm Xuân Vinh', 'Mạng máy tính & truyền thông'),
(9520358, 'Nguyễn Anh Vũ', 'Mạng máy tính & truyền thông'),
(9520359, 'Nguyễn Hoàng Vũ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520360, 'Nguyễn Tấn Vũ', 'Mạng máy tính & truyền thông'),
(9520361, 'Âu Tuấn Vũ', 'Kỹ thuật máy tính'),
(9520362, 'Nguyễn Quốc Vương', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520363, 'Nguyễn Viết Cương', 'Công nghệ phần mềm'),
(9520364, 'Nguyễn Minh Vượng', 'Công nghệ phần mềm'),
(9520366, 'Nguyễn Quốc Cường', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520367, 'Huỳnh Minh Đức', 'Chương trình tiên tiến'),
(9520368, 'Lâm Trung Hậu', 'Kỹ thuật máy tính'),
(9520370, 'Trần Xuân Hoàng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520371, 'Lương Phạm Thái Huy', 'Mạng máy tính & truyền thông'),
(9520373, 'Mai Trọng Khang', 'Cử nhân tài năng'),
(9520374, 'Huỳnh Đặng Duy Linh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520375, 'Châu Bình Nguyên', 'Công nghệ phần mềm'),
(9520376, 'Trần Chí Nguyện', 'Mạng máy tính & truyền thông'),
(9520377, 'Lê Hoàng Phi', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520378, 'Lê Hoàng Phúc', 'Công nghệ phần mềm'),
(9520379, 'Đào Anh Phụng', 'Mạng máy tính & truyền thông'),
(9520380, 'Nguyễn Tấn Phương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520381, 'Thạch Si Pô', 'Công nghệ phần mềm'),
(9520382, 'Huỳnh Phúc Trường Sơn', 'Mạng máy tính & truyền thông'),
(9520383, 'Phan Tấn Tài', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520384, 'Trần Văn Thanh', 'Hệ thống thông tin'),
(9520385, 'Lê Quang Thái', 'Công nghệ phần mềm'),
(9520386, 'Lê Thắng', 'Mạng máy tính & truyền thông'),
(9520387, 'Tạ Thu Thủy', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520388, 'Phạm Trung Tín', 'Cử nhân tài năng'),
(9520389, 'Nguyễn Minh Trí', 'Kỹ thuật máy tính'),
(9520390, 'Trần Đức Trung', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520392, 'Hứa Phước Trường', 'Công nghệ phần mềm'),
(9520393, 'Huỳnh Anh Tuấn', 'Công nghệ phần mềm'),
(9520394, 'Phan Văn Tùng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520395, 'Hà Phạm Quang Vũ', 'Mạng máy tính & truyền thông'),
(9520396, 'Võ Tiến An', 'Công nghệ phần mềm'),
(9520397, 'Huỳnh Thế An', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520399, 'Nguyễn Anh Chuẩn', 'Kỹ thuật máy tính'),
(9520401, 'Đào Xuân Dạng', ''),
(9520402, 'Nguyễn Toàn Định', 'Công nghệ phần mềm'),
(9520403, 'Châu Minh Giảng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520404, 'Nguyễn Thanh Hàng', 'Mạng máy tính & truyền thông'),
(9520405, 'Nguyễn Quang Hải', 'Công nghệ phần mềm'),
(9520406, 'Trương Công Hậu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520407, 'Trần Công Hậu', 'Công nghệ phần mềm'),
(9520408, 'Huỳnh Tấn Hiếu', 'Công nghệ phần mềm'),
(9520409, 'Văn Phú Hiếu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520410, 'Nguyễn Hoàng Hiệp', 'Kỹ thuật máy tính'),
(9520411, 'Vũ Quốc Hoàng', 'Mạng máy tính & truyền thông'),
(9520412, 'Phạm Nguyễn Vương Hoàng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520413, 'Võ Văn Kết', 'Mạng máy tính & truyền thông'),
(9520414, 'Ngô Duy Khánh', 'Mạng máy tính & truyền thông'),
(9520415, 'Trần Thiện Khiêm', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520416, 'Lưu Anh Kiệt', 'Mạng máy tính & truyền thông'),
(9520417, 'Nguyễn Thị Thiên Kiều', 'Hệ thống thông tin'),
(9520418, 'Võ Thanh Lâm', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520419, 'Nguyễn Hữu Lập', 'Hệ thống thông tin'),
(9520420, 'Tô Thành Luân', 'Hệ thống thông tin'),
(9520421, 'Ngô Thành Luân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520422, 'Phạm Xuân Mạnh', 'Mạng máy tính & truyền thông'),
(9520423, 'Lưu Thanh Minh', 'Công nghệ phần mềm'),
(9520424, 'Nguyễn Thanh Minh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520427, 'Võ Văn Phúc', 'Công nghệ phần mềm'),
(9520429, 'Nguyễn Xuân Quang', 'Mạng máy tính & truyền thông'),
(9520431, 'Nguyễn Như Quỳnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520432, 'Phạm Ngọc Thái Sơn', 'Công nghệ phần mềm'),
(9520433, 'Bùi Minh Sử', 'Kỹ thuật máy tính'),
(9520434, 'Phạm Minh Tâm', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520435, 'Kiều Quốc Thắng', 'Công nghệ phần mềm'),
(9520436, 'Phan Cao Thanh Thiện', 'Mạng máy tính & truyền thông'),
(9520438, 'Bùi Xuân Thức', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520439, 'Lê Đức Tiên', 'Công nghệ phần mềm'),
(9520440, 'Nguyễn Văn Tiến', 'Cử nhân tài năng'),
(9520441, 'Nguyễn Ngọc Tiến', 'Công nghệ phần mềm'),
(9520442, 'Lý Thủy Tiền', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520443, 'Hồ Quang Tín', 'Công nghệ phần mềm'),
(9520444, 'Nguyễn Văn Toàn', 'Công nghệ phần mềm'),
(9520445, 'Nguyên Hữu Toàn', 'Công nghệ phần mềm'),
(9520446, 'Lê Triều', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520447, 'Võ Minh Trí', 'Công nghệ phần mềm'),
(9520448, 'Hùynh Đức Trí', 'Công nghệ phần mềm'),
(9520449, 'Nguyễn Đình Trí', 'Hệ thống thông tin'),
(9520450, 'Trần Anh Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520451, 'Trần Quốc Tuấn', 'Cử nhân tài năng'),
(9520452, 'Ngô Văn Vàng', 'Công nghệ phần mềm'),
(9520453, 'Nguyễn Ngọc Việt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520454, 'Nguyễn Anh Vũ', 'Mạng máy tính & truyền thông'),
(9520455, 'Đỗ Văn Vương', 'Khoa học máy tính'),
(9520457, 'Đặng Dậu Thanh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520458, 'Phùng Thị Thúy An', 'Khoa học máy tính'),
(9520459, 'Tạ Chiêu An', 'Mạng máy tính & truyền thông'),
(9520460, 'Trương Hoàng An', ''),
(9520462, 'Nguyễn Tuấn Anh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520463, 'Nguyễn Văn Anh', 'Hệ thống thông tin'),
(9520464, 'Bùi Hữu Ba', 'Hệ thống thông tin'),
(9520465, 'Trần Thiên Bảo', 'Hệ thống thông tin'),
(9520466, 'Trần Văn Bảo', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520467, 'Võ Ngọc Duy Bảo', 'Hệ thống thông tin'),
(9520468, 'Nguyễn Xuân Bách', 'Hệ thống thông tin'),
(9520469, 'Đỗ Ngọc Biển', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520470, 'Nguyễn Văn Binh', 'Mạng máy tính & truyền thông'),
(9520471, 'Nguyễn Xuân Bình', 'Hệ thống thông tin'),
(9520472, 'Võ Ngô Bình', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520473, 'Lê Minh Cảnh', 'Hệ thống thông tin'),
(9520474, 'Lê Trung Chánh', 'Hệ thống thông tin'),
(9520475, 'Tăng Văn Chuẩn', 'Cử nhân tài năng'),
(9520476, 'Bùi Võ Quang Công', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520478, 'Huỳnh Công Danh', 'Hệ thống thông tin'),
(9520480, 'Trương Thanh Danh', 'Hệ thống thông tin'),
(9520481, 'Nguyễn Dương Ái Diệu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520482, 'Thới Ngọc Quốc Duẫn', 'Hệ thống thông tin'),
(9520483, 'Phan Thị Phương Dung', 'Hệ thống thông tin'),
(9520484, 'Nguyễn Văn Duyệt', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520485, 'Nguyễn Ngọc Dương', 'Hệ thống thông tin'),
(9520487, 'Trần Đại Dương', 'Khoa học máy tính'),
(9520488, 'Trần Văn Dương', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520489, 'Vũ Hải Dương', 'Hệ thống thông tin'),
(9520490, 'Lê Thanh Dũng', 'Chương trình tiên tiến'),
(9520491, 'Nguyễn Hoàng Dũng', 'Hệ thống thông tin'),
(9520492, 'Phan Anh Dũng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520493, 'Thái Quốc Dũng', 'Khoa học máy tính'),
(9520494, 'Trần Nguyên Dy', 'Hệ thống thông tin'),
(9520496, 'Lâm Vạn Đại', 'Hệ thống thông tin'),
(9520497, 'Hoàng Tất Đạt', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520498, 'Ngô Phát Đạt', 'Hệ thống thông tin'),
(9520499, 'Trần Hồng Đạt', 'Khoa học máy tính'),
(9520500, 'Nguyễn Văn Điệp', 'Cử nhân tài năng'),
(9520501, 'Nguyễn Anh Đức', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520502, 'Nguyễn Minh Đức', 'Mạng máy tính & truyền thông'),
(9520503, 'Lê Thanh Hà', 'Cử nhân tài năng'),
(9520504, 'Phạm Việt Hà', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520505, 'Đỗ Thanh Hải', 'Hệ thống thông tin'),
(9520506, 'Lâm Duy Hải', 'Kỹ thuật máy tính'),
(9520507, 'Lê Ngọc Hải', 'Kỹ thuật máy tính'),
(9520508, 'Nguyễn Thị Mỹ Hải', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520509, 'Nguyễn Văn Hải', 'Khoa học máy tính'),
(9520510, 'Trịnh Thế Hải', 'Khoa học máy tính'),
(9520511, 'Nguyễn Hữu Công Hạnh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520513, 'Đặng Minh Hiền', 'Mạng máy tính & truyền thông'),
(9520514, 'Nguyễn Thị Hiền', 'Hệ thống thông tin'),
(9520515, 'Nguyễn Thị Hiền', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520516, 'Lê Văn Hiếu', 'Hệ thống thông tin'),
(9520518, 'Nguyễn Trí Hiếu', 'Hệ thống thông tin'),
(9520521, 'Huỳnh Thái Hoàng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520522, 'Nguyễn Ngọc Hoàng', 'Mạng máy tính & truyền thông'),
(9520523, 'Võ Thị Ngọc Hoà', 'Hệ thống thông tin'),
(9520524, 'Dương Đình Hóa', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520526, 'Nguyễn Văn Huân', 'Kỹ thuật máy tính'),
(9520527, 'Phùng Huấn', 'Kỹ thuật máy tính'),
(9520528, 'Nguyễn Tấn Huy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520529, 'Nguyễn Thị Lệ Huyền', 'Hệ thống thông tin'),
(9520530, 'Nguyễn Hoàng Huynh', 'Kỹ thuật máy tính'),
(9520532, 'Nguyễn Phúc Hưng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520533, 'Nguyễn Văn Hưng', 'Khoa học máy tính'),
(9520534, 'Lê Duy Hùng', 'Khoa học máy tính'),
(9520535, 'Nguyễn Mạnh Hùng', 'Khoa học máy tính'),
(9520536, 'Nguyễn Sỹ Hùng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520537, 'Đinh Trọng Kết', 'Kỹ thuật máy tính'),
(9520538, 'Phạm Mạnh Khang', 'Kỹ thuật máy tính'),
(9520539, 'Nguyễn Đăng Khoa', 'Khoa học máy tính'),
(9520540, 'Nguyễn Đăng Khoa', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520541, 'Nguyễn Kiều Khoa', 'Mạng máy tính & truyền thông'),
(9520543, 'Đỗ Trung Kiên', 'Hệ thống thông tin'),
(9520545, 'Nguyễn Văn Kiệt', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520546, 'Phan Tuấn Kiệt', 'Khoa học máy tính'),
(9520547, 'Phạm Văn Lâm', 'Kỹ thuật máy tính'),
(9520548, 'Lê Quang Bảo Lân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520549, 'Võ Thanh Liêm', 'Mạng máy tính & truyền thông'),
(9520550, 'Đỗ Khương Nhật Linh', 'Hệ thống thông tin'),
(9520551, 'Nguyễn Văn Linh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520552, 'Nguyễn Thị Kiều Loan', 'Khoa học máy tính'),
(9520553, 'Vương Kim Loan', 'Hệ thống thông tin'),
(9520554, 'Lê Thăng Long', 'Kỹ thuật máy tính'),
(9520555, 'Phạm Hoàng Long', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520556, 'Trần Hữu Lộc', 'Khoa học máy tính'),
(9520557, 'Nguyễn Hữu Lợi', 'Khoa học máy tính'),
(9520558, 'Nguyễn Thành Luân', 'Hệ thống thông tin'),
(9520561, 'Lê Quang Lực', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520562, 'Nguyễn Đình Mạnh', 'Hệ thống thông tin'),
(9520563, 'Nguyễn Thị Mến', 'Hệ thống thông tin'),
(9520564, 'Dương Ngọc Minh', 'Kỹ thuật máy tính'),
(9520565, 'Lê Nhật Minh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520567, 'Trần Châu Toàn Mỹ', 'Khoa học máy tính'),
(9520568, 'Nguyễn Đàm Duy Nam', 'Kỹ thuật máy tính'),
(9520569, 'Nguyễn Hải Nam', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520570, 'Đỗ Thị Nga', 'Hệ thống thông tin'),
(9520572, 'Nguyễn Diệu Nga', 'Hệ thống thông tin'),
(9520573, 'Lê Đình Ngân', 'Kỹ thuật máy tính'),
(9520574, 'Mai Trọng Ngân', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520575, 'Nguyễn Hoàng Ngân', 'Cử nhân tài năng'),
(9520576, 'Nguyễn Hữu Ngân', 'Kỹ thuật máy tính'),
(9520577, 'Phạm Hồng Ngân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520580, 'Nguyễn Hữu Nghĩa', 'Kỹ thuật máy tính'),
(9520581, 'Nguyễn Sinh Ngọc', 'Kỹ thuật máy tính'),
(9520582, 'Nguyễn Thị Minh Ngọc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520583, 'Lê Nhật Nguyên', 'Cử nhân tài năng'),
(9520584, 'Nguyễn Hữu Hoàng Nguyên', 'Kỹ thuật máy tính'),
(9520585, 'Nguyễn Trần Minh Nguyên', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520588, 'Trần Châu Thành Nhân', 'Hệ thống thông tin'),
(9520589, 'Hoàng Tứ Nhã', 'Kỹ thuật máy tính'),
(9520590, 'Nguyễn Hoàng Nhã', 'Hệ thống thông tin'),
(9520592, 'Lê Huy Nhuận', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520593, 'Phạm Văn Nhuận', 'Kỹ thuật máy tính'),
(9520594, 'Bùi Minh Nhựt', 'Khoa học máy tính'),
(9520595, 'Phạm Minh Nhựt', 'Khoa học máy tính'),
(9520596, 'Cao Thị Niệm', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520597, 'Trần Ngọc Linh', 'Mạng máy tính & truyền thông'),
(9520599, 'Nguyễn Thị Nương', 'Hệ thống thông tin'),
(9520600, 'Hoàng Thị Kim Oanh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520601, 'Bùi Tấn Phát', 'Cử nhân tài năng'),
(9520602, 'Nguyễn Tấn Phát', 'Hệ thống thông tin'),
(9520603, 'Nguyễn Tấn Phong', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520604, 'Nguyễn Trần Tuấn Phong', 'Hệ thống thông tin'),
(9520605, 'Phạm Thanh Phong', 'Hệ thống thông tin'),
(9520606, 'Đỗ Thị Linh Phương', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520607, 'Nguyễn Dũng Phương', 'Cử nhân tài năng'),
(9520609, 'Liên Hữu Phước', 'Kỹ thuật máy tính'),
(9520610, 'Ngô Phi Phú', 'Hệ thống thông tin'),
(9520611, 'Nguyễn Ngọc Phú', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520612, 'Phạm Phú', 'Hệ thống thông tin'),
(9520613, 'Tạ Tấn Phú', 'Khoa học máy tính'),
(9520614, 'Nguyễn Thành Phúc', 'Khoa học máy tính'),
(9520615, 'Lư Thế Phục', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520616, 'Hồ Xuân Quang', 'Kỹ thuật máy tính'),
(9520617, 'Ngô Đình Quang', 'Hệ thống thông tin'),
(9520618, 'Ngô Tự Đăng Quang', ''),
(9520621, 'Nguyễn Quốc Quân', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520622, 'Nguyễn Viết Quân', 'Chương trình tiên tiến'),
(9520623, 'Đặng Thanh Qui', 'Hệ thống thông tin'),
(9520624, 'Phan Duy Quí', 'Kỹ thuật máy tính'),
(9520625, 'La Quang Quốc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520626, 'Trần Nguyên Quyết', 'Hệ thống thông tin'),
(9520627, 'Trần Sang', 'Hệ thống thông tin'),
(9520628, 'Trần Tấn Sang', 'Hệ thống thông tin'),
(9520630, 'Trần Nguyên Sĩ', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520631, 'Bùi Long Kỳ Sơn', 'Kỹ thuật máy tính'),
(9520632, 'Bùi Thanh Sơn', 'Kỹ thuật máy tính'),
(9520633, 'Chu Văn Sỹ', 'Hệ thống thông tin'),
(9520634, 'Phạm Công Tâm', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520635, 'Trần Hồng Tâm', 'Kỹ thuật máy tính'),
(9520636, 'Trần Thạch Duy Tân', 'Khoa học máy tính'),
(9520637, 'Lê Phạm Tân', 'Khoa học máy tính'),
(9520638, 'Lê Văn Tân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520640, 'Trần Nhật Tân', 'Mạng máy tính & truyền thông'),
(9520641, 'Dương Phát Tài', 'Hệ thống thông tin'),
(9520642, 'La Đặng Thành Tài', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520643, 'Nguyễn Tấn Tài', 'Kỹ thuật máy tính'),
(9520644, 'Nguyễn Văn Tài', 'Hệ thống thông tin'),
(9520645, 'Nguyễn Trường Thanh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520646, 'Đinh Đức Thành', 'Hệ thống thông tin'),
(9520647, 'Hồ Lê Thiện Thành', 'Khoa học máy tính'),
(9520648, 'Lư Văn Thành', 'Kỹ thuật máy tính'),
(9520649, 'Nguyễn Hải Thành', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520650, 'Nguyễn Minh Thành', 'Mạng máy tính & truyền thông'),
(9520651, 'Nguyễn Minh Thành', 'Kỹ thuật máy tính'),
(9520652, 'Phạm Bá Thành', ''),
(9520653, 'Đoàn Phương Thảo', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520654, 'Hòang Phương Thảo', 'Cử nhân tài năng'),
(9520655, 'Huỳnh Trần Như Thảo', 'Khoa học máy tính'),
(9520657, 'Lộ Ngọc Thạch', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520659, 'Đậu Đình Thắng', 'Kỹ thuật máy tính'),
(9520660, 'Nguyễn Huy Thắng', 'Hệ thống thông tin'),
(9520662, 'Bùi Chí Thiện', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520663, 'Hoàng Đức Thiện', 'Mạng máy tính & truyền thông'),
(9520664, 'Lê Hồ Hoàng Thiện', 'Khoa học máy tính'),
(9520665, 'Võ Minh Thiện', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520667, 'Đặng Huỳnh Phú Thịnh', 'Mạng máy tính & truyền thông'),
(9520668, 'Nguyễn Phúc Thịnh', 'Khoa học máy tính'),
(9520669, 'Trần Hữu Thịnh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520670, 'Trần Phúc Thịnh', 'Khoa học máy tính'),
(9520671, 'Trương Đức Thịnh', 'Hệ thống thông tin'),
(9520672, 'Nguyễn Hữu Thoại', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520673, 'Nguyễn Xuân Thọ', 'Khoa học máy tính'),
(9520674, 'Trần Hưng Thuận', 'Hệ thống thông tin'),
(9520676, 'Phạm Thị Thùy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520677, 'Nguyễn Chánh Thức', 'Hệ thống thông tin'),
(9520681, 'Phạm Hữu Tiến', 'Hệ thống thông tin'),
(9520682, 'Trần Tân Tiến', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520683, 'Ngô Công Trung Tín', 'Hệ thống thông tin'),
(9520684, 'Nguyễn Trung Tín', 'Hệ thống thông tin'),
(9520685, 'Trần Trung Tín', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520686, 'Nguyáťn BáşŁo ToĂ n', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(9520688, 'Trinh Tiến Tới', 'Hệ thống thông tin'),
(9520689, 'Phùng Thị Thùy Trang', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520690, 'Nguyễn Hồ Duy Tri', 'Hệ thống thông tin'),
(9520691, 'Văn Công Trình', 'Khoa học máy tính'),
(9520692, 'Nguyễn Hồ Duy Trí', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520693, 'Đỗ Lường Trọng', 'Hệ thống thông tin'),
(9520694, 'Lê Bảo Trung', 'Cử nhân tài năng'),
(9520695, 'Lê Đình Trung', 'Khoa học máy tính'),
(9520697, 'Trần Nam Trung', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520698, 'Trương Đình Trung', 'Khoa học máy tính'),
(9520699, 'Phan Văn Truyên', 'Hệ thống thông tin'),
(9520700, 'Nguyễn Xuân Trường', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520701, 'Nguyễn Sư Trưởng', 'Khoa học máy tính'),
(9520702, 'Lê Đình Tuân', 'Khoa học máy tính'),
(9520703, 'Bùi Văn Tuấn', 'Kỹ thuật máy tính'),
(9520704, 'Hồ Minh Tuấn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520705, 'Huỳnh Minh Tuấn', 'Kỹ thuật máy tính'),
(9520706, 'Lương Châu Tuấn', 'Khoa học máy tính'),
(9520707, 'Nguyễn Anh Tuấn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520708, 'Quách Thanh Tuấn', 'Mạng máy tính & truyền thông'),
(9520710, 'Trần Anh Tuấn', 'Hệ thống thông tin'),
(9520711, 'Trương Văn Tuấn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520712, 'Đặng Văn Tuyên', 'Hệ thống thông tin'),
(9520713, 'Nguyễn Kim Tùng', 'Kỹ thuật máy tính'),
(9520715, 'Trần Văn Tùng', 'Kỹ thuật máy tính'),
(9520716, 'Nguyễn Ngọc Tú', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520717, 'Hồ Phú Ty', 'Khoa học máy tính'),
(9520719, 'Phạm Công Viên', 'Mạng máy tính & truyền thông'),
(9520720, 'Hoàng Đình Việt', 'Cử nhân tài năng'),
(9520721, 'Lê Thế Vinh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520722, 'Nguyễn Minh Vương', 'Khoa học máy tính'),
(9520723, 'Võ Quốc Vương', 'Khoa học máy tính'),
(9520725, 'Lâm Hàn Vũ', 'Cử nhân tài năng'),
(9520726, 'Mai Lê Hoàng Vũ', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520727, 'Nguyễn Hoàng Vũ', 'Kỹ thuật máy tính'),
(9520729, 'Lê Thị Xoan', 'Khoa học máy tính'),
(9520730, 'Đỗ Thị Ngọc Yến', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520733, 'Y Buăn Adrơng', 'Hệ thống thông tin'),
(9520734, 'Y Phen Ktla', 'Hệ thống thông tin'),
(9520735, 'Y Nuyết Niê', 'Hệ thống thông tin'),
(9520736, 'Nguyễn Hoàng Giang', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520737, 'Y Hữu Êban', 'Mạng máy tính & truyền thông'),
(9520738, 'Buôn Krông Hồng Thanh', 'Mạng máy tính & truyền thông'),
(9520739, 'Y Huyết Niê', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520740, 'LĂŞ CĂ´ng Báşąng', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(9520742, 'Đàm Duy Dũng', 'Kỹ thuật máy tính'),
(9520743, 'Nguyễn Văn Đại', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520744, 'Nguyễn Lê Minh', 'Kỹ thuật máy tính'),
(9520746, 'Nguyễn Văn Sơn', 'Kỹ thuật máy tính'),
(9520747, 'Nguyễn Thành Tân', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9520748, 'Đặng Khánh Hưng', 'Chương trình tiên tiến'),
(9520749, 'Hồ Quốc Tuấn', 'Chương trình tiên tiến'),
(9720004, 'Nguyễn Hùynh Thế Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9720013, 'Hùynh Tấn Đạt', 'Đào tạo từ xa'),
(9720016, 'Nguyễn Anh  Dũng', 'Đào tạo từ xa'),
(9720035, 'Hồ Quốc  Kiên', 'Đào tạo từ xa'),
(9720039, 'Lê Thùy Linh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9720040, 'Nguyễn Vũ  Linh', 'Đào tạo từ xa'),
(9720041, 'Phạm Hòang Linh', 'Đào tạo từ xa'),
(9720044, 'Nguyễn Bình  Luận', 'Đào tạo từ xa'),
(9720045, 'Nguyễn Công Luận', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9720050, 'Nguyễn Hải Nam', 'Đào tạo từ xa'),
(9720052, 'Lê Chí Nào', 'Đào tạo từ xa'),
(9720059, 'Trần Hòai Nhân', 'Đào tạo từ xa'),
(9720060, 'Nguyễn Quang Nhẫn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9720064, 'Trần Hòai Nhi', 'Đào tạo từ xa'),
(9720070, 'Đặng Quốc Quân', 'Đào tạo từ xa'),
(9720084, 'Nguyễn Thanh Tâm', 'Đào tạo từ xa'),
(9720089, 'Nguyễn Phương Thanh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9720096, 'Nguyễn Như Thiên', 'Đào tạo từ xa'),
(9720101, 'Mai Kim Tiên', 'Đào tạo từ xa'),
(9720110, 'Lâm Nguyễn Thị Huyền Trân', 'Đào tạo từ xa'),
(9720120, 'Trương Lê  Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9720124, 'Nguyễn Thanh Vị', 'Đào tạo từ xa'),
(9730001, 'Nguyễn Văn  An', 'Đào tạo từ xa'),
(9730003, 'Vũ Kỳ Anh', 'Đào tạo từ xa'),
(9730004, 'Hoàng Hải  Âu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730005, 'Lê Quang  Bá', 'Đào tạo từ xa'),
(9730007, 'Nguyễn Thế Bằng', 'Đào tạo từ xa'),
(9730008, 'Trác Hồng  Chinh', 'Đào tạo từ xa'),
(9730009, 'Nguyễn Sơn Hoàng Chương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730010, 'Nguyễn Hoàng Tiến Chương', 'Đào tạo từ xa'),
(9730011, 'Võ Thành  Công', 'Đào tạo từ xa'),
(9730012, 'Dương Thế  Cừ', 'Đào tạo từ xa'),
(9730013, 'Nguyễn Tùng Cường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730014, 'Trần Quốc  Cường', 'Đào tạo từ xa'),
(9730015, 'Phạm Quốc  Cường', 'Đào tạo từ xa'),
(9730016, 'Ngô Quốc  Cường', 'Đào tạo từ xa'),
(9730017, 'Bùi Thế Đại', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730018, 'Nguyễn Phi  Đảo', 'Đào tạo từ xa'),
(9730019, 'Nguyễn Văn  Định', 'Đào tạo từ xa'),
(9730020, 'Lương Văn  Đức', 'Đào tạo từ xa'),
(9730021, 'Nguyễn Xuân  Đức', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730023, 'Nguyễn Văn Dũng', 'Đào tạo từ xa'),
(9730024, 'Lưu Quốc Dũng', 'Đào tạo từ xa'),
(9730025, 'Nguyễn Hùng  Dũng', 'Đào tạo từ xa'),
(9730026, 'Trịnh Đạt  Duy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730027, 'Lâm Thanh Giàu', 'Đào tạo từ xa'),
(9730028, 'Võ Mạnh Hà', 'Đào tạo từ xa'),
(9730029, 'Mai Tuấn  Hải', 'Đào tạo từ xa'),
(9730030, 'Nguyễn Hữu Hồng  Hải', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730032, 'Huỳnh Trung  Hiếu', 'Đào tạo từ xa'),
(9730033, 'Hồ  Hoà', 'Đào tạo từ xa'),
(9730034, 'Nguyễn Quốc  Hoàng', 'Đào tạo từ xa'),
(9730036, 'Nguyễn Đắc Hoạt', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730037, 'Phạm Thị Thu  Hồng', 'Đào tạo từ xa'),
(9730039, 'Trần Công Khanh', 'Đào tạo từ xa'),
(9730040, 'Cao Quý Khanh', 'Đào tạo từ xa'),
(9730043, 'Bùi Văn Khoẻ', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730044, 'Trần Đình  Khôn', 'Đào tạo từ xa'),
(9730046, 'Lê Thị Thùy  Lan', 'Đào tạo từ xa'),
(9730047, 'Lê Đình Long', 'Đào tạo từ xa'),
(9730048, 'Võ Thanh Nhật  Long', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730049, 'Nguyễn Hoàng  Long', 'Đào tạo từ xa'),
(9730050, 'Lê Xuân Luân', 'Đào tạo từ xa'),
(9730052, 'Phó Đức  Mạnh', 'Đào tạo từ xa'),
(9730053, 'Phạm Hoàng  Minh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730055, 'Nguyễn Minh  Nghĩa', 'Đào tạo từ xa'),
(9730056, 'Từ Chí  Nhân', 'Đào tạo từ xa'),
(9730058, 'Nguyễn Đức  Nhật', 'Đào tạo từ xa'),
(9730059, 'Nguyễn Thanh Minh  Nhựt', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730060, 'Đỗ Quốc  Phong', 'Đào tạo từ xa'),
(9730062, 'Huỳnh Văn  Phúc', 'Đào tạo từ xa'),
(9730063, 'Vũ Khắc  Phụng', 'Đào tạo từ xa'),
(9730066, 'Tô Đại  Quân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730069, 'Bùi Huy Quốc', 'Đào tạo từ xa'),
(9730070, 'Nguyễn Hải  Quỳnh', 'Đào tạo từ xa'),
(9730071, 'Võ Thanh Sang', 'Đào tạo từ xa'),
(9730072, 'Huỳnh Trọng Tâm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730074, 'Nguyễn Đức  Thám', 'Đào tạo từ xa'),
(9730075, 'Nguyễn Nhật  Thanh', 'Đào tạo từ xa'),
(9730076, 'Vũ Thái Thanh', 'Đào tạo từ xa'),
(9730077, 'Nguyễn Cao  Thanh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730080, 'Trần Trung  Tín', 'Đào tạo từ xa'),
(9730081, 'Trần Trung  Tín', 'Đào tạo từ xa'),
(9730082, 'Đinh Hồng  Tín', 'Đào tạo từ xa'),
(9730084, 'Nguyễn Long  Toàn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730085, 'Nguyễn Ngọc  Triệu', 'Đào tạo từ xa'),
(9730087, 'Nguyễn Thành Trung', 'Đào tạo từ xa'),
(9730088, 'Trịnh Thanh  Trung', 'Đào tạo từ xa'),
(9730089, 'Nguyễn Ngọc  Trường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730091, 'Mai Thanh Tuấn', 'Đào tạo từ xa'),
(9730092, 'Lê Thanh  Tùng', 'Đào tạo từ xa'),
(9730093, 'Dương Văn  Tuyển', 'Đào tạo từ xa'),
(9730094, 'Nguyễn Hoàng  Vân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730095, 'Nguyễn Quốc  Việt', 'Đào tạo từ xa'),
(9730096, 'Nguyễn Phúc  Vinh', 'Đào tạo từ xa'),
(9730098, 'Nguyễn Ngọc Minh Châu', 'Đào tạo từ xa'),
(9730099, 'Nguyễn Cao  Cường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730100, 'Hồ Cao  Đẳng', 'Đào tạo từ xa'),
(9730101, 'Nguyễn Thanh Đông', 'Đào tạo từ xa'),
(9730102, 'Nguyễn Hoàng  Long', 'Đào tạo từ xa'),
(9730103, 'Lê Văn  Thanh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730107, 'Vy Đức  Anh', 'Đào tạo từ xa'),
(9730111, 'Hồ Đỗ Thiên Chi', 'Đào tạo từ xa'),
(9730112, 'Trương Minh  Đăng', 'Đào tạo từ xa'),
(9730114, 'Trần Văn  Dũng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730115, 'Bùi Thanh  Dũng', 'Đào tạo từ xa'),
(9730116, 'Mai Việt  Dũng', 'Đào tạo từ xa'),
(9730117, 'Tạ Khương  Duy', 'Đào tạo từ xa'),
(9730119, 'Nguyễn Minh  Hoàng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730122, 'Nguyễn Văn  Mười', 'Đào tạo từ xa'),
(9730123, 'Nguyễn Nhựt  Nam', 'Đào tạo từ xa'),
(9730124, 'Hoàng Đình  Nguyên', 'Đào tạo từ xa'),
(9730125, 'Khổng Văn  Nhật', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730127, 'Nguyễn Lê Thị  Phúc', 'Đào tạo từ xa'),
(9730130, 'Hoàng Xuân  Sang', 'Đào tạo từ xa'),
(9730131, 'Lâm Khương Trường  Sơn', 'Đào tạo từ xa'),
(9730132, 'Lê Thiện  Sơn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730133, 'Phạm Vũ Linh Tâm', 'Đào tạo từ xa'),
(9730134, 'Phan Văn Tất', 'Đào tạo từ xa'),
(9730136, 'Đoàn Nhựt  Thanh', 'Đào tạo từ xa'),
(9730137, 'Võ Quốc  Thanh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730138, 'Bùi Tiến  Thành', 'Đào tạo từ xa'),
(9730139, 'Nguyễn Công Thành', 'Đào tạo từ xa'),
(9730140, 'Lê Minh Thế', 'Đào tạo từ xa'),
(9730141, 'Trần Ngọc  Thịnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730146, 'Dương Kỳ  Trí', 'Đào tạo từ xa'),
(9730149, 'Bùi Quốc  Tuấn', 'Đào tạo từ xa'),
(9730150, 'Nguyễn Thùy  Vân', 'Đào tạo từ xa'),
(9730153, 'Lê Đình  Cường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730155, 'Trương Công  Định', 'Đào tạo từ xa'),
(9730158, 'Trương Minh  Hải', 'Đào tạo từ xa'),
(9730159, 'Trần Văn  Hiếu', 'Đào tạo từ xa'),
(9730161, 'Khâu Phi  Hoàng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730162, 'Nguyễn Vĩnh Hùng', 'Đào tạo từ xa'),
(9730163, 'Lưu Cẩm  Huy', 'Đào tạo từ xa'),
(9730164, 'Dương Phước Hưng', 'Đào tạo từ xa'),
(9730165, 'Trương Anh  Khoa', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730170, 'Đặng Tử  Long', 'Đào tạo từ xa'),
(9730171, 'Dương Quốc Khánh  Luân', 'Đào tạo từ xa'),
(9730173, 'Nguyễn Văn  Nam', 'Đào tạo từ xa'),
(9730175, 'Võ Thanh Nhã', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730178, 'Trương Vĩ  Phong', 'Đào tạo từ xa'),
(9730184, 'Nguyễn Minh  Thái', 'Đào tạo từ xa'),
(9730185, 'Lê Toàn  Thắng', 'Đào tạo từ xa'),
(9730187, 'Nguyễn Võ Minh  Thông', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730189, 'Nguyễn Trung Tín', 'Đào tạo từ xa'),
(9730190, 'Nguyễn Trung  Tín', 'Đào tạo từ xa'),
(9730191, 'Nguyễn Thị Thùy  Trang', 'Đào tạo từ xa'),
(9730195, 'Lâm Kiến  Tùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730196, 'Nguyễn Sơn  Tùng', 'Đào tạo từ xa'),
(9730197, 'Nguyễn Sơn  Tùng', 'Đào tạo từ xa'),
(9730198, 'Hoàng Thái  Tuyên', 'Đào tạo từ xa'),
(9730199, 'Trần Minh Vấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730201, 'Nguyễn Hoàng Phúc', 'Đào tạo từ xa'),
(9730202, 'Nguyễn Đình  Quốc', 'Đào tạo từ xa'),
(9730203, 'Phạm Hoàng  Thống', 'Đào tạo từ xa'),
(9730204, 'Nguyễn Lê Ngọc Luân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730207, 'Lê Đình  Cường', 'Đào tạo từ xa'),
(9730208, 'Huỳnh Văn  Hiền', 'Đào tạo từ xa'),
(9730210, 'Nguyễn Chí  Cường', 'Đào tạo từ xa'),
(9730211, 'Nguyễn Kim  Hằng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730212, 'Lê Ngọc  Trung', 'Đào tạo từ xa'),
(9730216, 'Nguyễn Thanh Tùng', 'Đào tạo từ xa'),
(9730218, 'Lê Sáng  Hiền', 'Đào tạo từ xa'),
(9730219, 'Giang Vệ  Cang', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730221, 'Bùi Thái  Tuấn', 'Đào tạo từ xa'),
(9730224, 'Nguyễn Khánh  Pha', 'Đào tạo từ xa'),
(9730225, 'Phạm Viết  Tín', 'Đào tạo từ xa'),
(9730226, 'Lê Hoàng  Yến', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730227, 'Trần Minh  Hoàng', 'Đào tạo từ xa'),
(9730228, 'Lê Hoàng Đức Nhã', 'Đào tạo từ xa'),
(9730229, 'Phương Thị Thùy  Trang', 'Đào tạo từ xa'),
(9730230, 'Nguyễn Văn  Bàng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730232, 'Nguyễn Vĩnh  Trường', 'Đào tạo từ xa'),
(9730233, 'Ngô Hoàng  Hải', 'Đào tạo từ xa'),
(9730234, 'Nguyễn Anh  Sơn', 'Đào tạo từ xa'),
(9730235, 'Nguyễn Văn  Pích', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730236, 'Lê Hoàng  Hà', 'Đào tạo từ xa'),
(9730237, 'Nguyễn Duy  Thông', 'Đào tạo từ xa'),
(9730238, 'Đặng Hữu  Đức', 'Đào tạo từ xa'),
(9730239, 'Nguyễn Văn  Điền', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730240, 'Đặng Văn  Hài', 'Đào tạo từ xa'),
(9730241, 'Huỳnh Ngọc  Nhẫn', 'Đào tạo từ xa'),
(9730242, 'Võ Hữu  Thọ', 'Đào tạo từ xa'),
(9730243, 'Lê Minh Triết', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730244, 'Nguyễn Tăng  Luân', 'Đào tạo từ xa'),
(9730245, 'Hồ Ngọc Phú', 'Đào tạo từ xa'),
(9730246, 'Lê Hoàng  Bình', 'Đào tạo từ xa'),
(9730247, 'Lý Huỳnh Thanh Bình', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730248, 'Trần Minh  Châu', 'Đào tạo từ xa'),
(9730249, 'Nguyễn Hoàng Dũng', 'Đào tạo từ xa'),
(9730251, 'Trương Minh  Hải', 'Đào tạo từ xa'),
(9730252, 'Đồng Văn  Hảo', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730253, 'Nguyễn Ánh  Hồng', 'Đào tạo từ xa'),
(9730255, 'Đoàn Hoàng  Lanh', 'Đào tạo từ xa'),
(9730256, 'Đặng Quách Nhật', 'Đào tạo từ xa'),
(9730260, 'Phạm Kim Thành', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730262, 'Nguyễn Thế  Thức', 'Đào tạo từ xa'),
(9730263, 'Tô Quốc  Trung', 'Đào tạo từ xa'),
(9730264, 'Nguyễn Ngọc  Tuấn', 'Đào tạo từ xa'),
(9730265, 'Lê Tiến Phương  Tùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730267, 'Đặng Văn  Bé', 'Đào tạo từ xa'),
(9730269, 'Huỳnh Đình Khiêm', 'Đào tạo từ xa'),
(9730270, 'Vũ Ngọc Khoa', 'Đào tạo từ xa'),
(9730271, 'Dư Huỳnh An  Lay', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(9730272, 'Nguyễn Thanh  Luân', 'Đào tạo từ xa'),
(9730274, 'Nguyễn Trọng  Phước', 'Đào tạo từ xa'),
(9730277, 'Nguyễn Thế  Vinh', 'Đào tạo từ xa'),
(10010036, 'Huỳnh Quang  Tây', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020123, 'Bùi Tuấn  Anh', 'Đào tạo từ xa'),
(10020124, 'Hoàng Ngọc  Anh', 'Đào tạo từ xa'),
(10020125, 'Kiều Đức  Anh', 'Đào tạo từ xa'),
(10020126, 'Nguyễn Thị Lan  Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020127, 'Phạm Duy  Anh', 'Đào tạo từ xa'),
(10020128, 'Hoàng Quang Anh', 'Đào tạo từ xa'),
(10020129, 'Ngô Kiều  Anh', 'Đào tạo từ xa'),
(10020130, 'Nguyễn Thị Bích  Ánh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020131, 'Phan Thị Ngọc Ánh', 'Đào tạo từ xa'),
(10020132, 'Nguyễn Xuân  Bắc', 'Đào tạo từ xa'),
(10020133, 'Nguyễn Đình  Chuẩn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020134, 'Hoàng Mạnh Cường', 'Đào tạo từ xa'),
(10020135, 'Hoàng Mạnh  Cường', 'Đào tạo từ xa'),
(10020136, 'Nguyễn Ngọc  Cường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020137, 'Nguyễn Ngọc Diệp', 'Đào tạo từ xa'),
(10020138, 'Nguyễn Văn Dự', 'Đào tạo từ xa'),
(10020139, 'Chu Thuỷ  Dương', 'Đào tạo từ xa'),
(10020140, 'Nguyễn Thị Thuỳ Dương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020141, 'Nguyễn Thuỳ Dung', 'Đào tạo từ xa'),
(10020142, 'Nguyễn Khắc Dũng', 'Đào tạo từ xa'),
(10020143, 'Trần Văn  Dũng', 'Đào tạo từ xa'),
(10020144, 'Nguyễn Tiến  Dũng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020145, 'Nguyễn Văn  Dũng', 'Đào tạo từ xa'),
(10020146, 'Nguyễn Trường Giang', 'Đào tạo từ xa'),
(10020147, 'Nguyễn Vũ Long Giang', 'Đào tạo từ xa'),
(10020148, 'Phạm Ngọc Hải', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020149, 'Ngô Hồng  Hạnh', 'Đào tạo từ xa'),
(10020150, 'Nguyễn Thị Hồng  Hạnh', 'Đào tạo từ xa'),
(10020151, 'Nguyễn Thị Hà', 'Đào tạo từ xa'),
(10020152, 'Trần Hữu Hiển', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020153, 'Đào Tuấn Hiệp', 'Đào tạo từ xa'),
(10020154, 'Nguyễn Hoàng  Hiệp', 'Đào tạo từ xa'),
(10020155, 'Bạch Văn  Hiếu', 'Đào tạo từ xa'),
(10020156, 'Lê Trung Hiếu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020157, 'Nguyễn Chí  Hiếu', 'Đào tạo từ xa'),
(10020158, 'Nguyễn Ngọc Hiếu', 'Đào tạo từ xa'),
(10020159, 'Phạm Yến Hoa', 'Đào tạo từ xa'),
(10020160, 'Nguyễn Hữu Hoan', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020162, 'Nguyễn Tiến  Hoàng', 'Đào tạo từ xa'),
(10020163, 'Phạm Đức Minh  Hoàng', 'Đào tạo từ xa'),
(10020164, 'Nguyễn Quốc Huy Hoàng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020165, 'Nguyễn Phú  Hưng', 'Đào tạo từ xa'),
(10020166, 'Phạm Quốc  Hưng', 'Đào tạo từ xa'),
(10020167, 'Phạm Thị Hương', 'Đào tạo từ xa'),
(10020169, 'Chế Ngọc  Hưởng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020170, 'Hà Nam Huân', 'Đào tạo từ xa'),
(10020171, 'Phùng Văn Hùng', 'Đào tạo từ xa'),
(10020172, 'Nguyễn Ngọc  Hùng', 'Đào tạo từ xa'),
(10020173, 'Đoàn Bá  Hùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020174, 'Lê Ngọc Huy', 'Đào tạo từ xa'),
(10020175, 'Nguyễn Đình  Huy', 'Đào tạo từ xa'),
(10020176, 'Nguyễn Quang Khánh', 'Đào tạo từ xa'),
(10020177, 'Nguyễn Đăng  Khương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020178, 'Đào Quý  Khuê', 'Đào tạo từ xa'),
(10020179, 'Nguyễn Hữu Khuê', 'Đào tạo từ xa'),
(10020180, 'Nguyễn Tùng  Lâm', 'Đào tạo từ xa'),
(10020181, 'Đặng Thị  Lanh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020182, 'Đặng Thị Diệu  Linh', 'Đào tạo từ xa'),
(10020183, 'Nguyễn Hà  Linh', 'Đào tạo từ xa'),
(10020184, 'Tô Hoàng Linh', 'Đào tạo từ xa'),
(10020185, 'Văn Đình  Linh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020187, 'Trần Xuân Lộc', 'Đào tạo từ xa'),
(10020188, 'Kim Thị  Loan', 'Đào tạo từ xa'),
(10020189, 'Nguyễn Thị Phương  Loan', 'Đào tạo từ xa'),
(10020190, 'Trịnh Đình  Lợi', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020191, 'Lê Hoàng  Long', 'Đào tạo từ xa'),
(10020192, 'Lê Văn  Long', 'Đào tạo từ xa'),
(10020193, 'Bùi Thành  Luân', 'Đào tạo từ xa'),
(10020195, 'Nguyễn Thị Mận', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020196, 'Nguyễn Văn  Mạnh', 'Đào tạo từ xa'),
(10020197, 'Đỗ Văn Mạnh', 'Đào tạo từ xa'),
(10020198, 'Đoàn Đức  Mạnh', 'Đào tạo từ xa'),
(10020199, 'Phạm Văn Mạnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020200, 'Nguyễn Thế Minh', 'Đào tạo từ xa'),
(10020201, 'Nguyễn Quốc Đại', 'Đào tạo từ xa'),
(10020202, 'Nguyễn Thành  Đạt', 'Đào tạo từ xa'),
(10020203, 'Dương Văn Nam', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020204, 'Mai Khánh  Nam', 'Đào tạo từ xa'),
(10020205, 'Nguyễn Văn  Nam', 'Đào tạo từ xa'),
(10020206, 'Phạm Hoàng  Nam', 'Đào tạo từ xa'),
(10020207, 'Phạm Văn  Nam', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020208, 'Luyện Hằng  Nga', 'Đào tạo từ xa'),
(10020209, 'Trần Thị Tuyết  Ngân', 'Đào tạo từ xa'),
(10020210, 'Đỗ Thị Hồng  Ngọc', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020211, 'Đặng Văn  Nhật', 'Đào tạo từ xa'),
(10020213, 'Nguyễn Văn Nội', 'Đào tạo từ xa'),
(10020214, 'Nguyễn Hải  Đường', 'Đào tạo từ xa'),
(10020215, 'Bùi Mạnh  Đức', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020216, 'Đoàn Xuân  Đức', 'Đào tạo từ xa'),
(10020217, 'Trịnh Tiến  Đức', 'Đào tạo từ xa'),
(10020218, 'Trịnh Văn Đức', 'Đào tạo từ xa'),
(10020219, 'Dương Văn  Oai', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020220, 'Nguyễn Minh  Phương', 'Đào tạo từ xa'),
(10020221, 'Nguyễn Việt Phương', 'Đào tạo từ xa'),
(10020222, 'Đặng Văn Phước', 'Đào tạo từ xa'),
(10020223, 'Hoàng Văn Phú', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020224, 'Phạm Anh  Quân', 'Đào tạo từ xa'),
(10020226, 'Nguyễn Hồng  Quang', 'Đào tạo từ xa'),
(10020227, 'Phạm Văn  Quang', 'Đào tạo từ xa'),
(10020228, 'Vũ Duy  Quang', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020229, 'Bùi Thị Quế', 'Đào tạo từ xa'),
(10020231, 'Vũ Văn  Quyền', 'Đào tạo từ xa'),
(10020232, 'Phạm Thị Quyên', 'Đào tạo từ xa'),
(10020233, 'Nguyễn Ngọc  Quyết', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020234, 'Lê Thị  Quỳnh', 'Đào tạo từ xa'),
(10020235, 'Phạm Văn  Quý', 'Đào tạo từ xa'),
(10020236, 'Trương Thế  Rinh', 'Đào tạo từ xa'),
(10020237, 'Phan Thị Sâm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020238, 'Nguyễn Viết  Sơn', 'Đào tạo từ xa'),
(10020239, 'Nguyễn Vũ Sơn', 'Đào tạo từ xa'),
(10020240, 'Trần Thị Tâm', 'Đào tạo từ xa'),
(10020241, 'Nguyễn Thành  Tân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020242, 'Nguyễn Văn  Tam', 'Đào tạo từ xa'),
(10020243, 'Lê Anh  Tài', 'Đào tạo từ xa'),
(10020244, 'Nguyễn Ngọc  Thắng', 'Đào tạo từ xa'),
(10020245, 'Trần Đăng  Thành', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020246, 'Nguyễn Văn  Thảo', 'Đào tạo từ xa'),
(10020247, 'Nguyễn Thị Tho', 'Đào tạo từ xa'),
(10020248, 'Nguyễn Viết Thoan', 'Đào tạo từ xa'),
(10020250, 'Võ Công  Thuỷ', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020251, 'Đào Mạnh  Trường', 'Đào tạo từ xa'),
(10020252, 'Nguyễn Thế  Trường', 'Đào tạo từ xa'),
(10020253, 'Đinh Văn  Trung', 'Đào tạo từ xa'),
(10020254, 'Phạm Ngọc  Trung', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020255, 'Trần Anh  Trung', 'Đào tạo từ xa'),
(10020256, 'Lê Đức  Trung', 'Đào tạo từ xa'),
(10020257, 'Lê Quang  Trung', 'Đào tạo từ xa'),
(10020258, 'Nguyễn Hữu Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020259, 'Nguyễn Mạnh Tuấn', 'Đào tạo từ xa'),
(10020260, 'Vũ Quang Tuấn', 'Đào tạo từ xa'),
(10020261, 'Nguyễn Văn Tuấn', 'Đào tạo từ xa'),
(10020262, 'Nguyễn Văn Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020263, 'Nguyễn Văn  Tuấn', 'Đào tạo từ xa'),
(10020264, 'Đỗ Anh  Tuấn', 'Đào tạo từ xa'),
(10020265, 'Đỗ Ngọc Tùng', 'Đào tạo từ xa'),
(10020266, 'Nguyễn Hải  Tùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020267, 'Nguyễn Khánh  Tùng', 'Đào tạo từ xa'),
(10020269, 'Trần Thanh  Tùng', 'Đào tạo từ xa'),
(10020270, 'Trần Ngọc  Tú', 'Đào tạo từ xa'),
(10020271, 'Nguyễn Công Hà  Uyên', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020272, 'Đinh Văn  Việt', 'Đào tạo từ xa'),
(10020273, 'Trần Tuấn Việt', 'Đào tạo từ xa'),
(10020274, 'Vũ Văn  Vượng', 'Đào tạo từ xa'),
(10020275, 'Nguyễn Hữu Xuân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020276, 'Nguyễn  Thị  Xuyến', 'Đào tạo từ xa'),
(10020277, 'Nguyễn Thị Hải  Yến', 'Đào tạo từ xa'),
(10020278, 'Đỗ Hải Yến', 'Đào tạo từ xa'),
(10020279, 'Trần Ngọc  Yến', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020280, 'Trần Thị Yến', 'Đào tạo từ xa'),
(10020281, 'Bùi Doãn An', 'Đào tạo từ xa'),
(10020282, 'Hoàng Việt Anh', 'Đào tạo từ xa'),
(10020283, 'Nguyễn Việt Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020284, 'Nguyễn Việt Anh', 'Đào tạo từ xa'),
(10020285, 'Đặng  Đình Cát', 'Đào tạo từ xa'),
(10020287, 'Nguyễn Văn Chiến', 'Đào tạo từ xa'),
(10020288, 'Thái Văn Công', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020289, 'Đỗ Mạnh Cường', 'Đào tạo từ xa'),
(10020290, 'Nguyễn Hải Đăng', 'Đào tạo từ xa'),
(10020291, 'Nguyễn Tuấn  Đạt', 'Đào tạo từ xa'),
(10020293, 'Mai Quý Đôn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020294, 'Hồ Diên  Đức', 'Đào tạo từ xa'),
(10020295, 'Lương Văn Đức', 'Đào tạo từ xa'),
(10020296, 'Đồng Minh Đức', 'Đào tạo từ xa'),
(10020297, 'Vũ Đại  Dũng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020300, 'Nguyễn Hồng  Dương', 'Đào tạo từ xa'),
(10020301, 'Phạm Trùng  Dương', 'Đào tạo từ xa'),
(10020303, 'Mạc Đỗ Hoàng Dương', 'Đào tạo từ xa'),
(10020304, 'Cao Thị Giang', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020307, 'Nguyễn Hoàng  Hải', 'Đào tạo từ xa'),
(10020308, 'Nguyễn Thế Hải', 'Đào tạo từ xa'),
(10020309, 'Nguyễn Xuân Hải', 'Đào tạo từ xa'),
(10020310, 'Nguyễn Thanh Hằng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020311, 'Đặng Văn Hiệp', 'Đào tạo từ xa'),
(10020312, 'Lường Thị Hoa', 'Đào tạo từ xa'),
(10020313, 'Nguyễn Trọng  Hoàng', 'Đào tạo từ xa'),
(10020315, 'Nguyễn Thanh Hùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020317, 'Lê Văn Hưng', 'Đào tạo từ xa'),
(10020319, 'Nguyễn Diệu Hương', 'Đào tạo từ xa'),
(10020320, 'Nguyễn Gia  Huy', 'Đào tạo từ xa'),
(10020322, 'Phan Thị Huyền', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020323, 'Bùi Năng Khang', 'Đào tạo từ xa'),
(10020327, 'Hoàng Đạt Kiên', 'Đào tạo từ xa'),
(10020328, 'Nguyễn Thế  Kỳ', 'Đào tạo từ xa'),
(10020329, 'Bùi Thanh Linh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020330, 'Nguyễn Duy Linh', 'Đào tạo từ xa'),
(10020331, 'Đinh Thị  Loan', 'Đào tạo từ xa'),
(10020333, 'Phan Công Luật', 'Đào tạo từ xa'),
(10020334, 'Nguyễn Hữu Mẫn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020337, 'Nguyễn Tất Minh', 'Đào tạo từ xa'),
(10020338, 'Đoàn Hoài Nam', 'Đào tạo từ xa'),
(10020339, 'Nguyễn Minh  Ngọc', 'Đào tạo từ xa'),
(10020341, 'Cao Bá  Phước', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020343, 'Nguyễn Văn Quang', 'Đào tạo từ xa'),
(10020344, 'Đỗ Mạnh Quyền', 'Đào tạo từ xa'),
(10020346, 'Nguyễn Hoàng  Sơn', 'Đào tạo từ xa'),
(10020347, 'Phan Sỹ  Sơn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020349, 'Lê Đức  Tài', 'Đào tạo từ xa'),
(10020350, 'Đỗ Đình Tâm', 'Đào tạo từ xa'),
(10020352, 'Dương Đình Thăng', 'Đào tạo từ xa'),
(10020353, 'Trần Đình Thắng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020355, 'Lê Trọng Thành', 'Đào tạo từ xa'),
(10020356, 'Cao Thị Thanh', 'Đào tạo từ xa'),
(10020358, 'Phạm Quang Tháp', 'Đào tạo từ xa'),
(10020359, 'Lê Văn Thưởng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020360, 'Nguyễn Văn  Tính', 'Đào tạo từ xa'),
(10020362, 'Nguyễn Ngọc Trâm', 'Đào tạo từ xa'),
(10020363, 'Chu Thị  Trang', 'Đào tạo từ xa'),
(10020364, 'Lý Hoàng Trung', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020365, 'Từ Việt Trung', 'Đào tạo từ xa'),
(10020367, 'Nguyễn Tuấn Tú', 'Đào tạo từ xa'),
(10020369, 'Đặng Minh  Tuấn', 'Đào tạo từ xa'),
(10020371, 'Hoàng Mạnh Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020372, 'Nguyễn  Hoàng Tùng', 'Đào tạo từ xa'),
(10020374, 'Trần Văn  Ước', 'Đào tạo từ xa'),
(10020376, 'Nguyễn Thị Định', 'Đào tạo từ xa'),
(10020377, 'Vũ Văn Duy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020378, 'Nguyễn Hữu Hải', 'Đào tạo từ xa'),
(10020380, 'Đào Mạnh  Hiếu', 'Đào tạo từ xa'),
(10020382, 'Đinh Thùy Linh', 'Đào tạo từ xa'),
(10020383, 'Tống Thị Mai', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10020384, 'Vũ Thị Mai', 'Đào tạo từ xa'),
(10020385, 'Lưu Nguyễn Thành Trung', 'Đào tạo từ xa'),
(10030001, 'Đặng Hoàng Anh', 'Đào tạo từ xa'),
(10030003, 'Vũ Thị Kim Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10030005, 'Nguyễn Thành Công', 'Đào tạo từ xa'),
(10030006, 'Nguyễn Mạnh Cường', 'Đào tạo từ xa'),
(10030007, 'Nguyễn Tiến Cường', 'Đào tạo từ xa'),
(10030008, 'Cao Khả  Đạt', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10030009, 'Sử Phi  Định', 'Đào tạo từ xa'),
(10030010, 'Vương Xuân Độ', 'Đào tạo từ xa'),
(10030013, 'Nguyễn Trung Đức', 'Đào tạo từ xa'),
(10030014, 'Nguyễn Đình Được', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10030015, 'Nguyễn Thị Duyên', 'Đào tạo từ xa'),
(10030019, 'Nguyễn Minh Hiếu', 'Đào tạo từ xa'),
(10030023, 'Mai Thế Hùng', 'Đào tạo từ xa'),
(10030024, 'Hoàng Ngọc Hưng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10030026, 'Ngô Duy Long', 'Đào tạo từ xa'),
(10030028, 'Nguyễn Văn Mạnh', 'Đào tạo từ xa'),
(10030030, 'Nguyễn Bảo Minh', 'Đào tạo từ xa'),
(10030031, 'Trần Huy Nam', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10030032, 'Lê Văn Nhâm', 'Đào tạo từ xa'),
(10030034, 'Nguyễn Thị Nhung', 'Đào tạo từ xa'),
(10030035, 'Trần Thị Phương', 'Đào tạo từ xa'),
(10030040, 'Nguyễn Phi Sơn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10030041, 'Nguyễn Quyết Tâm', 'Đào tạo từ xa'),
(10030042, 'La Duy Thanh', 'Đào tạo từ xa'),
(10030043, 'Nguyễn Văn Thành', 'Đào tạo từ xa'),
(10030045, 'Đinh Thị Ánh Thơ', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10030048, 'Vũ Quang Toàn', 'Đào tạo từ xa'),
(10030049, 'Nguyễn Thu Trang', 'Đào tạo từ xa'),
(10030051, 'Phạm Văn Trung', 'Đào tạo từ xa'),
(10030054, 'Nguyễn Thanh Tùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10030055, 'Trần Bảo Tùng', 'Đào tạo từ xa'),
(10030056, 'Trần Văn Tùng', 'Đào tạo từ xa'),
(10030057, 'Trần Thế Văn', 'Đào tạo từ xa'),
(10030059, 'Lê Hùng Vượng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10030061, 'Bùi Đức Anh', 'Đào tạo từ xa'),
(10030067, 'Sầm Việt Dũng', 'Đào tạo từ xa'),
(10030069, 'Ngô Đức Hùng', 'Đào tạo từ xa'),
(10030070, 'Nguyễn Quang Huy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10030071, 'Nông Quang Kỳ', 'Đào tạo từ xa'),
(10030074, 'Vũ Thị Nhung', 'Đào tạo từ xa'),
(10030077, 'Nguyễn Mạnh Quân', 'Đào tạo từ xa'),
(10030080, 'Lê Quang Trung', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040002, 'Nguyễn Tuấn  Anh', 'Đào tạo từ xa'),
(10040004, 'Phạm Quang Anh', 'Đào tạo từ xa'),
(10040005, 'Nguyễn Thị  Ánh', 'Đào tạo từ xa'),
(10040009, 'Hoàng Thành  Công', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040010, 'Đỗ Thị  Cúc', 'Đào tạo từ xa'),
(10040011, 'Phạm Anh  Cường', 'Đào tạo từ xa'),
(10040016, 'Quản Bách  Diệp', 'Đào tạo từ xa'),
(10040017, 'Bùi Trung  Đức', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040018, 'Đỗ Minh  Đức', 'Đào tạo từ xa'),
(10040019, 'Nguyễn Quang Đức', 'Đào tạo từ xa'),
(10040020, 'Hoàng Thị Hương  Dung', 'Đào tạo từ xa'),
(10040022, 'Đào Tiến  Dũng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040028, 'Bùi Thị  Giang', 'Đào tạo từ xa'),
(10040032, 'Đỗ Văn  Hậu', 'Đào tạo từ xa'),
(10040033, 'Đỗ Văn Hệ', 'Đào tạo từ xa'),
(10040037, 'Nguyễn Hữu Hùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040040, 'Nguyễn Thị  Hương', 'Đào tạo từ xa'),
(10040041, 'Trần Thị  Hương', 'Đào tạo từ xa'),
(10040042, 'Đào Quang  Huy', 'Đào tạo từ xa'),
(10040045, 'Nguyễn Công  Huy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040046, 'Nguyễn Quang Huy', 'Đào tạo từ xa'),
(10040047, 'Hoàng Văn  Huynh', 'Đào tạo từ xa'),
(10040049, 'Nguyễn Đức Khánh', 'Đào tạo từ xa'),
(10040050, 'Vũ Anh  Khoa', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040051, 'Phạm Đoàn Khuê', 'Đào tạo từ xa'),
(10040053, 'Bùi Đức Lâm', 'Đào tạo từ xa'),
(10040054, 'Bùi Quang  Lê', 'Đào tạo từ xa'),
(10040055, 'Vũ Thị  Linh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040058, 'Nguyễn Tiến  Mạnh', 'Đào tạo từ xa'),
(10040061, 'Nguyễn Quốc  Mạnh', 'Đào tạo từ xa'),
(10040063, 'Lưu Đức Nghĩa', 'Đào tạo từ xa'),
(10040064, 'Phạm Tuấn  Nghĩa', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040066, 'Nguyễn Thị Thanh  Nhàn', 'Đào tạo từ xa'),
(10040069, 'Trần Đại  Phước', 'Đào tạo từ xa'),
(10040072, 'Hoàng Ngọc Quang', 'Đào tạo từ xa'),
(10040075, 'Phạm Duy Quyền', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040078, 'Trần Thành  Tài', 'Đào tạo từ xa'),
(10040080, 'Ngô Thị  Tám', 'Đào tạo từ xa'),
(10040081, 'Vũ Thanh  Tâm', 'Đào tạo từ xa'),
(10040084, 'Hoàng Văn  Thăng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040085, 'Bùi Ngọc Thành', 'Đào tạo từ xa'),
(10040087, 'Nguyễn Quang Thanh', 'Đào tạo từ xa'),
(10040088, 'Vũ Bá  Thanh', 'Đào tạo từ xa'),
(10040092, 'Hoàng Thị Diệu  Thúy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040093, 'Bùi Văn Thủy', 'Đào tạo từ xa'),
(10040094, 'Lê Văn  Tiến', 'Đào tạo từ xa'),
(10040095, 'Phạm Việt Tiến', 'Đào tạo từ xa'),
(10040096, 'Đỗ Việt  Tiệp', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040098, 'Trịnh Thúc  Triều', 'Đào tạo từ xa'),
(10040101, 'Phạm Đức Trọng', 'Đào tạo từ xa'),
(10040104, 'Phạm Thị Quốc Trưởng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040108, 'Nguyễn Văn  Tuấn', 'Đào tạo từ xa'),
(10040109, 'Bùi Văn  Tùng', 'Đào tạo từ xa'),
(10040110, 'Dương Thanh  Tùng', 'Đào tạo từ xa'),
(10040112, 'Phạm Thanh  Tùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10040114, 'Tiêu Thị Thảo Vân', 'Đào tạo từ xa'),
(10040116, 'Nguyễn Hoàng  Việt', 'Đào tạo từ xa'),
(10120001, 'Cao Thúy Ái', 'Đào tạo từ xa'),
(10120002, 'Trần Xuân Bách', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10120003, 'Phan Văn Bào', 'Đào tạo từ xa'),
(10120005, 'Tô Bé Chính', 'Đào tạo từ xa'),
(10120007, 'Bao Quốc Công', 'Đào tạo từ xa'),
(10120009, 'Nguyễn Thành Công', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10120010, 'Hồng Văn Cường', 'Đào tạo từ xa'),
(10120011, 'Trịnh Hoàng Đa', 'Đào tạo từ xa'),
(10120012, 'Nguyễn Hải Đăng', 'Đào tạo từ xa'),
(10120020, 'Trương Văn Huần', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10120021, 'Trần Hải Kê', 'Đào tạo từ xa'),
(10120023, 'Nguyễn Hoàng Khiêm', 'Đào tạo từ xa'),
(10120025, 'Phạm Đăng Khoa', 'Đào tạo từ xa'),
(10120027, 'Nguyễn Văn Luân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10120029, 'Trần Minh Luận', 'Đào tạo từ xa'),
(10120031, 'Trần Văn Lừng', 'Đào tạo từ xa'),
(10120036, 'Dương Văn Nèo', 'Đào tạo từ xa'),
(10120038, 'Lai Minh Nghĩa', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10120040, 'Phạm Hồng Nhanh', 'Đào tạo từ xa'),
(10120041, 'Nguyễn Thị Nhường', 'Đào tạo từ xa'),
(10120042, 'Cao Minh Nhựt', 'Đào tạo từ xa'),
(10120050, 'Trần Văn Sang', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10120051, 'Phan Văn Sang', 'Đào tạo từ xa'),
(10120055, 'Trần Văn Thoảng', 'Đào tạo từ xa'),
(10120056, 'Lê Anh Tiến', 'Đào tạo từ xa'),
(10120057, 'Nguyễn Bảo Toàn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10120058, 'Nguyễn Viết Trong', 'Đào tạo từ xa'),
(10120059, 'Huỳnh Minh Trung', 'Đào tạo từ xa'),
(10120060, 'Lê Đức Trung', 'Đào tạo từ xa'),
(10120061, 'Phan Anh Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10120062, 'Đặng Minh Út', 'Đào tạo từ xa'),
(10120063, 'Lê Văn Vẵn', 'Đào tạo từ xa'),
(10190006, 'Dương Mạnh Chính', 'Đào tạo từ xa'),
(10190009, 'Đặng Văn  Đạt', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10190107, 'Phạm Văn Đông', 'Đào tạo từ xa'),
(10190187, 'Lê Cảnh Tình', 'Đào tạo từ xa'),
(10520001, 'Lê Thế Dũng', 'Công nghệ phần mềm'),
(10520002, 'Nguyễn Khánh Thi', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520004, 'Hồ Ngọc Lê', 'Kỹ thuật máy tính'),
(10520005, 'Nguyễn Phạm Anh Duy', 'Kỹ thuật máy tính'),
(10520006, 'Đỗ Công Danh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520007, 'Trát Hoàng Trung Nguyên', 'Kỹ thuật máy tính'),
(10520008, 'Châu Trọng Nam', 'Hệ thống thông tin'),
(10520009, 'Đào Hoàng Dương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520010, 'Đặng Lê Bảo Chương', 'Mạng máy tính & truyền thông'),
(10520011, 'Nguyễn Bảo Duy', 'Mạng máy tính & truyền thông'),
(10520013, 'Đặng Hoàng Phi', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520015, 'Trần Vũ Trường Phi', 'Mạng máy tính & truyền thông'),
(10520016, 'Đoàn Thanh Nam', 'Kỹ thuật máy tính'),
(10520018, 'Nguyễn Thuận Hoà', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520019, 'Bùi Nguyễn Hoàng Tân', 'Chương trình tiên tiến'),
(10520020, 'Đoàn Anh Đức', 'Kỹ thuật máy tính'),
(10520021, 'Đoàn Thiện Toàn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520022, 'Cao Quang Minh', 'Chương trình tiên tiến'),
(10520023, 'Nguyễn Văn Tùng', 'Kỹ thuật máy tính'),
(10520024, 'Nghiêm Đức Lê Quang', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520025, 'Đặng Bá Tới', 'Hệ thống thông tin'),
(10520026, 'Nguyễn Tấn Hậu', 'Mạng máy tính & truyền thông'),
(10520027, 'Nguyễn Đức Tân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520028, 'Nguyễn Minh Trung', 'Chương trình tiên tiến'),
(10520029, 'Tráş§n Ngáťc KhĂĄnh', 'Háť tháťng thĂ´ng tin'),
(10520030, 'Lê Quốc Đạt', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520031, 'Cao Bình Nguyên', 'Mạng máy tính & truyền thông'),
(10520032, 'Trần Anh Nguyên', 'Khoa học máy tính'),
(10520033, 'Tráş§n TĂ˘n PhĆ°áťc', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520034, 'Đoàn Trịnh Trọng Trung', 'Hệ thống thông tin'),
(10520035, 'Nguyễn Phan Lộc', 'Khoa học máy tính'),
(10520036, 'Nguyễn Hoàng Ân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520037, 'Dương Ngọc Dung', 'Kỹ thuật máy tính'),
(10520038, 'Trần Ngọc Bảo Minh', 'Mạng máy tính & truyền thông'),
(10520039, 'Nguyễn Lương Bằng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520040, 'Trần Lê Tuấn Anh', 'Công nghệ phần mềm'),
(10520041, 'Nguyễn Ngọc Dương', 'Kỹ thuật máy tính'),
(10520042, 'Trần Tấn Phúc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520044, 'Nguyễn Duy Tín', 'Kỹ thuật máy tính'),
(10520045, 'Nguyễn Tấn Phát', 'Chương trình tiên tiến'),
(10520046, 'Lê Vân Thành Vĩ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520047, 'Đoàn Vạn Thắng', 'Mạng máy tính & truyền thông'),
(10520048, 'Chu Quang Thái', 'Công nghệ phần mềm'),
(10520049, 'Nguyáťn VÄn Nam', ''),
(10520050, 'Diệp Thế Vinh', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520051, 'Phạm Bảo Ngọc', 'Công nghệ phần mềm'),
(10520052, 'Võ Đức Huy', 'Khoa học máy tính'),
(10520053, 'Lê Anh Đức', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520054, 'Nguyễn Phan Trọng Nhân', 'Mạng máy tính & truyền thông'),
(10520055, 'Lâm Hạ Long', 'Mạng máy tính & truyền thông'),
(10520056, 'Nguyễn Phú Quí', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520057, 'Nguyễn Văn Đồng', 'Kỹ thuật máy tính'),
(10520058, 'NgĂ´ Quáťc Huy', 'Khoa háťc mĂĄy tĂ­nh'),
(10520059, 'Nguyễn Hoàng Long', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520060, 'Trần Quốc Cường', 'Công nghệ phần mềm'),
(10520061, 'Phan Văn Tâm', 'Công nghệ phần mềm'),
(10520062, 'Nguyễn Đức Trọng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520064, 'Nguyễn Thanh Hiền', 'Khoa học máy tính'),
(10520065, 'Nguyễn Mạnh Hiếu', 'Kỹ thuật máy tính'),
(10520066, 'Trần Tấn Tài', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520067, 'Trần Quốc Bảo', 'Hệ thống thông tin'),
(10520068, 'Ngô An Ninh', 'Hệ thống thông tin'),
(10520069, 'Vũ Văn Lợi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520070, 'Äáşˇng VÄn HĂšng', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(10520071, 'Vũ Xuân Trường', 'Kỹ thuật máy tính'),
(10520072, 'Nguyễn Văn Hùng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520073, 'Đoàn Xuân Cầu', 'Kỹ thuật máy tính'),
(10520074, 'Phạm Duy', 'Cử nhân tài năng'),
(10520076, 'Lê Văn Cảnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520077, 'Ngô Xuân Cường', 'Công nghệ phần mềm'),
(10520079, 'Nguyễn Văn Thụ', 'Mạng máy tính & truyền thông'),
(10520080, 'Lưu Văn Lực', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520081, 'Nguyễn Thị Mai', 'Kỹ thuật máy tính'),
(10520082, 'Trần Văn Quân', 'Kỹ thuật máy tính'),
(10520083, 'Lê Thị Quyên', 'Hệ thống thông tin'),
(10520084, 'Nguyễn Văn Phong', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520085, 'VĹŠ VÄn LĂ˝', 'CĂ´ng ngháť pháş§n máťm'),
(10520086, 'Hoàng Đình Hùng', 'Khoa học máy tính'),
(10520087, 'Hồ Xuân Hùng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520088, 'Nguyễn Văn Toản', 'Mạng máy tính & truyền thông'),
(10520089, 'Nguyễn Văn Thịnh', 'Kỹ thuật máy tính'),
(10520090, 'Phạm Văn Giang', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520092, 'Trần Quốc Thuấn', 'Khoa học máy tính'),
(10520093, 'Nguyễn Đình Hòang', 'Kỹ thuật máy tính'),
(10520094, 'Phạm Mạnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520095, 'Lê Quốc Tiến', 'Hệ thống thông tin'),
(10520096, 'Nguyễn Đình Hòa', 'Công nghệ phần mềm'),
(10520097, 'Nguyễn Thanh Tiến', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520098, 'Trần Tiến Trung', 'Hệ thống thông tin'),
(10520099, 'Trần Đức Tiến', 'Hệ thống thông tin'),
(10520100, 'ÄĂ o Anh NguyĂŞn', 'Cáť­ nhĂ˘n tĂ i nÄng'),
(10520101, 'Võ Minh Sơn', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520102, 'Lê Đắc Sỹ', 'Hệ thống thông tin'),
(10520103, 'Nguyễn Đạo Đức', 'Hệ thống thông tin'),
(10520104, 'Trần Hồng Quân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520106, 'Đào Duy Tùng', 'Công nghệ phần mềm'),
(10520107, 'Hàn Thiện Nghĩa', 'Khoa học máy tính'),
(10520108, 'Trần Trọng Nhân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520109, 'Nguyễn Cao Phước', 'Kỹ thuật máy tính'),
(10520110, 'Nguyễn Sanh Thịnh', 'Mạng máy tính & truyền thông'),
(10520111, 'Nguyễn Văn Thịnh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520112, 'Nguyễn Văn Chiến', 'Công nghệ phần mềm'),
(10520113, 'Lâm Văn Quốc Huy', 'Công nghệ phần mềm'),
(10520114, 'Hoàng Nhật Tiến', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520116, 'Nguyễn Văn Bảo Sinh', 'Kỹ thuật máy tính'),
(10520118, 'Lê Nhâm Thân', 'Hệ thống thông tin'),
(10520120, 'Nguyễn Ngọc Hiệu', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520121, 'Nguyễn Thiện Lai', 'Khoa học máy tính'),
(10520122, 'Nguyễn Tấn Công', 'Hệ thống thông tin'),
(10520123, 'Đặng Huy Chương', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520124, 'Nguyễn Công Hoàn', 'Khoa học máy tính'),
(10520125, 'Đồng Quang Trần Danh', 'Kỹ thuật máy tính'),
(10520126, 'Hoàng Phú Bình', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520127, 'Nguyễn Đỗ Cao Trí', 'Công nghệ phần mềm'),
(10520128, 'Huỳnh Ngọc Hiệp', 'Công nghệ phần mềm'),
(10520129, 'Dương Hoàng Khải', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520130, 'Nguyễn Văn Sinh', 'Công nghệ phần mềm'),
(10520131, 'Cao Văn Lực', 'Mạng máy tính & truyền thông'),
(10520132, 'Nguyễn Đình Hiển', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520133, 'Tôn Ngọc Tẩn', 'Công nghệ phần mềm'),
(10520134, 'Nguyến Văn Duy', 'Mạng máy tính & truyền thông'),
(10520135, 'Nguyễn Tấn Hoan', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520136, 'Võ Tấn Vui', 'Mạng máy tính & truyền thông'),
(10520137, 'Huỳnh Đức Tân', 'Kỹ thuật máy tính'),
(10520138, 'Nguyễn Văn Thịnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520139, 'Hoàng Tiến Pháp', 'Khoa học máy tính'),
(10520140, 'Nguyễn Hồ Trọng Thảo', 'Hệ thống thông tin'),
(10520141, 'Lê Văn Mến', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520142, 'Nguyễn Lê Trung', 'Cử nhân tài năng'),
(10520143, 'Nguyễn Thanh Cường', 'Mạng máy tính & truyền thông'),
(10520144, 'Phạm Nông', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520145, 'Bùi Ngọc Lâm', 'Kỹ thuật máy tính'),
(10520146, 'Nguyễn Mạnh Hưng', 'Kỹ thuật máy tính'),
(10520147, 'Nguyễn Ngọc Sang', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520148, 'Hồ Sĩ Hùng', 'Kỹ thuật máy tính'),
(10520149, 'Nguyễn Đình Hoàng Nguyên', 'Mạng máy tính & truyền thông'),
(10520150, 'Vũ Văn Sỹ', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520151, 'Nguyễn Thành Sang', 'Công nghệ phần mềm'),
(10520153, 'Nguyễn Văn Thân', 'Công nghệ phần mềm'),
(10520154, 'Cao Minh Toàn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520155, 'Nguyễn Minh Trí', 'Kỹ thuật máy tính'),
(10520156, 'Nguyễn Lê Huy', 'Mạng máy tính & truyền thông'),
(10520157, 'Nguyễn Thái Bình', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520159, 'Hàn Nguyên Tuấn', 'Hệ thống thông tin'),
(10520160, 'Đỗ Hiếu Thương', 'Khoa học máy tính'),
(10520161, 'Cao Hoàng Vũ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520162, 'Huỳnh Ngọc Huy', 'Công nghệ phần mềm'),
(10520163, 'PháşĄm TáşĽn Long', 'CĂ´ng ngháť pháş§n máťm'),
(10520164, 'Phan Lê Linh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520165, 'Võ Văn Trình', 'Mạng máy tính & truyền thông'),
(10520166, 'Nguyễn Thái Thắng', 'Hệ thống thông tin'),
(10520167, 'Đoàn Huỳnh Vọng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520168, 'Lương Văn Trọng', 'Công nghệ phần mềm'),
(10520169, 'Hoàng Minh Tuấn', 'Mạng máy tính & truyền thông'),
(10520170, 'Bùi Thế Hưng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520171, 'Võ Đình Phú', 'Kỹ thuật máy tính'),
(10520172, 'Trần Quốc Thắng', 'Hệ thống thông tin'),
(10520173, 'LĂ˝ Thanh Háş­u', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520174, 'Nguyễn Duy Tiến', 'Chương trình tiên tiến'),
(10520176, 'Đỗ Ngọc Sâm', 'Công nghệ phần mềm'),
(10520177, 'Nguyễn Văn Thuận', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520179, 'Nguyễn Tấn Toàn', 'Cử nhân tài năng'),
(10520180, 'Phan Hữu Tây', 'Mạng máy tính & truyền thông'),
(10520181, 'Khổng Xuân Trung', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520182, 'Nguyễn Mạnh Duy', 'Kỹ thuật máy tính'),
(10520183, 'Huỳnh Xuân Tùng', 'Kỹ thuật máy tính'),
(10520184, 'Nguyễn Hồng Quân', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520186, 'Kỷ Văn Xí', 'Công nghệ phần mềm'),
(10520187, 'Hà Phi Phú', 'Công nghệ phần mềm'),
(10520189, 'Lê Minh Trí', 'Chương trình tiên tiến'),
(10520190, 'Phan Thị Thanh Ngân', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520191, 'Châu Tiếng Việt', 'Công nghệ phần mềm'),
(10520192, 'Nguyễn Ngọc Hưng', 'Mạng máy tính & truyền thông'),
(10520193, 'Trần Minh Tâm', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520194, 'Phạm Minh Trường', 'Mạng máy tính & truyền thông'),
(10520195, 'Nguyễn Thiện Mỹ', 'Công nghệ phần mềm'),
(10520196, 'Phan Hoài Quốc', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520197, 'Phạm Vinh', 'Kỹ thuật máy tính'),
(10520198, 'Võ Hồng Phi', 'Khoa học máy tính'),
(10520199, 'Lê Công Tuy', 'Hệ thống thông tin'),
(10520200, 'Nguyễn Quang Sáng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520202, 'Võ Xuân Ngọc', 'Công nghệ phần mềm'),
(10520203, 'Trần Đức Yên', 'Công nghệ phần mềm'),
(10520204, 'Lê Phước Thạch', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520205, 'Huỳnh Văn Thân', 'Công nghệ phần mềm'),
(10520206, 'Nguyễn Nam Khánh', 'Mạng máy tính & truyền thông'),
(10520207, 'Nguyễn Thị Mỹ Dung', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520210, 'Lưu Nguyễn Hữu Đức', 'Công nghệ phần mềm'),
(10520211, 'Lê Tuấn Anh', 'Công nghệ phần mềm'),
(10520212, 'Đào Xuân Hiển', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520213, 'Lê Duy Thành', 'Khoa học máy tính'),
(10520214, 'Trần Anh Dũng', 'Hệ thống thông tin'),
(10520216, 'Đặng Đình Hoàng', 'Công nghệ phần mềm'),
(10520217, 'Nguyễn Công Lý', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520218, 'Hồ Thị Xuân Thơ', 'Mạng máy tính & truyền thông'),
(10520219, 'Phạm Đình Sứng', 'Khoa học máy tính'),
(10520220, 'Lê Văn Hưng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520222, 'Đoàn Văn Thắng', 'Hệ thống thông tin'),
(10520223, 'Nguyễn Đình Phúc', 'Cử nhân tài năng'),
(10520224, 'Lê Văn Sáng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520225, 'Tô Ngọc Khánh', 'Công nghệ phần mềm'),
(10520226, 'Đào Lý Trân', 'Mạng máy tính & truyền thông'),
(10520227, 'Lê Tấn Hào Phú', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520228, 'Nguyễn Thị Bảo Ngọc', 'Cử nhân tài năng'),
(10520229, 'Võ Văn Duyệt', 'Công nghệ phần mềm'),
(10520230, 'Lê Nguyễn Vĩnh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520231, 'Võ Công Sơn', 'Công nghệ phần mềm'),
(10520232, 'Trần Văn Khánh', 'Mạng máy tính & truyền thông'),
(10520233, 'Lê Hữu Phước', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520235, 'Nguyễn Đức Nghị', 'Hệ thống thông tin'),
(10520236, 'Nguyễn Anh Tuấn', 'Mạng máy tính & truyền thông'),
(10520237, 'Phạm Ngọc Ánh', ''),
(10520238, 'Đỗ Đăng Khoa', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520239, 'Trần Trọng Thông', 'Hệ thống thông tin'),
(10520240, 'Nguyễn Thúc Hảo', 'Hệ thống thông tin'),
(10520241, 'Nguyễn Quốc Linh Khang', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520242, 'Lê Quốc Khánh', 'Chương trình tiên tiến'),
(10520243, 'Đặng Văn Bão', 'Khoa học máy tính'),
(10520244, 'Tống Đăng Tuyền', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520245, 'Nguyễn Văn Biên', 'Cử nhân tài năng'),
(10520246, 'Phạm Văn Phong', 'Khoa học máy tính'),
(10520247, 'Hoàng Minh Thắng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520249, 'Nguyễn Thị Minh Hiển', 'Mạng máy tính & truyền thông'),
(10520250, 'Nguyễn Văn Ninh', 'Mạng máy tính & truyền thông'),
(10520251, 'Nguyễn Thái Hà', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520252, 'Trần Đạt', 'Công nghệ phần mềm'),
(10520253, 'Phùng Đức Lâm', ''),
(10520254, 'Phạm Văn Tú', 'Công nghệ phần mềm'),
(10520255, 'Trần Phước Vĩnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520256, 'Lê Đình Trường Sơn', 'Hệ thống thông tin'),
(10520257, 'Trần Phước Thảo', 'Mạng máy tính & truyền thông'),
(10520258, 'Nguyễn Luận', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520259, 'Nguyễn Thanh Tuyến', 'Hệ thống thông tin'),
(10520260, 'Nguyễn Ngọc Sáng', 'Mạng máy tính & truyền thông'),
(10520261, 'Trần Khánh Duy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520262, 'Nguyễn Hoàng Anh', 'Kỹ thuật máy tính'),
(10520263, 'Võ Thành Tâm', 'Mạng máy tính & truyền thông'),
(10520264, 'Trần Như Vĩnh Lộc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520266, 'Bùi Nguyễn Duy Hiếu', 'Công nghệ phần mềm'),
(10520267, 'Trần Quốc Huy', 'Hệ thống thông tin'),
(10520268, 'Nguyễn Đình Hoàng Long', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520269, 'Ngô Lê Minh Quốc', 'Cử nhân tài năng'),
(10520270, 'Nguyễn Thành Tin', 'Hệ thống thông tin'),
(10520271, 'Hoàng Trung Đức', 'Hệ thống thông tin'),
(10520272, 'Lưu Quang Vũ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520273, 'Mai Dương Hoàng Cường', 'Mạng máy tính & truyền thông'),
(10520274, 'Võ Thanh Tòng', 'Hệ thống thông tin'),
(10520275, 'Trịnh Minh Nhật', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520276, 'Trịnh Duy Thành', 'Công nghệ phần mềm'),
(10520277, 'Nguyễn Mai Tuấn Dũng', 'Công nghệ phần mềm'),
(10520278, 'Nguyễn Hồng Phúc', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520279, 'Nguyễn Thanh Tùng', 'Mạng máy tính & truyền thông'),
(10520281, 'Lê Kim Quyền', 'Công nghệ phần mềm'),
(10520282, 'Nguyễn Ngọc Minh Tuấn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520283, 'Trần Đình Vũ', 'Hệ thống thông tin'),
(10520284, 'Nguyễn Đức Cường', 'Cử nhân tài năng'),
(10520285, 'Nguyễn Thị Yến Linh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520287, 'Nguyễn Hoàng Nam', 'Mạng máy tính & truyền thông'),
(10520288, 'Nguyễn Văn Dương', 'Mạng máy tính & truyền thông'),
(10520289, 'Nguyễn Đức Hiếu', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520291, 'Lê Phương Bảo', 'Kỹ thuật máy tính'),
(10520292, 'Phạm Ngọc Dương', 'Công nghệ phần mềm'),
(10520293, 'Đỗ Xuân Lập', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520294, 'Vũ Trọng Tùng', 'Hệ thống thông tin'),
(10520295, 'Nguyễn Trung Tiến', 'Khoa học máy tính'),
(10520296, 'Nguyễn Thanh Bình', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520297, 'Phạm Trung Cương', 'Hệ thống thông tin'),
(10520298, 'Lộc Văn Tiến', 'Kỹ thuật máy tính'),
(10520299, 'Bùi Đức An', 'Hệ thống thông tin'),
(10520300, 'Nguyễn Hồng Cương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520301, 'Phạm Văn Ngọc', 'Mạng máy tính & truyền thông'),
(10520302, 'Bùi Nguyễn Mạnh Cường', 'Công nghệ phần mềm'),
(10520303, 'Đinh Văn Đại', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520304, 'Trần Minh Thành', 'Công nghệ phần mềm'),
(10520305, 'Phạm Cao Thắng', 'Khoa học máy tính'),
(10520306, 'Cao Công Danh', 'Cử nhân tài năng'),
(10520308, 'Hoàng Thanh Huy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520309, 'Trương Minh Châu', 'Kỹ thuật máy tính'),
(10520310, 'Trần Xuân Mạnh', 'Khoa học máy tính'),
(10520311, 'Nguyễn Tấn Thành', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520312, 'Đỗ Văn Tuấn', 'Công nghệ phần mềm'),
(10520313, 'Vũ Nguyên Bình', 'Kỹ thuật máy tính'),
(10520314, 'Trương Ngọc Đạt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520315, 'Nguyễn Thị Hương', 'Hệ thống thông tin'),
(10520316, 'Lê Văn Quang', 'Khoa học máy tính'),
(10520317, 'Đỗ Bá Hưng', 'Hệ thống thông tin'),
(10520318, 'Nguyễn Trọng Nghĩa', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520319, 'Nguyễn Quang Lộc', 'Hệ thống thông tin'),
(10520320, 'Bùi Đức Hưng', 'Hệ thống thông tin'),
(10520321, 'Phan Võ Long Thiên', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520322, 'Đoàn Trần Hoàng', 'Mạng máy tính & truyền thông'),
(10520323, 'Vũ Văn Việt', 'Khoa học máy tính'),
(10520324, 'Lê Thị Thảo', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520325, 'Nguyễn Huy Tuấn', 'Kỹ thuật máy tính'),
(10520326, 'Lê Hoàng Hòa', 'Mạng máy tính & truyền thông'),
(10520327, 'Lê Văn Lê', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520328, 'Phạm Nữ Kiều Duyên', 'Mạng máy tính & truyền thông'),
(10520329, 'Võ Khôi Việt', 'Công nghệ phần mềm'),
(10520330, 'Trần Văn Nam', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520331, 'Nguyễn Tuấn Anh', 'Công nghệ phần mềm'),
(10520332, 'Phạm Thái Hiền', 'Cử nhân tài năng'),
(10520333, 'Ngô Lộc Trà', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520334, 'Huỳnh Đắc Nhân', 'Mạng máy tính & truyền thông'),
(10520336, 'Trần Võ Hảo', 'Kỹ thuật máy tính'),
(10520337, 'Diệp Thế Anh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520338, 'Đỗ Văn Kiên', 'Kỹ thuật máy tính'),
(10520339, 'Nguyễn Minh Tiến', 'Công nghệ phần mềm'),
(10520340, 'Đặng Thanh Duy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520341, 'Vũ Quang Vinh', 'Mạng máy tính & truyền thông'),
(10520342, 'Phạm Hoàng Phú', 'Hệ thống thông tin'),
(10520343, 'Cao Phước Thừa', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520344, 'Trịnh Ngọc Phương Thanh', 'Mạng máy tính & truyền thông'),
(10520345, 'Nguyễn Mạnh Huy', 'Công nghệ phần mềm'),
(10520346, 'Nguyễn Huỳnh Quý Nam', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520347, 'Văn Trung Duy', 'Kỹ thuật máy tính'),
(10520348, 'Trần Minh Hiển', 'Công nghệ phần mềm'),
(10520349, 'Nguyễn Duy Vũ', 'Công nghệ phần mềm'),
(10520350, 'Hồ Ngọc Sơn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520351, 'Đỗ Phạm Tuấn Dũng', 'Hệ thống thông tin'),
(10520352, 'Trần Thị Khánh Nguyên', 'Mạng máy tính & truyền thông'),
(10520353, 'Nguyễn Đức Trung', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520354, 'Nguyễn Tiến Hoàng Linh', 'Mạng máy tính & truyền thông'),
(10520355, 'Cao Văn Nhàn', 'Kỹ thuật máy tính'),
(10520356, 'Phạm Hữu Hoài', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520357, 'Võ Hồng Kha', 'Chương trình tiên tiến'),
(10520358, 'Hồ Nhật Kiên', 'Chương trình tiên tiến'),
(10520359, 'Ngô Kim Phi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520360, 'Phạm Hồng Cẩm', 'Hệ thống thông tin'),
(10520361, 'Trần Mỹ Kim Quân', 'Mạng máy tính & truyền thông'),
(10520362, 'Nguyễn Vĩnh Kim Long', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520363, 'Nguyễn Tiến Phúc', 'Kỹ thuật máy tính'),
(10520364, 'Trần Thanh Liêm', 'Kỹ thuật máy tính'),
(10520365, 'Kiều Lê Hồng Kông', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520367, 'Đào Nguyễn Trung Tín', 'Hệ thống thông tin'),
(10520368, 'Nguyễn Quốc Dũng', 'Khoa học máy tính'),
(10520369, 'Vũ Vương Hiệp', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520371, 'Nguyễn Hùng Mạnh', 'Kỹ thuật máy tính'),
(10520372, 'Phạm Vũ Quốc Vinh', 'Hệ thống thông tin'),
(10520373, 'Lại Hồng Thiên', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520375, 'Nguyễn Hoàng Quân', 'Công nghệ phần mềm'),
(10520376, 'Trần Thái Quốc Bảo', 'Kỹ thuật máy tính'),
(10520377, 'Phạm Minh Triết', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520378, 'Nguyễn Giang Châu', 'Công nghệ phần mềm'),
(10520379, 'Bùi Hoàng Khánh Duy', 'Khoa học máy tính'),
(10520380, 'Lưu Quốc Lương', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520381, 'Cái Huy Quốc Thắng', 'Khoa học máy tính'),
(10520382, 'Võ Thành Long', 'Kỹ thuật máy tính'),
(10520383, 'Ngô Hồng Tín', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520384, 'Nguyễn Chí Hùng', 'Hệ thống thông tin'),
(10520385, 'Lê Phúc', 'Khoa học máy tính'),
(10520386, 'Äáşˇng VĹŠ HáşŁi Long', 'Khoa háťc mĂĄy tĂ­nh');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520387, 'Châu Thịnh Khang', 'Kỹ thuật máy tính'),
(10520388, 'Trần Thanh Trường', 'Mạng máy tính & truyền thông'),
(10520389, 'Võ Ngọc Lâm Sơn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520390, 'Lê Quách Minh Hoàng', 'Kỹ thuật máy tính'),
(10520391, 'Nguyễn Thanh Toàn', 'Kỹ thuật máy tính'),
(10520392, 'Lê Công Ánh', 'Hệ thống thông tin'),
(10520393, 'Vũ Đức Tài', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520394, 'Trịnh Ngọc Huy', 'Công nghệ phần mềm'),
(10520395, 'Nguyễn Phi Hùng', 'Công nghệ phần mềm'),
(10520396, 'Phùng Xuân Trường', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520397, 'Lê Bá Nhựt', 'Kỹ thuật máy tính'),
(10520398, 'Đỗ Thị Duyên', 'Mạng máy tính & truyền thông'),
(10520399, 'Nguyễn Hữu Thọ', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520400, 'Nguyễn Chí Thanh', 'Kỹ thuật máy tính'),
(10520401, 'Vũ Thanh Hòa', 'Mạng máy tính & truyền thông'),
(10520402, 'Nguyễn Thiên Võ', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520403, 'Nguyễn Văn Quyền', 'Hệ thống thông tin'),
(10520404, 'Đoàn Minh Tiến', 'Công nghệ phần mềm'),
(10520405, 'Mai Văn Vương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520406, 'Lê Ngọc Hồng Phúc', 'Hệ thống thông tin'),
(10520407, 'Đinh Duy Linh', 'Hệ thống thông tin'),
(10520408, 'Đoàn Văn Lịch', 'Hệ thống thông tin'),
(10520409, 'Hứa Tuấn Anh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520410, 'Trương Minh Khoa', 'Kỹ thuật máy tính'),
(10520411, 'Tô Hồng Phong', 'Công nghệ phần mềm'),
(10520413, 'Mai Trung Hiếu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520414, 'Trang Huy Hớn', 'Mạng máy tính & truyền thông'),
(10520415, 'Trần Trung Tiến', 'Mạng máy tính & truyền thông'),
(10520416, 'Võ Hoàng Thiện', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520417, 'Trần Công Thành', 'Mạng máy tính & truyền thông'),
(10520418, 'Bùi Hữu Hiệp', 'Công nghệ phần mềm'),
(10520419, 'Nguyễn Hồ Trọng Khoa', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520420, 'Nguyáťn ThĂ nh HĆ°ng', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(10520421, 'Nguyễn Tiến Minh Đăng', 'Kỹ thuật máy tính'),
(10520422, 'Trần Hữu Linh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520423, 'Huỳnh Hồng Hiếu', 'Khoa học máy tính'),
(10520424, 'Phạm Trường An', 'Hệ thống thông tin'),
(10520425, 'Trần Lê Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520426, 'Nguyễn Hồng Ngọc', 'Kỹ thuật máy tính'),
(10520427, 'Nguyễn Văn Quốc Vương', 'Chương trình tiên tiến'),
(10520428, 'Phan Duy Liên Khiết', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520429, 'Mai Chí Thông', 'Mạng máy tính & truyền thông'),
(10520430, 'Vũ Thanh Nguyên', 'Cử nhân tài năng'),
(10520433, 'Phạm Phúc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520434, 'Trần Đình Thi', 'Công nghệ phần mềm'),
(10520436, 'Huỳnh Dương Quy', 'Hệ thống thông tin'),
(10520437, 'TrĆ°ĆĄng ÄÄng Khoa', 'CĂ´ng ngháť pháş§n máťm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520438, 'Nguyễn Anh Trường', 'Hệ thống thông tin'),
(10520439, 'Tống Văn Ngoan', 'Cử nhân tài năng'),
(10520440, 'Nguyễn Văn Phụng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520441, 'Trần Thành Nhân', 'Kỹ thuật máy tính'),
(10520442, 'Bùi Bảo Trân', 'Mạng máy tính & truyền thông'),
(10520443, 'Phạm Đức Mạnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520444, 'Nguyễn Đức Nguyên', 'Hệ thống thông tin'),
(10520445, 'Võ Minh Tâm', 'Mạng máy tính & truyền thông'),
(10520446, 'Phan Thanh Bạo', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520447, 'Tráş§n HoĂ ng ThĂĄi', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(10520448, 'Xa Thị Mỹ Hương', 'Khoa học máy tính'),
(10520449, 'Trương Đức Hòa', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520450, 'Trương Đình Minh Hiếu', 'Mạng máy tính & truyền thông'),
(10520451, 'Vũ Bá Lâm', 'Kỹ thuật máy tính'),
(10520452, 'Trần Minh Trí', 'Chương trình tiên tiến'),
(10520454, 'Chu Văn Nam', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520455, 'Nguyễn Hồng Thái', 'Kỹ thuật máy tính'),
(10520456, 'Ngô Thanh Tuấn', 'Kỹ thuật máy tính'),
(10520457, 'Nguyễn Minh Quân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520458, 'Nguyễn Kim Tín', 'Kỹ thuật máy tính'),
(10520459, 'Trần Vĩnh Nghĩa', 'Công nghệ phần mềm'),
(10520460, 'Nguyễn Đăng Khôi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520461, 'Võ Huỳnh Đức Huy', 'Mạng máy tính & truyền thông'),
(10520462, 'Đoàn Quang Khôi', 'Công nghệ phần mềm'),
(10520463, 'Võ Hiếu Phúc', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520464, 'Ngô Duy Kha', 'Công nghệ phần mềm'),
(10520465, 'Ngô Minh Nguyên', 'Công nghệ phần mềm'),
(10520466, 'Bùi Anh Vinh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520467, 'Nguyễn Đăng Khoa', 'Mạng máy tính & truyền thông'),
(10520468, 'Lê Đoàn Thành Tâm', 'Mạng máy tính & truyền thông'),
(10520470, 'Lâm Sơn Thảo', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520472, 'Nguyễn Minh Quân', 'Kỹ thuật máy tính'),
(10520473, 'Nguyễn Quang Thái', 'Kỹ thuật máy tính'),
(10520474, 'Lê Hoàng Lâm', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520475, 'Lê Hữu Đức', 'Hệ thống thông tin'),
(10520476, 'Trần Hoàng Duy', 'Mạng máy tính & truyền thông'),
(10520477, 'Nguyễn Khánh Phong', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520479, 'Phạm Xuân Việt', 'Kỹ thuật máy tính'),
(10520480, 'Nguyễn Ngọc Thanh Huy', 'Công nghệ phần mềm'),
(10520482, 'Phạm Dương Tuấn Duy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520483, 'Ngô Nhựt Đời', 'Kỹ thuật máy tính'),
(10520484, 'Vương Hoàng Vũ', 'Kỹ thuật máy tính'),
(10520487, 'Äinh VÄn TĂ i', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520488, 'Bùi Thị Mỉnh', 'Khoa học máy tính'),
(10520489, 'Nguyễn Trường Giang', 'Công nghệ phần mềm'),
(10520490, 'Nguyễn Chí Hiếu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520491, 'Nguyễn Thanh Phương', 'Công nghệ phần mềm'),
(10520492, 'Lê Văn Khánh', 'Mạng máy tính & truyền thông'),
(10520493, 'Đặng Khôi Nguyên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520494, 'Trần Hồng Ngân', 'Chương trình tiên tiến'),
(10520495, 'Huỳnh Hiếu Nghĩa', 'Khoa học máy tính'),
(10520496, 'Trần Quang Vinh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520497, 'Nguyễn Tấn Khoa', 'Cử nhân tài năng'),
(10520498, 'Nguyễn Ngọc Bảo Châu', 'Kỹ thuật máy tính'),
(10520499, 'Nguyễn Minh Tuấn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520500, 'Nguyễn Hữu Nhân', 'Kỹ thuật máy tính'),
(10520501, 'Nguyễn Khắc Huy', 'Hệ thống thông tin'),
(10520502, 'Nguyễn Đức Duy', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520503, 'Trần Hoài Minh', 'Công nghệ phần mềm'),
(10520504, 'Trương Nhựt Bình', 'Mạng máy tính & truyền thông'),
(10520505, 'Nguyễn Việt Quốc', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520506, 'Lê Minh Tâm', 'Hệ thống thông tin'),
(10520507, 'Lê Hữu Vinh', 'Khoa học máy tính'),
(10520508, 'Võ Long Triều', 'Hệ thống thông tin'),
(10520509, 'Nguyễn Văn Thái', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520510, 'Tạ Khương Quang', 'Công nghệ phần mềm'),
(10520511, 'Bùi Vũ Khánh Bình', 'Chương trình tiên tiến'),
(10520512, 'Trần Phúc Duy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520513, 'Nguyễn Chí Đang', 'Hệ thống thông tin'),
(10520514, 'Đinh Lê Giang', 'Kỹ thuật máy tính'),
(10520515, 'Thi Quốc Cường', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520516, 'Lê Võ Hữu Trí', 'Công nghệ phần mềm'),
(10520517, 'Phùng Quốc Vương', 'Chương trình tiên tiến'),
(10520518, 'Trần Thái Bình', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520519, 'Lâm Chí Thiện', 'Hệ thống thông tin'),
(10520520, 'Phan Huy Tự', 'Chương trình tiên tiến'),
(10520521, 'Nguyển Hồng Hải Đăng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520522, 'Nguyễn Văn Hiếu', 'Công nghệ phần mềm'),
(10520523, 'Nguyễn Thành Minh', 'Công nghệ phần mềm'),
(10520524, 'Nguyễn Bá Học', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520525, 'Trần Văn Nguyên', 'Cử nhân tài năng'),
(10520526, 'LĂŞ HĂ  Nam', 'Khoa háťc mĂĄy tĂ­nh'),
(10520527, 'Trương Lê Văn Cường', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520528, 'Lê Thị Hường', 'Kỹ thuật máy tính'),
(10520529, 'Đặng Thanh Dũng', 'Khoa học máy tính'),
(10520530, 'Nguyễn Công Quỳnh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520531, 'Nguyễn Công Phúc', 'Hệ thống thông tin'),
(10520532, 'Phạm Văn Thuần', 'Cử nhân tài năng'),
(10520533, 'Lê Văn Lịch', ''),
(10520534, 'Phan Đình Linh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520535, 'Phạm Quốc Thịnh', 'Kỹ thuật máy tính'),
(10520536, 'Trương Văn Nghĩa', 'Hệ thống thông tin'),
(10520537, 'Vũ Duy Mừng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520538, 'Sinh viên thôi học', 'Mạng máy tính & truyền thông'),
(10520539, 'Phan Văn Huy', 'Khoa học máy tính'),
(10520541, 'Lê Văn Thành Trung', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520542, 'Ngô Tấn Tài', 'Khoa học máy tính'),
(10520543, 'Bùi Thị Ngọc Yến', 'Hệ thống thông tin'),
(10520544, 'Huỳnh Nhật Vũ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520545, 'Triệu Đức Văn', 'Kỹ thuật máy tính'),
(10520546, 'Vũ Đức Phong', 'Mạng máy tính & truyền thông'),
(10520547, 'Nguyễn Viết Thắng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520548, 'Hồ Văn Điền', 'Khoa học máy tính'),
(10520549, 'BĂši VÄn Thu', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(10520550, 'Nguyễn Tấn Huy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520551, 'Trương Văn Dũng', 'Khoa học máy tính'),
(10520552, 'Đặng Văn Đảng', 'Mạng máy tính & truyền thông'),
(10520553, 'Nguyễn Vinh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520554, 'Phạm Văn Trường', 'Hệ thống thông tin'),
(10520555, 'Nguyễn Duy Khiêm', 'Khoa học máy tính'),
(10520556, 'Nguyễn Vương Quốc Trung', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520557, 'Trương Văn Hoàng', 'Kỹ thuật máy tính'),
(10520558, 'Đào Văn Quyền', 'Kỹ thuật máy tính'),
(10520559, 'Ngô Minh Quân', 'Cử nhân tài năng'),
(10520561, 'Hoàng Quang Trung', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520563, 'Lê Phước Ái', 'Hệ thống thông tin'),
(10520564, 'Cao Hoàng An', 'Hệ thống thông tin'),
(10520565, 'Nguyễn Thái Ân', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520566, 'Nguyáťn Tháşż Anh', 'Háť tháťng thĂ´ng tin'),
(10520567, 'Lê Ngọc Anh', 'Công nghệ phần mềm'),
(10520568, 'Nguyễn Văn Anh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520569, 'Lê Tuấn Anh', 'Hệ thống thông tin'),
(10520570, 'Hoàng Thế Anh', 'Khoa học máy tính'),
(10520571, 'Lê Công Đức Anh', 'Hệ thống thông tin'),
(10520572, 'Cổ Gia Bảo', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520574, 'Trần Hữu Chinh', 'Chương trình tiên tiến'),
(10520575, 'Võ Thị Trang Châu', 'Hệ thống thông tin'),
(10520576, 'Lại Thế Chính', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520578, 'Nguyễn Tiến Cường', 'Mạng máy tính & truyền thông'),
(10520579, 'Nguyễn Chánh Đông', 'Kỹ thuật máy tính'),
(10520580, 'Lưu Khánh Dương', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520581, 'Hồ Đức Dũng', 'Hệ thống thông tin'),
(10520582, 'Nguyễn Văn Đức', 'Hệ thống thông tin'),
(10520583, 'Trần Trung Đức', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520584, 'Nguyễn Văn Đức', 'Mạng máy tính & truyền thông'),
(10520585, 'Phan Hoài Giang', 'Khoa học máy tính'),
(10520586, 'Nguyễn Trung Hiếu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520587, 'Giang Minh Hiếu', 'Hệ thống thông tin'),
(10520589, 'VĹŠ VÄn HoĂ ng', ''),
(10520591, 'Hoàng Hải Huy', 'Cử nhân tài năng'),
(10520593, 'Phan Duy Hải', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520594, 'Nguyễn Phạm Diễm Hằng', 'Hệ thống thông tin'),
(10520595, 'Trần Xuân Hòa', 'Mạng máy tính & truyền thông'),
(10520596, 'Võ Thái Hòa', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520597, 'Nguyễn Văn Hùng', 'Hệ thống thông tin'),
(10520599, 'Phạm Văn Khôi', 'Cử nhân tài năng'),
(10520600, 'Vương Gia Khánh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520601, 'Nguyễn Thành Liêm', 'Kỹ thuật máy tính'),
(10520602, 'Trần Văn Long', 'Mạng máy tính & truyền thông'),
(10520603, 'Trịnh Khắc Luân', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520604, 'Ngô Thành Lâm', 'Cử nhân tài năng'),
(10520605, 'Trần Minh Lâm', 'Hệ thống thông tin'),
(10520606, 'Huỳnh Chấn Lượng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520608, 'Nguyễn Tài Tấn Lộc', 'Kỹ thuật máy tính'),
(10520610, 'Lê Trọng Lợi', 'Hệ thống thông tin'),
(10520611, 'Nguyễn Quốc Minh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520612, 'Lưu Thúy Ngân', 'Hệ thống thông tin'),
(10520613, 'Nguyễn Xuân Ngọc', 'Hệ thống thông tin'),
(10520615, 'Hồng Minh Nhân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520616, 'Phạm Tấn Nhất', 'Mạng máy tính & truyền thông'),
(10520618, 'Lê Trần Nhật', 'Khoa học máy tính'),
(10520619, 'Phan Đình Phong', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520620, 'Lê Vũ Phương', 'Khoa học máy tính'),
(10520621, 'Trần Thái Phú', 'Khoa học máy tính'),
(10520622, 'Bùi Trọng Phú', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520623, 'Nguyễn Hồng Phúc', 'Mạng máy tính & truyền thông'),
(10520624, 'Nguyễn Văn Phục', 'Mạng máy tính & truyền thông'),
(10520625, 'Nguyễn Nhật Quân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520628, 'Nguyễn Phương Thanh', 'Khoa học máy tính'),
(10520630, 'Huỳnh Văn Thông', 'Hệ thống thông tin'),
(10520631, 'Nguyễn Phước Thạnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520632, 'Trần Thị Mỹ Thú', 'Mạng máy tính & truyền thông'),
(10520633, 'Nguyễn Đăng Trường', 'Hệ thống thông tin'),
(10520634, 'Hoàng Nhật Trường', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520635, 'Huỳnh Vủ Trường', 'Khoa học máy tính'),
(10520636, 'Huỳnh Minh Trí', 'Mạng máy tính & truyền thông'),
(10520637, 'Nguyễn Trọng Tuyên', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520638, 'Tạ Văn Tuyển', 'Mạng máy tính & truyền thông'),
(10520639, 'Bùi Quốc Tuyến', 'Hệ thống thông tin'),
(10520641, 'Lê Thị Ánh Tuyết', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520642, 'Trần Văn Tuấn', 'Hệ thống thông tin'),
(10520643, 'Trần Phúc Tâm', 'Mạng máy tính & truyền thông'),
(10520645, 'Văn Thị Tính', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520646, 'Nguyễn Thanh Tú', 'Hệ thống thông tin'),
(10520648, 'Nguyễn Thanh Viễn', 'Hệ thống thông tin'),
(10520649, 'Nguyễn Trung Việt', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10520650, 'Hoàng Đình Vũ', 'Khoa học máy tính'),
(10520651, 'Võ Trường Vũ', 'Chương trình tiên tiến'),
(10520652, 'Nguyễn Đinh Vũ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720003, 'Nguyeãn Ngoïc Duõng', 'Đào tạo từ xa'),
(10720007, 'Voõ Ñaêng Khoa', 'Đào tạo từ xa'),
(10720019, 'Laâm Thaùi Ngoïc', 'Đào tạo từ xa'),
(10720025, 'Buøi Vónh Phuùc', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720033, 'Ngoâ Thieân Töù', 'Đào tạo từ xa'),
(10720034, 'Vuõ Anh Tuaán', 'Đào tạo từ xa'),
(10720036, 'Löu Phöông  Töôøng', 'Đào tạo từ xa'),
(10720039, 'Voõ Thò Nhö YÙ', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720040, 'Nguyeãn Vieät An', 'Đào tạo từ xa'),
(10720042, 'Ñoøan Tuaán Anh', 'Đào tạo từ xa'),
(10720043, 'Phạm Tuaán Anh', 'Đào tạo từ xa'),
(10720044, 'Huøynh Ngoïc Böûu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720054, 'Tröông Ngoïc Giaøu', 'Đào tạo từ xa'),
(10720058, 'Phaïm Long Khaùnh', 'Đào tạo từ xa'),
(10720059, 'Döông Töû Khoâi', 'Đào tạo từ xa'),
(10720060, 'Ñinh Thò Ngoïc  Kieàu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720061, 'Huøynh Thò  Lanh', 'Đào tạo từ xa'),
(10720062, 'Đỗ Kim Lieân', 'Đào tạo từ xa'),
(10720070, 'Nguyễn Thị Kim Sang', 'Đào tạo từ xa'),
(10720071, 'Ngô Thái Sơn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720073, 'Nguyeãn Chí Taâm', 'Đào tạo từ xa'),
(10720079, 'Leâ Tuaán Vuõ', 'Đào tạo từ xa'),
(10720080, 'Nguyễn Hòang Ba', 'Đào tạo từ xa'),
(10720081, 'Phaïm Chí  Baïn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720082, 'Trònh Quoác Baûo', 'Đào tạo từ xa'),
(10720083, 'Buøi Thò  Chaún', 'Đào tạo từ xa'),
(10720084, 'Phaïm Coâng  Danh', 'Đào tạo từ xa'),
(10720085, 'Taï Thò Beù Dieåm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720094, 'Huøynh Thò Gia Lang', 'Đào tạo từ xa'),
(10720095, 'Phạm Chuùc Linh', 'Đào tạo từ xa'),
(10720101, 'Lâm Thúy Ngân', 'Đào tạo từ xa'),
(10720103, 'Thaùi Thò  Ngoan', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720105, 'Hoà Hoøang Nhaân', 'Đào tạo từ xa'),
(10720107, 'Mai Hoøang Nhi', 'Đào tạo từ xa'),
(10720116, 'Leâ Hoøang Anh Quoác', 'Đào tạo từ xa'),
(10720118, 'Höùa Vaên  Taán', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720120, 'Döông Minh Thanh', 'Đào tạo từ xa'),
(10720122, 'Leâ Thò Phöông  Thaûo', 'Đào tạo từ xa'),
(10720123, 'Traàn Thò Aùnh  Thi', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720124, 'Ngoâ Nguyeãn Höõu Thoïai', 'Đào tạo từ xa'),
(10720125, 'Nguyeãn Ñöùc Thònh', 'Đào tạo từ xa'),
(10720130, 'Traàn Duy Tính', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720133, 'Traàn Thò Huyeàn Trang', 'Đào tạo từ xa'),
(10720139, 'Trònh Thaønh Tuù', 'Đào tạo từ xa'),
(10720141, 'Traàn Quang Vinh', 'Đào tạo từ xa'),
(10720144, 'Nguyeãn Phi Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720148, 'Cao Hoaøng Duy', 'Đào tạo từ xa'),
(10720149, 'Nguyeãn Vaên Ngoïc  Em', 'Đào tạo từ xa'),
(10720152, 'Nguyễn Vũ Hoài', 'Đào tạo từ xa'),
(10720156, 'Nguyeãn Vaên Lôïi', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720158, 'Liêu  Đal', 'Đào tạo từ xa'),
(10720161, 'Đặng Thanh Nhả', 'Đào tạo từ xa'),
(10720164, 'Nguyeãn Phong Phuù', 'Đào tạo từ xa'),
(10720165, 'Đặng Hoàng Phúc', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10720166, 'Voõ Hoàng Thaùi', 'Đào tạo từ xa'),
(10720167, 'Leâ Trung Tính', 'Đào tạo từ xa'),
(10720171, 'Hồ Minh Luân', 'Đào tạo từ xa'),
(10720172, 'Trần Hoàng Linh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730007, 'Mai Quốc  Danh', 'Đào tạo từ xa'),
(10730008, 'Trần Văn  Điềm', 'Đào tạo từ xa'),
(10730011, 'Lê Thanh Dũng', 'Đào tạo từ xa'),
(10730012, 'Tăng Quốc  Dũng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730016, 'Nguyễn Hữu  Hà', 'Đào tạo từ xa'),
(10730020, 'Nguyễn Thị Thu  Hiền', 'Đào tạo từ xa'),
(10730022, 'Phùng Văn Huy', 'Đào tạo từ xa'),
(10730027, 'Đặng Việt  Khởi', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730030, 'Nguyễn Khoa  Mẫn', 'Đào tạo từ xa'),
(10730034, 'Lê Quang  Nguyên', 'Đào tạo từ xa'),
(10730038, 'Phan Văn Quốc', 'Đào tạo từ xa'),
(10730039, 'Võ Anh  Quốc', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730040, 'Nguyễn Hữu  Rôn', 'Đào tạo từ xa'),
(10730044, 'Khúc Mạnh Thảo', 'Đào tạo từ xa'),
(10730046, 'Lê Minh  Thuận', 'Đào tạo từ xa'),
(10730047, 'Lê Thành Thuận', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730048, 'Phan Thị Ngọc Thy', 'Đào tạo từ xa'),
(10730049, 'Lê Minh  Triết', 'Đào tạo từ xa'),
(10730055, 'Huỳnh Công  Vụ', 'Đào tạo từ xa'),
(10730056, 'Phạm Như  Ý', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730058, 'Trần Huỳnh Bảo An', 'Đào tạo từ xa'),
(10730059, 'Nguyễn Thị Ngọc Ân', 'Đào tạo từ xa'),
(10730061, 'Phan Thế Bảo', 'Đào tạo từ xa'),
(10730062, 'Nguyễn Thị Kim Chăm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730063, 'Nguyễn Hữu Chí', 'Đào tạo từ xa'),
(10730064, 'Nguyễn Văn Cường', 'Đào tạo từ xa'),
(10730065, 'Lê Công Duy', 'Đào tạo từ xa'),
(10730066, 'Nguyễn Phan Duy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730067, 'Hồ Thanh Hải', 'Đào tạo từ xa'),
(10730069, 'Bùi Thế Hiển', 'Đào tạo từ xa'),
(10730070, 'Nguyễn Văn Hiếu', 'Đào tạo từ xa'),
(10730071, 'Trần Trung Hiếu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730073, 'Trương Kim Huy', 'Đào tạo từ xa'),
(10730074, 'Nguyễn Phạm Nam Kha', 'Đào tạo từ xa'),
(10730075, 'Từ Phương Khôi', 'Đào tạo từ xa'),
(10730076, 'Nguyễn Hồng Khuyên', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730078, 'Lê Hữu Lộc', 'Đào tạo từ xa'),
(10730079, 'Phạm Thế Lữ', 'Đào tạo từ xa'),
(10730080, 'Nguyễn Văn Nam', 'Đào tạo từ xa'),
(10730081, 'Lê Thị Thanh Nga', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730083, 'Võ Hữu Nghị', 'Đào tạo từ xa'),
(10730084, 'Phạm Toàn Nghị', 'Đào tạo từ xa'),
(10730085, 'Nguyễn Thanh Ngoan', 'Đào tạo từ xa'),
(10730087, 'Phan Thị Như Ngọc', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730088, 'Nguyễn Thái Ngọc', 'Đào tạo từ xa'),
(10730089, 'Phan Nguyễn Hoài Nhân', 'Đào tạo từ xa'),
(10730091, 'Đặng Thị Yến Nhi', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730092, 'Nguyễn Thị Cẩm Nhung', 'Đào tạo từ xa'),
(10730094, 'Nguyễn Thanh Phong', 'Đào tạo từ xa'),
(10730097, 'Trần Thiện Phước', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730098, 'Nguyễn Thị Hồng Phước', 'Đào tạo từ xa'),
(10730099, 'Nguyễn Duy Phương', 'Đào tạo từ xa'),
(10730100, 'Trương Lê Thanh Phương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730102, 'Nguyễn Thị Lệ Quyên', 'Đào tạo từ xa'),
(10730103, 'Trần Minh Tâm', 'Đào tạo từ xa'),
(10730104, 'Lê Minh Tâm', 'Đào tạo từ xa'),
(10730105, 'Nguyễn Huy Thanh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730106, 'Nguyễn Hoàng Thảo', 'Đào tạo từ xa'),
(10730107, 'Đặng Lệ Thi', 'Đào tạo từ xa'),
(10730108, 'Phan Minh Thiện', 'Đào tạo từ xa'),
(10730109, 'Lê Huỳnh Thương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730110, 'Trần Thị Bé Thương', 'Đào tạo từ xa'),
(10730112, 'Phạm Hồng Tiến', 'Đào tạo từ xa'),
(10730113, 'Nguyễn Ngọc Trưng', 'Đào tạo từ xa'),
(10730114, 'Nguyễn Thanh Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730115, 'Nguyễn Thanh Việt', 'Đào tạo từ xa'),
(10730116, 'Phạm Hoàng Vĩnh', 'Đào tạo từ xa'),
(10730117, 'Đặng Xuân Vũ', 'Đào tạo từ xa'),
(10730118, 'Lê Hải Yến', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730120, 'Võ Ngọc Ẩn', 'Đào tạo từ xa'),
(10730122, 'Ngô Tuấn Anh', 'Đào tạo từ xa'),
(10730126, 'Lê Minh  Đạt', 'Đào tạo từ xa'),
(10730127, 'Trần Hữu  Đức', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730129, 'Nguyễn Khánh Duy', 'Đào tạo từ xa'),
(10730130, 'Bùi Lê Hoàng  Giang', 'Đào tạo từ xa'),
(10730132, 'Nguyễn Đức  Hiền', 'Đào tạo từ xa'),
(10730134, 'Lê Duy Hòa', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730138, 'Nguyễn Thị Kim Kha', 'Đào tạo từ xa'),
(10730139, 'Lê Phúc Khánh', 'Đào tạo từ xa'),
(10730140, 'Nguyễn Duy Linh', 'Đào tạo từ xa'),
(10730142, 'Lê Thị Mỹ Lộc', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730143, 'Ngô Thanh Mai', 'Đào tạo từ xa'),
(10730144, 'Trần Thị Ngọc Mai', 'Đào tạo từ xa'),
(10730145, 'Phạm Huy Minh', 'Đào tạo từ xa'),
(10730147, 'Huỳnh Thảo Nghi', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730148, 'Bùi Khánh Nguyên', 'Đào tạo từ xa'),
(10730149, 'Hồ Văn Nhã', 'Đào tạo từ xa'),
(10730151, 'Quản Trọng Nhân', 'Đào tạo từ xa'),
(10730152, 'Nguyễn Phạm An Nhơn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730156, 'Trần Ngọc  Phú', 'Đào tạo từ xa'),
(10730157, 'Lê Minh Anh Phúc', 'Đào tạo từ xa'),
(10730160, 'Nguyễn Trọng  Sang', 'Đào tạo từ xa'),
(10730162, 'Trần Thanh Tâm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730165, 'Nguyễn Long Thăng', 'Đào tạo từ xa'),
(10730169, 'Dương Thị Thanh Thương', 'Đào tạo từ xa'),
(10730170, 'Bùi Trung Tín', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730172, 'Nguyễn Trần Minh  Trí', 'Đào tạo từ xa'),
(10730173, 'Võ Việt  Tú', 'Đào tạo từ xa'),
(10730174, 'Phạm Minh  Tuấn', 'Đào tạo từ xa'),
(10730177, 'Võ Việt  Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730178, 'Tưởng Long Tường', 'Đào tạo từ xa'),
(10730179, 'Võ Trần Thanh  Vân', 'Đào tạo từ xa'),
(10730181, 'Lê Thái  Vinh', 'Đào tạo từ xa'),
(10730185, 'Đoàn Phan Huy Cường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730188, 'Trương Hoài  Nam', 'Đào tạo từ xa'),
(10730189, 'Huỳnh Chiêm Quốc  Tùng', 'Đào tạo từ xa'),
(10730190, 'Huỳnh Ngọc  Mai', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730192, 'Nguyễn Duy  Trường', 'Đào tạo từ xa'),
(10730193, 'Nguyễn Hữu  Trọng', 'Đào tạo từ xa'),
(10730194, 'Nguyễn Ngọc  Thịnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730195, 'Nguyễn Tấn  Thành', 'Đào tạo từ xa'),
(10730196, 'Đỗ Phi  Tú', 'Đào tạo từ xa'),
(10730200, 'Trịnh Khiết  Mảnh', 'Đào tạo từ xa'),
(10730202, 'Lê Quang  Hưng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730203, 'Trương Thị Ngọc  Hân', 'Đào tạo từ xa'),
(10730205, 'Đặng Hữu  Huy', 'Đào tạo từ xa'),
(10730207, 'Nguyễn Văn  Vinh', 'Đào tạo từ xa'),
(10730208, 'Nguyễn Thị  Chinh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730211, 'Nguyễn Đức  Dĩnh', 'Đào tạo từ xa'),
(10730213, 'Phan Thanh  Hải', 'Đào tạo từ xa'),
(10730214, 'Nguyễn Đình  Hiến', 'Đào tạo từ xa'),
(10730216, 'Lê Trần Ngọc Hùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730218, 'Nguyễn Cao  Huy', 'Đào tạo từ xa'),
(10730219, 'Nguyễn Huỳnh  Khanh', 'Đào tạo từ xa'),
(10730222, 'Lê Thái  Sơn', 'Đào tạo từ xa'),
(10730224, 'Nguyễn Đức  Thịnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730225, 'Lê Thị Ngọc  Trân', 'Đào tạo từ xa'),
(10730226, 'Mai Văn  Trường', 'Đào tạo từ xa'),
(10730228, 'Nguyễn Anh Tú', 'Đào tạo từ xa'),
(10730229, 'Võ Phương  Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730231, 'Trương Hồng  Yến', 'Đào tạo từ xa'),
(10730233, 'Trần Đạt', 'Đào tạo từ xa'),
(10730234, 'Phan Ngọc Diệp', 'Đào tạo từ xa'),
(10730237, 'Nguyễn Văn Huyền Em', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730238, 'Nguyễn Trường Giang', 'Đào tạo từ xa'),
(10730239, 'Nguyễn Long Hải', 'Đào tạo từ xa'),
(10730240, 'Phan Đức Hậu', 'Đào tạo từ xa'),
(10730242, 'Nguyễn Thị Ngọc Hiển', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730243, 'Nguyễn Mạnh Hiếu', 'Đào tạo từ xa'),
(10730244, 'Nguyễn Tiến Hữu', 'Đào tạo từ xa'),
(10730245, 'Huỳnh Tâm Khánh', 'Đào tạo từ xa'),
(10730246, 'Lê Văn Kiếm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730252, 'Nguyễn Minh Nhật', 'Đào tạo từ xa'),
(10730254, 'Lê Văn Quốc', 'Đào tạo từ xa'),
(10730256, 'Nguyễn Thành Sang', 'Đào tạo từ xa'),
(10730257, 'Trương Hoàng Tâm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730262, 'Nguyễn Kiều Phương Thảo', 'Đào tạo từ xa'),
(10730263, 'Trần Kim Thi', 'Đào tạo từ xa'),
(10730265, 'Phan Văn Trắng', 'Đào tạo từ xa'),
(10730269, 'Võ Hoàng Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730270, 'Nguyễn Thanh  Tâm', 'Đào tạo từ xa'),
(10730271, 'Nguyễn Tuấn  Anh', 'Đào tạo từ xa'),
(10730272, 'Nguyễn Duy Thanh Bảo', 'Đào tạo từ xa'),
(10730275, 'Trần Việt Cường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730280, 'Lưu Tấn Minh Dũng', 'Đào tạo từ xa'),
(10730282, 'Nguyễn Thái Việt Dũng', 'Đào tạo từ xa'),
(10730285, 'Lê Văn Hải', 'Đào tạo từ xa'),
(10730287, 'Nguyễn Khắc Hiếu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730288, 'Lê Xuân Hổ', 'Đào tạo từ xa'),
(10730290, 'Võ Minh  Huấn', 'Đào tạo từ xa'),
(10730292, 'Bùi Văn Hữu', 'Đào tạo từ xa'),
(10730295, 'Ngô Quốc Bảo Kỳ', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730296, 'Nguyễn Khắc  Lâm', 'Đào tạo từ xa'),
(10730297, 'Ngô Văn  Lượng', 'Đào tạo từ xa'),
(10730298, 'Trần Bình Minh', 'Đào tạo từ xa'),
(10730299, 'Trần Tuấn Minh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730302, 'Đinh Tấn Trọng  Nghĩa', 'Đào tạo từ xa'),
(10730304, 'Huỳnh Đức  Nhân', 'Đào tạo từ xa'),
(10730306, 'Nguyễn Thế Phiệt', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730307, 'Phù Mỹ Phượng', 'Đào tạo từ xa'),
(10730308, 'Ngô Phước  Quả', 'Đào tạo từ xa'),
(10730309, 'Phùng Đức Vũ  Quân', 'Đào tạo từ xa'),
(10730313, 'Trương Minh Tài', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730314, 'Nguyễn  Thanh', 'Đào tạo từ xa'),
(10730315, 'Phan Thị Phương  Thảo', 'Đào tạo từ xa'),
(10730316, 'Bùi Xuân  Tiến', 'Đào tạo từ xa'),
(10730317, 'Lương Trần Tín', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730319, 'Huỳnh Công  Trung', 'Đào tạo từ xa'),
(10730321, 'Ngô Vĩnh Tường', 'Đào tạo từ xa'),
(10730323, 'Nguyễn Vương Vũ', 'Đào tạo từ xa'),
(10730325, 'Phạm Thị Thư Y', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730326, 'Phạm Thị  Yến', 'Đào tạo từ xa'),
(10730327, 'Nguyễn Phúc Thiên Ân', 'Đào tạo từ xa'),
(10730330, 'Nguyễn Văn  Hậu', 'Đào tạo từ xa'),
(10730334, 'Nguyễn Hồng Khánh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730335, 'Nguyễn Hà Khánh', 'Đào tạo từ xa'),
(10730339, 'Phạm Hoàng  Long', 'Đào tạo từ xa'),
(10730341, 'Đỗ Thanh Nam', 'Đào tạo từ xa'),
(10730343, 'Nguyễn Tấn  Phi', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730349, 'Đào Minh Sơn', 'Đào tạo từ xa'),
(10730352, 'Bùi Trọng Tiến', 'Đào tạo từ xa'),
(10730358, 'Dư Huỳnh An  Lay', 'Đào tạo từ xa'),
(10730359, 'Nguyễn Thanh  Luân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730361, 'Nguyễn Hoàng Phúc', 'Đào tạo từ xa'),
(10730366, 'Công Nguyễn Hoàng  Bảo', 'Đào tạo từ xa'),
(10730367, 'Phạm Cao  Cường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730370, 'Võ Hoàng Lý  Hải', 'Đào tạo từ xa'),
(10730374, 'Lê Nguyễn Huỳnh  Liên', 'Đào tạo từ xa'),
(10730376, 'Vy Danh  Mẫn', 'Đào tạo từ xa'),
(10730389, 'Lê Thị Quỳnh Châu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730392, 'Lê Trường Giang', 'Đào tạo từ xa'),
(10730394, 'Lê Thị Ngọc Hân', 'Đào tạo từ xa'),
(10730399, 'Huỳnh Thị Hoàng Linh', 'Đào tạo từ xa'),
(10730400, 'Nguyễn Thành Luân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730402, 'Trần Việt Nam', 'Đào tạo từ xa'),
(10730403, 'Phạm Thanh Nhân', 'Đào tạo từ xa'),
(10730405, 'Nguyễn Hữu Tài', 'Đào tạo từ xa'),
(10730407, 'Nguyễn Đình Thuần', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730408, 'Võ Hoàng Thương', 'Đào tạo từ xa'),
(10730411, 'Lê Trần Trọng Cần', 'Đào tạo từ xa'),
(10730414, 'Lương Trọng Nghĩa', 'Đào tạo từ xa'),
(10730438, 'Lê Thành Hải', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730442, 'Nguyễn Nguyên Khiếu', 'Đào tạo từ xa'),
(10730444, 'Phạm Đăng  Vũ', 'Đào tạo từ xa'),
(10730445, 'Võ Phụng Minh', 'Đào tạo từ xa'),
(10730446, 'Đinh Tấn  Huy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730448, 'Nguyễn Quốc Trí', 'Đào tạo từ xa'),
(10730453, 'Hoàng Tú Việt', 'Đào tạo từ xa'),
(10730455, 'Nguyễn Phương Cường', 'Đào tạo từ xa'),
(10730456, 'Vũ Việt Hưng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730465, 'Trần Huy  Hoàng', 'Đào tạo từ xa'),
(10730466, 'Nguyễn Quốc  Hùng', 'Đào tạo từ xa'),
(10730469, 'Đặng Văn  Khuyến', 'Đào tạo từ xa'),
(10730478, 'Nguyễn Minh  Tấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730479, 'Dương Quốc  Thắng', 'Đào tạo từ xa'),
(10730483, 'Trương Nhật Đăng', 'Đào tạo từ xa'),
(10730484, 'Nguyễn Ngọc  Huy', 'Đào tạo từ xa'),
(10730487, 'Mai Hoàng  Nhân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(10730489, 'Nguyễn Ngọc Tiệp', 'Đào tạo từ xa'),
(11020001, 'Hoàng Ngọc Anh', 'Đào tạo từ xa'),
(11020002, 'Hoàng Trần Tuấn Anh', 'Đào tạo từ xa'),
(11020003, 'Nguyễn Thế Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020004, 'Nguyễn Tiến Anh', 'Đào tạo từ xa'),
(11020005, 'Nguyễn Tuấn Anh', 'Đào tạo từ xa'),
(11020006, 'Phạm Tuấn Anh', 'Đào tạo từ xa'),
(11020007, 'Tô Thị Nguyệt Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020008, 'Trần Xuân Anh', 'Đào tạo từ xa'),
(11020009, 'Trương Lê Anh', 'Đào tạo từ xa'),
(11020010, 'Uông Duy Anh', 'Đào tạo từ xa'),
(11020011, 'Triệu Văn Chính', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020012, 'Hoàng Thị  Chuyên', 'Đào tạo từ xa'),
(11020013, 'Vi Văn Chuyền', 'Đào tạo từ xa'),
(11020014, 'Ngô Hữu  Công', 'Đào tạo từ xa'),
(11020015, 'Nguyễn Văn Cường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020016, 'Lê Phạm Đại', 'Đào tạo từ xa'),
(11020017, 'Vũ Văn Đại', 'Đào tạo từ xa'),
(11020018, 'Lại Văn Danh', 'Đào tạo từ xa'),
(11020019, 'Trần Xuân Đạt', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020020, 'Vi Hoàng Đạt', 'Đào tạo từ xa'),
(11020021, 'Vũ Thành Đạt', 'Đào tạo từ xa'),
(11020022, 'Phạm Văn  Định', 'Đào tạo từ xa'),
(11020023, 'Nguyễn Văn Du', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020024, 'Phạm Văn  Đức', 'Đào tạo từ xa'),
(11020025, 'Trương Trung Đức', 'Đào tạo từ xa'),
(11020026, 'Lã Thị Kim Dung', 'Đào tạo từ xa'),
(11020027, 'Lê Đình  Dung', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020028, 'Bành Minh Dũng', 'Đào tạo từ xa'),
(11020029, 'Lã Hoàng Dũng', 'Đào tạo từ xa'),
(11020030, 'Đỗ Hoàng Dương', 'Đào tạo từ xa'),
(11020031, 'Lê Anh  Dương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020032, 'Nguyễn Văn Dương', 'Đào tạo từ xa'),
(11020033, 'Vũ Văn Dương', 'Đào tạo từ xa'),
(11020034, 'Nguyễn Thế Duyệt', 'Đào tạo từ xa'),
(11020035, 'Đặng Đình Hà', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020036, 'Đậu Thị  Hà', 'Đào tạo từ xa'),
(11020037, 'Đỗ  Ngọc Hà', 'Đào tạo từ xa'),
(11020038, 'Lê Thị Thu Hà', 'Đào tạo từ xa'),
(11020040, 'Nguyễn Xuân Hai', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020041, 'Đỗ Sơn Hải', 'Đào tạo từ xa'),
(11020043, 'Nguyễn Văn Hậu', 'Đào tạo từ xa'),
(11020044, 'Nguyễn  Thị  Hiên', 'Đào tạo từ xa'),
(11020046, 'Nguyễn Thị  Hiền', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020047, 'Đinh Trung Hiếu', 'Đào tạo từ xa'),
(11020048, 'Vũ Đức Hiếu', 'Đào tạo từ xa'),
(11020049, 'Nguyễn Hòa', 'Đào tạo từ xa'),
(11020050, 'Bùi Văn  Hoàng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020051, 'Đỗ Huy Hoàng', 'Đào tạo từ xa'),
(11020053, 'Phạm Ngọc Hoàng', 'Đào tạo từ xa'),
(11020054, 'Phạm Đức Huấn', 'Đào tạo từ xa'),
(11020055, 'Chu Sơn Hùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020056, 'Nguyễn Mạnh Hùng', 'Đào tạo từ xa'),
(11020057, 'Nguyễn Tiến Hùng', 'Đào tạo từ xa'),
(11020058, 'Phạm Hữu Hùng', 'Đào tạo từ xa'),
(11020059, 'Bùi Đình Hưng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020060, 'Đỗ Văn  Hưng', 'Đào tạo từ xa'),
(11020061, 'Đoàn Đức Hưng', 'Đào tạo từ xa'),
(11020062, 'Nguyễn Thị Thanh Hương', 'Đào tạo từ xa'),
(11020064, 'Nguyễn Thị Hường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020065, 'Tạ Thị  Hường', 'Đào tạo từ xa'),
(11020066, 'Nguyễn Quốc Huy', 'Đào tạo từ xa'),
(11020067, 'Trần Xuân Huy', 'Đào tạo từ xa'),
(11020069, 'Bùi Văn Khánh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020070, 'Nguyễn Ngọc Khánh', 'Đào tạo từ xa'),
(11020071, 'Triệu Văn Kiên', 'Đào tạo từ xa'),
(11020072, 'Lương Văn Lâm', 'Đào tạo từ xa'),
(11020073, 'Âu Thị Lan', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020074, 'Nguyễn Phương Lan', 'Đào tạo từ xa'),
(11020075, 'Đinh Xuân  Lập', 'Đào tạo từ xa'),
(11020076, 'Nguyễn Thị  Liên', 'Đào tạo từ xa'),
(11020077, 'Tạ Thị  Liên', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020078, 'Đàm Văn Linh', 'Đào tạo từ xa'),
(11020079, 'Hoàng Đại Linh', 'Đào tạo từ xa'),
(11020080, 'Nguyễn Tiến Linh', 'Đào tạo từ xa'),
(11020081, 'Vũ Đức Tuấn Linh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020082, 'Hà Ngọc Loan', 'Đào tạo từ xa'),
(11020083, 'Nguyễn Văn Lợi', 'Đào tạo từ xa'),
(11020084, 'Hoàng Hải Long', 'Đào tạo từ xa'),
(11020087, 'Lê Thành Luân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020088, 'Trần Văn   Luyện', 'Đào tạo từ xa'),
(11020089, 'Phạm Văn  Mạnh', 'Đào tạo từ xa'),
(11020090, 'Đỗ Trà Mi', 'Đào tạo từ xa'),
(11020091, 'Kiều Hồng Minh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020092, 'Bùi Thị Diễm My', 'Đào tạo từ xa'),
(11020093, 'Ngô Thị Hà My', 'Đào tạo từ xa'),
(11020094, 'Lương Ngọc Nam', 'Đào tạo từ xa'),
(11020095, 'Nguyễn Hoàng Nam', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020096, 'Nguyễn Thành Nam', 'Đào tạo từ xa'),
(11020097, 'Phạm Hoàng Nam', 'Đào tạo từ xa'),
(11020098, 'Quách Giang Nam', 'Đào tạo từ xa'),
(11020099, 'Hà Hoàn Nghĩa', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020100, 'Nguyễn Trọng Nghĩa', 'Đào tạo từ xa'),
(11020102, 'Lưu Thị Nương Nương', 'Đào tạo từ xa'),
(11020103, 'Lý Nam Phong', 'Đào tạo từ xa'),
(11020104, 'Trần  Nhật Phong', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020105, 'Đào Văn Phúc', 'Đào tạo từ xa'),
(11020106, 'Triệu Đức Phương', 'Đào tạo từ xa'),
(11020107, 'Đỗ Kim Phượng', 'Đào tạo từ xa'),
(11020108, 'Trần Thanh Quang', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020109, 'Nguyễn Viết Quảng', 'Đào tạo từ xa'),
(11020110, 'Hoàng Chí Soát', 'Đào tạo từ xa'),
(11020111, 'Lê Văn Tài', 'Đào tạo từ xa'),
(11020112, 'Đinh Thanh Thắng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020113, 'Huỳnh Trọng  Thắng', 'Đào tạo từ xa'),
(11020114, 'Lê Huy Thắng', 'Đào tạo từ xa'),
(11020115, 'Vũ Chí Thanh', 'Đào tạo từ xa'),
(11020116, 'Nguyễn Thị Thảo', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020117, 'Phạm Thị Thảo', 'Đào tạo từ xa'),
(11020118, 'Nguyễn Trọng Thịnh', 'Đào tạo từ xa'),
(11020119, 'Mông Trí  Thọ', 'Đào tạo từ xa'),
(11020120, 'Nguyễn Thị Kim Thoa', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020121, 'Nguyễn Văn Thông', 'Đào tạo từ xa'),
(11020122, 'Phạm Thị Lệ Thư', 'Đào tạo từ xa'),
(11020123, 'Lò Văn Thuận', 'Đào tạo từ xa'),
(11020124, 'Ngô Văn Thuận', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020125, 'Hoàng Văn  Thực', 'Đào tạo từ xa'),
(11020126, 'Nguyễn Đức  Tiệp', 'Đào tạo từ xa'),
(11020127, 'Bùi Thúy Tỉnh', 'Đào tạo từ xa'),
(11020128, 'Đỗ Khắc Toàn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020130, 'Nguyễn Thị  Trâm', 'Đào tạo từ xa'),
(11020132, 'Nguyễn Ngọc Trí', 'Đào tạo từ xa'),
(11020133, 'Hà Quang  Trung', 'Đào tạo từ xa'),
(11020134, 'Lưu  Tuấn Tú', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020135, 'Phạm Thị Nguyệt Tú', 'Đào tạo từ xa'),
(11020136, 'Trần Đình Tú', 'Đào tạo từ xa'),
(11020137, 'Đào Minh Tuấn', 'Đào tạo từ xa'),
(11020138, 'Nguyễn Anh Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020139, 'Nguyễn Văn Tuấn', 'Đào tạo từ xa'),
(11020140, 'Đỗ Thanh Tùng', 'Đào tạo từ xa'),
(11020141, 'Nguyễn Thanh Tùng', 'Đào tạo từ xa'),
(11020142, 'Nguyễn Xuân Tùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020143, 'Nguyễn Quang Tuyền', 'Đào tạo từ xa'),
(11020144, 'Tạ Văn  Tuyền', 'Đào tạo từ xa'),
(11020145, 'Bùi Thị Tuyết', 'Đào tạo từ xa'),
(11020146, 'Nguyễn Thị Vân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020147, 'Nguyễn Thị Vân', 'Đào tạo từ xa'),
(11020148, 'Trần Thị Vân', 'Đào tạo từ xa'),
(11020149, 'Nguyễn Tuấn Vũ', 'Đào tạo từ xa'),
(11020150, 'Trịnh Văn Vũ', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020151, 'Nguyễn Duy Vượng', 'Đào tạo từ xa'),
(11020152, 'Trần Văn   Xuân', 'Đào tạo từ xa'),
(11020153, 'Phạm Trung Anh', 'Đào tạo từ xa'),
(11020154, 'Hoàng Đình Du', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020155, 'Nguyễn Văn Đức', 'Đào tạo từ xa'),
(11020156, 'Lê Tiến Dũng', 'Đào tạo từ xa'),
(11020157, 'Hoàng  Hải', 'Đào tạo từ xa'),
(11020158, 'Nguyễn Chiến Hào', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020159, 'Kiều Duy  Khánh', 'Đào tạo từ xa'),
(11020160, 'Trần Quang Lãm', 'Đào tạo từ xa'),
(11020161, 'Trần Quang Long', 'Đào tạo từ xa'),
(11020162, 'Mã Thị Ly', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11020163, 'Lê  Việt Phương', 'Đào tạo từ xa'),
(11020165, 'Phàn Lão San', 'Đào tạo từ xa'),
(11020166, 'Đỗ Thế Sơn', 'Đào tạo từ xa'),
(11030028, 'Nguyễn Hoàng Nam', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11030029, 'Đồng Văn Nam', 'Đào tạo từ xa'),
(11030030, 'Phạm Văn Nghĩa', 'Đào tạo từ xa'),
(11030031, 'Nguyễn Thanh Quang', 'Đào tạo từ xa'),
(11030032, 'Vương Đình Quyết', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11030033, 'Nguyễn Mậu Sơn', 'Đào tạo từ xa'),
(11030034, 'Bùi Văn Tâm', 'Đào tạo từ xa'),
(11030035, 'Bùi Tiến Thắng', 'Đào tạo từ xa'),
(11030036, 'Đinh Quang Thành', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11030037, 'Lành Trung Thông', 'Đào tạo từ xa'),
(11030038, 'Ngô Văn Thuận', 'Đào tạo từ xa'),
(11030039, 'Nguyễn Văn Trường', 'Đào tạo từ xa'),
(11030040, 'Phạm Thanh Tùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11030041, 'Tô Duy Tùng', 'Đào tạo từ xa'),
(11030042, 'Nguyễn Phúc Tùng', 'Đào tạo từ xa'),
(11030043, 'Hoàng Đình Tùng', 'Đào tạo từ xa'),
(11030044, 'Lương Văn Tưởng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11030045, 'Nguyễn Ngọc Xuân', 'Đào tạo từ xa'),
(11040002, 'Nguyễn Thị Ngọc Ánh', 'Đào tạo từ xa'),
(11040003, 'Phạm Thị Anh', 'Đào tạo từ xa'),
(11040004, 'Hoàng Hải Bằng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040006, 'Bùi Huy Chiến', 'Đào tạo từ xa'),
(11040007, 'Lưu Việt Công', 'Đào tạo từ xa'),
(11040008, 'Nguyễn Thành Công', 'Đào tạo từ xa'),
(11040014, 'Vũ Hữu Đạt', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040015, 'Đồng Văn Điền', 'Đào tạo từ xa'),
(11040017, 'Phạm Văn Điệp', 'Đào tạo từ xa'),
(11040018, 'Nguyễn Sỹ Đức', 'Đào tạo từ xa'),
(11040019, 'Vũ Thị Dung', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040020, 'Nguyễn Thị Dung', 'Đào tạo từ xa'),
(11040021, 'Bùi Tiến Dũng', 'Đào tạo từ xa'),
(11040022, 'Vũ Văn Dũng', 'Đào tạo từ xa'),
(11040023, 'Trần Hoàng Dương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040024, 'Đặng Danh Hoàng Duy', 'Đào tạo từ xa'),
(11040025, 'Nguyễn Đức Duy', 'Đào tạo từ xa'),
(11040029, 'Đỗ Thị Ngọc Hà', 'Đào tạo từ xa'),
(11040032, 'Vũ Duy Hải', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040036, 'Vũ Văn Hiệp', 'Đào tạo từ xa'),
(11040038, 'Đào Quang Hiếu', 'Đào tạo từ xa'),
(11040039, 'Tạ Thành Hiếu', 'Đào tạo từ xa'),
(11040041, 'Đinh Đăng Hoàng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040042, 'Phạm Thị Thu Hồng', 'Đào tạo từ xa'),
(11040044, 'Phan Thị Thu Hương', 'Đào tạo từ xa'),
(11040045, 'Đoàn Văn Huy', 'Đào tạo từ xa'),
(11040048, 'Bùi Phú Khánh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040049, 'Nguyễn Duy Khánh', 'Đào tạo từ xa'),
(11040051, 'Nguyễn Văn Khoát', 'Đào tạo từ xa'),
(11040054, 'Nguyễn Hoàng Linh', 'Đào tạo từ xa'),
(11040055, 'Mai Thế Lợi', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040058, 'Nguyễn Trọng Minh', 'Đào tạo từ xa'),
(11040059, 'Trần Minh', 'Đào tạo từ xa'),
(11040066, 'Trịnh Đức Phong', 'Đào tạo từ xa'),
(11040067, 'Trần Mạnh Phương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040071, 'Bùi Đức Quyết', 'Đào tạo từ xa'),
(11040072, 'Lê Xuân Quyết', 'Đào tạo từ xa'),
(11040079, 'Nguyễn Văn Thạo', 'Đào tạo từ xa'),
(11040080, 'Bùi Quang Thìn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040081, 'Nguyễn Bùi Thịnh', 'Đào tạo từ xa'),
(11040082, 'Trần Thị Thơm Thơm', 'Đào tạo từ xa'),
(11040084, 'Đinh Thị Thùy', 'Đào tạo từ xa'),
(11040085, 'Vũ Thị Bích Thủy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040087, 'Trần Văn Tiến', 'Đào tạo từ xa'),
(11040090, 'Trần Mạnh Trung', 'Đào tạo từ xa'),
(11040092, 'Ngô Xuân Tư', 'Đào tạo từ xa'),
(11040093, 'Trần Xuân Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040095, 'Trịnh Văn Tùng', 'Đào tạo từ xa'),
(11040096, 'Nguyễn Hữu Uy', 'Đào tạo từ xa'),
(11040097, 'Trần Văn Vĩ', 'Đào tạo từ xa'),
(11040099, 'Đồng Phạm Hoàng Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11040101, 'Đặng Duy Tiến', 'Đào tạo từ xa'),
(11100002, 'Nguyễn Tuấn Anh', 'Đào tạo từ xa'),
(11100004, 'Vũ Văn  Bảo', 'Đào tạo từ xa'),
(11100005, 'Phạm Văn Chính', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100006, 'Lương Viết Đại', 'Đào tạo từ xa'),
(11100009, 'Trần Thị Đượm', 'Đào tạo từ xa'),
(11100011, 'Nguyễn Thế Duy', 'Đào tạo từ xa'),
(11100012, 'Phạm Đức Duy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100013, 'Nguyễn Hữu Giáp', 'Đào tạo từ xa'),
(11100014, 'Phùng Mạnh Hà', 'Đào tạo từ xa'),
(11100017, 'Bùi Quang  Hưng', 'Đào tạo từ xa'),
(11100018, 'Bùi Văn Khải', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100019, 'Nguyễn Đăng Khoa', 'Đào tạo từ xa'),
(11100020, 'Vũ Văn  Lâm', 'Đào tạo từ xa'),
(11100021, 'Hoàng Văn Long', 'Đào tạo từ xa'),
(11100023, 'Lê Xuân Ngọc', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100024, 'Vũ Đình Phong', 'Đào tạo từ xa'),
(11100028, 'Cao Văn Sơn', 'Đào tạo từ xa'),
(11100029, 'Đào Nguyên Sơn', 'Đào tạo từ xa'),
(11100030, 'Lê Quý Tài', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100034, 'Đoàn Duy Thành', 'Đào tạo từ xa'),
(11100035, 'Nguyễn Hồng  Thinh', 'Đào tạo từ xa'),
(11100036, 'Nguyễn Hữu Thịnh', 'Đào tạo từ xa'),
(11100037, 'Lê Ngọc Thương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100039, 'Nguyễn Văn Tú', 'Đào tạo từ xa'),
(11100041, 'Nguyễn Ngọc Tùng', 'Đào tạo từ xa'),
(11100042, 'Nguyễn Văn Tùng', 'Đào tạo từ xa'),
(11100044, 'Nguyễn Thanh Tùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100045, 'Đỗ Ngọc Tuyên', 'Đào tạo từ xa'),
(11100049, 'Nguyễn Hồng  Vinh', 'Đào tạo từ xa'),
(11100083, 'Bùi Tuấn  Anh', 'Đào tạo từ xa'),
(11100084, 'Đoàn Đức  Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100087, 'Phạm Hoàng  Đại', 'Đào tạo từ xa'),
(11100091, 'Vũ Đình  Dũng', 'Đào tạo từ xa'),
(11100092, 'Vũ Trọng  Dũng', 'Đào tạo từ xa'),
(11100093, 'Phạm Ngọc Tuấn  Dương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100095, 'Nguyễn Trung  Duy', 'Đào tạo từ xa'),
(11100096, 'Đỗ Văn  Duy', 'Đào tạo từ xa'),
(11100097, 'Dương Hồng  Hà', 'Đào tạo từ xa'),
(11100098, 'Nguyễn Thị  Hà', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100099, 'Lê Khắc  Hải', 'Đào tạo từ xa'),
(11100100, 'Dương Thị Thu  Hiển', 'Đào tạo từ xa'),
(11100101, 'Trần Minh  Hoàng', 'Đào tạo từ xa'),
(11100102, 'Bùi Hữu  Hợp', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100105, 'Hoàng Văn  Huy', 'Đào tạo từ xa'),
(11100108, 'Đặng Duy  Khánh', 'Đào tạo từ xa'),
(11100109, 'Đinh Hải  Lâm', 'Đào tạo từ xa'),
(11100110, 'Lê Văn  Mạnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100111, 'Nguyễn Thị  Mười', 'Đào tạo từ xa'),
(11100114, 'Đỗ Thị  Oanh', 'Đào tạo từ xa'),
(11100115, 'Trần Minh  Phương', 'Đào tạo từ xa'),
(11100116, 'Đoàn Văn  Quang', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100117, 'Nguyễn Hữu  Quyết', 'Đào tạo từ xa'),
(11100118, 'Nguyễn Ngọc  Soái', 'Đào tạo từ xa'),
(11100120, 'Nguyễn Hoàng  Sơn', 'Đào tạo từ xa'),
(11100121, 'Bùi Mạnh  Sỹ', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100124, 'Đoàn Thị Thu  Thảo', 'Đào tạo từ xa'),
(11100125, 'Bùi Đặng  Thiêm', 'Đào tạo từ xa'),
(11100126, 'Phạm Bá  Trung', 'Đào tạo từ xa'),
(11100128, 'Đinh Như  Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100129, 'Phan Thanh  Tùng', 'Đào tạo từ xa'),
(11100130, 'Nguyễn Thanh  Tùng', 'Đào tạo từ xa'),
(11100131, 'Trần Thanh  Tùng', 'Đào tạo từ xa'),
(11100134, 'Phạm Hồng  Vương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100135, 'Hoàng Gia  Vượng', 'Đào tạo từ xa'),
(11100136, 'Nguyễn Tuấn  Anh', 'Đào tạo từ xa'),
(11100137, 'Đào Xuân  Chiến', 'Đào tạo từ xa'),
(11100138, 'Bùi Đình  Chiến', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100139, 'Trần Văn  Chung', 'Đào tạo từ xa'),
(11100140, 'Bùi Văn  Diệp', 'Đào tạo từ xa'),
(11100141, 'Lê Anh  Đức', 'Đào tạo từ xa'),
(11100142, 'Nguyễn Huy  Đức', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100143, 'Phạm Mạnh  Đức', 'Đào tạo từ xa'),
(11100144, 'Phan Thành Dũng', 'Đào tạo từ xa'),
(11100145, 'Tạ Thị Thu Hà', 'Đào tạo từ xa'),
(11100146, 'Vũ Ngọc  Hải', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100148, 'Nguyễn Bá  Hùng', 'Đào tạo từ xa'),
(11100149, 'Lương Minh  Hưng', 'Đào tạo từ xa'),
(11100150, 'Nguyễn Xuân  Khánh', 'Đào tạo từ xa'),
(11100152, 'Nguyễn Đức  Lộc', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100153, 'Phó Thị Kiều  My', 'Đào tạo từ xa'),
(11100154, 'Đỗ Thị  Nga', 'Đào tạo từ xa'),
(11100155, 'Nguyễn Thái  Ngọc', 'Đào tạo từ xa'),
(11100156, 'Nguyễn Văn  Như', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100157, 'Bùi Đình  Phong', 'Đào tạo từ xa'),
(11100158, 'Hoàng Trọng  Quyền', 'Đào tạo từ xa'),
(11100159, 'Vũ Hoàng  Sơn', 'Đào tạo từ xa'),
(11100160, 'Hoàng Văn  Sơn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100162, 'Nguyễn Chiến  Thắng', 'Đào tạo từ xa'),
(11100163, 'Phạm Việt  Thắng', 'Đào tạo từ xa'),
(11100164, 'Nguyễn Thế Hương  Thanh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100165, 'Nguyễn Thị  Thao', 'Đào tạo từ xa'),
(11100166, 'Nguyễn Hoàng  Thao', 'Đào tạo từ xa'),
(11100167, 'Nguyễn Hữu  Thảo', 'Đào tạo từ xa'),
(11100169, 'Dương Văn  Thỏa', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100170, 'Cao Thị  Thuân', 'Đào tạo từ xa'),
(11100171, 'Bùi Văn  Thương', 'Đào tạo từ xa'),
(11100172, 'Trần Văn  Thường', 'Đào tạo từ xa'),
(11100173, 'Đỗ Quang  Tiến', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11100174, 'Phạm Thành  Trung', 'Đào tạo từ xa'),
(11100176, 'Cao Mạnh  Trường', 'Đào tạo từ xa'),
(11100177, 'Bùi Văn  Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520001, 'Võ Thị Diệu Ái', 'Mạng máy tính & truyền thông'),
(11520002, 'Trần Văn An', 'Mạng máy tính & truyền thông'),
(11520003, 'Huỳnh Văn An', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520004, 'Võ Duy Thái An', 'Khoa học máy tính'),
(11520005, 'Đinh Thành An', 'Mạng máy tính & truyền thông'),
(11520006, 'Lương Thái Võ Việt An', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520007, 'Lương Hoàng Thế Anh', 'Mạng máy tính & truyền thông'),
(11520008, 'Cao Việt Anh', 'Mạng máy tính & truyền thông'),
(11520009, 'Phùng Hoàng Anh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520010, 'Vy Văn Anh', 'Mạng máy tính & truyền thông'),
(11520012, 'Lê Công Tuấn Anh', 'Kỹ thuật máy tính'),
(11520013, 'Nguyễn Tuấn Anh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520014, 'Lê Tiến Anh', 'Cử nhân tài năng'),
(11520015, 'Mai Hùng Ánh', 'Kỹ thuật máy tính'),
(11520016, 'Nguyễn Vũ Ngọc Bảo', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520017, 'Lâm Hoàng Bảo', 'Kỹ thuật máy tính'),
(11520018, 'Bùi Ngọc Bảo', 'Chương trình tiên tiến'),
(11520019, 'Huỳnh Thiên Bảo', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520020, 'Trần Quốc Bảo', 'Hệ thống thông tin'),
(11520021, 'Phạm Thị Ngọc Bích', 'Công nghệ phần mềm'),
(11520022, 'Đỗ Thị Ngọc Bích', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520023, 'Nguyễn Xuân Biển', 'Kỹ thuật máy tính'),
(11520024, 'Phạm Thanh Bình', 'Kỹ thuật máy tính'),
(11520025, 'Ngô Tấn Bình', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520026, 'Nguyễn Nhựt Bình', 'Công nghệ phần mềm'),
(11520027, 'Lê Văn Cảnh', 'Công nghệ phần mềm'),
(11520028, 'Trần Hoàng Cảnh', 'Công nghệ phần mềm'),
(11520029, 'Triệu Văn Cấp', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520030, 'Nguyễn Khắc Chân', 'Mạng máy tính & truyền thông'),
(11520031, 'Vũ Văn Thuần Chất', 'Kỹ thuật máy tính'),
(11520032, 'Đinh Nguyễn Ngọc Châu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520033, 'Vũ Nguyễn Tâm Châu', 'Kỹ thuật máy tính'),
(11520034, 'Trần Phương Chung', 'Kỹ thuật máy tính'),
(11520035, 'Lê Văn Cự', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520036, 'Võ Duy Cương', 'Công nghệ phần mềm'),
(11520037, 'Nguyễn Mạnh Cường', 'Hệ thống thông tin'),
(11520038, 'PháşĄm KháşŻc CĆ°áťng', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520039, 'Trần Tiến Đại', 'Công nghệ phần mềm'),
(11520040, 'Mìn Nhật Đăng', ''),
(11520041, 'Phan Hải Đăng', 'Khoa học máy tính'),
(11520042, 'Vũ Viết Đăng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520043, 'Võ Phương Danh', 'Hệ thống thông tin'),
(11520044, 'Bùi Võ Thanh Danh', 'Khoa học máy tính'),
(11520045, 'Trần Công Danh', ''),
(11520046, 'Huỳnh Hữu Danh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520047, 'Lê Văn Đức Đạo', 'Mạng máy tính & truyền thông'),
(11520048, 'Trương Thế Đạt', 'Mạng máy tính & truyền thông'),
(11520049, 'Nguyễn Hữu Đạt', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520050, 'Trương Xuân Đạt', 'Mạng máy tính & truyền thông'),
(11520051, 'HoĂ ng Tiáşżn ÄáşĄt', 'CĂ´ng ngháť pháş§n máťm'),
(11520052, 'Nguyễn Bá Đạt', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520054, 'Nguyễn Đức Đạt', 'Hệ thống thông tin'),
(11520055, 'Ngô Hiển Đạt', 'Mạng máy tính & truyền thông'),
(11520056, 'Vũ Bá Tất Đạt', 'Kỹ thuật máy tính'),
(11520057, 'Thái Văn Đạt', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520058, 'Hong Choi Dềng', 'Cử nhân tài năng'),
(11520059, 'Mạc Thị Diễm', 'Công nghệ phần mềm'),
(11520060, 'Nguyễn Xuân Điệp', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520061, 'Nguyễn Văn Điệu', 'Kỹ thuật máy tính'),
(11520062, 'Trần Hữu Định', 'Mạng máy tính & truyền thông'),
(11520063, 'Trần Tiến Định', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520064, 'Lưu Ngọc Đỏ', 'Công nghệ phần mềm'),
(11520065, 'MĂŁ Tháť ÄĂ´ng', 'Cáť­ nhĂ˘n tĂ i nÄng'),
(11520066, 'Đào Đức Đồng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520067, 'Võ Đại Đồng', ''),
(11520068, 'Đinh Thiện Đức', 'Kỹ thuật máy tính'),
(11520069, 'Đào Đông Đức', ''),
(11520070, 'Phạm Minh Đức', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520071, 'Nguyáťn Trung ÄáťŠc', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(11520072, 'Võ Văn Đức', 'Kỹ thuật máy tính'),
(11520073, 'Huỳnh Công Đức', 'Mạng máy tính & Truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520074, 'Bùi Hoàng Ngọc Dũng', 'Công nghệ phần mềm'),
(11520075, 'Ngô Tấn Dững', 'Công nghệ phần mềm'),
(11520076, 'Đặng Vũ Dương', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520077, 'Nguyễn Thái Dương', 'Hệ thống thông tin'),
(11520078, 'Nguyễn Bình Dương', 'Công nghệ phần mềm'),
(11520079, 'Nguyễn Hữu Duy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520080, 'Nguyễn Quang Duy', 'Khoa học máy tính'),
(11520081, 'Phan Anh Duy', 'Hệ thống thông tin'),
(11520082, 'Lý Phạm Minh Duy', 'Kỹ thuật máy tính'),
(11520083, 'Trương Hòang Duy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520084, 'Võ Văn Duy', 'Mạng máy tính & truyền thông'),
(11520085, 'Lê Khánh Duy', 'Công nghệ phần mềm'),
(11520086, 'Nguyễn Thành Duyệt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520087, 'Phạm Cảnh Em', 'Công nghệ phần mềm'),
(11520088, 'Nguyễn Ngọc Gia', 'Kỹ thuật máy tính'),
(11520089, 'Đỗ Trần Giang', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520090, 'Trần Hoàng Giang', 'Kỹ thuật máy tính'),
(11520091, 'Trần Huệ Hà', 'Công nghệ phần mềm'),
(11520092, 'Hồ Trần Sĩ Hà', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520093, 'Đào Thị Thu Hà', 'Mạng máy tính & truyền thông'),
(11520094, 'Nguyễn Trí Hải', 'Cử nhân tài năng'),
(11520095, 'Lê Trịnh Thế Hải', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520096, 'Lê Đình Hải', 'Hệ thống thông tin'),
(11520097, 'Phạm Nguyên Hải', 'Kỹ thuật máy tính'),
(11520098, 'Ngô Trí Hạnh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520099, 'Trần Diệu Nhất Hạnh', 'Công nghệ phần mềm'),
(11520100, 'Nguyễn Lê Hậu', 'Khoa học máy tính'),
(11520101, 'Nguyễn Công Hậu', 'Mạng máy tính & Truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520102, 'Nguyễn Công Hiến', 'Hệ thống thông tin'),
(11520103, 'Trần Phúc Hiền', 'Công nghệ phần mềm'),
(11520104, 'Nguyễn Quang Hiển', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520105, 'Trần Quang Hiệp', 'Công nghệ phần mềm'),
(11520106, 'Nguyễn Văn Hiệp', 'Kỹ thuật máy tính'),
(11520107, 'Trương Trung Hiếu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520108, 'Nguyễn Trung Hiếu', 'Hệ thống thông tin'),
(11520109, 'Võ Minh Bảo Hiếu', 'Hệ thống thông tin'),
(11520110, 'Phan Trung Hiếu', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520111, 'Lê Thành Hiếu', 'Hệ thống thông tin'),
(11520112, 'Nguyáťn Tháť Hoa', 'Cáť­ nhĂ˘n tĂ i nÄng'),
(11520113, 'Nguyễn Văn Hóa', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520114, 'Nguyễn Thanh Hòa', 'Mạng máy tính & truyền thông'),
(11520115, 'Dương Thanh Hòa', 'Kỹ thuật máy tính'),
(11520116, 'Trần Nguyễn Tuấn Hoàng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520117, 'Trương Lê Hoàng', 'Chương trình tiên tiến'),
(11520118, 'Nguyễn Vũ Hoàng', 'Khoa học máy tính'),
(11520119, 'Trần Ngọc Hoàng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520120, 'Nguyễn Mạnh Hoàng', 'Mạng máy tính & truyền thông'),
(11520121, 'Trương Thành Hoàng', 'Mạng máy tính & truyền thông'),
(11520122, 'Sơ Tuấn Hoàng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520123, 'Phạm Viết Hoàng', 'Kỹ thuật máy tính'),
(11520124, 'Vũ Viết Hoàng', 'Công nghệ phần mềm'),
(11520125, 'Nguyễn Huy Hoàng', 'Mạng máy tính & truyền thông'),
(11520126, 'Nguyễn Văn Hoàng', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520127, 'Nguyễn Văn Hoàng', 'Kỹ thuật máy tính'),
(11520128, 'Nguyễn Quang Học', 'Mạng máy tính & truyền thông'),
(11520129, 'Nguyễn Đình Hồi', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520130, 'Mai Văn Huân', 'Khoa học máy tính'),
(11520131, 'Hoàng Đức Hùng', 'Công nghệ phần mềm'),
(11520132, 'Nguyễn Phi Hùng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520133, 'Hà Văn Hùng', 'Mạng máy tính & truyền thông'),
(11520134, 'Nguyễn Văn Hùng', 'Công nghệ phần mềm'),
(11520135, 'Nguyễn Minh Hùng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520136, 'TrĆ°ĆĄng Tráťng HĂšng', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(11520137, 'Phạm Duy Hưng', 'Hệ thống thông tin'),
(11520138, 'Nguyễn Thị Kim Hương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520139, 'Nguyễn Văn Hướng', 'Cử nhân tài năng'),
(11520140, 'Lục Chí Hướng', 'Kỹ thuật máy tính'),
(11520141, 'Võ Khắc Hưởng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520142, 'Nguyễn Lương Trường Huy', 'Chương trình tiên tiến'),
(11520143, 'Huỳnh Quang Huy', 'Công nghệ phần mềm'),
(11520144, 'Nguyễn Văn Quốc Huy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520145, 'Nguyễn Đức Huy', 'Kỹ thuật máy tính'),
(11520146, 'Trịnh Đình Huy', 'Kỹ thuật máy tính'),
(11520148, 'Huỳnh Phạm Quốc Huy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520149, 'Nguyễn Tiến Huy', 'Công nghệ phần mềm'),
(11520150, 'Nguyễn Vũ Huy', 'Công nghệ phần mềm'),
(11520151, 'Nguyễn Thanh Huy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520152, 'Nguyễn Gia Huy', 'Mạng máy tính & truyền thông'),
(11520153, 'Trịnh Xuân Huy', 'Chương trình tiên tiến'),
(11520154, 'Nguyễn Ngọc Huy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520155, 'Bùi Trần Hoàng Huy', 'Khoa học máy tính'),
(11520156, 'Dương Hồ Minh Huy', 'Mạng máy tính & truyền thông'),
(11520157, 'Trần Quang Huy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520158, 'Huỳnh Thanh Huy', 'Công nghệ phần mềm'),
(11520159, 'Phú Văn Kachu', 'Công nghệ phần mềm'),
(11520160, 'Châu Trọng Kha', 'Hệ thống thông tin'),
(11520161, 'Bùi Lê Kha', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520162, 'Hồ Nguyễn Anh Kha', 'Khoa học máy tính'),
(11520163, 'Võ Minh Kha', 'Công nghệ phần mềm'),
(11520164, 'Trần Duy Khải', 'Mạng máy tính & Truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520165, 'Lê Tuấn Khang', 'Kỹ thuật máy tính'),
(11520166, 'Bùi Duy Khanh', 'Khoa học máy tính'),
(11520167, 'Lê Văn Khánh', 'Mạng máy tính & truyền thông'),
(11520168, 'Cao Minh Khánh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520169, 'Nguyễn Duy Khánh', 'Mạng máy tính & truyền thông'),
(11520170, 'Phạm Lê Khánh', 'Mạng máy tính & truyền thông'),
(11520171, 'Hồ Minh Khánh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520172, 'Đinh Quang Khánh', 'Công nghệ phần mềm'),
(11520173, 'Huỳnh Thiện Khiêm', 'Khoa học máy tính'),
(11520174, 'Nguyễn Thiện Khiêm', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520175, 'Nguyễn Thanh Khiết', 'Khoa học máy tính'),
(11520176, 'Hồ Kỳ Khoa', 'Khoa học máy tính'),
(11520177, 'Nguyáťn HáşŁi ÄÄng Khoa', 'Háť tháťng thĂ´ng tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520178, 'Trần Anh Khoa', 'Mạng máy tính & truyền thông'),
(11520179, 'Phan Văn Đăng Khoa', 'Công nghệ phần mềm'),
(11520180, 'Huỳnh Duy Khoa', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520181, 'Trần Đăng Khoa', 'Mạng máy tính & truyền thông'),
(11520182, 'Trần Hoàng Khôi', 'Kỹ thuật máy tính'),
(11520183, 'Phan Trường Khởi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520184, 'Nguyễn Duy Khương', 'Chương trình tiên tiến'),
(11520185, 'Nguyễn Trung Đăng Khương', 'Hệ thống thông tin'),
(11520186, 'La Duy Kiên', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520187, 'Phạm Trung Kiên', 'Khoa học máy tính'),
(11520188, 'Trương Văn Kiên', 'Kỹ thuật máy tính'),
(11520189, 'Nguyễn Quốc Kiện', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520190, 'Lưu Phú Kiệt', 'Khoa học máy tính'),
(11520191, 'Phạm Hoàng Kiệt', 'Khoa học máy tính'),
(11520192, 'Võ Thị Thuý Kiều', 'Khoa học máy tính'),
(11520193, 'Nguyễn Kim', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520194, 'Nguyễn Thế Lai', 'Kỹ thuật máy tính'),
(11520195, 'Nguyễn Danh Hoài Lam', 'Kỹ thuật máy tính'),
(11520196, 'Vương Đức Lâm', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520197, 'Đỗ Sơn Lâm', 'Công nghệ phần mềm'),
(11520198, 'Hoàng Xuân Lâm', 'Khoa học máy tính'),
(11520200, 'Nguyễn Ngọc Lâm', 'Kỹ thuật máy tính'),
(11520201, 'Trương Hoàng Lân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520202, 'Quách Thành Lập', 'Khoa học máy tính'),
(11520203, 'Lưu Nguyễn Hoàng Lê', 'Kỹ thuật máy tính'),
(11520204, 'Bùi Thanh Liêm', 'Khoa học máy tính'),
(11520205, 'Đỗ Viết Liêm', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520206, 'Lê Thị Diệu Linh', 'Hệ thống thông tin'),
(11520207, 'Trương Văn Linh', 'Mạng máy tính & truyền thông'),
(11520208, 'Nguyễn Mạnh Linh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520209, 'Nguyễn Tiến Linh', 'Khoa học máy tính'),
(11520210, 'Nguyễn Chí Linh', 'Công nghệ phần mềm'),
(11520211, 'Phạm Quang Linh', 'Kỹ thuật máy tính'),
(11520212, 'Đặng ánh Loan', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520213, 'Nguyễn Văn Lộc', 'Hệ thống thông tin'),
(11520214, 'Nguyễn Tài Lộc', 'Hệ thống thông tin'),
(11520215, 'Phạm Tấn Lộc', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520216, 'Lê Nguyên Lộc', 'Mạng máy tính & truyền thông'),
(11520217, 'Lê Minh Lợi', 'Kỹ thuật máy tính'),
(11520218, 'Lương Tiểu Long', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520219, 'Võ Trần Hoàng Long', 'Kỹ thuật máy tính'),
(11520220, 'Bùi Ngọc Long', 'Công nghệ phần mềm'),
(11520221, 'Lâm Hoàng Bảo Long', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520222, 'Trần Bảo Long', 'Chương trình tiên tiến'),
(11520223, 'Nguyễn Hữu Kỳ Long', 'Công nghệ phần mềm'),
(11520224, 'Ngô Thị Lương', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520225, 'Nguyễn Thành Lưu', 'Khoa học máy tính'),
(11520226, 'Bùi Duy Lưu', 'Công nghệ phần mềm'),
(11520227, 'Nguyễn Công Lý', 'Công nghệ phần mềm'),
(11520228, 'Bùi Thị Mai', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520229, 'Võ Lê Minh', 'Khoa học máy tính'),
(11520230, 'Nguyễn Văn Minh', 'Kỹ thuật máy tính'),
(11520231, 'Hoàng Đức Minh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520232, 'Đặng Liên Minh', 'Hệ thống thông tin'),
(11520233, 'Phạm Diểm My', 'Khoa học máy tính'),
(11520234, 'Nguyễn Văn Thể Mỹ', 'Kỹ thuật máy tính'),
(11520235, 'Ngô Hoàng Nam', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520236, 'Huỳnh Tấn Nam', 'Kỹ thuật máy tính'),
(11520237, 'Trần Thanh Nam', 'Mạng máy tính & truyền thông'),
(11520238, 'Lưu Hùng Nam', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520239, 'Trần Duy Nam', 'Khoa học máy tính'),
(11520240, 'Nguyễn Ngọc Nam', 'Khoa học máy tính'),
(11520241, 'Nguyễn Viết Nam', 'Kỹ thuật máy tính'),
(11520242, 'Mai Phương Nga', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520243, 'Đỗ Thị Thanh Ngân', 'Hệ thống thông tin'),
(11520244, 'Nguyễn Hoàng Ngân', 'Kỹ thuật máy tính'),
(11520245, 'Lê Trung Nghĩa', 'Công nghệ phần mềm'),
(11520246, 'Huáťłnh Tráťng NghÄŠa', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520247, 'Đoàn Trọng Nghĩa', 'Kỹ thuật máy tính'),
(11520248, 'Nguyễn Trường Nghĩa', 'Công nghệ phần mềm'),
(11520249, 'Nguyễn Minh Nghĩa', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520250, 'Hồ Huấn Nghiêm', 'Kỹ thuật máy tính'),
(11520251, 'Nguyễn Minh Ngọc', 'Kỹ thuật máy tính'),
(11520252, 'Cao Đoan Hồng Ngọc', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520253, 'Phan Trần Như Ngọc', 'Kỹ thuật máy tính'),
(11520254, 'Ngô Thái Ngọc', 'Kỹ thuật máy tính'),
(11520255, 'Đoàn Xuân Nguyên', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520256, 'Nguyễn Đình Nguyên', 'Hệ thống thông tin'),
(11520257, 'Hồ Cao Nguyên', 'Khoa học máy tính'),
(11520258, 'Nguyễn Trung Nguyên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520259, 'Huỳnh Nhật Nguyên', 'Khoa học máy tính'),
(11520260, 'Nguyễn Thanh Nhã', 'Hệ thống thông tin'),
(11520261, 'Nguyễn Thị Thanh Nhàn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520262, 'Phan Phước Nhân', 'Hệ thống thông tin'),
(11520263, 'Nguyễn Trường Nhân', 'Hệ thống thông tin'),
(11520264, 'Nguyễn Trọng Nhân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520265, 'Nguyễn Lê Nhân', 'Hệ thống thông tin'),
(11520266, 'Đoàn Trọng Nhân', 'Mạng máy tính & truyền thông'),
(11520267, 'LĂ˝ Tráťng NhĂ˘n', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520268, 'Thiều Anh Nhất', 'Hệ thống thông tin'),
(11520269, 'Nguyễn Trần Minh Nhật', 'Hệ thống thông tin'),
(11520270, 'Lê Yến Nhi', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520271, 'Võ Thị Ánh Nhi', 'Hệ thống thông tin'),
(11520272, 'Hồ Văn Ninh', 'Kỹ thuật máy tính'),
(11520273, 'Vũ Thị Ngọc Ninh', 'Mạng máy tính & truyền thông'),
(11520274, 'Nguyễn Đình Phát', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520275, 'Nguyễn Đức Phát', 'Mạng máy tính & truyền thông'),
(11520276, 'Đỗ Hữu Phát', 'Công nghệ phần mềm'),
(11520277, 'Nguyễn Thành Phát', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520278, 'Đinh Quang Phát', 'Mạng máy tính & truyền thông'),
(11520279, 'Phạm Minh Phát', 'Mạng máy tính & truyền thông'),
(11520280, 'Nguyễn Văn Phát', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520281, 'Nguyễn Bá Trường Phi', 'Khoa học máy tính'),
(11520282, 'Lê Đình Phi', 'Mạng máy tính & truyền thông'),
(11520283, 'Tôn Phi', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520284, 'Dương Tuấn Phong', 'Mạng máy tính & truyền thông'),
(11520285, 'Đỗ Thanh Phong', ''),
(11520286, 'Phạm Vũ Thanh Phong', 'Công nghệ phần mềm'),
(11520287, 'Nguyễn Thành Phú', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520288, 'Lê Sanh Phúc', ''),
(11520289, 'Nguyễn Xuân Phúc', 'Kỹ thuật máy tính'),
(11520290, 'Lê Văn Phúc', 'Mạng máy tính & truyền thông'),
(11520291, 'Nguyễn Hoài Phúc', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520292, 'PháşĄm ÄáťŠc PhĂšng', ''),
(11520293, 'Phó Thiên Phước', 'Khoa học máy tính'),
(11520294, 'Trần Nhữ Phương', 'Mạng máy tính & Truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520295, 'Nguyáťn Viáťt PhĆ°ĆĄng', 'Khoa háťc mĂĄy tĂ­nh'),
(11520296, 'ThĂĄi ÄáťŠc PhĆ°ĆĄng', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520297, 'Phạm Thị Phương', 'Hệ thống thông tin'),
(11520298, 'Đỗ Hoàng Phương', 'Kỹ thuật máy tính'),
(11520299, 'Ngô Thị Quỳnh Phương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520300, 'Hồ Nguyễn Huỳnh Phương', 'Mạng máy tính & truyền thông'),
(11520301, 'Phạm Minh Quân', 'Khoa học máy tính'),
(11520302, 'Trần Hồng Quân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520303, 'Nguyễn Minh Quân', 'Công nghệ phần mềm'),
(11520304, 'Đặng Quốc Quân', 'Khoa học máy tính'),
(11520305, 'Tráş§n Anh QuĂ˘n', 'CĂ´ng ngháť pháş§n máťm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520306, 'Nguyễn Anh Quang', 'Mạng máy tính & truyền thông'),
(11520307, 'Nguyễn Văn Quang', 'Công nghệ phần mềm'),
(11520308, 'Phan Quốc Quang', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520309, 'Nguyễn Duy Quang', 'Mạng máy tính & truyền thông'),
(11520310, 'Phạm Hồng Quang', 'Kỹ thuật máy tính'),
(11520311, 'Hoàng Vinh Quang', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520312, 'Văn Tấn Quốc', 'Mạng máy tính & truyền thông'),
(11520313, 'Nguyễn Hữu Quốc', 'Mạng máy tính & truyền thông'),
(11520314, 'Nguyễn Phú Quý', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520315, 'Nguyễn Ngọc Quý', 'Mạng máy tính & truyền thông'),
(11520316, 'Hồ Sĩ Quý', 'Khoa học máy tính'),
(11520317, 'Nguyễn Nam Quý', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520318, 'Phạm Văn Quý', 'Khoa học máy tính'),
(11520319, 'Huỳnh Mậu Quý', 'Hệ thống thông tin'),
(11520320, 'Đặng Ngọc Quyên', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520321, 'Cao Phạm Hoàng Quyên', 'Hệ thống thông tin'),
(11520322, 'Vũ Văn Quyến', 'Khoa học máy tính'),
(11520323, 'Nguyễn Vương Quyền', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520324, 'Nguyễn Văn Quyền', 'Mạng máy tính & truyền thông'),
(11520325, 'Vũ Văn Quyết', 'Mạng máy tính & Truyền thông'),
(11520326, 'Lê Đức Sang', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520327, 'LÄng HoĂ i Sang', 'CĂ´ng ngháť pháş§n máťm'),
(11520328, 'Ngô Thị Ngọc Sang', 'Khoa học máy tính'),
(11520329, 'Ngô Thị Hồng Sen', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520330, 'Nguyễn Phú Sĩ', 'Mạng máy tính & truyền thông'),
(11520331, 'Hà Đức Sơn', 'Kỹ thuật máy tính'),
(11520332, 'Trịnh Phó Sơn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520333, 'Nguyễn Thanh Sơn', 'Kỹ thuật máy tính'),
(11520334, 'Phạm Như Tài', 'Khoa học máy tính'),
(11520335, 'Nguyễn Thành Tài', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520336, 'Trần Vũ Tấn Tài', 'Mạng máy tính & truyền thông'),
(11520337, 'Nguyễn Duy Tài', 'Mạng máy tính & truyền thông'),
(11520338, 'Võ Hữu Tài', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520339, 'Huỳnh Tấn Đức Tài', 'Kỹ thuật máy tính'),
(11520340, 'Phan Duy Tài', 'Công nghệ phần mềm'),
(11520341, 'Phạm Thế Tài', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520342, 'Đinh Thành Tài', 'Hệ thống thông tin'),
(11520343, 'Nguyễn Thành Tâm', 'Công nghệ phần mềm'),
(11520344, 'Thái Thanh Tâm', ''),
(11520345, 'Phan Đức Minh Tân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520346, 'Trần Ngọc Tân', 'Hệ thống thông tin'),
(11520347, 'Lê Duy Tân', 'Kỹ thuật máy tính'),
(11520348, 'Nguyễn Duy Tân', ''),
(11520349, 'Đoàn Duy Tân', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520350, 'LĂŞ Duy TĂ˘n', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(11520351, 'Trương Lê Thúc Tân', 'Kỹ thuật máy tính'),
(11520352, 'Vi Minh Tấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520353, 'Tạ Đình Tấn', 'Kỹ thuật máy tính'),
(11520354, 'Vy Kim Tăng', 'Mạng máy tính & truyền thông'),
(11520355, 'Đỗ Nguyên Thạch', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520356, 'LĂŞ Ngáťc TháşĄch', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(11520357, 'Nguyễn Thành Thái', 'Công nghệ phần mềm'),
(11520358, 'Kỳ Anh Thái', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520359, 'Võ Trần Thái', 'Công nghệ phần mềm'),
(11520360, 'Trần Quốc Thái', 'Công nghệ phần mềm'),
(11520361, 'Lê Thị Thắm', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520362, 'Võ Thắng', 'Khoa học máy tính'),
(11520363, 'Kinh Quang Thắng', 'Khoa học máy tính'),
(11520364, 'Nguyễn Quốc Thắng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520365, 'Huỳnh Lưu Đại Thắng', 'Công nghệ phần mềm'),
(11520366, 'Nguyễn Thị Thanh', 'Khoa học máy tính'),
(11520367, 'Nguyễn Như Thanh', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520368, 'Dương Phước Thành', 'Hệ thống thông tin'),
(11520369, 'Trịnh Văn Thành', 'Công nghệ phần mềm'),
(11520370, 'Nguyễn Viết Thành', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520371, 'Hồ Hoàng Thành', 'Khoa học máy tính'),
(11520372, 'Lữ Hoàng Thành', 'Công nghệ phần mềm'),
(11520373, 'Nguyễn Phước Thành', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520374, 'Hoàng Mạnh Thành', 'Khoa học máy tính'),
(11520375, 'Lương Ngọc Thảo', ''),
(11520376, 'Võ Trường Thi', 'Khoa học máy tính'),
(11520377, 'Lê Trọng Thiên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520378, 'Bành Lê Vũ Thiện', 'Công nghệ phần mềm'),
(11520379, 'Nguyễn Hoàng Thiện', 'Hệ thống thông tin'),
(11520380, 'Nguyễn Anh Thiết', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520381, 'Hoàng Ngọc Thiệu', 'Mạng máy tính & truyền thông'),
(11520382, 'Huỳnh Trương Văn Thìn', 'Kỹ thuật máy tính'),
(11520383, 'Lê Quang Thịnh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520384, 'Nguyễn Thịnh', 'Hệ thống thông tin'),
(11520385, 'Nguyễn Tiến Thịnh', 'Hệ thống thông tin'),
(11520386, 'Phạm Quốc Thịnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520387, 'Nguyễn Ngọc Thịnh', 'Mạng máy tính & truyền thông'),
(11520388, 'Nguyễn Trần Thịnh', 'Công nghệ phần mềm'),
(11520389, 'Lê Xuân Thịnh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520390, 'Trần Hoàng Thịnh', 'Công nghệ phần mềm'),
(11520391, 'Trần Hồng Thọ', 'Công nghệ phần mềm'),
(11520392, 'Trương Ứng Thọ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520393, 'Nguyễn Nhã Thông', 'Mạng máy tính & truyền thông'),
(11520394, 'Bùi Thị Quỳnh Thư', 'Mạng máy tính & truyền thông'),
(11520395, 'Trương Hoà Thuận', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520396, 'Vũ Văn Thuận', 'Công nghệ phần mềm'),
(11520397, 'Vũ Đức Thuận', 'Hệ thống thông tin'),
(11520398, 'Phan Công Thức', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520399, 'Vũ Phú Thức', 'Chương trình tiên tiến'),
(11520400, 'Nguyễn Thị Hoài Thương', 'Hệ thống thông tin'),
(11520401, 'Lê Văn Thuỷ', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520402, 'Phạm Trần Phương Thùy', 'Hệ thống thông tin'),
(11520403, 'Nguyễn Vĩnh Thụy', 'Khoa học máy tính'),
(11520404, 'Trần Bảo Tiến', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520405, 'Trương Minh Tiến', 'Mạng máy tính & Truyền thông'),
(11520406, 'Bùi Thanh Tiến', 'Khoa học máy tính'),
(11520407, 'Nguyễn Minh Tiến', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520408, 'Nguyễn Văn Tiến', 'Công nghệ phần mềm'),
(11520409, 'Trần Minh Tiến', 'Mạng máy tính & truyền thông'),
(11520410, 'Hồ Nhật Tiến', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520412, 'Lâm Trí Tín', 'Hệ thống thông tin'),
(11520413, 'Lê Trọng Tính', 'Kỹ thuật máy tính'),
(11520414, 'Nguyễn Thị Tình', 'Công nghệ phần mềm'),
(11520415, 'Võ Văn Tịnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520416, 'Nguyễn Thanh Toàn', 'Kỹ thuật máy tính'),
(11520417, 'Âu Thế Toàn', 'Hệ thống thông tin'),
(11520418, 'Nguyễn Đức Toàn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520419, 'Nguyễn Trọng Toàn', 'Hệ thống thông tin'),
(11520420, 'Huỳnh Tấn Toàn', 'Công nghệ phần mềm'),
(11520421, 'Ngô Thanh Toàn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520422, 'Trương Phúc Toàn', 'Hệ thống thông tin'),
(11520423, 'Lê Văn Toàn', 'Hệ thống thông tin'),
(11520424, 'Nguyễn Duy Toàn', 'Kỹ thuật máy tính'),
(11520425, 'Trần Quốc Toản', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520426, 'Võ Thị Trang', 'Hệ thống thông tin'),
(11520427, 'Trần Hạnh Trang', 'Khoa học máy tính'),
(11520428, 'Nguyễn Hồng Trí', 'Cử nhân tài năng'),
(11520429, 'Khưu Nhựt Trí', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520430, 'Phan Minh Trí', 'Mạng máy tính & truyền thông'),
(11520431, 'Huỳnh Hồ Thị Mộng Trinh', 'Công nghệ phần mềm'),
(11520432, 'Nguyễn Khánh Trình', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520433, 'Nguyễn Văn Trọng', 'Công nghệ phần mềm'),
(11520434, 'Lê Thành Trọng', 'Hệ thống thông tin'),
(11520435, 'Nguyễn Trần Hoàng Thiên Trúc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520436, 'Nguyễn Công Trung', ''),
(11520437, 'Đinh Quang Trung', 'Công nghệ phần mềm'),
(11520438, 'Phạm Văn Trung', 'Công nghệ phần mềm'),
(11520439, 'Huỳnh Hoàng Nhật Trường', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520440, 'Lê Lương Trường', 'Hệ thống thông tin'),
(11520441, 'Lê Minh Truyền', 'Hệ thống thông tin'),
(11520442, 'Tô Mạnh Tú', 'Chương trình tiên tiến'),
(11520443, 'Võ Kim Tú', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520444, 'Chế Minh Tú', 'Công nghệ phần mềm'),
(11520445, 'Trần Quang Tú', 'Mạng máy tính & truyền thông'),
(11520446, 'Trần Thanh Tú', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520447, 'Chu Thanh Tú', 'Khoa học máy tính'),
(11520448, 'Lê Anh Minh Tuấn', 'Mạng máy tính & truyền thông'),
(11520449, 'Trịnh Anh Tuấn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520450, 'Trần Thanh Tuấn', 'Mạng máy tính & truyền thông'),
(11520451, 'Bùi Nguyễn Mạnh Tuấn', 'Mạng máy tính & truyền thông'),
(11520452, 'Huỳnh Ngọc Tuấn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520453, 'Nguyễn Văn Thanh Tuấn', 'Khoa học máy tính'),
(11520454, 'Đặng Văn Tuấn', 'Kỹ thuật máy tính'),
(11520455, 'Võ Trương Anh Tuấn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520456, 'LĂŞ Tráťng TuáşĽn', 'CĂ´ng ngháť pháş§n máťm'),
(11520457, 'Lê Tuấn', 'Khoa học máy tính'),
(11520458, 'Nguyễn Hữu Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520459, 'Đào Thanh Tuấn', 'Hệ thống thông tin'),
(11520460, 'Trần Quốc Tuấn', 'Kỹ thuật máy tính'),
(11520461, 'Trần Trọng Hoàng Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520462, 'Phạm Tăng Tùng', 'Chương trình tiên tiến'),
(11520463, 'Hoàng Văn Tùng', 'Công nghệ phần mềm'),
(11520464, 'Đinh Thanh Tùng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520465, 'Đặng Xuân Tùng', 'Hệ thống thông tin'),
(11520466, 'Lê Sỹ Tùng', 'Công nghệ phần mềm'),
(11520467, 'Bùi Kim Tùng', 'Hệ thống thông tin'),
(11520468, 'Huỳnh Minh Tuyên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520469, 'Trần Trung Tuyến', 'Công nghệ phần mềm'),
(11520470, 'Nguyễn Anh Tuyễn', 'Hệ thống thông tin'),
(11520471, 'Từ Phước Tuyển', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520472, 'Nguyễn Hoàng Kháng Uy', 'Mạng máy tính & Truyền thông'),
(11520473, 'Nguyáťn VÄn Uy', 'CĂ´ng ngháť pháş§n máťm'),
(11520474, 'Nguyễn Thanh Hoàng Uyên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520475, 'Nguyễn Mạnh Văn', 'Công nghệ phần mềm'),
(11520476, 'Nguyễn Trung Việt', ''),
(11520477, 'Bùi Ngọc Việt', ''),
(11520478, 'Võ Tấn Việt', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520479, 'Võ Hữu Vinh', 'Kỹ thuật máy tính'),
(11520480, 'Phạm Đăng Vinh', 'Hệ thống thông tin'),
(11520481, 'Lê Hiển Vinh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520482, 'Nguyễn Diệp Ngọc Vinh', 'Công nghệ phần mềm'),
(11520483, 'Hồ Xuân Vĩnh', 'Công nghệ phần mềm'),
(11520484, 'Nguyễn Xuân Vĩnh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520485, 'Nguyễn Minh Vũ', 'Công nghệ phần mềm'),
(11520486, 'Nguyễn Văn Vũ', 'Hệ thống thông tin'),
(11520487, 'Trần Anh Vũ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520488, 'Trương Công Mạnh Vũ', 'Kỹ thuật máy tính'),
(11520489, 'Nguyễn Hoàng Vũ', 'Công nghệ phần mềm'),
(11520490, 'Nguyễn Văn Vũ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520492, 'Huỳnh Anh Vũ', 'Chương trình tiên tiến'),
(11520493, 'Hồ Hoàng Vũ', 'Kỹ thuật máy tính'),
(11520494, 'Nguyễn Hoàng Vương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520495, 'ÄĂ o Duy VĆ°ĆĄng', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(11520496, 'Huỳnh Văn Hoa Xuân', 'Công nghệ phần mềm'),
(11520497, 'Phạm Xuân Y', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520498, 'Nguyễn Minh Phú', 'Khoa học máy tính'),
(11520499, 'Hứa Quốc Bảo', 'Mạng máy tính & truyền thông'),
(11520501, 'Nguyễn Quang An', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520502, 'Trần Trường An', 'Khoa học máy tính'),
(11520503, 'Đinh Thúy An', 'Cử nhân tài năng'),
(11520504, 'Đặng Phước An', 'Kỹ thuật máy tính'),
(11520505, 'Nguyễn Hoà An', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520506, 'Hồ Xuân Ân', 'Mạng máy tính & truyền thông'),
(11520507, 'Nguyễn Thị Quỳnh Anh', 'Hệ thống thông tin'),
(11520508, 'Lê Văn Anh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520509, 'Cao Hoàng Anh', 'Hệ thống thông tin'),
(11520510, 'Nguyễn Đức Anh', 'Hệ thống thông tin'),
(11520511, 'Hồ Tuấn Anh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520512, 'Lê Thị Ngọc Ánh', 'Hệ thống thông tin'),
(11520513, 'Nguyễn Văn Bắc', 'Kỹ thuật máy tính'),
(11520514, 'Bùi Hải Bằng', 'Kỹ thuật máy tính'),
(11520515, 'Nguyễn Văn Bình', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520516, 'Lê Kim Chân', 'Hệ thống thông tin'),
(11520517, 'Nguyễn Công Chánh', 'Khoa học máy tính'),
(11520518, 'Thái Hồng Châu', 'Khoa học máy tính'),
(11520519, 'Phạm Minh Châu', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520520, 'Vũ Duy Chinh', 'Kỹ thuật máy tính'),
(11520521, 'Phạm Văn Cường', 'Hệ thống thông tin'),
(11520522, 'Võ Hùng Cường', 'Khoa học máy tính'),
(11520523, 'Nguyễn Quý Cường', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520524, 'Nguyễn Vũ Cường', 'Công nghệ phần mềm'),
(11520525, 'Vũ Mạnh Cường', 'Kỹ thuật máy tính'),
(11520526, 'Tạ Quang Đại', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520527, 'Văn Tiến Đạt', 'Hệ thống thông tin'),
(11520528, 'Nguyễn Tiến Đạt', 'Mạng máy tính & truyền thông'),
(11520529, 'Phạm Quốc Đạt', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520530, 'Đặng Quốc Đạt', 'Hệ thống thông tin'),
(11520531, 'Lê Thị Hiền Đoan', 'Kỹ thuật máy tính'),
(11520532, 'Lê Thị Hiền Đoan', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520533, 'Trần Minh Đức', 'Hệ thống thông tin'),
(11520534, 'Đặng Đình Đức', 'Mạng máy tính & truyền thông'),
(11520535, 'Nguyễn Hoàng Dũng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520536, 'Nguyễn Văn Dũng', 'Mạng máy tính & truyền thông'),
(11520537, 'Tráş§n ÄáşĄi DĆ°ĆĄng', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(11520538, 'Trịnh Hoài Dương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520539, 'Nguyáťn Tráş§n Duy', 'Cáť­ nhĂ˘n tĂ i nÄng'),
(11520540, 'Nguyễn Trường Giang', 'Kỹ thuật máy tính'),
(11520541, 'Phạm Văn Hài', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520542, 'Nguyễn Quang Hải', 'Mạng máy tính & truyền thông'),
(11520543, 'Nguyễn Trung Hải', 'Mạng máy tính & truyền thông'),
(11520544, 'Nguyễn Văn Hải', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520545, 'Phùng Quốc Hải', 'Hệ thống thông tin'),
(11520546, 'Võ Khôi Nam Hải', 'Mạng máy tính & Truyền thông'),
(11520547, 'Phạm Đình Hải', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520548, 'Nguyễn Đăng Hải', 'Kỹ thuật máy tính'),
(11520549, 'NgĂ´ VÄn HĂ o', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(11520550, 'Trương Phước Hậu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520551, 'Hà Trung Hiến', 'Kỹ thuật máy tính'),
(11520552, 'Nguyễn Hữu Hiếu', 'Hệ thống thông tin'),
(11520553, 'Hoàng Trung Hiếu', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520554, 'Lê Văn Hiếu', 'Mạng máy tính & truyền thông'),
(11520555, 'Nguyễn Minh Hiếu', 'Khoa học máy tính'),
(11520556, 'Nguyễn Trung Hiếu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520557, 'Lê Văn Hoà', 'Kỹ thuật máy tính'),
(11520558, 'Lữ Thy Vỹ Hòa', 'Khoa học máy tính'),
(11520559, 'Vũ Hữu Hoài', 'Công nghệ phần mềm'),
(11520560, 'Đặng Văn Hoàng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520561, 'Phạm Bảo Hoàng', 'Mạng máy tính & truyền thông'),
(11520562, 'Thượng Đảo Hoàng', 'Mạng máy tính & truyền thông'),
(11520563, 'Lê Huy Hoàng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520564, 'Nguyễn Văn Hoàng', 'Chương trình tiên tiến'),
(11520565, 'Nguyễn Minh Hoàng', 'Mạng máy tính & Truyền thông'),
(11520566, 'Tôn Minh Hoàng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520567, 'Nguyễn Phú Hội', 'Mạng máy tính & truyền thông'),
(11520568, 'Đặng Xuân Huấn', 'Hệ thống thông tin'),
(11520569, 'Hoàng Khắc Hùng', ''),
(11520570, 'Cao Việt Hùng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520571, 'Dương Tấn Hùng', 'Hệ thống thông tin'),
(11520572, 'Ngô Khắc Hùng', 'Khoa học máy tính'),
(11520573, 'Huỳnh Ngọc Hưng', ''),
(11520574, 'Nhan Chấn Hưng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520575, 'Nguyễn Quang Huy', 'Hệ thống thông tin'),
(11520576, 'Nguyễn Hoàng Huy', 'Mạng máy tính & truyền thông'),
(11520577, 'Nguyễn Văn Kha', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520578, 'Bùi Tất Khải', 'Kỹ thuật máy tính'),
(11520579, 'Bá Văn Hoàng Khanh', 'Công nghệ phần mềm'),
(11520580, 'Vũ Đình Khoa', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520581, 'Lê Tấn Khoa', 'Mạng máy tính & truyền thông'),
(11520582, 'Trần Đăng Khoa', 'Khoa học máy tính'),
(11520584, 'Đặng Vũ Lâm', 'Khoa học máy tính'),
(11520585, 'Cao Mạnh Lanh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520586, 'Nguyễn Thị Lành', 'Mạng máy tính & Truyền thông'),
(11520587, 'Nguyễn Khánh Liền', 'Khoa học máy tính'),
(11520588, 'Nguyễn Trần Hoàng Linh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520589, 'Nguyễn Bá Hoàng Linh', 'Mạng máy tính & truyền thông'),
(11520590, 'Điền Thị Mỹ Linh', 'Mạng máy tính & Truyền thông'),
(11520591, 'Mạc Minh Lợi', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520592, 'Nguyáťn HoĂ ng Long', 'Cáť­ nhĂ˘n tĂ i nÄng'),
(11520593, 'Nguyễn Tân Quí Long', 'Cử nhân tài năng'),
(11520594, 'Nguyễn Kim Long', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520595, 'Nguyễn Hữu Long', 'Mạng máy tính & truyền thông'),
(11520596, 'Trịnh Thế Lữ', 'Kỹ thuật máy tính'),
(11520597, 'Nguyễn Mạnh Luật', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520598, 'Đặng Quang Lực', 'Hệ thống thông tin'),
(11520599, 'Cao Đường Minh', 'Mạng máy tính & truyền thông'),
(11520600, 'Dương Hoàng Nam', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520601, 'Đoàn Thành Nam', 'Khoa học máy tính'),
(11520602, 'Trần Trung Nam', 'Kỹ thuật máy tính'),
(11520603, 'Nguyễn Hoàng Nghĩa', 'Cử nhân tài năng'),
(11520604, 'Đoàn Đại Ngọc', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520605, 'VĹŠ Tháť Ngáťc', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(11520606, 'Phạm Thùy Nhi', 'Khoa học máy tính'),
(11520607, 'Huỳnh Văn Nhựt', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520608, 'Nguyễn Xuân Phong', 'Mạng máy tính & truyền thông'),
(11520609, 'Trần Hữu Phúc', 'Khoa học máy tính'),
(11520610, 'Tôn Thất Phúc', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520611, 'Lê Anh Phước', 'Công nghệ phần mềm'),
(11520612, 'Đặng Hữu Phước', 'Chương trình tiên tiến'),
(11520613, 'Võ Văn Phương', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520614, 'Nguyễn Duy Phương', 'Công nghệ phần mềm'),
(11520615, 'Trần Hoài Phương', 'Mạng máy tính & truyền thông'),
(11520616, 'Đỗ Minh Quân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520617, 'Nguyễn Đức Quân', 'Hệ thống thông tin'),
(11520618, 'Nguyễn Ngọc Quang', 'Cử nhân tài năng'),
(11520619, 'Võ Huỳnh Minh Quang', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520620, 'Nguyễn Minh Quý', 'Công nghệ phần mềm'),
(11520621, 'Nguyễn Vĩnh San', 'Mạng máy tính & truyền thông'),
(11520622, 'Nguyễn Công Sang', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520623, 'Phạm Thanh Sang', 'Hệ thống thông tin'),
(11520624, 'Nguyễn Ngọc Sơn', 'Công nghệ phần mềm'),
(11520625, 'Trần Hoàng Ngọc Sơn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520626, 'Nguyễn Thanh Sương', 'Kỹ thuật máy tính'),
(11520627, 'Nguyễn Hữu Tài', 'Khoa học máy tính'),
(11520628, 'Trần Đình Tài', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520629, 'Đặng Công Tâm', 'Hệ thống thông tin'),
(11520630, 'Phạm Chí Tâm', 'Hệ thống thông tin'),
(11520631, 'Võ Văn Tâm', 'Khoa học máy tính'),
(11520632, 'Phạm Thanh Sang', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520633, 'Lê Vũ Tâm', 'Hệ thống thông tin'),
(11520634, 'Dương Ngọc Thạch', 'Hệ thống thông tin'),
(11520635, 'Đỗ Xuân Thái', 'Mạng máy tính & Truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520636, 'Phạm Nam Thắng', 'Công nghệ phần mềm'),
(11520637, 'Tăng Quốc Thanh', 'Hệ thống thông tin'),
(11520638, 'Nguyễn Chí Thành', 'Hệ thống thông tin'),
(11520639, 'Lê Hoài Tâm', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520640, 'Trương Mai Thảo', 'Khoa học máy tính'),
(11520641, 'Phạm Huỳnh Phương Thảo', 'Hệ thống thông tin'),
(11520642, 'Vũ Thị Bích Thảo', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520643, 'Hà Minh Thi', 'Công nghệ phần mềm'),
(11520644, 'Nguyễn Văn Thiên', 'Mạng máy tính & truyền thông'),
(11520645, 'Lương Đức Thiện', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520646, 'Nguyễn Văn Thoại', 'Mạng máy tính & truyền thông'),
(11520647, 'Nguyễn Trọng Thoại', 'Khoa học máy tính'),
(11520648, 'Dương Nhật Thời', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520649, 'Trần Văn Thuấn', 'Hệ thống thông tin'),
(11520650, 'Cao Văn Thuấn', ''),
(11520651, 'Lê Nguyễn Mai Thủy', 'Công nghệ phần mềm'),
(11520652, 'Nguyễn Trung Tiến', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520653, 'Trần Quang Tiến', 'Công nghệ phần mềm'),
(11520654, 'Nguyễn Trung Tín', 'Chương trình tiên tiến'),
(11520655, 'Đặng Hữu Tín', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520656, 'Nguyễn Hữu Tình', 'Khoa học máy tính'),
(11520658, 'Phạm Thu Trang', 'Hệ thống thông tin'),
(11520659, 'Huỳnh Ngọc Trang', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520660, 'Trần Hồng Trang', 'Hệ thống thông tin'),
(11520661, 'Phan Thị Thu Trang', 'Cử nhân tài năng'),
(11520662, 'Nguyễn Văn Trắng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520663, 'Thân Khiết Trí', 'Chương trình tiên tiến'),
(11520664, 'Chung Nhất Trí', 'Khoa học máy tính'),
(11520665, 'Huỳnh Thanh Trí', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520666, 'Hồ Hồng Trọng', 'Hệ thống thông tin'),
(11520667, 'Trương Hoài Trúc', 'Công nghệ phần mềm'),
(11520668, 'Đặng Đỗ Trung', 'Mạng máy tính & Truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520669, 'Nguyễn Hiếu Trung', 'Công nghệ phần mềm'),
(11520670, 'Trần Phạm Song Trường', 'Mạng máy tính & truyền thông'),
(11520671, 'Võ Nhật Trường', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520672, 'Phạm Huỳnh Thanh Tú', 'Công nghệ phần mềm'),
(11520673, 'Lâm Thị Mỹ Tú', 'Chương trình tiên tiến'),
(11520674, 'Nguyễn Tuấn Tú', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520675, 'Nguyễn Văn Tuấn', 'Khoa học máy tính'),
(11520676, 'Phạm Quốc Tuấn', 'Cử nhân tài năng'),
(11520677, 'Lê Minh Tuấn', 'Kỹ thuật máy tính'),
(11520678, 'Nguyễn Anh Tuấn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520679, 'Phan Văn Tuấn', 'Khoa học máy tính'),
(11520680, 'Nguyễn Khắc Anh Tuấn', 'Chương trình tiên tiến'),
(11520681, 'Phạm Anh Tuấn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520682, 'Nguyễn Việt Tùng', 'Mạng máy tính & truyền thông'),
(11520683, 'Lê Văn Tùng', 'Mạng máy tính & truyền thông'),
(11520684, 'Trần Sơn Tùng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520685, 'Võ Thị Thu Uyên', 'Hệ thống thông tin'),
(11520686, 'Nguyễn Trọng Văn', 'Công nghệ phần mềm'),
(11520687, 'Nguyễn Phi Viễn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520688, 'Hồ Trần Thiên Ngọc Việt', 'Mạng máy tính & truyền thông'),
(11520689, 'Phạm Nhất Vin', 'Mạng máy tính & Truyền thông'),
(11520690, 'Hồ Văn Vinh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520691, 'Nguyễn Duy Vinh', 'Mạng máy tính & truyền thông'),
(11520692, 'Nguyễn Thành Vinh', 'Mạng máy tính & truyền thông'),
(11520693, 'Đỗ Minh Vũ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520694, 'Tô Anh Vũ', 'Mạng máy tính & truyền thông'),
(11520695, 'Lê Nguyễn Quang Vũ', 'Mạng máy tính & truyền thông'),
(11520696, 'Lê Quang Vũ', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520697, 'Phạm Thế Vũ', 'Hệ thống thông tin'),
(11520698, 'Nguyễn Văn Vương', 'Hệ thống thông tin'),
(11520699, 'Đào Lập Xuân', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520700, 'Võ Đoàn Ngọc Trường Xuân', 'Mạng máy tính & truyền thông'),
(11520701, 'Vũ Huy Chương', 'Khoa học máy tính'),
(11520702, 'Nguyễn Phú Cường', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520703, 'Đỗ Thành Đạt', 'Kỹ thuật máy tính'),
(11520704, 'Lưu Văn Lành', 'Chương trình tiên tiến'),
(11520705, 'Dương Ngọc Ly', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520706, 'Nguyễn Sỹ Mạnh', 'Công nghệ phần mềm'),
(11520707, 'Nguyễn Đình Hoàng Nguyên', 'Công nghệ phần mềm'),
(11520708, 'Lê Văn Phương', 'Hệ thống thông tin'),
(11520709, 'Võ Dương Quang', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11520710, 'Lê Minh Trí', ''),
(11520711, 'NgĂ´ Hiáşżu TrĆ°áťng', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(11520712, 'Tống Thị Phương Uyên', 'Kỹ thuật máy tính'),
(11720009, 'Ung Thanh Kiều', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11720013, 'Dương Minh Nhất', 'Đào tạo từ xa'),
(11720019, 'Lê Truyền Thanh', 'Đào tạo từ xa'),
(11720020, 'Trương Hoàng Thiện', 'Đào tạo từ xa'),
(11720021, 'Cao Minh Thơ', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11720022, 'Nguyễn Thị Kim Thuyền', 'Đào tạo từ xa'),
(11720024, 'Mai Hòa Bình', 'Đào tạo từ xa'),
(11720029, 'Phạm Thanh Nguyên', 'Đào tạo từ xa'),
(11720031, 'Hoàng Minh Quân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11720032, 'Huỳnh Trọng Tài', 'Đào tạo từ xa'),
(11720036, 'Lê Hoàng Vĩnh', 'Đào tạo từ xa'),
(11720037, 'Voõ quoác Vöông', 'Đào tạo từ xa'),
(11720038, 'Nguyễn Hải Đăng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11720043, 'Vuõ Quang Minh', 'Đào tạo từ xa'),
(11720045, 'Đặng Thị Huỳnh Như', 'Đào tạo từ xa'),
(11720046, 'Trương Thanh Tài', 'Đào tạo từ xa'),
(11720048, 'Mai Thị Mộng Thu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11720049, 'Lê Nhật Trường', 'Đào tạo từ xa'),
(11720050, 'Nguyễn Thaùi  Hiền', 'Đào tạo từ xa'),
(11720051, 'Trương Văn  Hoøa', 'Đào tạo từ xa'),
(11720054, 'Nguyễn Kim Ngân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11720057, 'Leâ Ngoïc Tuyết', 'Đào tạo từ xa'),
(11730001, 'Trần Phạm Trường  An', 'Đào tạo từ xa'),
(11730002, 'Nguyễn Phúc Hồng An', 'Đào tạo từ xa'),
(11730003, 'Trần Quốc Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730004, 'Nguyễn Phương Bằng', 'Đào tạo từ xa'),
(11730005, 'Đặng Huy Cảnh', 'Đào tạo từ xa'),
(11730006, 'Nguyễn Thị Hồng Châu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730007, 'Thạch Văn  Cường', 'Đào tạo từ xa'),
(11730008, 'Đoàn Huỳnh Đảm', 'Đào tạo từ xa'),
(11730010, 'Nguyễn Thế Định', 'Đào tạo từ xa'),
(11730011, 'Hồ Thị Mỹ Dung', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730012, 'Nguyễn Văn  Gẩm', 'Đào tạo từ xa'),
(11730013, 'Phan Thanh  Hà', 'Đào tạo từ xa'),
(11730015, 'Đặng Việt Hưng', 'Đào tạo từ xa'),
(11730016, 'Phan Ngọc Hưng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730018, 'Lê Phú  Hữu', 'Đào tạo từ xa'),
(11730019, 'Trần Khắc  Huy', 'Đào tạo từ xa'),
(11730020, 'Phạm Nhựt Kha', 'Đào tạo từ xa'),
(11730021, 'Nguyễn Mai Khanh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730022, 'Phạm Thanh Khôi', 'Đào tạo từ xa'),
(11730023, 'Phan Duy Khương', 'Đào tạo từ xa'),
(11730024, 'Võ Nguyễn Yên  Lam', 'Đào tạo từ xa'),
(11730025, 'Bùi Quang Lân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730026, 'Lê Công Lập', 'Đào tạo từ xa'),
(11730027, 'Nguyễn Trần Nhật Linh', 'Đào tạo từ xa'),
(11730029, 'Hồ Chí Na', 'Đào tạo từ xa'),
(11730030, 'Trần Hoàng Nam', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730031, 'Võ Trung Nghĩa', 'Đào tạo từ xa'),
(11730032, 'Trần Trung  Nghĩa', 'Đào tạo từ xa'),
(11730033, 'Nguyễn Hữu  Nghĩa', 'Đào tạo từ xa'),
(11730034, 'Lê Quang Ngự', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730035, 'Trương Ly  Nha', 'Đào tạo từ xa'),
(11730036, 'Đào Công Nhanh', 'Đào tạo từ xa'),
(11730037, 'Nguyễn Thị Kim Nhi', 'Đào tạo từ xa'),
(11730038, 'Lê Thị Nhiệm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730039, 'Cao Phạm Huỳnh Như', 'Đào tạo từ xa'),
(11730040, 'Võ Minh  Nhựt', 'Đào tạo từ xa'),
(11730041, 'Nguyễn Hoàng Nhựt', 'Đào tạo từ xa'),
(11730042, 'Lê Thanh Phong', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730043, 'Nguyễn Thanh Phú', 'Đào tạo từ xa'),
(11730044, 'Nguyễn Lê Phước', 'Đào tạo từ xa'),
(11730045, 'Trương Nhựt Phương', 'Đào tạo từ xa'),
(11730046, 'Nguyễn Thanh Phương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730049, 'Đào Tấn Tài', 'Đào tạo từ xa'),
(11730051, 'Huỳnh Thanh Tâm', 'Đào tạo từ xa'),
(11730052, 'Lê Minh  Thái', 'Đào tạo từ xa'),
(11730053, 'Nguyễn Thị Thầm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730054, 'Phan Văn  Thặng', 'Đào tạo từ xa'),
(11730055, 'Nguyễn Trung Thành', 'Đào tạo từ xa'),
(11730057, 'Huỳnh Thị Anh Thư', 'Đào tạo từ xa'),
(11730058, 'Phạm Thanh  Thưởng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730059, 'Nguyễn Sơn  Thủy', 'Đào tạo từ xa'),
(11730060, 'Nguyễn Thị Tố Tri', 'Đào tạo từ xa'),
(11730061, 'Nguyễn Minh Trí', 'Đào tạo từ xa'),
(11730062, 'Lê Duy  Trí', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730063, 'Trần Thị Thanh Trúc', 'Đào tạo từ xa'),
(11730065, 'Lê Huy Tùng', 'Đào tạo từ xa'),
(11730066, 'Trần Quốc Việt', 'Đào tạo từ xa'),
(11730069, 'Trần Minh Vương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730070, 'Đặng Thị Yến Xuân', 'Đào tạo từ xa'),
(11730071, 'Nguyễn Thành Châu', 'Đào tạo từ xa'),
(11730072, 'Trần Hoàng Đạo', 'Đào tạo từ xa'),
(11730073, 'Trần Văn Diệp', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730074, 'Dương Thị Hà', 'Đào tạo từ xa'),
(11730075, 'Trịnh Văn Minh Hải', 'Đào tạo từ xa'),
(11730076, 'Nguyễn Huỳnh', 'Đào tạo từ xa'),
(11730078, 'Mai Văn Khánh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730081, 'Lê Hoàng Luân', 'Đào tạo từ xa'),
(11730084, 'Nguyễn Bình Phương', 'Đào tạo từ xa'),
(11730085, 'Nguyễn Hữu Sơn', 'Đào tạo từ xa'),
(11730087, 'Nguyễn Anh Thư', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730089, 'Đoàn Thanh Trọng', 'Đào tạo từ xa'),
(11730090, 'Đoàn Quang Vinh', 'Đào tạo từ xa'),
(11730094, 'Phạm Quốc Hậu', 'Đào tạo từ xa'),
(11730095, 'Nguyễn Thanh Khoa', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730097, 'Nguyễn Anh Thi', 'Đào tạo từ xa'),
(11730098, 'Trần Chí Thiện', 'Đào tạo từ xa'),
(11730099, 'Nguyễn Thị Thanh Thủy', 'Đào tạo từ xa'),
(11730100, 'Lê Thùy Trang', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730101, 'Nguyễn Anh Tú', 'Đào tạo từ xa'),
(11730103, 'Nguyễn Thanh  Bình', 'Đào tạo từ xa'),
(11730104, 'Nguyễn Văn  Bình', 'Đào tạo từ xa'),
(11730108, 'Nguyễn Hữu  Duy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730110, 'Nguyễn Vũ Đăng  Khoa', 'Đào tạo từ xa'),
(11730114, 'Trần Lương Thanh  Nghị', 'Đào tạo từ xa'),
(11730115, 'Đặng Thị Kim  Ngọc', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730116, 'Lê Quang  Nguyên', 'Đào tạo từ xa'),
(11730117, 'Tống Thành Nhân', 'Đào tạo từ xa'),
(11730118, 'Vũ Đức  Nhất', 'Đào tạo từ xa'),
(11730120, 'Huỳnh Hạnh  Phúc', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730121, 'Nguyễn Tuấn  Phương', 'Đào tạo từ xa'),
(11730122, 'Cao  Quang', 'Đào tạo từ xa'),
(11730124, 'Bùi Minh  Sang', 'Đào tạo từ xa'),
(11730125, 'Lê Hoàng  Tâm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730126, 'Nguyễn Minh  Tâm', 'Đào tạo từ xa'),
(11730127, 'Nguyễn Văn  Thành', 'Đào tạo từ xa'),
(11730128, 'Nguyễn Thị Thanh Thúy', 'Đào tạo từ xa'),
(11730129, 'Phạm Lộc  Tiến', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730130, 'Nguyễn Thanh  Toàn', 'Đào tạo từ xa'),
(11730131, 'Trịnh Kiều  Trang', 'Đào tạo từ xa'),
(11730132, 'Nguyễn Minh  Trường', 'Đào tạo từ xa'),
(11730133, 'Trần Anh  Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730134, 'Âu Thành  Vĩnh', 'Đào tạo từ xa'),
(11730137, 'Hồ Ngọc Bách', 'Đào tạo từ xa'),
(11730138, 'Võ Thanh Bình', 'Đào tạo từ xa'),
(11730141, 'Nguyễn Bá  Duy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730143, 'Mai Gia Hải', 'Đào tạo từ xa'),
(11730144, 'Huỳnh Trung Hiếu', 'Đào tạo từ xa'),
(11730147, 'Nguyễn Sỹ  Hoàng', 'Đào tạo từ xa'),
(11730148, 'Dương Quốc  Huy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730151, 'Đào Duy  Lên', 'Đào tạo từ xa'),
(11730152, 'Trần Việt Long', 'Đào tạo từ xa'),
(11730153, 'Phan Ngọc Minh', 'Đào tạo từ xa'),
(11730155, 'Nguyễn Ngô Ngọc Ngân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730157, 'Hồ Quốc  Thái', 'Đào tạo từ xa'),
(11730163, 'Đỗ Hữu Quốc  Trường', 'Đào tạo từ xa'),
(11730164, 'Hoàng Trọng  Viên', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730166, 'Mai Trần Hồng Yến', 'Đào tạo từ xa'),
(11730167, 'Huỳnh Quang Bình', 'Đào tạo từ xa'),
(11730169, 'Thái Duy Mạnh  Dũng', 'Đào tạo từ xa'),
(11730171, 'Ngô Đức  Hải', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730173, 'Lê Hoàng  Hiệp', 'Đào tạo từ xa'),
(11730176, 'Trần Bá Sỹ Quỳnh', 'Đào tạo từ xa'),
(11730177, 'Nguyễn Đình  Tâm', 'Đào tạo từ xa'),
(11730178, 'Lê Văn Thạch', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730180, 'Nguyễn Văn  Thể', 'Đào tạo từ xa'),
(11730187, 'Trần Thanh Vũ', 'Đào tạo từ xa'),
(11730188, 'Vũ Tuấn  Anh', 'Đào tạo từ xa'),
(11730189, 'Hồ Viết  Chính', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730191, 'Nguyễn Ngọc  Hiếu', 'Đào tạo từ xa'),
(11730193, 'Nguyễn Anh  Khoa', 'Đào tạo từ xa'),
(11730194, 'Nguyễn Vĩnh  Lộc', 'Đào tạo từ xa'),
(11730195, 'Đoàn Thiện  Phước', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730197, 'Nguyễn Trần Nhật  Tuấn', 'Đào tạo từ xa'),
(11730198, 'Phạm Quốc  Tuyến', 'Đào tạo từ xa'),
(11730199, 'Võ Thị Tiếp Vươn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730200, 'Nguyễn Ngọc Anh', 'Đào tạo từ xa'),
(11730201, 'Trần Minh Thảo  Anh', 'Đào tạo từ xa'),
(11730202, 'Thái Văn  Cường', 'Đào tạo từ xa'),
(11730203, 'Trần Văn  Duy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730207, 'Hoàng Thanh  Minh', 'Đào tạo từ xa'),
(11730209, 'Nguyễn Phương  Thanh', 'Đào tạo từ xa'),
(11730210, 'Phạm Duy  Thịnh', 'Đào tạo từ xa'),
(11730211, 'Nguyễn Văn  Điệp', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730213, 'Huỳnh Đức  Huy', 'Đào tạo từ xa'),
(11730215, 'Nguyễn Hoàng  Lộc', 'Đào tạo từ xa'),
(11730216, 'Đinh Việt  Long', 'Đào tạo từ xa'),
(11730218, 'Phạm Văn  Tài', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730220, 'Phạm Viết  Thắng', 'Đào tạo từ xa'),
(11730223, 'Lê Bá Khánh  Tùng', 'Đào tạo từ xa'),
(11730224, 'Huỳnh Duy An', 'Đào tạo từ xa'),
(11730225, 'Nguyễn Ngọc Trường An', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730226, 'Lê Trương Tuấn Anh', 'Đào tạo từ xa'),
(11730231, 'Lê Duy Đức', 'Đào tạo từ xa'),
(11730233, 'Trần Anh Khoa', 'Đào tạo từ xa'),
(11730235, 'Phạm Ngọc Lịnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730239, 'Võ Hoàng Nam', 'Đào tạo từ xa'),
(11730240, 'Nguyễn Duy Nam', 'Đào tạo từ xa'),
(11730241, 'Lê Thị Kim Ngân', 'Đào tạo từ xa'),
(11730242, 'Đoàn Văn Hữu Nhạn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730245, 'Tôn Thị Nhớ', 'Đào tạo từ xa'),
(11730246, 'Dư Thành Phú', 'Đào tạo từ xa'),
(11730248, 'Phạm Thị Trúc Phương', 'Đào tạo từ xa'),
(11730249, 'Lê Thị Quyết', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730251, 'Đặng Phạm Quốc Thịnh', 'Đào tạo từ xa'),
(11730252, 'Nguyễn Phúc Thọ', 'Đào tạo từ xa'),
(11730253, 'Huỳnh Thị Thu Trang', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730254, 'Hồ Trung Trực', 'Đào tạo từ xa'),
(11730258, 'Lê Thị Tường Vân', 'Đào tạo từ xa'),
(11730259, 'Huỳnh Thế Vinh', 'Đào tạo từ xa'),
(11730265, 'Nguyễn Văn Điều', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730266, 'Võ Đức Duy', 'Đào tạo từ xa'),
(11730267, 'Trần Thị Thu Duyên', 'Đào tạo từ xa'),
(11730269, 'Tô Tử Kha', 'Đào tạo từ xa'),
(11730270, 'Trần Văn Khải', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730271, 'Đào Huỳnh Long', 'Đào tạo từ xa'),
(11730273, 'Lê Thanh Ngọc', 'Đào tạo từ xa'),
(11730274, 'Đoàn Anh Nhớ', 'Đào tạo từ xa'),
(11730283, 'Lê Ngọc Trang', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730289, 'Phạm Lê Xuân', 'Đào tạo từ xa'),
(11730291, 'Trần Quang Bình', 'Đào tạo từ xa'),
(11730292, 'Huỳnh Quốc Chinh', 'Đào tạo từ xa'),
(11730293, 'Nguyễn Hào  Cường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730295, 'Nguyễn Hải Đông', 'Đào tạo từ xa'),
(11730296, 'Nguyễn Đức Dũng', 'Đào tạo từ xa'),
(11730297, 'Huỳnh Hán Việt Bảo Dương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730305, 'Nguyễn Ngọc Hòa', 'Đào tạo từ xa'),
(11730306, 'Nguyễn Thái Hòa', 'Đào tạo từ xa'),
(11730308, 'Hoàng Thế Hưng', 'Đào tạo từ xa'),
(11730309, 'Phùng Đức  Huy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730311, 'Trần Anh Khoa', 'Đào tạo từ xa'),
(11730314, 'Lê Văn  Sinh', 'Đào tạo từ xa'),
(11730315, 'Dương Trung Sơn', 'Đào tạo từ xa'),
(11730317, 'Đinh Xuân Thái', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730319, 'Trần Đặng Anh Thảo', 'Đào tạo từ xa'),
(11730320, 'Ngô Quang Thi', 'Đào tạo từ xa'),
(11730321, 'Phạm Thị Đan Thùy', 'Đào tạo từ xa'),
(11730322, 'Huỳnh Kim Toàn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730327, 'Lương Thanh Xuân', 'Đào tạo từ xa'),
(11730328, 'Lê Tấn  Đạt', 'Đào tạo từ xa'),
(11730329, 'Đoàn Ngọc  Doanh', 'Đào tạo từ xa'),
(11730330, 'Phạm Huy  Hoàng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730332, 'Lâm Thanh  Nguyên', 'Đào tạo từ xa'),
(11730333, 'Lê Tùng  Phương', 'Đào tạo từ xa'),
(11730334, 'Vũ Huy  Quang', 'Đào tạo từ xa'),
(11730335, 'Hà Thiện  Tây', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730336, 'Thân Đức Huỳnh  Thắng', 'Đào tạo từ xa'),
(11730353, 'Nguyễn Văn Hiếu', 'Đào tạo từ xa'),
(11730354, 'Đặng Nguyễn Đức Hùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730355, 'Danh Thanh Hùng', 'Đào tạo từ xa'),
(11730356, 'Nguyễn Văn Mạnh', 'Đào tạo từ xa'),
(11730357, 'Lương Thị Như Nguyệt', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730358, 'Nguyễn Thị Lan Phương', 'Đào tạo từ xa'),
(11730360, 'Mai Thị Kim Riếp', 'Đào tạo từ xa'),
(11730362, 'Huỳnh Minh Thoại', 'Đào tạo từ xa'),
(11730363, 'Dương Hoài Thông', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730364, 'Cao Thị Tuyết Trinh', 'Đào tạo từ xa'),
(11730365, 'Trần Trọng Thanh', 'Đào tạo từ xa'),
(11730367, 'Trần Hoàng  Ai', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(11730369, 'Nguyễn Trương Vân  Hạc', 'Đào tạo từ xa'),
(12040001, 'Hoàng Tuấn Anh', 'Đào tạo từ xa'),
(12040002, 'Lê Quyền Anh', 'Đào tạo từ xa'),
(12040003, 'Ngô Tuấn Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040005, 'Nguyễn Việt Anh', 'Đào tạo từ xa'),
(12040006, 'Phạm Việt Anh', 'Đào tạo từ xa'),
(12040007, 'Vũ Tuấn Anh', 'Đào tạo từ xa'),
(12040009, 'Vũ Văn Cường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040012, 'Vũ Thị Dung', 'Đào tạo từ xa'),
(12040013, 'Dương Văn Dũng', 'Đào tạo từ xa'),
(12040014, 'Nguyễn Thanh Hải', 'Đào tạo từ xa'),
(12040015, 'Lê Thị Thu Hằng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040016, 'Đặng Thị Hạnh', 'Đào tạo từ xa'),
(12040018, 'Phạm Huy Hoàng', 'Đào tạo từ xa'),
(12040019, 'Phạm Đăng Hùng', 'Đào tạo từ xa'),
(12040020, 'Nguyễn Thị Huyền', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040021, 'Phạm Thị Khánh Huyền', 'Đào tạo từ xa'),
(12040022, 'Nguyễn Văn Khải', 'Đào tạo từ xa'),
(12040024, 'Lê Văn Linh', 'Đào tạo từ xa'),
(12040025, 'Vũ Đỗ Tuấn Linh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040026, 'Hoàng Đình Long', 'Đào tạo từ xa'),
(12040027, 'Nguyễn Công Long', 'Đào tạo từ xa'),
(12040028, 'Trịnh Thị Lý', 'Đào tạo từ xa'),
(12040029, 'Nguyễn Hữu Mạnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040030, 'Nguyễn Văn Mạnh', 'Đào tạo từ xa'),
(12040031, 'Vũ Nhân Mạnh', 'Đào tạo từ xa'),
(12040032, 'Đào Đình Nam', 'Đào tạo từ xa'),
(12040033, 'Hoàng Việt Nam', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040034, 'Nguyễn Văn Ngọc', 'Đào tạo từ xa'),
(12040035, 'Vũ Thị Ngọc', 'Đào tạo từ xa'),
(12040036, 'Phạm Văn Nhân', 'Đào tạo từ xa'),
(12040038, 'Nguyễn Văn Phú', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040039, 'Cao Nam Phương', 'Đào tạo từ xa'),
(12040041, 'Phạm Văn Quyết', 'Đào tạo từ xa'),
(12040042, 'Trần Anh Sơn', 'Đào tạo từ xa'),
(12040043, 'Hoàng Văn Tài', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040044, 'Đỗ Chiến Thắng', 'Đào tạo từ xa'),
(12040045, 'Nguyễn Duy Thành', 'Đào tạo từ xa'),
(12040046, 'Trần Văn Thành', 'Đào tạo từ xa'),
(12040047, 'Trần Đức Thiện', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040048, 'Phạm Bá Thiệu', 'Đào tạo từ xa'),
(12040049, 'Nguyễn Thị Thu', 'Đào tạo từ xa'),
(12040050, 'Tô Văn Thưởng', 'Đào tạo từ xa'),
(12040051, 'Nguyễn Đăng Tiến', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040052, 'Vũ Văn Toàn', 'Đào tạo từ xa'),
(12040053, 'Bùi Thị Trâm', 'Đào tạo từ xa'),
(12040055, 'Vũ Đức Trọng', 'Đào tạo từ xa'),
(12040056, 'Hoàng Văn Trung', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040058, 'Nguyễn Thành Trung', 'Đào tạo từ xa'),
(12040060, 'Trần Kim Tú', 'Đào tạo từ xa'),
(12040061, 'Đồng Minh Tuấn', 'Đào tạo từ xa'),
(12040062, 'Đỗ Văn Tuất', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12040063, 'Nguyễn Đức Tùng', 'Đào tạo từ xa'),
(12040065, 'Phạm Quốc Tưởng', 'Đào tạo từ xa'),
(12040066, 'Phan Đình Vinh', 'Đào tạo từ xa'),
(12520001, 'Nguyễn Trường An', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520002, 'Nguyễn Tuấn An', 'Khoa học máy tính'),
(12520003, 'Cao Ngọc Anh', 'Công nghệ phần mềm'),
(12520004, 'Lê Doãn Huỳnh Tuấn Anh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520005, 'Lê Tuấn Anh', 'Công nghệ phần mềm'),
(12520006, 'Lê Tuấn Anh', 'Công nghệ phần mềm'),
(12520007, 'Lê Việt Anh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520008, 'Nguyễn Hoàng Anh', 'Mạng máy tính & truyền thông'),
(12520009, 'Nguyễn Ngọc Quỳnh Anh', 'Hệ thống thông tin'),
(12520010, 'Nguyễn Tuấn Anh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520011, 'Nguyễn Tuấn Anh', 'Công nghệ phần mềm'),
(12520012, 'Nguyễn Việt Anh', 'Tân sinh viên'),
(12520013, 'Nguyễn Vũ Anh', 'Công nghệ phần mềm'),
(12520014, 'Trần Ngọc Anh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520015, 'Trương Quế Anh', 'Chương trình tiên tiến'),
(12520016, 'Võ Xuân Anh', 'Công nghệ phần mềm'),
(12520017, 'Y Thân Ayun', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520018, 'Äinh Nháş­t BÄng', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(12520019, 'Nguyễn Ngọc Bằng', 'Khoa học máy tính'),
(12520020, 'Hoàng Trọng Bảo', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520021, 'Lê Văn Bảo', 'Mạng máy tính & truyền thông'),
(12520022, 'Nguyễn Quốc Bảo', 'Công nghệ phần mềm'),
(12520023, 'Phạm Bảo', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520024, 'Phạm Ngọc Bảo', 'Công nghệ phần mềm'),
(12520025, 'Trần Nguyên Bảo', 'Mạng máy tính & truyền thông'),
(12520026, 'Phan Y Biển', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520027, 'Lê Hữu Bình', 'Mạng máy tính & truyền thông'),
(12520028, 'Nguyễn Văn Bình', 'Kỹ thuật máy tính'),
(12520029, 'Nhữ Thanh Bình', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520030, 'Phạm Thái Bình', 'Kỹ thuật máy tính'),
(12520031, 'Ung Sơn Bình', 'Công nghệ phần mềm'),
(12520032, 'Bùi Đăng Bộ', 'Hệ thống thông tin'),
(12520033, 'Nguyễn Văn Bông', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520034, 'Nguyễn Văn Cảnh', 'Công nghệ phần mềm'),
(12520035, 'Nguyễn Thanh Cao', 'Công nghệ phần mềm'),
(12520036, 'Nguyễn Văn Chính', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520037, 'Lưu Công Chình', 'Công nghệ phần mềm'),
(12520038, 'Nguyễn Thành Công', 'Kỹ thuật máy tính'),
(12520039, 'Hồ Kim Cúc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520040, 'Ngô Tuấn Cường', 'Kỹ sư tài năng ANTT'),
(12520041, 'Nguyễn Quốc Cường', 'Mạng máy tính & truyền thông'),
(12520042, 'Nguyáťn Sáťš MáşĄnh CĆ°áťng', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520043, 'Nguyễn Trần Quốc Cường', 'Hệ thống thông tin'),
(12520044, 'Trần Minh Cường', 'Công nghệ phần mềm'),
(12520045, 'Võ Văn Cường', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520046, 'Đặng Minh Đắc', 'Tân sinh viên'),
(12520047, 'Nguyễn Đức Đại', 'Khoa học máy tính'),
(12520048, 'Phạm Anh Đại', 'Công nghệ phần mềm'),
(12520049, 'Trịnh Minh Đại', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520050, 'Trần Ngọc Dân', 'Công nghệ phần mềm'),
(12520051, 'Lê Hải Đăng', 'Kỹ thuật máy tính'),
(12520052, 'Nguyễn Hải Đăng', 'Tân sinh viên'),
(12520053, 'Nguyễn Viết Danh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520054, 'Tráş§n HáťŻu Danh', 'CĂ´ng ngháť pháş§n máťm'),
(12520055, 'Hà Tấn Đạt', 'Mạng máy tính & truyền thông'),
(12520056, 'Lê Văn Đạt', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520057, 'Lương Tấn Đạt', 'Khoa học máy tính'),
(12520058, 'Lý Gia Đạt', 'Hệ thống thông tin'),
(12520059, 'Nguyễn Lê Thành Đạt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520060, 'Nguyễn Thành Đạt', 'Kỹ sư tài năng ANTT'),
(12520061, 'Nguyễn Trần ý Đạt', 'Công nghệ phần mềm'),
(12520062, 'Nguyễn Tuấn Đạt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520063, 'Quang Tuấn Đạt', 'Công nghệ phần mềm'),
(12520064, 'Tôn Thất Thành Đạt', 'Mạng máy tính & truyền thông'),
(12520065, 'Trần Bá Đạt', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520066, 'Trần Đình Đạt', 'Công nghệ phần mềm'),
(12520067, 'Vũ Tiến Đạt', 'Công nghệ phần mềm'),
(12520068, 'Hồ Quí Đầy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520069, 'Đào Thị Kiều Diễm', 'Công nghệ phần mềm'),
(12520070, 'Nguyễn Văn Diện', 'Khoa học máy tính'),
(12520071, 'Trương Thành Diện', 'Kỹ sư tài năng ANTT'),
(12520072, 'Nguyễn Tiến Đình', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520073, 'Hoàng Ngọc Định', 'Công nghệ phần mềm'),
(12520074, 'Nguyễn Kỳ Đôn', 'Tân sinh viên'),
(12520075, 'Đỗ Trung Đông', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520076, 'Lê Văn Kỳ Dự', 'Công nghệ phần mềm'),
(12520077, 'Hà Huy Đức', 'Công nghệ phần mềm'),
(12520078, 'Nguyễn Văn Đức', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520079, 'Phan Ngọc Đức', 'Mạng máy tính & truyền thông'),
(12520080, 'Trần Hữu Đức', 'Kỹ thuật máy tính'),
(12520081, 'Võ Minh Đức', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520082, 'Huỳnh Dũng', 'Mạng máy tính & truyền thông'),
(12520083, 'Lâm Quốc Dũng', 'Công nghệ phần mềm'),
(12520084, 'Lê Trung Dũng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520085, 'Mai Tiến Dũng', 'Mạng máy tính & truyền thông'),
(12520086, 'Nguyễn Anh Dũng', 'Công nghệ phần mềm'),
(12520087, 'Nguyễn Đình Dũng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520088, 'Nguyễn Kim Dũng', 'Công nghệ phần mềm'),
(12520089, 'Nguyễn Phi Dũng', 'Kỹ sư tài năng ANTT'),
(12520090, 'Phạm Ngọc Dũng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520091, 'Đào Duy Dương', 'Công nghệ phần mềm'),
(12520092, 'Đỗ Thanh Dương', 'Tân sinh viên'),
(12520093, 'Nguyễn Hoàng Dương', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520094, 'Bùi Nguyễn Thanh Duy', 'Mạng máy tính & truyền thông'),
(12520095, 'Đặng Văn Duy', 'Kỹ thuật máy tính'),
(12520096, 'Đào Văn Duy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520097, 'Đinh Tiến Duy', 'Mạng máy tính & truyền thông'),
(12520098, 'Đỗ Ngọc Bảo Duy', 'Tân sinh viên'),
(12520099, 'Hồ Lập Duy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520100, 'Lương Phan Bảo Duy', 'Khoa học máy tính'),
(12520101, 'Ngô Quốc Duy', 'Hệ thống thông tin'),
(12520102, 'Ngô Thái Duy', 'Công nghệ phần mềm'),
(12520103, 'Nguyễn Anh Duy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520104, 'Nguyễn Hoàng Duy', 'Mạng máy tính & truyền thông'),
(12520105, 'Nguyễn Hoàng Duy', 'Tân sinh viên'),
(12520106, 'Nguyễn Trần Khánh Duy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520107, 'Nguyễn Xuân Duy', 'Khoa học máy tính'),
(12520108, 'Phạm Duy', 'Kỹ thuật máy tính'),
(12520109, 'Phạm Võ Khánh Duy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520110, 'Phan Ngọc Duy', 'Mạng máy tính & truyền thông'),
(12520111, 'Phan Nguyễn Đăng Duy', 'Công nghệ phần mềm'),
(12520112, 'Phùng Anh Duy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520113, 'Quách Đại Phan Duy', 'Kỹ sư tài năng ANTT'),
(12520114, 'Trần Anh Duy', 'Kỹ thuật máy tính'),
(12520115, 'Trần Khánh Duy', 'Khoa học máy tính'),
(12520116, 'Vương Hoàng Duy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520117, 'Nguyễn Thị Thu Giang', 'Hệ thống thông tin'),
(12520118, 'Trịnh Hoàng Giang', 'Hệ thống thông tin'),
(12520119, 'Trương Hoài Giang', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520120, 'Bùi Thanh Giao', 'Công nghệ phần mềm'),
(12520121, 'Nguyễn Văn Giáp', 'Công nghệ phần mềm'),
(12520122, 'Cấn Hoàng Hải', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520123, 'Nguyễn Duy Hải', 'Mạng máy tính & truyền thông'),
(12520124, 'Nguyễn Lâm Hải', 'Hệ thống thông tin'),
(12520125, 'Trần Liêu Phước Hải', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520126, 'Trần Thanh Hải', 'Công nghệ phần mềm'),
(12520127, 'Hoàng Ngọc Hạnh', 'Công nghệ phần mềm'),
(12520128, 'Lê Văn Hạnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520129, 'Nguyễn Thị Hồng Hạnh', 'Mạng máy tính & truyền thông'),
(12520130, 'Vưu Chí Hào', 'Công nghệ phần mềm'),
(12520131, 'Phạm Hoàng Hảo', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520132, 'Hứa Văn Hậu', 'Tân sinh viên'),
(12520133, 'Cao Xuân Hiếu', 'Khoa học máy tính'),
(12520134, 'Đỗ Phạm Trung Hiếu', 'Kỹ thuật máy tính'),
(12520135, 'Đỗ Trung Hiếu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520136, 'Nguyễn Hữu Hiếu', 'Công nghệ phần mềm'),
(12520137, 'Nguyễn Minh Hiếu', 'Công nghệ phần mềm'),
(12520138, 'Nguyễn Quang Hiếu', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520139, 'Nguyễn Trung Hiếu', 'Tân sinh viên'),
(12520140, 'Nguyễn Văn Hiếu', 'Công nghệ phần mềm'),
(12520141, 'Trần Chí Hiếu', 'Công nghệ phần mềm'),
(12520142, 'Võ Văn Hiếu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520143, 'VĂľ VÄn Hiáşżu', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(12520144, 'Nguyễn Lê Minh Hoà', 'Kỹ thuật máy tính'),
(12520145, 'Lê Đức Hòa', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520146, 'Trương Nguyễn Thái Hòa', ''),
(12520147, 'Võ Đức Hòa', 'Mạng máy tính & truyền thông'),
(12520148, 'Lê Thị Hoài', 'Hệ thống thông tin'),
(12520149, 'Nguyễn Kim Hoàn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520150, 'Trần Quốc Hoàn', 'Hệ thống thông tin'),
(12520151, 'Vũ Khải Hoàn', 'Mạng máy tính & truyền thông'),
(12520152, 'Lưu Văn Hoàng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520153, 'Nguyễn Hoàng', 'Kỹ sư tài năng ANTT'),
(12520154, 'Nguyễn Huy Hoàng', 'Công nghệ phần mềm'),
(12520155, 'Nguyễn Ngọc Hoàng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520156, 'Nguyễn Hoàng Ngọc Hồng', 'Hệ thống thông tin'),
(12520157, 'Nguyễn Thị Thanh Hồng', 'Công nghệ phần mềm'),
(12520158, 'Nguyễn Minh Huân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520159, 'Nguyễn Việt Hùng', 'Mạng máy tính & truyền thông'),
(12520160, 'Nguyễn Việt Hùng', 'Công nghệ phần mềm'),
(12520161, 'Phạm Thanh Hùng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520162, 'Phạm Văn Hùng', 'Mạng máy tính & truyền thông'),
(12520163, 'Trần Mạnh Hùng', 'Mạng máy tính & truyền thông'),
(12520164, 'Trần Văn Hùng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520165, 'Vũ Đình Hùng', 'Khoa học máy tính'),
(12520166, 'Nguyễn Đức Hưng', 'Mạng máy tính & truyền thông'),
(12520167, 'PháşĄm NguyĂŞn HĆ°ng', 'Cáť­ nhĂ˘n tĂ i nÄng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520168, 'Hoàng Thị Thu Hương', 'Mạng máy tính & truyền thông'),
(12520169, 'Nguyễn Thị Hương', 'Công nghệ phần mềm'),
(12520170, 'Trương Thị Diễm Hương', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520171, 'Võ Xuân Hữu', 'Công nghệ phần mềm'),
(12520172, 'Hồ Thanh Huy', 'Công nghệ phần mềm'),
(12520173, 'Lâm Hoàng Huy', 'Công nghệ phần mềm'),
(12520174, 'Lý Nhật Huy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520175, 'Nguyễn Quốc Huy', 'Mạng máy tính & truyền thông'),
(12520176, 'Phạm Văn Huy', 'Công nghệ phần mềm'),
(12520177, 'Trần Đắc Huy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520178, 'Trần Phú Huy', 'Kỹ sư tài năng ANTT'),
(12520179, 'Vũ Đức Huy', 'Công nghệ phần mềm'),
(12520180, 'Vũ Đức Huy', 'Hệ thống thông tin'),
(12520181, 'Bùi Thị Lệ Huyền', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520182, 'Nguyễn Thị Thanh Huyền', 'Tân sinh viên'),
(12520183, 'Phan Thanh Huyền', 'Tân sinh viên'),
(12520184, 'Phạm Quang Kha', 'Tân sinh viên'),
(12520185, 'Lê Phan Khải', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520186, 'Trần Quang Khải', 'Công nghệ phần mềm'),
(12520187, 'Đặng Hữu Khang', 'Hệ thống thông tin'),
(12520188, 'Nguyễn Hoàng Khang', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520189, 'Tráş§n TrĂ­ Khang', 'Káťš sĆ° tĂ i nÄng ANTT'),
(12520190, 'Vũ An Khang', 'Mạng máy tính & truyền thông'),
(12520191, 'LĂŞ TáşĽn VĹŠ Khanh', 'CĂ´ng ngháť pháş§n máťm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520192, 'Trần Quốc Tuấn Khanh', 'Công nghệ phần mềm'),
(12520193, 'Văn Công Khanh', 'Mạng máy tính & truyền thông'),
(12520194, 'Đặng Ngọc Khánh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520195, 'Nguyễn Duy Khánh', 'Chương trình tiên tiến'),
(12520196, 'Nguyễn Quốc Khánh', 'Kỹ thuật máy tính'),
(12520197, 'Nguyễn Văn Khánh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520198, 'Phạm Quốc Khánh', 'Công nghệ phần mềm'),
(12520199, 'Phạm Xuân Khánh', 'Công nghệ phần mềm'),
(12520200, 'Từ Nguyên Gia Khánh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520201, 'Huỳnh Quang Khiêm', 'Khoa học máy tính'),
(12520202, 'Đỗ Đăng Khoa', 'Kỹ sư tài năng ANTT'),
(12520203, 'Huỳnh Đăng Khoa', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520204, 'Huỳnh Đức Đăng Khoa', 'Công nghệ phần mềm'),
(12520205, 'Nguyễn Đăng Khoa', 'Khoa học máy tính'),
(12520206, 'Phạm Đăng Khoa', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520207, 'Tăng Duy Khoa', 'Công nghệ phần mềm'),
(12520208, 'Phan Điền Mạnh Khôi', 'Công nghệ phần mềm'),
(12520209, 'Nguyễn Trung Kiên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520210, 'Tống Trí Kiên', 'Kỹ thuật máy tính'),
(12520211, 'Mai Tuấn Kiệt', 'Kỹ thuật máy tính'),
(12520212, 'Nguyễn Lê Tuấn Kiệt', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520213, 'Phạm Tuấn Kiệt', 'Công nghệ phần mềm'),
(12520214, 'Trần Tuấn Kiệt', 'Tân sinh viên'),
(12520215, 'Phạm Việt Kim', 'Tân sinh viên'),
(12520216, 'Trần Ngọc Kông', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520217, 'Hoàng Hải Lâm', 'Tân sinh viên'),
(12520218, 'Nguyễn Trung Lâm', 'Công nghệ phần mềm'),
(12520219, 'Trần Cao Lâm', 'Kỹ thuật máy tính'),
(12520220, 'Trần Tùng Lâm', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520221, 'Trần Văn Lâm', 'Mạng máy tính & truyền thông'),
(12520222, 'Ngô Duy Lân', 'Khoa học máy tính'),
(12520223, 'Nguyễn Thị Yến Lệ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520224, 'Nguyễn Hiếu Liêm', 'Khoa học máy tính'),
(12520225, 'Nguyễn Trần Thành Liễu', 'Khoa học máy tính'),
(12520226, 'Nguyễn Chí Linh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520227, 'Nguyễn Thị Linh', 'Khoa học máy tính'),
(12520228, 'Phạm Ngọc Linh', 'Công nghệ phần mềm'),
(12520229, 'Trần Hoài Linh', 'Tân sinh viên'),
(12520230, 'Lê Thị Loan', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520231, 'Trịnh Đình Loan', 'Công nghệ phần mềm'),
(12520232, 'Đỗ Trần Đại Lộc', 'Kỹ thuật máy tính'),
(12520233, 'Lê Đoàn Đại Lộc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520235, 'Nguyễn Minh Lộc', 'Công nghệ phần mềm'),
(12520236, 'Nguyễn Tấn Lộc', 'Công nghệ phần mềm'),
(12520237, 'Đoàn Vũ Long', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520238, 'Lê Xích Long', 'Kỹ sư tài năng ANTT'),
(12520239, 'Nguyễn Hoàng Long', 'Công nghệ phần mềm'),
(12520240, 'Nguyễn Hoàng Long', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520241, 'Nguyễn Hữu Long', 'Mạng máy tính & truyền thông'),
(12520242, 'Phạm Hòang Long', 'Mạng máy tính & truyền thông'),
(12520243, 'Phạm Tâm Long', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520244, 'Trần Hoàng Long', 'Kỹ sư tài năng ANTT'),
(12520245, 'Nguyễn Thành Luân', 'Công nghệ phần mềm'),
(12520246, 'Trần Thành Luân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520247, 'Hồ Công Luận', 'Mạng máy tính & truyền thông'),
(12520248, 'Trần Minh Luận', 'Công nghệ phần mềm'),
(12520249, 'Trần Như Luận', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520250, 'Phùng Duy Lương', 'Công nghệ phần mềm'),
(12520251, 'Lê Văn Lượng', 'Công nghệ phần mềm'),
(12520252, 'Nguyễn Thị Phương Mai', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520253, 'Nguyễn Thị Thanh Mai', 'Khoa học máy tính'),
(12520254, 'Phan Thành Ngọc Mẫn', 'Mạng máy tính & truyền thông'),
(12520255, 'Lê Duy Mạnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520256, 'Nguyễn Tiến Mạnh', 'Mạng máy tính & truyền thông'),
(12520257, 'Bùi Đức Minh', 'Khoa học máy tính'),
(12520258, 'Cao Nhật Minh', 'Công nghệ phần mềm'),
(12520259, 'Lê Minh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520260, 'Lê Duy Minh', ''),
(12520261, 'Lê Phước Minh', 'Chương trình tiên tiến'),
(12520262, 'Nguyễn Ngọc Minh', 'Công nghệ phần mềm'),
(12520263, 'Trần Bình Minh', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520264, 'Trần Ngọc Minh', 'Mạng máy tính & truyền thông'),
(12520265, 'Nguyễn Thị Hà My', 'Tân sinh viên'),
(12520266, 'Dương Thị Mỹ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520267, 'Đỗ Phương Nam', 'Tân sinh viên'),
(12520268, 'Dương Hoài Nam', 'Tân sinh viên'),
(12520269, 'Hoàng Đại Nam', 'Khoa học máy tính'),
(12520270, 'Hoàng Phương Nam', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520271, 'Hoàng Văn Nam', 'Công nghệ phần mềm'),
(12520272, 'Lê Xuân Nam', 'Công nghệ phần mềm'),
(12520273, 'Nguyễn Chí Nam', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520274, 'Nguyễn Hoài Nam', 'Mạng máy tính & truyền thông'),
(12520275, 'Nguyễn Hoài Nam', 'Hệ thống thông tin'),
(12520276, 'Nguyễn Thanh Nam', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520277, 'Phạm Hải Nam', 'Mạng máy tính & truyền thông'),
(12520278, 'Phạm Hoàng Nam', 'Mạng máy tính & truyền thông'),
(12520279, 'Trần Hoài Nam', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520280, 'Bùi Thị Hằng Nga', 'Tân sinh viên'),
(12520281, 'Nguyễn Thị Thiên Nga', 'Công nghệ phần mềm'),
(12520282, 'Nguyễn Phạm Thủy Ngân', ''),
(12520283, 'Nguyễn Văn Ngân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520284, 'Lương Thế Nghi', 'Mạng máy tính & truyền thông'),
(12520285, 'Dương Hữu Nghĩa', 'Kỹ sư tài năng ANTT'),
(12520286, 'Lê Tùng Nghĩa', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520287, 'Song Thành Nghĩa', 'Công nghệ phần mềm'),
(12520288, 'Tống Duy Ngọc', 'Mạng máy tính & truyền thông'),
(12520289, 'Trần Thị Ngọc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520290, 'Bùi Viết Trung Nguyên', 'Công nghệ phần mềm'),
(12520291, 'Nguyễn Bá Nguyên', 'Kỹ sư tài năng ANTT'),
(12520292, 'Nguyễn Phúc Nguyên', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520293, 'Nguyễn Thành Nguyên', 'Kỹ sư tài năng ANTT'),
(12520294, 'Nguyễn Trọng Nguyên', 'Mạng máy tính & truyền thông'),
(12520295, 'Phạm Kim Chấn Nguyên', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520296, 'Trần Thị Thảo Nguyên', ''),
(12520297, 'Nguyễn Hoàng Nhã', 'Công nghệ phần mềm'),
(12520298, 'Đặng Thành Nhân', 'Công nghệ phần mềm'),
(12520299, 'Lê Thanh Nhân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520300, 'Nguyễn Khoa Minh Nhân', 'Công nghệ phần mềm'),
(12520301, 'Trần Trí Nhân', 'Công nghệ phần mềm'),
(12520302, 'Vũ Thành Nhân', ''),
(12520303, 'Nguyễn Đức Nhẫn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520304, 'Đặng Minh Nhật', 'Công nghệ phần mềm'),
(12520305, 'Lê Quang Nhật', 'Công nghệ phần mềm'),
(12520306, 'Nguyễn Anh Nhật', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520307, 'Lê Quang Như', 'Công nghệ phần mềm'),
(12520308, 'Trần Thiên Như', 'Hệ thống thông tin'),
(12520309, 'Trần Thị Nhung', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520310, 'Nguyễn Bình Nhưỡng', 'Công nghệ phần mềm'),
(12520311, 'Trịnh Chấn Phát', 'Công nghệ phần mềm'),
(12520312, 'Lê Nô Hoàng Phi', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520313, 'Nguyễn Hồng Phi', 'Công nghệ phần mềm'),
(12520314, 'Đoàn Nguyễn Xuân Phong', 'Kỹ thuật máy tính'),
(12520315, 'Lê Nguyễn Hải Phong', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520316, 'Tăng Hoàng Phong', 'Công nghệ phần mềm'),
(12520317, 'Phạm Thanh Phú', 'Công nghệ phần mềm'),
(12520318, 'Đào Hoàng Phúc', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520319, 'Lê Hoàng Phúc', 'Mạng máy tính & truyền thông'),
(12520320, 'Võ Hoàng Phúc', 'Kỹ sư tài năng ANTT'),
(12520321, 'Nguyễn Kiến Phước', ''),
(12520322, 'Bùi Thanh Phương', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520323, 'Cao Xuân Phương', 'Chương trình tiên tiến'),
(12520324, 'Đỗ Hoàng Phương', 'Công nghệ phần mềm'),
(12520325, 'Nguyễn Hoàng Duy Phương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520326, 'Phan Văn Phương', 'Kỹ thuật máy tính'),
(12520327, 'Tống Văn Phương', 'Kỹ thuật máy tính'),
(12520328, 'Võ Hoài Phương', 'Công nghệ phần mềm'),
(12520329, 'Võ Phương Phương', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520330, 'Vương Thị Phương', 'Mạng máy tính & truyền thông'),
(12520331, 'Lâm Vĩ Phượng', 'Mạng máy tính & truyền thông'),
(12520332, 'Cáp Hữu Quân', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520333, 'Lê Duy Quân', 'Công nghệ phần mềm'),
(12520334, 'Lê Minh Quân', 'Công nghệ phần mềm'),
(12520335, 'Lê Toàn Quân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520336, 'Lưu Trương Anh Quân', 'Công nghệ phần mềm'),
(12520337, 'Nguyễn Anh Quân', 'Khoa học máy tính'),
(12520338, 'Phạm Thanh Quân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520339, 'Trần Đức Quân', 'Kỹ thuật máy tính'),
(12520340, 'Nguyễn Huy Quang', 'Mạng máy tính & truyền thông'),
(12520341, 'Nguyễn Nhật Quang', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520342, 'Nguyễn Nhật Quang', 'Công nghệ phần mềm'),
(12520343, 'Phan Vinh Quang', 'Mạng máy tính & truyền thông'),
(12520344, 'Trình Công Quang', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520345, 'Trần Cẩm Quốc', 'Công nghệ phần mềm'),
(12520346, 'Trần Hữu Quốc', 'Tân sinh viên'),
(12520347, 'Phạm Minh Quy', 'Công nghệ phần mềm'),
(12520348, 'Lê Kim Quý', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520349, 'Nguyễn Xuân Quý', 'Khoa học máy tính'),
(12520350, 'Lê Thanh Sang', 'Kỹ thuật máy tính'),
(12520351, 'Nguyễn Hoàng Sang', 'Mạng máy tính & truyền thông'),
(12520352, 'Phạm Minh Sang', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520353, 'Phạm Thanh Sang', 'Công nghệ phần mềm'),
(12520354, 'Võ Thanh Sĩ', 'Công nghệ phần mềm'),
(12520355, 'Hồ Hoàng Sơn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520356, 'Hoàng Huy Sơn', 'Công nghệ phần mềm'),
(12520357, 'Lê Hoàng Sơn', 'Tân sinh viên'),
(12520358, 'Nguyễn Hoàng Sơn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520359, 'Nguyễn Văn Sơn', 'Mạng máy tính & truyền thông'),
(12520360, 'Phạm Hồng Sơn', 'Công nghệ phần mềm'),
(12520361, 'Phạm Tuấn Trung Sơn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520362, 'Lương Văn Song', 'Khoa học máy tính'),
(12520363, 'Tạ Đình Sung', 'Kỹ sư tài năng ANTT'),
(12520364, 'Mai Trung Tá', 'Khoa học máy tính'),
(12520365, 'Bùi Ngọc Tài', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520366, 'Đoàn Minh Tài', 'Công nghệ phần mềm'),
(12520367, 'Dư Phát Tài', 'Công nghệ phần mềm'),
(12520368, 'Dương Minh Tâm', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520369, 'Lê Minh Tâm', 'Mạng máy tính & truyền thông'),
(12520370, 'Nguyễn Công Tâm', 'Kỹ thuật máy tính'),
(12520371, 'Trần Hữu Tâm', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520372, 'Trần Khắc Trí Tâm', 'Mạng máy tính & truyền thông'),
(12520373, 'Hoàng Ngọc Tân', 'Mạng máy tính & truyền thông'),
(12520374, 'Nguyễn Huỳnh Thái Tân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520375, 'Nguyễn Minh Tân', 'Công nghệ phần mềm'),
(12520376, 'Nguyễn Thanh Tân', 'Công nghệ phần mềm'),
(12520377, 'Nguyễn Văn Tân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520378, 'Tô Thế Tân', 'Công nghệ phần mềm'),
(12520379, 'Tống Duy Tân', 'Mạng máy tính & truyền thông'),
(12520380, 'Trương Thanh Tân', 'Tân sinh viên'),
(12520381, 'Võ Hoàng Tân', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520382, 'Võ Huỳnh Minh Tân', 'Mạng máy tính & truyền thông'),
(12520383, 'Phạm Quốc Tấn', 'Mạng máy tính & truyền thông'),
(12520384, 'Đoàn Thành Thái', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520385, 'Lê Hồng Thái', 'Mạng máy tính & truyền thông'),
(12520386, 'Nguyễn Hoàng Thái', 'Công nghệ phần mềm'),
(12520387, 'Nguyễn Văn Thái', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520388, 'Phạm Hồng Thái', 'Mạng máy tính & truyền thông'),
(12520389, 'Mai Trường Thắng', 'Khoa học máy tính'),
(12520390, 'Nguyễn Tiến Thắng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520391, 'Tráş§n Viáşżt TháşŻng', 'Khoa háťc mĂĄy tĂ­nh'),
(12520392, 'Vũ Văn Thắng', 'Mạng máy tính & truyền thông'),
(12520393, 'Phan Thanh Thanh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520394, 'Trần Duy Thanh', 'Công nghệ phần mềm'),
(12520395, 'Bùi Văn Thành', 'Công nghệ phần mềm'),
(12520396, 'Đỗ Bảo Thành', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520397, 'Nguyễn Cao Thành', 'Kỹ thuật máy tính'),
(12520398, 'Nguyễn Đình Hoàng Thành', 'Hệ thống thông tin'),
(12520399, 'Nguyễn Ngọc Thành', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520400, 'Nguyễn Quang Thành', 'Công nghệ phần mềm'),
(12520401, 'Phan Trung Thành', 'Tân sinh viên'),
(12520402, 'Trần Minh Thành', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520403, 'Trương Công Thành', 'Mạng máy tính & truyền thông'),
(12520404, 'Trương Lê Trung Thành', 'Chương trình tiên tiến'),
(12520405, 'Đoàn Thị Thanh Thảo', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520406, 'Hồ Thị Thanh Thảo', 'Công nghệ phần mềm'),
(12520407, 'Phạm Quốc Thảo', 'Tân sinh viên'),
(12520408, 'Lê Quốc Thể', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520409, 'Đặng Đình Thi', 'Hệ thống thông tin'),
(12520410, 'Huỳnh Trung Thi', 'Khoa học máy tính'),
(12520411, 'Hoàng Xuân Thiên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520412, 'Đỗ Đức Thiện', 'Công nghệ phần mềm'),
(12520413, 'Nguyễn Văn Thiện', 'Công nghệ phần mềm'),
(12520414, 'Vương Quốc Thiện', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520415, 'Lê Nguyễn Thịnh', 'Mạng máy tính & truyền thông'),
(12520416, 'Nguyễn Tiến Thịnh', 'Công nghệ phần mềm'),
(12520417, 'Nguyễn Văn Thịnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520418, 'Từ Tiến Thịnh', 'Công nghệ phần mềm'),
(12520419, 'Nguyễn Hữu Thọ', 'Kỹ sư tài năng ANTT'),
(12520420, 'Võ Kỳ Thoại', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520421, 'Nguyễn Đình Thông', 'Công nghệ phần mềm'),
(12520422, 'Nguyễn Thanh Thông', 'Tân sinh viên'),
(12520423, 'Trần Văn Thông', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520424, 'Đoàn Thị Xuân Thu', 'Công nghệ phần mềm'),
(12520425, 'Nguyễn Vũ Xuân Thu', 'Hệ thống thông tin'),
(12520426, 'Võ Thụy Anh Thư', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520427, 'Hoàng Trọng Thuần', 'Công nghệ phần mềm'),
(12520428, 'Đào Duy Thuận', 'Mạng máy tính & truyền thông'),
(12520429, 'Trần Hữu Thuận', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520430, 'Cao Thị Thương', 'Công nghệ phần mềm'),
(12520431, 'Nguyễn Công Thưởng', 'Mạng máy tính & truyền thông'),
(12520432, 'Đào Thị Thu Thuỷ', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520433, 'Trần Thị Hồng Thúy', 'Hệ thống thông tin'),
(12520434, 'Lê Minh Tiến', 'Công nghệ phần mềm'),
(12520435, 'Nguyễn Đức Tiến', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520436, 'Thạch Ngọc Tiến', 'Mạng máy tính & truyền thông'),
(12520437, 'Phạm Văn Tiệp', 'Hệ thống thông tin'),
(12520438, 'Trần Quốc Tín', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520439, 'Nguyễn Trung Tính', 'Mạng máy tính & truyền thông'),
(12520440, 'Nguyễn Tuệ Tĩnh', 'Mạng máy tính & truyền thông'),
(12520441, 'Lê Thanh Tỉnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520442, 'Nguyễn Văn Tịnh', 'Kỹ thuật máy tính'),
(12520443, 'Mai Khánh Toàn', 'Hệ thống thông tin'),
(12520444, 'Ngô Văn Toàn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520445, 'Nguyễn Phước Toàn', 'Mạng máy tính & truyền thông'),
(12520446, 'Nhan Đạo Toàn', 'Kỹ sư tài năng ANTT'),
(12520447, 'Trần Văn Toàn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520448, 'Vũ Ngọc Toàn', 'Mạng máy tính & truyền thông'),
(12520449, 'Đậu Thị Trà', 'Tân sinh viên'),
(12520450, 'Huỳnh Thanh Trà', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520451, 'Phạm Thị Trang', 'Mạng máy tính & truyền thông'),
(12520452, 'Lê Minh Trạng', 'Công nghệ phần mềm'),
(12520453, 'Hoàng Minh Trí', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520454, 'Lâm Minh Trí', 'Mạng máy tính & truyền thông'),
(12520455, 'Lương Nguyễn Minh Trí', 'Hệ thống thông tin'),
(12520456, 'Nguyễn Trí', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520457, 'Nguyễn Đức Trí', 'Tân sinh viên'),
(12520458, 'Nguyễn Lê Trí', 'Mạng máy tính & truyền thông'),
(12520459, 'Trần Nguyễn Triết', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520460, 'Đặng Hoàng Triều', 'Hệ thống thông tin'),
(12520461, 'Nhan Đặng Hải Triều', 'Công nghệ phần mềm'),
(12520462, 'Lê Vinh Trọng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520463, 'Lê Trung Trực', 'Kỹ thuật máy tính'),
(12520464, 'Trần Minh Trực', 'Mạng máy tính & truyền thông'),
(12520465, 'Bùi Chí Trung', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520466, 'Đặng Nguyễn Duy Trung', 'Mạng máy tính & truyền thông'),
(12520467, 'Lê Minh Trung', 'Công nghệ phần mềm'),
(12520468, 'Ngô Trung', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520469, 'Nguyễn Đình Trung', 'Tân sinh viên'),
(12520470, 'Nguyễn Thành Trung', 'Mạng máy tính & truyền thông'),
(12520471, 'VĂľ Thanh ChĂ­nh Trung', 'Háť tháťng thĂ´ng tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520472, 'Phạm Nam Truờng', 'Công nghệ phần mềm'),
(12520473, 'Lê Xuân Trường', 'Công nghệ phần mềm'),
(12520474, 'Đặng Trần Anh Tú', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520475, 'TáşĄ Trang Thanh TĂş', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(12520476, 'Vũ Minh Tú', 'Mạng máy tính & truyền thông'),
(12520477, 'Khang MáşĄnh Táť­', 'Khoa háťc mĂĄy tĂ­nh');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520478, 'Cao Ngọc Tuấn', 'Cử nhân tài năng'),
(12520479, 'Đặng Anh Tuấn', 'Công nghệ phần mềm'),
(12520480, 'Đỗ Anh Tuấn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520481, 'Hồ Anh Tuấn', 'Công nghệ phần mềm'),
(12520482, 'Hoàng Quốc Tuấn', 'Công nghệ phần mềm'),
(12520483, 'Huỳnh Hữu Anh Tuấn', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520484, 'Nguyáťn Tráťng TuáşĽn', 'CĂ´ng ngháť pháş§n máťm'),
(12520485, 'TÄng BĂĄ TuáşĽn', 'CĂ´ng ngháť pháş§n máťm'),
(12520486, 'Trần Minh Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520487, 'Văn Vũ Tuấn', 'Công nghệ phần mềm'),
(12520488, 'Võ Hoàng Tuấn', 'Công nghệ phần mềm'),
(12520489, 'Biện Thanh Tùng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520490, 'Huỳnh Phạm Phương Tùng', 'Khoa học máy tính'),
(12520491, 'Nguyễn Hoàng Khánh Tường', 'Mạng máy tính & truyền thông'),
(12520492, 'Nguyễn Thanh Anh Tuyên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520493, 'Nguyễn Anh Văn', 'Kỹ thuật máy tính'),
(12520494, 'Lương Quốc Vĩ', 'Hệ thống thông tin'),
(12520495, 'Nguyễn Chánh Viên', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520496, 'Đinh Thế Viễn', 'Công nghệ phần mềm'),
(12520497, 'Nguyễn Quang Việt', 'Tân sinh viên'),
(12520498, 'Nguyễn Xuân Việt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520499, 'Trần Đức Việt', 'Mạng máy tính & truyền thông'),
(12520500, 'Trương Thanh Việt', 'Mạng máy tính & truyền thông'),
(12520501, 'Trương Trung Việt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520502, 'Võ Hắc Việt', ''),
(12520503, 'Võ Quốc Việt', 'Mạng máy tính & truyền thông'),
(12520504, 'Huỳnh Khoa Vin', 'Công nghệ phần mềm'),
(12520505, 'Bùi Thanh Vinh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520506, 'Huỳnh Thế Vinh', 'Công nghệ phần mềm'),
(12520507, 'Huỳnh Thế Vinh', 'Mạng máy tính & truyền thông'),
(12520508, 'Lâm Bỉnh Vinh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520509, 'Lê Nguyễn Hữu Vinh', 'Kỹ thuật máy tính'),
(12520510, 'Lê Quang Vinh', 'Công nghệ phần mềm'),
(12520511, 'Lê Xuân Vinh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520512, 'Lê Xuân Vinh', 'Kỹ thuật máy tính'),
(12520513, 'Thiều Quang Vinh', 'Công nghệ phần mềm'),
(12520514, 'Trần Đức Vinh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520515, 'Dương Hoàng Vũ', 'Công nghệ phần mềm'),
(12520516, 'Huỳnh Ngọc Vũ', 'Mạng máy tính & truyền thông'),
(12520517, 'Trương Hoài Vũ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520518, 'Đào Tố Vương', 'Mạng máy tính & truyền thông'),
(12520519, 'Đỗ Hà Vương Vương', 'Mạng máy tính & truyền thông'),
(12520520, 'Nguyễn Lê Vỹ', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520521, 'Dương Thị Ngọc Xuân', 'Kỹ thuật máy tính'),
(12520522, 'Phạm Trường Xuân', 'Tân sinh viên'),
(12520523, 'Nguyễn Duy Ý', 'Kỹ sư tài năng ANTT'),
(12520524, 'Hồ Thị Hải Yến', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520525, 'Nguyễn Bá Thông', 'Tân sinh viên'),
(12520526, 'Cao Văn Phúc', 'Công nghệ phần mềm'),
(12520527, 'Dương Quốc Tín', 'Kỹ sư tài năng ANTT'),
(12520528, 'Nguyễn Kiên', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520529, 'Triệu Văn Hưng', 'Mạng máy tính & truyền thông'),
(12520530, 'Phạm Minh An', 'Mạng máy tính & truyền thông'),
(12520531, 'Nguyễn Phan Thanh An', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520532, 'Phạm Hồng Ân', 'Khoa học máy tính'),
(12520533, 'Nguyễn Lê Thiên Ân', 'Hệ thống thông tin'),
(12520534, 'Phan Đức Anh', 'Kỹ thuật máy tính'),
(12520535, 'Hoàng Tuấn Anh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520536, 'Phùng Quốc Anh', 'Hệ thống thông tin'),
(12520537, 'Mã Tuấn Anh', 'Hệ thống thông tin'),
(12520538, 'Trần Hải Âu', 'Khoa học máy tính'),
(12520539, 'Văn Hoàng Bảo', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520540, 'Nguyễn Chia Thiên Bảo', 'Cử nhân tài năng'),
(12520541, 'Nguyễn Thanh Bình', 'Mạng máy tính & truyền thông'),
(12520542, 'Vũ Hải Bình', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520543, 'Trần Đình Cầu', 'Tân sinh viên'),
(12520544, 'Nguyễn Minh Chánh', 'Kỹ thuật máy tính'),
(12520545, 'Nguyễn Đức Châu', 'Khoa học máy tính'),
(12520546, 'Nguyễn Khắc Chiến', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520547, 'Hồ Quang Chiến', 'Mạng máy tính & truyền thông'),
(12520548, 'Ngô Quốc Chung', 'Hệ thống thông tin'),
(12520549, 'Trần Thị Kim Chung', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520550, 'Nguyễn Hưng Chương', 'Khoa học máy tính'),
(12520551, 'Phạm Tiến Cường', 'Mạng máy tính & truyền thông'),
(12520552, 'Đoàn Hùng Cường', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520553, 'Lê Việt Cường', 'Mạng máy tính & truyền thông'),
(12520554, 'Nguyễn Hải Đăng', 'Công nghệ phần mềm'),
(12520555, 'Trà Lê Minh Đăng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520556, 'Nguyễn Hải Đăng', 'Khoa học máy tính'),
(12520557, 'Nguyễn Văn Đặng', 'Tân sinh viên'),
(12520558, 'Trần Công Danh', 'Kỹ thuật máy tính'),
(12520559, 'Hồ Minh Đạt', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520560, 'Phan Tấn Đạt', ''),
(12520561, 'Nguyễn Trần Tiến Đạt', 'Kỹ thuật máy tính'),
(12520562, 'Trương Ấn Độ', 'Hệ thống thông tin'),
(12520563, 'Lê Công Đoàn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520564, 'Phan Trung Đông', 'Khoa học máy tính'),
(12520565, 'Nguyễn Trọng Ngô Việt Du', 'Khoa học máy tính'),
(12520566, 'Nguyễn Huỳnh Trường Duân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520567, 'Dương Đức Ái', 'Kỹ thuật máy tính'),
(12520568, 'Phạm Minh Đức', ''),
(12520569, 'Phùng Thị Hạnh Dung', 'Hệ thống thông tin'),
(12520570, 'Nguyễn Chí Dũng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520571, 'Hoàng Trung Dũng', 'Kỹ thuật máy tính'),
(12520572, 'Lê Văn Dũng', 'Khoa học máy tính'),
(12520573, 'Vũ Văn Dương', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520574, 'Trần Thùy Dương', 'Hệ thống thông tin'),
(12520575, 'Phan Thanh Duy', 'Hệ thống thông tin'),
(12520576, 'Hồ Quang Duy', 'Tân sinh viên'),
(12520577, 'Lâm Văn Duy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520578, 'Bùi Phan Duy', 'Kỹ thuật máy tính'),
(12520579, 'Lê Đặng Thành Trung Em', 'Mạng máy tính & truyền thông'),
(12520580, 'Trần Bá Giáp', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520581, 'Nguyễn Thanh Hải', 'Mạng máy tính & truyền thông'),
(12520582, 'Đinh Dương Hải', 'Hệ thống thông tin'),
(12520583, 'Đinh Long Hải', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520584, 'Đặng Thị Thanh Hải', 'Hệ thống thông tin'),
(12520585, 'Nguyễn Ngọc Hải', 'Tân sinh viên'),
(12520586, 'Ngô Thị Thúy Hằng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520587, 'Đỗ Hoàng Hiển', 'Mạng máy tính & truyền thông'),
(12520588, 'Nguyễn Minh Hiệp', 'Mạng máy tính & truyền thông'),
(12520589, 'Nguyễn Phạm Hoàng Hiệp', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520590, 'Đặng Vũ Hiệp', 'Mạng máy tính & truyền thông'),
(12520591, 'Đinh Thành Hiếu', 'Hệ thống thông tin'),
(12520592, 'Trương Trần Hiếu', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520593, 'Phạm Trung HIếu', 'Mạng máy tính & truyền thông'),
(12520594, 'Hoàng Trung Hiếu', 'Khoa học máy tính'),
(12520595, 'Nguyễn Trung Hiếu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520596, 'Đặng Thái Hòa', 'Mạng máy tính & truyền thông'),
(12520597, 'Lê Minh Hoàng', 'Hệ thống thông tin'),
(12520598, 'Nguyễn Lê Thanh Hùng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520599, 'Nguyễn Văn Hùng', 'Khoa học máy tính'),
(12520600, 'Bùi Việt Hùng', 'Kỹ thuật máy tính'),
(12520601, 'Nguyễn Trần Minh Hùng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520602, 'Nguyễn Tiến Hùng', 'Mạng máy tính & truyền thông'),
(12520603, 'Nguyễn Phúc Thành Hưng', 'Mạng máy tính & truyền thông'),
(12520604, 'Nguyễn Phú Hữu', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520605, 'Nguyễn Trọng Vũ Huy', 'Tân sinh viên'),
(12520606, 'Lê Văn Huy', 'Mạng máy tính & truyền thông'),
(12520607, 'Nguyễn Văn Huy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520608, 'Vũ Phúc Minh Huy', 'Kỹ thuật máy tính'),
(12520609, 'Ngô Quốc Huy', 'Mạng máy tính & truyền thông'),
(12520610, 'Trần Nhật Huy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520611, 'Tráş§n Thanh Huy', 'ChĆ°ĆĄng trĂŹnh tiĂŞn tiáşżn'),
(12520612, 'Trần Gia Huy', 'Tân sinh viên'),
(12520613, 'Tôn Thất Huy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520614, 'Phạm Lê Bá Huỳnh', 'Mạng máy tính & truyền thông'),
(12520615, 'Y- Trần Trung Nguyên Kbuôr', 'Khoa học máy tính'),
(12520616, 'Trịnh Bảo Kha', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520617, 'Lê Tuấn Khải', 'Mạng máy tính & truyền thông'),
(12520618, 'Nguyễn Trần Duy Khang', 'Mạng máy tính & truyền thông'),
(12520619, 'Nguyễn Dư Duy Khang', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520620, 'Phan Tuấn Khang', 'Chương trình tiên tiến'),
(12520621, 'Phan Quang Khánh', 'Hệ thống thông tin'),
(12520622, 'Quang Phúc Đăng Khoa', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520623, 'Nguyễn Xuân Khoái', 'Cử nhân tài năng'),
(12520624, 'Lê Thị Hương Khuê', 'Khoa học máy tính'),
(12520625, 'Võ Đăng Bảo Khương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520626, 'Lê Minh Kiệt', 'Kỹ thuật máy tính'),
(12520627, 'Phan Văn Lăng', 'Kỹ thuật máy tính'),
(12520628, 'Nguyễn Thị Mỹ Lệ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520629, 'Nguyễn Vũ Linh', 'Khoa học máy tính'),
(12520630, 'Huỳnh Vĩnh Lộc', 'Hệ thống thông tin'),
(12520631, 'Trần Tấn Lộc', 'Hệ thống thông tin'),
(12520632, 'Nguyễn Phúc Lợi', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520633, 'Phan ÄĂŹnh Minh Long', 'Háť tháťng thĂ´ng tin'),
(12520634, 'Hoàng Đình Long', 'Tân sinh viên'),
(12520635, 'Nguyễn Hoàng Long', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520636, 'Bùi Đức Lực', 'Khoa học máy tính'),
(12520637, 'Nguyễn Trịnh Thảo Ly', 'Hệ thống thông tin'),
(12520638, 'Trịnh Hoàng Minh', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520639, 'Nguyễn Lê Quang Minh', 'Hệ thống thông tin'),
(12520640, 'Dương Hoàng Nam', 'Hệ thống thông tin'),
(12520641, 'Nguyễn Hoài Nam', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520642, 'Nguyễn Thọ Nam', 'Khoa học máy tính'),
(12520643, 'Trần Thế Nam', 'Hệ thống thông tin'),
(12520644, 'Tiếu Hoài Nam', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520645, 'Nguyễn Hoàng Nam', 'Hệ thống thông tin'),
(12520646, 'Vũ Thị Hồng Nga', 'Hệ thống thông tin'),
(12520647, 'Nguyễn Thành Nghị', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520648, 'Huỳnh Đạt Nghĩa', 'Mạng máy tính & truyền thông'),
(12520649, 'Phạm Hồng Nghĩa', 'Tân sinh viên'),
(12520650, 'Thạch Anh Nghĩa', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520651, 'Trần Văn Nghiệp', 'Hệ thống thông tin'),
(12520652, 'Nguyễn Tuấn Ngọc', 'Khoa học máy tính'),
(12520653, 'Đặng Minh Ngọc', 'Khoa học máy tính'),
(12520654, 'Trịnh Mỹ Ngôn', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520655, 'Nguyễn Hữu Nguyên', 'Mạng máy tính & truyền thông'),
(12520656, 'Hoàng Đình Nguyên', 'Khoa học máy tính'),
(12520657, 'Trần Thị Thảo Nguyên', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520658, 'Trương Nữ Minh Nguyệt', 'Hệ thống thông tin'),
(12520659, 'Trương Đức Nhã', 'Mạng máy tính & truyền thông'),
(12520660, 'Nguyễn Minh Nhân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520661, 'Chu Công Hoài Nhân', 'Khoa học máy tính'),
(12520662, 'Nguyễn Hoài Nhân', 'Hệ thống thông tin'),
(12520663, 'Lưu Đạt Nhất', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520664, 'Nguyễn Lê Thành Nhơn', 'Kỹ thuật máy tính'),
(12520665, 'Võ Minh Nhựt', 'Khoa học máy tính'),
(12520666, 'Phùng Minh Nhựt', 'Hệ thống thông tin'),
(12520667, 'Phạm Tấn Phát', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520668, 'Võ Nguyễn Tín Phát', 'Khoa học máy tính'),
(12520669, 'Trang Nguyên Phát', 'Mạng máy tính & truyền thông'),
(12520670, 'Cao Phạm Thanh Phong', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520671, 'Nguyễn Đức Phú', 'Kỹ thuật máy tính'),
(12520672, 'Đỗ Nguyễn Hoàng Phú', 'Mạng máy tính & truyền thông'),
(12520673, 'Nguyễn Vĩnh Phúc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520674, 'Huỳnh Hoàng Phúc', 'Kỹ thuật máy tính'),
(12520675, 'Phạm Thị Phúc', 'Hệ thống thông tin'),
(12520676, 'Trịnh Minh Phúc', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520677, 'Huáťłnh ÄoĂ n HáťŻu PhĂşc', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(12520678, 'Huỳnh Thiên Phước', 'Hệ thống thông tin'),
(12520679, 'Đinh Cao Phước', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520680, 'Từ Hoàng Phương', 'Tân sinh viên'),
(12520681, 'Trần Tuấn Phương', 'Khoa học máy tính'),
(12520682, 'Bùi Minh Quân', 'Khoa học máy tính'),
(12520683, 'Nguyễn Trung Quân', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520684, 'Nguyễn Thành Quân', 'Khoa học máy tính'),
(12520685, 'Phạm Nguyễn Vinh Quang', 'Kỹ thuật máy tính'),
(12520686, 'Phan Văn Quang', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520687, 'Nguyễn Hồ Quang', 'Kỹ thuật máy tính'),
(12520688, 'Phạm Phú Quí', 'Hệ thống thông tin'),
(12520689, 'Nguyễn Đình Quốc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520690, 'Dương Hoàng Quốc', 'Hệ thống thông tin'),
(12520691, 'Nguyễn Ngân Sang', 'Mạng máy tính & truyền thông'),
(12520692, 'Nguyễn Lê Hoàng Sang', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520693, 'Phạm Thị Hương Sen', 'Hệ thống thông tin'),
(12520694, 'PháşĄm Thanh SĆĄn', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(12520695, 'Hồ Văn Sơn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520696, 'Nguyễn Văn Sỹ', 'Mạng máy tính & truyền thông'),
(12520697, 'Vũ Viết Tài', 'Mạng máy tính & truyền thông'),
(12520698, 'Huỳnh Hữu Tài', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520699, 'Lê Vũ Tâm', 'Mạng máy tính & truyền thông'),
(12520700, 'Ngô Nhật Tâm', 'Mạng máy tính & truyền thông'),
(12520701, 'Nguyễn Minh Tâm', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520702, 'Nguyễn Thái Trí Tâm', 'Hệ thống thông tin'),
(12520703, 'Trần Văn Thang', 'Hệ thống thông tin'),
(12520704, 'Lâm Duy Thắng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520705, 'Trần Cao Thắng', 'Kỹ thuật máy tính'),
(12520706, 'Trần Quang Thắng', 'Khoa học máy tính'),
(12520707, 'Phạm Phúc Thắng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520708, 'Phạm Văn Thanh', 'Mạng máy tính & truyền thông'),
(12520709, 'Dương Thị Mỹ Thanh', 'Hệ thống thông tin'),
(12520710, 'Chu Văn Thanh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520711, 'Nguyễn Thị Châu Thanh', 'Hệ thống thông tin'),
(12520712, 'Tô Minh Thanh', 'Kỹ thuật máy tính'),
(12520713, 'Quách Tuấn Thanh', 'Khoa học máy tính'),
(12520714, 'Lý Bá Thành', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520715, 'BĂši Minh Anh TháşŁo', 'Khoa háťc mĂĄy tĂ­nh'),
(12520716, 'Nguyễn Thanh Thảo', 'Mạng máy tính & truyền thông'),
(12520717, 'Nguyễn Thị Minh Thi', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520718, 'Dương Minh Thiện', 'Khoa học máy tính'),
(12520719, 'Lê Hoàng Phúc Thiện', 'Kỹ thuật máy tính'),
(12520720, 'Nguyễn Đăng Thiện', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520721, 'Lê Thị Mỹ Thịnh', 'Hệ thống thông tin'),
(12520722, 'Nguyễn Tấn Thịnh', 'Tân sinh viên'),
(12520723, 'Nguyễn Đức Thịnh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520724, 'Hoàng Xuân Thịnh', 'Kỹ thuật máy tính'),
(12520725, 'Dương Quốc Thịnh', 'Khoa học máy tính'),
(12520726, 'Quách Đức Thọ', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520727, 'Đinh Thị Kim Thoa', 'Hệ thống thông tin'),
(12520728, 'Đỗ Anh Thông', 'Cử nhân tài năng'),
(12520729, 'Lê Trọng Thông', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520730, 'Trần Anh Thông', 'Chương trình tiên tiến'),
(12520731, 'Đặng Thị Anh Thư', 'Hệ thống thông tin'),
(12520732, 'Nguyễn Quốc Thuận', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520733, 'Nguyễn Thanh Thuận', 'Kỹ thuật máy tính'),
(12520734, 'Nguyáťn PhĂş Thuáş­n', 'Háť tháťng thĂ´ng tin'),
(12520735, 'Nguyễn Tự Thuật', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520736, 'Phan Thị Thương', 'Khoa học máy tính'),
(12520737, 'Dương Nguyên An Thuyên', 'Cử nhân tài năng'),
(12520738, 'Võ Kim Tiên', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520739, 'Nguyễn Minh Tiến', 'Kỹ thuật máy tính'),
(12520740, 'Châu Quốc Tiến', 'Mạng máy tính & truyền thông'),
(12520741, 'Trịnh Đình Tiến', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520742, 'Nguyễn Minh Tín', 'Tân sinh viên'),
(12520743, 'Lê Quang Tín', 'Khoa học máy tính'),
(12520744, 'Nguyễn Ngọc Tịnh', 'Khoa học máy tính'),
(12520745, 'Nguyễn Đỗ Quỳnh Trâm', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520746, 'Nguyễn Hoàng Ái Trân', 'Hệ thống thông tin'),
(12520747, 'Nguyễn Mai Thiên Trang', 'Chương trình tiên tiến'),
(12520748, 'Nguyễn Anh Trí', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520749, 'Hồ Trần Trí', 'Khoa học máy tính'),
(12520750, 'Đào Nguyễn Minh Trí', 'Hệ thống thông tin'),
(12520751, 'Nguyễn Lê Nhật Triều', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520752, 'Trần Minh Triệu', 'Kỹ thuật máy tính'),
(12520753, 'Nguyễn Minh Triệu', 'Mạng máy tính & truyền thông'),
(12520754, 'Cao Hữu Trọng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520755, 'Lê Huỳnh Thanh Trúc', 'Mạng máy tính & truyền thông'),
(12520756, 'Trần Hồng Thiên Trúc', 'Kỹ thuật máy tính'),
(12520757, 'Trần Công Trực', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520758, 'Dương Minh Trực', 'Hệ thống thông tin'),
(12520759, 'Nguyễn Bảo Trung', 'Khoa học máy tính'),
(12520760, 'Nguyễn Minh Trung', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520761, 'Nguyễn Phước Trung', 'Mạng máy tính & truyền thông'),
(12520762, 'Đào Tiến Trường', 'Khoa học máy tính'),
(12520763, 'Nguyễn Xuân Trường', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520764, 'Phạm Anh Tuấn', 'Khoa học máy tính'),
(12520765, 'Nguyễn Anh Tuấn', 'Mạng máy tính & truyền thông'),
(12520766, 'Nguyễn Huỳnh Quang Tuấn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520767, 'Nguyễn Phan Anh Tuấn', 'Hệ thống thông tin'),
(12520768, 'Nguyễn Công Anh Tuấn', 'Mạng máy tính & truyền thông'),
(12520769, 'Nguyáťn Duy TĂšng', 'Háť tháťng thĂ´ng tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520770, 'Đỗ Đặng Tùng', 'Mạng máy tính & truyền thông'),
(12520771, 'Hoàng Thanh Tùng', 'Kỹ thuật máy tính'),
(12520772, 'Phan Thanh Tùng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520773, 'Lê Khánh Tường', 'Mạng máy tính & truyền thông'),
(12520774, 'Nguyễn Thị Thanh Tuyền', 'Cử nhân tài năng'),
(12520775, 'Trần Văn Tý', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520776, 'Bùi Quốc Tý', 'Cử nhân tài năng'),
(12520777, 'Nguyễn Hà Tuyết Vân', 'Hệ thống thông tin'),
(12520778, 'Cao Triệu Vĩ', 'Kỹ thuật máy tính'),
(12520779, 'Tướng Văn Vĩ', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520780, 'Nguyễn Quốc Việt', 'Kỹ thuật máy tính'),
(12520781, 'Đỗ Xuân Vinh', 'Chương trình tiên tiến'),
(12520782, 'Đặng Hữu Vinh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520783, 'Vương Thành Vinh', 'Kỹ thuật máy tính'),
(12520784, 'Huỳnh Ngọc Vinh', 'Kỹ thuật máy tính'),
(12520785, 'Võ Phước Vinh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520786, 'Nguyễn Anh Vũ', 'Khoa học máy tính'),
(12520787, 'Nguyễn Lê Thành Vũ', 'Hệ thống thông tin'),
(12520788, 'Phạm Thiên Vũ', 'Tân sinh viên'),
(12520789, 'Nguyễn Thị Yến', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520790, 'Mai Nguyên Khang', 'Khoa học máy tính'),
(12520791, 'Võ Ngọc Khánh', 'Cử nhân tài năng'),
(12520792, 'Hoàng Đình Long', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520793, 'Nguyễn Hữu Khánh', 'Hệ thống thông tin'),
(12520794, 'Trần Thị Bích Ngọc', 'Hệ thống thông tin'),
(12520795, 'Hồ Quang Khải', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520796, 'Huỳnh Thế Hiển', 'Tân sinh viên'),
(12520797, 'Trần Đạo', 'Kỹ thuật máy tính'),
(12520798, 'Kiều Văn Phước', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520799, 'Äáşˇng Tháť Kim Luyáşżn', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(12520800, 'Nguyễn Đức Cường', 'Mạng máy tính & truyền thông'),
(12520801, 'Nguyễn Đưc Cảnh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520802, 'Trần Thị Duyên Hồng', 'Khoa học máy tính'),
(12520803, 'Nguyễn Ngọc Sơn', 'Mạng máy tính & truyền thông'),
(12520804, 'Lê Trung Nhật', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520805, 'Trần Vùn Dậu', 'Khoa học máy tính'),
(12520806, 'LĆ°u Trung KiĂŞn', 'Háť tháťng thĂ´ng tin'),
(12520807, 'Nguyễn Quốc Nguyên', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520808, 'Nguyễn Ngọc Lân', 'Khoa học máy tính'),
(12520809, 'Huỳnh Văn Ân', 'Tân sinh viên'),
(12520810, 'Trần Đức Anh', 'Chương trình tiên tiến'),
(12520811, 'Vũ Tuấn Anh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520812, 'Mai Văn Chư', 'Kỹ thuật máy tính'),
(12520813, 'Đoàn Thị Kim Chung', 'Hệ thống thông tin'),
(12520814, 'Nguyễn Tuấn Cường', 'Khoa học máy tính'),
(12520815, 'Nguyễn Văn Cường', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520816, 'Hà Huy Đại', 'Kỹ thuật máy tính'),
(12520817, 'Nguyễn Công Danh', 'Hệ thống thông tin'),
(12520818, 'Nguyễn Thành Danh', 'Kỹ thuật máy tính'),
(12520819, 'Trần Xuân Đào', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520820, 'Trần Thành Đạt', 'Tân sinh viên'),
(12520821, 'Lý Tấn Dũng', 'Cử nhân tài năng'),
(12520822, 'Nguyễn Thùy Dung', 'Tân sinh viên'),
(12520823, 'Trần Thị Dung', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520824, 'Trương Quốc Dũng', 'Mạng máy tính & truyền thông'),
(12520825, 'Đào Khánh Duy', 'Khoa học máy tính'),
(12520826, 'Nguyễn Bá Duy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520827, 'Nguyễn Đình Duy', 'Khoa học máy tính'),
(12520828, 'Trần Vũ Duy', 'Mạng máy tính & truyền thông'),
(12520829, 'Nguyễn Thị Ngọc Hà', 'Tân sinh viên'),
(12520830, 'Lê Thị Thu Hà', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520831, 'Trần Đình Hà', 'Kỹ thuật máy tính'),
(12520832, 'Phạm Đức Hai', 'Tân sinh viên'),
(12520833, 'Bùi Thanh Hiền', 'Hệ thống thông tin'),
(12520834, 'Mã Tuấn Minh Hiển', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520835, 'Phạm Thanh Hiền', 'Kỹ thuật máy tính'),
(12520836, 'Lê Văn Hiệp', 'Hệ thống thông tin'),
(12520837, 'Tạ Phạm Kim Hiếu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520838, 'Trần Thiện Hiệu', 'Khoa học máy tính'),
(12520839, 'Lê Trung Hiếu', 'Cử nhân tài năng'),
(12520840, 'Phan Thị Minh Hiếu', 'Tân sinh viên'),
(12520841, 'Đoàn Nguyên Hiếu', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520842, 'Nguyễn Ngọc Hoàng', 'Hệ thống thông tin'),
(12520843, 'Trần Nguyễn Nhật Hoàng', 'Tân sinh viên'),
(12520844, 'Vương Đình Hoàng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520845, 'Phạm Minh Hoàng', 'Khoa học máy tính'),
(12520846, 'Trần Thái Hoàng', 'Khoa học máy tính'),
(12520847, 'Trần Hoàng', 'Tân sinh viên'),
(12520848, 'Trần Văn Hoàng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520849, 'Nguyễn Thị Huệ', 'Tân sinh viên'),
(12520850, 'Vũ Thị Thanh Huệ', 'Kỹ thuật máy tính'),
(12520851, 'Trần Thị Huệ', 'Mạng máy tính & truyền thông'),
(12520852, 'Hoàng Hưng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520853, 'Dương Thị Diễm Hương', 'Kỹ thuật máy tính'),
(12520854, 'Dương Thị Ngọc Huyền', 'Khoa học máy tính'),
(12520855, 'Trương Hoàng Diễm Huyền', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520856, 'Dương Duy Khang', 'Hệ thống thông tin'),
(12520857, 'Huỳnh Minh Khánh', 'Hệ thống thông tin'),
(12520858, 'Đặng Bảo Khánh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520859, 'Nguyễn Tâm Khoa', 'Cử nhân tài năng'),
(12520860, 'Thái Văn Khoa', 'Cử nhân tài năng'),
(12520861, 'Nguyễn Trung Kiên', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520862, 'Đàm Đình Kiệt', 'Mạng máy tính & truyền thông'),
(12520863, 'Lê Hồng Mỹ Kim', 'Tân sinh viên'),
(12520864, 'Đỗ Văn Lẹ', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520865, 'Lê Thị Thúy Loan', 'Mạng máy tính & truyền thông'),
(12520866, 'Ông Tấn Lộc', 'Cử nhân tài năng'),
(12520867, 'Dương Sỉ Long', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520868, 'Nguyễn Ngọc Bảo Long', 'Kỹ thuật máy tính'),
(12520869, 'Văn Ngọc Lưu', 'Mạng máy tính & truyền thông'),
(12520870, 'Võ Thị Thiên Lý', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520871, 'Cao Đường Minh', 'Tân sinh viên'),
(12520872, 'Huỳnh Ngọc Khánh Mỹ', 'Hệ thống thông tin'),
(12520873, 'Nguyễn Hoàng My', 'Hệ thống thông tin'),
(12520874, 'Huỳnh Thi My', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520875, 'Hoàng Trọng Nam', 'Khoa học máy tính'),
(12520876, 'Phạm Thanh Nam', 'Mạng máy tính & truyền thông'),
(12520877, 'Phan Thị Kim Nên', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520878, 'Lê Thị Kim Ngân', 'Hệ thống thông tin'),
(12520879, 'Võ Thị Kim Ngân', 'Khoa học máy tính'),
(12520880, 'Nguyễn Thành Duy Nguyên', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520881, 'Mạch Văn Nguyên', 'Mạng máy tính & truyền thông'),
(12520882, 'Lê Minh Nhân', 'Kỹ thuật máy tính'),
(12520883, 'Nguyễn Văn Nhân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520884, 'Nguyễn Đình Minh Nhật', 'Hệ thống thông tin'),
(12520885, 'Nguyễn Quang Nhật', 'Cử nhân tài năng'),
(12520886, 'Nguyễn Văn Nhất', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520887, 'Trần Thị Thảo Nhi', 'Hệ thống thông tin'),
(12520888, 'Lê Thị Bít Nhi', 'Khoa học máy tính'),
(12520889, 'Võ Triệu Quang Nhi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520890, 'Huỳnh Bá Nhuận', 'Hệ thống thông tin'),
(12520891, 'Hồ Thị Bé Ni', 'Mạng máy tính & truyền thông'),
(12520892, 'Lại Thành Phát', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520893, 'Nguyễn Trường Phi', 'Kỹ thuật máy tính'),
(12520894, 'Võ Hoài Phong', 'Cử nhân tài năng'),
(12520895, 'Lê Hoàng Phúc', 'Tân sinh viên'),
(12520896, 'Đậu Quang Phúc', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520897, 'Thạch Ngọc Phúc', 'Kỹ thuật máy tính'),
(12520898, 'Nguyễn Minh Phụng', 'Tân sinh viên'),
(12520899, 'Lữ Thư Phương', 'Hệ thống thông tin'),
(12520900, 'Dương Trần Hà Phương', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520901, 'Phạm Minh Quan', 'Hệ thống thông tin'),
(12520902, 'Nguyễn Phan Hoàng Quân', 'Mạng máy tính & truyền thông'),
(12520904, 'Nguyễn Vinh Quang', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520905, 'Đồng Thị Mỹ Quyền', 'Hệ thống thông tin'),
(12520906, 'Lê Xuân Sinh', 'Kỹ thuật máy tính'),
(12520907, 'Vũ Như Tài', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520908, 'Trần Thị Thanh Tâm', 'Tân sinh viên'),
(12520909, 'Nguyễn Thanh Tâm', 'Mạng máy tính & truyền thông'),
(12520910, 'Nguyễn Xuân Tân', ''),
(12520911, 'Cao Huỳnh Tân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520912, 'Tạ Đình Tấn', 'Mạng máy tính & truyền thông'),
(12520913, 'Nguyễn Thị Thanh Tân', 'Tân sinh viên'),
(12520914, 'Trần Quốc Thái', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520915, 'Đào Thắng', 'Kỹ thuật máy tính'),
(12520916, 'Võ Đức Thiện', 'Tân sinh viên'),
(12520917, 'Phạm Tấn Thiện', 'Mạng máy tính & truyền thông'),
(12520918, 'Hồ Phúc Thịnh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520919, 'Đỗ Hùng Thịnh', 'Kỹ sư tài năng ANTT'),
(12520920, 'Đoàn Ngô Minh Thư', 'Tân sinh viên'),
(12520921, 'Nguyễn Ngọc Đăng Thy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520922, 'Nguyễn Thuận Tiến', 'Hệ thống thông tin'),
(12520923, 'Trần Hồ Trung Tín', 'Tân sinh viên'),
(12520924, 'Trần Văn Trinh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520925, 'Trần Nguyễn Bảo Trung', 'Khoa học máy tính'),
(12520926, 'Nguyễn Quốc Trung', 'Tân sinh viên'),
(12520927, 'Lê Công Trường', 'Tân sinh viên'),
(12520928, 'Trần Nguyễn Anh Tú', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520929, 'Trần Hoàng Tuân', 'Cử nhân tài năng'),
(12520930, 'Hồ Anh Tuấn', 'Khoa học máy tính'),
(12520931, 'Ngô Đức Tùng', 'Mạng máy tính & truyền thông'),
(12520932, 'Cao Trung Tuyến', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520933, 'Trương Thị Thảo Uyên', 'Hệ thống thông tin'),
(12520934, 'Phùng Trọng Văn', 'Tân sinh viên'),
(12520935, 'Hoàng Thị Vấn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520936, 'Hoàng Việt', 'Khoa học máy tính'),
(12520937, 'Tôn Thất Quang Vinh', 'Hệ thống thông tin'),
(12520938, 'Đoàn Trọng Vũ', 'Hệ thống thông tin'),
(12520939, 'Thái Thanh Vũ', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520940, 'Nguyễn Hạ Anh Vũ', 'Cử nhân tài năng'),
(12520941, 'Phan Văn Vũ', 'Tân sinh viên'),
(12520942, 'Đoàn Văn Vũ', 'Kỹ thuật máy tính'),
(12520943, 'Thái Anh Vũ', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520944, 'Phan Nguyễn Anh Vũ', 'Mạng máy tính & truyền thông'),
(12520945, 'Nguyễn Huy Vũ', 'Mạng máy tính & truyền thông'),
(12520946, 'Vũ Lê Thanh Xuân', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520947, 'Huỳnh Thiện Ý', 'Cử nhân tài năng'),
(12520948, 'Trần Hải Yến', 'Mạng máy tính & truyền thông'),
(12520949, 'Lê Thanh Huyền', 'Tân sinh viên'),
(12520950, 'Đỗ Nhị Linh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520951, 'Nhâm Phi Long', 'Tân sinh viên'),
(12520952, 'Phan Văn Luân', 'Mạng máy tính & truyền thông'),
(12520953, 'Nguyễn Phương Nam', 'Tân sinh viên'),
(12520954, 'Nguyễn Bảo Ngọc', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520955, 'Hoàng Văn Nhân', 'Kỹ thuật máy tính'),
(12520956, 'Hồ Duy Phước', 'Tân sinh viên'),
(12520957, 'Đinh Diệu Thùy', 'Tân sinh viên'),
(12520958, 'Vàng A Toán', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520959, 'Tôn Đức Việt', 'Mạng máy tính & truyền thông'),
(12520960, 'Lê Thị Yến', 'Tân sinh viên'),
(12520961, 'Hoàng Đức Chiến', 'Tân sinh viên'),
(12520962, 'Nguyễn Phú Cường', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520963, 'Nguyễn Thị Cẩm Duyên', 'Tân sinh viên'),
(12520964, 'Nguyễn Thu Hà', 'Cử nhân tài năng'),
(12520965, 'Bùi Xuân Hải', 'Hệ thống thông tin'),
(12520966, 'Nguyễn Thị Hởi', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520967, 'Võ Khánh Hưng', 'Khoa học máy tính'),
(12520968, 'Phạm Thị Bích Ly', 'Tân sinh viên'),
(12520969, 'Nguyễn Duy Minh', 'Tân sinh viên'),
(12520970, 'Nguyễn Tiến Phát', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520971, 'Phan Văn Tân', 'Cử nhân tài năng'),
(12520972, 'Dương Thành Khánh', 'Tân sinh viên'),
(12520973, 'Nguyễn Thế Thời', 'Hệ thống thông tin'),
(12520974, 'Nguyễn Văn Tiến', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520975, 'Nguyễn Văn Trực', 'Tân sinh viên'),
(12520976, 'Đỗ Cao Trường', 'Tân sinh viên'),
(12520977, 'Nguyễn Anh Tuấn', 'Tân sinh viên'),
(12520978, 'Lê Ngọc Tùng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520980, 'Đặng Minh Trí', 'Kỹ sư tài năng ANTT'),
(12520981, 'Trương Đức  Hùng', 'Chương trình tiên tiến'),
(12520982, 'Trương Lê Bảo  Long', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520983, 'Nguyễn Khánh  Minh', 'Chương trình tiên tiến'),
(12520984, 'Trịnh Xuân  Sang', 'Chương trình tiên tiến'),
(12520985, 'Nguyễn Đình  Sinh', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520986, 'Đỗ Huỳnh Anh  Thụy', 'Chương trình tiên tiến'),
(12520987, 'Nguyễn Minh  Toàn', 'Hệ thống thông tin'),
(12520988, 'Châu Phạm Minh  Tùng', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12520989, 'Trần Xuân  Viên', 'Chương trình tiên tiến'),
(12730001, 'Sấm Thế  Bảo', 'Đào tạo từ xa'),
(12730005, 'Nguyễn Đình  Long', 'Đào tạo từ xa'),
(12730007, 'Nguyễn Thanh  Phong', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730010, 'Nguyễn Toàn  Thắng', 'Đào tạo từ xa'),
(12730011, 'Phạm Trung Hiếu', 'Đào tạo từ xa'),
(12730015, 'Ngô Túc Thanh', 'Đào tạo từ xa'),
(12730019, 'Phạm Bá  Lợi', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730020, 'Trương Quảng  An', 'Đào tạo từ xa'),
(12730021, 'Lê Nguyễn Hải  Đăng', 'Đào tạo từ xa'),
(12730022, 'Diệp Chấn  Đạt', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730024, 'Trương Văn  Điền', 'Đào tạo từ xa'),
(12730025, 'Nguyễn Huy Đông', 'Đào tạo từ xa'),
(12730026, 'Phan Văn  Đông', 'Đào tạo từ xa'),
(12730027, 'Đặng Hoàng  Đức', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730028, 'Lương Văn  Dũng', 'Đào tạo từ xa'),
(12730029, 'Nguyễn Thái  Dũng', 'Đào tạo từ xa'),
(12730031, 'Nguyễn Thành  Hải', 'Đào tạo từ xa'),
(12730033, 'Nguyễn Minh  Hoàng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730034, 'Lê Đức  Huy', 'Đào tạo từ xa'),
(12730035, 'Phan Tùng  Keng', 'Đào tạo từ xa'),
(12730036, 'Dương Duy  Khánh', 'Đào tạo từ xa'),
(12730038, 'Trương Vĩnh  Khuê', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730040, 'Nguyễn Quang  Nghiệp', 'Đào tạo từ xa'),
(12730041, 'Đinh Thành  Nhân', 'Đào tạo từ xa'),
(12730042, 'Bùi Xuân  Ninh', 'Đào tạo từ xa'),
(12730043, 'Trần Yến  Phi', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730044, 'Lê Hồng  Phong', 'Đào tạo từ xa'),
(12730045, 'Cao Hữu  Phúc', 'Đào tạo từ xa'),
(12730046, 'Hứa Vĩnh Phúc', 'Đào tạo từ xa'),
(12730047, 'Phạm Tuấn  Quỳnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730048, 'Đào Duy Tâm', 'Đào tạo từ xa'),
(12730050, 'Nguyễn Hải  Triều', 'Đào tạo từ xa'),
(12730051, 'Nguyễn Anh  Tú', 'Đào tạo từ xa'),
(12730053, 'Đặng Đạt  Văn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730055, 'Ngô Văn  Việt', 'Đào tạo từ xa'),
(12730057, 'Đoàn Thanh Bằng', 'Đào tạo từ xa'),
(12730058, 'Nguyễn Thanh Diệu', 'Đào tạo từ xa'),
(12730059, 'Lưu Quang Hải', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730060, 'Võ Minh Hoàng', 'Đào tạo từ xa'),
(12730062, 'Nguyễn Thị Kim Ngân', 'Đào tạo từ xa'),
(12730063, 'Trần Hớn Quang', 'Đào tạo từ xa'),
(12730064, 'Võ Thái Sơn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730066, 'Hứa Kiện Toàn', 'Đào tạo từ xa'),
(12730069, 'Nguyễn Thị Bé', 'Đào tạo từ xa'),
(12730075, 'Nguyễn Thanh An', 'Đào tạo từ xa'),
(12730076, 'Lê Văn Thệ Anh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730080, 'Nguyễn Phan DONA', 'Đào tạo từ xa'),
(12730081, 'Hồ Thị Ngọc Dung', 'Đào tạo từ xa'),
(12730082, 'Trần Ngọc Giàu', 'Đào tạo từ xa'),
(12730083, 'Nguyễn Thanh Hoàng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730084, 'Nguyễn Tùng Kha', 'Đào tạo từ xa'),
(12730085, 'Nguyễn Yến Khoa', 'Đào tạo từ xa'),
(12730087, 'Huỳnh Công Luận', 'Đào tạo từ xa'),
(12730089, 'Phạm Hoàng Minh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730091, 'Phạm Kim Ngân', 'Đào tạo từ xa'),
(12730094, 'Nguyễn Văn Nhiều', 'Đào tạo từ xa'),
(12730098, 'Nguyễn Thành Phát', 'Đào tạo từ xa'),
(12730106, 'Nguyễn Quốc Thắng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730109, 'Phan Văn Tiến', 'Đào tạo từ xa'),
(12730110, 'Lê Phúc Toàn', 'Đào tạo từ xa'),
(12730111, 'Phạm Lê Bảo Trọng', 'Đào tạo từ xa'),
(12730112, 'Phạm Thanh Trung', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730113, 'Châu Văn Tuấn', 'Đào tạo từ xa'),
(12730114, 'Nguyễn Thị Thùy Uyên', 'Đào tạo từ xa'),
(12730115, 'Phạm Hoài Việt', 'Đào tạo từ xa'),
(12730118, 'Phạm Hoàng  Ân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730119, 'Hà Nguyễn Tuấn  Anh', 'Đào tạo từ xa'),
(12730120, 'Nguyễn Tấn  Đạt', 'Đào tạo từ xa'),
(12730121, 'Bùi Tiến  Đạt', 'Đào tạo từ xa'),
(12730122, 'Nguyễn Quang  Đồng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730123, 'Nguyễn Thái  Dũng', 'Đào tạo từ xa'),
(12730124, 'Doãn Châu  Giang', 'Đào tạo từ xa'),
(12730125, 'Phan Minh Hân', 'Đào tạo từ xa'),
(12730126, 'Phó Trung  Hiếu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730127, 'Trương Lê Ngọc  Hiếu', 'Đào tạo từ xa'),
(12730128, 'Phan Văn  Hùng', 'Đào tạo từ xa'),
(12730129, 'Nguyễn Hữu  Hưởng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730131, 'Trần Phạm Đăng  Khoa', 'Đào tạo từ xa'),
(12730132, 'Nguyễn Thanh  Long', 'Đào tạo từ xa'),
(12730133, 'Huỳnh Văn  Một', 'Đào tạo từ xa'),
(12730134, 'Nguyễn Kim  Ngân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730135, 'Đặng Chí  Quang', 'Đào tạo từ xa'),
(12730136, 'Nguyễn văn  Qúi', 'Đào tạo từ xa'),
(12730137, 'Lê Thanh  Sang', 'Đào tạo từ xa'),
(12730138, 'Trần Đức  Thắng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730139, 'Võ Đức  Thắng', 'Đào tạo từ xa'),
(12730140, 'Đỗ Hà  Thanh', 'Đào tạo từ xa'),
(12730141, 'Nguyễn Tất  Thành', 'Đào tạo từ xa'),
(12730142, 'Nguyễn Thị Bích  Thảo', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730143, 'Nguyễn  Thi', 'Đào tạo từ xa'),
(12730144, 'Nguyễn Hoàng  Tín', 'Đào tạo từ xa'),
(12730145, 'Phạm Minh  Tín', 'Đào tạo từ xa'),
(12730146, 'Nguyễn Thị Thúy  Trinh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730147, 'Bùi Lê  Tuân', 'Đào tạo từ xa'),
(12730149, 'Nguyễn Chí Vượng', 'Đào tạo từ xa'),
(12730150, 'Phan Tấn Đạt', 'Đào tạo từ xa'),
(12730154, 'Lê Đặng Thế Phương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730155, 'Nguyễn Duy Phương', 'Đào tạo từ xa'),
(12730156, 'Phan Thanh Tần', 'Đào tạo từ xa'),
(12730157, 'Ngô Quốc Tự', 'Đào tạo từ xa'),
(12730160, 'Phan Nguyên Thế Bảo', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730162, 'Nguyễn Đình  Cương', 'Đào tạo từ xa'),
(12730163, 'Lâm Quang Đại', 'Đào tạo từ xa'),
(12730164, 'Lê Minh Diệu', 'Đào tạo từ xa'),
(12730165, 'Hoàng Văn Hiền', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730166, 'Nguyễn Đình  Hiếu', 'Đào tạo từ xa'),
(12730172, 'Lê Thanh Lâm', 'Đào tạo từ xa'),
(12730173, 'Lê Nguyễn Duy Linh', 'Đào tạo từ xa'),
(12730174, 'Lương Võ Hải  Minh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730176, 'Nguyễn Hoàng Nguyên', 'Đào tạo từ xa'),
(12730177, 'Đỗ Ngọc Nguyện', 'Đào tạo từ xa'),
(12730179, 'Lê Hùng Thiên Phước', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730180, 'Huỳnh Nguyễn Bảo Quốc', 'Đào tạo từ xa'),
(12730181, 'Trần Nam Sơn', 'Đào tạo từ xa'),
(12730182, 'Trần Thanh Tâm', 'Đào tạo từ xa'),
(12730183, 'Hà Duy Thanh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730184, 'Nguyễn Kim Thành', 'Đào tạo từ xa'),
(12730185, 'Nguyễn Đình  Thao', 'Đào tạo từ xa'),
(12730187, 'Nguyễn Thị  Thúy', 'Đào tạo từ xa'),
(12730188, 'Lại Minh Tiên', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730189, 'Trần Văn Tín', 'Đào tạo từ xa'),
(12730190, 'Nguyễn Chánh  Tín', 'Đào tạo từ xa'),
(12730191, 'Võ Minh Toàn', 'Đào tạo từ xa'),
(12730192, 'Trần Công Trung', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730193, 'Lê Trọng Trường', 'Đào tạo từ xa'),
(12730194, 'Trương Châu Tuấn', 'Đào tạo từ xa'),
(12730195, 'Nguyễn Thái Tuấn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730197, 'Nguyễn Thị Xuân Diệu', 'Đào tạo từ xa'),
(12730198, 'Viên Văn Khải', 'Đào tạo từ xa'),
(12730201, 'Nguyễn Hữu Tài', 'Đào tạo từ xa'),
(12730202, 'Lương Hoàng Tâm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730203, 'Võ Khánh Toàn', 'Đào tạo từ xa'),
(12730207, 'Phan Nguyễn Tấn Hậu', 'Đào tạo từ xa'),
(12730208, 'Trịnh Đình  Phước', 'Đào tạo từ xa'),
(12730209, 'Bùi Minh Phương', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730210, 'Nguyễn Đăng Sơn', 'Đào tạo từ xa'),
(12730211, 'Ngô Anh Tuấn', 'Đào tạo từ xa'),
(12730212, 'Huỳnh Thị Kim Uyên', 'Đào tạo từ xa'),
(12730213, 'Nguyễn Quốc  Bảo', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730214, 'Nguyễn Ngọc  Bồng', 'Đào tạo từ xa'),
(12730215, 'Nguyễn Đức  Công', 'Đào tạo từ xa'),
(12730216, 'Nguyễn Quốc  Cường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730217, 'Nguyễn Ngọc Duy  Cường', 'Đào tạo từ xa'),
(12730218, 'Trương Văn  Điền', 'Đào tạo từ xa'),
(12730220, 'Hoàng Trọng  Hậu', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730222, 'Nguyễn Khắc  Hoàng', 'Đào tạo từ xa'),
(12730223, 'Vũ Đức  Hợp', 'Đào tạo từ xa'),
(12730224, 'Nguyễn Thanh  Hùng', 'Đào tạo từ xa'),
(12730225, 'Trần Lê  Hưng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730226, 'Đỗ Trương Song  Hỷ', 'Đào tạo từ xa'),
(12730227, 'Nguyễn Đình  Khiêm', 'Đào tạo từ xa'),
(12730228, 'Bùi Đăng  Khoa', 'Đào tạo từ xa'),
(12730229, 'Nguyễn Phước  Lâm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730230, 'Phạm Huy  Lượng', 'Đào tạo từ xa'),
(12730231, 'Nhan Chánh  Nghiệp', 'Đào tạo từ xa'),
(12730232, 'Đoàn Huy  Nhật', 'Đào tạo từ xa'),
(12730233, 'Lâm Quang  Nhiên', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730234, 'La Đức  Nhuận', 'Đào tạo từ xa'),
(12730235, 'Đặng Minh  Nhựt', 'Đào tạo từ xa'),
(12730236, 'Phạm Nguyên  Phi', 'Đào tạo từ xa'),
(12730237, 'Lê Hoàng Hải  Sơn', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730238, 'Nguyễn Ngọc  Tâm', 'Đào tạo từ xa'),
(12730240, 'Ôn Thanh  Toàn', 'Đào tạo từ xa'),
(12730241, 'Trương Quang  Tùng', 'Đào tạo từ xa'),
(12730242, 'Phan Ngọc  Xuyến', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730243, 'Ngô Thị Trường An', 'Đào tạo từ xa'),
(12730245, 'Huỳnh Trí Dũng', 'Đào tạo từ xa'),
(12730246, 'Trương Thị Hận', 'Đào tạo từ xa'),
(12730248, 'Nguyễn Thành Hiển', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730249, 'Phan Văn Hòa', 'Đào tạo từ xa'),
(12730250, 'Trần Thị Diễm Kiều', 'Đào tạo từ xa'),
(12730251, 'Nguyễn Thị Kim Ngân', 'Đào tạo từ xa'),
(12730252, 'Nguyễn Thanh Thắng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730254, 'Cao Minh Trực', 'Đào tạo từ xa'),
(12730255, 'Võ Anh Tuấn', 'Đào tạo từ xa'),
(12730256, 'Nguyễn Hoàng  Dũng', 'Đào tạo từ xa'),
(12730257, 'Hồ Đức  Hải', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730258, 'Nguyễn Cao Hưng', 'Đào tạo từ xa'),
(12730259, 'Phan Văn Duy Khoa', 'Đào tạo từ xa'),
(12730260, 'Phạm Bá  Lợi', 'Đào tạo từ xa'),
(12730261, 'Trần Thị Quỳnh  Nga', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730262, 'Võ Trần Minh Phú', 'Đào tạo từ xa'),
(12730263, 'Trần Văn Thuận', 'Đào tạo từ xa'),
(12730264, 'Lương Trần  Tín', 'Đào tạo từ xa'),
(12730265, 'Nguyễn Thế  Trường', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730266, 'Võ Lê  Trưởng', 'Đào tạo từ xa'),
(12730267, 'Sầm Minh  Cẩm', 'Đào tạo từ xa'),
(12730269, 'Vũ Ngọc  Dũng', 'Đào tạo từ xa'),
(12730270, 'Bạch Thị Kiều  Hạnh', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730271, 'Hoàng Trọng  Hậu', 'Đào tạo từ xa'),
(12730272, 'Phạm Nguyên  Phi', 'Đào tạo từ xa'),
(12730273, 'Nguyễn Hồ Thế  Phương', 'Đào tạo từ xa'),
(12730274, 'Đỗ Thanh  Tâm', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730275, 'Nguyễn Tấn  Thân', 'Đào tạo từ xa'),
(12730276, 'Huỳnh  Thanh', 'Đào tạo từ xa'),
(12730277, 'Nguyễn Trọng Thiện  Thành', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(12730278, 'Nguyễn Chí Cao  Thông', 'Đào tạo từ xa'),
(12730279, 'Cao Thành  Trung', 'Đào tạo từ xa'),
(12730280, 'Thái Minh  Tuấn', 'Đào tạo từ xa'),
(12730281, 'Trương Quang  Tùng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520001, 'Võ Huỳnh An', 'Khoa học máy tính'),
(13520002, 'Nguyễn Ngọc An', 'Công nghệ phần mềm'),
(13520003, 'Phùng Ngọc An', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520004, 'Huỳnh Phước An', 'Công nghệ phần mềm'),
(13520005, 'Nguyễn Phạm Hoài An', 'Mạng máy tính & truyền thông'),
(13520006, 'Lê Khắc An', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520007, 'Trần Hùng Phương An', 'Công nghệ phần mềm'),
(13520008, 'Trịnh Phước An', 'Kỹ sư tài năng ANTT'),
(13520009, 'Nguyễn Thế Anh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520010, 'Nguyễn Tuấn Anh', 'Kỹ thuật máy tính'),
(13520011, 'Tăng Yến Anh', 'Kỹ thuật máy tính'),
(13520012, 'Lê Tuấn Anh', 'Tân sinh viên'),
(13520013, 'Liễu Hoàng Anh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520014, 'Trịnh Thị Phương Anh', 'Khoa học máy tính'),
(13520015, 'Nguyễn Duy Anh', 'Mạng máy tính & truyền thông'),
(13520016, 'Nguyễn Nam Anh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520017, 'Phạm Tuấn Anh', 'Công nghệ phần mềm'),
(13520018, 'Phạm Hoàng Ngọc Anh', 'Kỹ thuật máy tính'),
(13520019, 'Lê Quốc Anh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520020, 'Lâm Tuấn Anh', 'Công nghệ phần mềm'),
(13520021, 'Mai Hoàng Phương Anh', 'Hệ thống thông tin'),
(13520022, 'Nguyễn Quốc Anh', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520023, 'Trần Phúc Anh', 'Hệ thống thông tin'),
(13520024, 'Nguyễn Thị Lan Anh', 'Mạng máy tính & truyền thông'),
(13520026, 'Trương Thị Minh Ái', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520027, 'Trần Đức Ân', 'Hệ thống thông tin'),
(13520028, 'Mai Thiện Ân', 'BM Khoa học & Kỹ thuật thông tin'),
(13520029, 'Lê Khúc Bình Ân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520030, 'Trương Kim Ấn', 'Kỹ thuật máy tính'),
(13520031, 'Nguyễn Ngọc Ẩn', 'Cử nhân tài năng'),
(13520032, 'Lê Ngọc ẩn', 'Tân sinh viên'),
(13520033, 'Lê Khắc Ba', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520034, 'Hồ Văn Ban', 'BM Khoa học & Kỹ thuật thông tin'),
(13520035, 'Lý Gia Bảo', 'Hệ thống thông tin'),
(13520036, 'Nguyễn Quốc Bảo', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520037, 'Lý Tiểu Bằng', 'Khoa học máy tính'),
(13520038, 'Nguyễn Quốc Bảo', 'Khoa học máy tính'),
(13520039, 'Phan Gia Bảo', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520040, 'Huỳnh Quang Bảo', 'Mạng máy tính & truyền thông'),
(13520041, 'Lê Thanh Công Bảo', 'Kỹ thuật máy tính'),
(13520042, 'Nguyễn Trần Quốc Bảo', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520043, 'Đỗ Huy Bảy', 'Công nghệ phần mềm'),
(13520044, 'Vũ Minh Bạch', 'Mạng máy tính & truyền thông'),
(13520045, 'Tráş§n Ngáťc BáşŻc', 'Khoa háťc mĂĄy tĂ­nh');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520046, 'Đoàn Lê Ngọc Bảo', 'Công nghệ phần mềm'),
(13520047, 'Nguyễn Văn Bách', 'Mạng máy tính & truyền thông'),
(13520048, 'Tống Viết Bảo', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520049, 'Trần Thế Bảo', 'Khoa học máy tính'),
(13520050, 'Tưởng Ngọc Quốc Bình', 'BM Khoa học & Kỹ thuật thông tin'),
(13520051, 'Phạm Công Bình', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520052, 'Điểu An Bình', 'BM Khoa học & Kỹ thuật thông tin'),
(13520053, 'Lê Thanh Bình', 'Kỹ sư tài năng ANTT'),
(13520054, 'Nguyễn Ngọc Nam Bình', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520055, 'Trần Long Biên', 'Tân sinh viên'),
(13520056, 'Hồ Thanh Bình', 'Mạng máy tính & truyền thông'),
(13520057, 'Huỳnh Tuấn Bình', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520058, 'Nguyễn Quang Bình', 'Công nghệ phần mềm'),
(13520059, 'Nguyễn Đức Bình', 'Tân sinh viên'),
(13520060, 'Bùi Xuân Bông', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520061, 'Trần Vương Bông', 'Kỹ thuật máy tính'),
(13520062, 'Huỳnh Nguyễn Quốc Bửu', 'Hệ thống thông tin'),
(13520063, 'Nguyễn Phi Can', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520064, 'Lê Văn Cân', 'Công nghệ phần mềm'),
(13520065, 'Vũ Ngọc Cẩn', 'BM Khoa học & Kỹ thuật thông tin'),
(13520066, 'Nguyễn Ngọc Cẩn', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520067, 'Huỳnh Ngọc Cảnh', 'Mạng máy tính & truyền thông'),
(13520068, 'Nguyễn Hiếu Cảnh', 'BM Khoa học & Kỹ thuật thông tin'),
(13520069, 'Nguyễn Hữu Thanh Cảnh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520070, 'Lê Thiện Cầu', 'Công nghệ phần mềm'),
(13520071, 'Nguyễn Hoàng Minh Châu', 'Kỹ thuật máy tính'),
(13520072, 'Trần Thanh Châu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520073, 'Võ Thị Minh Chi', 'Mạng máy tính & truyền thông'),
(13520074, 'Phạm Đỗ Kim Chi', 'Cử nhân tài năng'),
(13520075, 'Nguyễn Văn Chiên', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520076, 'Vũ Minh Chiến', 'BM Khoa học & Kỹ thuật thông tin'),
(13520078, 'Hồ Thị Chinh', 'Mạng máy tính & truyền thông'),
(13520079, 'Huỳnh Khắc Chinh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520080, 'Phạm Văn Chính', 'An ninh thông tin'),
(13520081, 'Nguyễn Đăng Quang Chính', 'Khoa học máy tính'),
(13520082, 'Lê Thị Kim Chung', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520083, 'Trần Quang Chương', 'Kỹ thuật máy tính'),
(13520084, 'Trần Văn Chương', 'BM Khoa học & Kỹ thuật thông tin'),
(13520085, 'Nguyễn Hoàng Chương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520086, 'Nguyễn Đình Chương', 'Công nghệ phần mềm'),
(13520087, 'Lê Hữu Công', 'Kỹ thuật máy tính'),
(13520088, 'Nguyễn Văn Công', 'An ninh thông tin'),
(13520089, 'Vũ Văn Công', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520090, 'Hồ Chí Công', 'Khoa học máy tính'),
(13520091, 'Phan Ngọc Cương', 'Mạng máy tính & truyền thông'),
(13520092, 'Lý Trung Cương', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520093, 'Nông Quốc Cường', 'Khoa học máy tính'),
(13520094, 'Nguyễn Hữu Cường', 'An ninh thông tin'),
(13520095, 'Lê Văn Cường', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520096, 'Nguyễn Mạnh Cường', 'Khoa học máy tính'),
(13520097, 'Lê Đức Cường', 'Hệ thống thông tin'),
(13520098, 'Ngô Cường', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520099, 'Phạm Nguyễn Duy Cường', 'Mạng máy tính & truyền thông'),
(13520100, 'Lưu Tuấn Cường', 'Khoa học máy tính'),
(13520101, 'Lý Quốc Cường', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520102, 'Nguyễn Văn Cường', 'BM Khoa học & Kỹ thuật thông tin'),
(13520103, 'Trương Huy Cường', 'Công nghệ phần mềm'),
(13520104, 'Hồ Mạnh Cường', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520105, 'Nguyễn Quốc Cường', 'Công nghệ phần mềm'),
(13520106, 'Nguyễn Phú Cường', 'Kỹ thuật máy tính'),
(13520107, 'Nguyễn Đức Cường', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520108, 'Phan Mạnh Cường', 'Tân sinh viên'),
(13520109, 'Võ Cường', 'Tân sinh viên'),
(13520110, 'Phạm Thành Danh', 'Khoa học máy tính'),
(13520111, 'Đỗ Công Danh', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520112, 'Võ Thành Danh', 'Tân sinh viên'),
(13520113, 'Nguyễn Công Danh', 'Chương trình tiên tiến'),
(13520114, 'Võ Công Danh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520115, 'Nguyễn Thị Hoàng Diễm', 'Mạng máy tính & truyền thông'),
(13520116, 'Quách Thị Diệu', 'BM Khoa học & Kỹ thuật thông tin'),
(13520117, 'Võ Hùng Dinh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520118, 'Phạm Nguyễn Ngọc Doanh', 'Mạng máy tính & truyền thông'),
(13520119, 'Nguyễn Trường Doanh', 'Mạng máy tính & truyền thông'),
(13520120, 'Trần Phi Dũ', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520121, 'Phạm Thị Dung', 'Mạng máy tính & truyền thông'),
(13520122, 'Lê Thị Thùy Dung', 'Hệ thống thông tin'),
(13520123, 'Nguyễn Thị Kim Dung', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520124, 'Nguyễn Thị Dung', 'Tân sinh viên'),
(13520125, 'Dương Thị Mỹ Dung', 'Tân sinh viên'),
(13520126, 'Lê Thị Kim Dung', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520127, 'Nguyễn Quốc Dũng', 'Mạng máy tính & truyền thông'),
(13520128, 'Hoàng Xuân Dũng', 'Hệ thống thông tin'),
(13520129, 'Trần Tiến Dũng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520130, 'Nguyễn Quang Dũng', 'Mạng máy tính & truyền thông'),
(13520131, 'Nguyễn Văn Dũng', 'Hệ thống thông tin'),
(13520132, 'Hứa Trí Dũng', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520133, 'Nguyễn Hoàng Dũng', 'Kỹ thuật máy tính'),
(13520134, 'Nguyễn Quốc Dũng', 'BM Khoa học & Kỹ thuật thông tin'),
(13520135, 'Nguyễn Tuyến Dũng', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520136, 'Lê Viết Hoàng Dũng', 'Mạng máy tính & truyền thông'),
(13520137, 'Hà Văn Dũng', 'Công nghệ phần mềm'),
(13520138, 'Lăng Trọng Dụng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520139, 'Huỳnh Thanh Dương', 'Công nghệ phần mềm'),
(13520140, 'Lê Vũ Thuỳ Dương', 'An ninh thông tin'),
(13520141, 'Hà Đại Dương', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520142, 'Nguyễn Văn Dương', 'Công nghệ phần mềm'),
(13520143, 'Nguyễn Minh Dương', 'Hệ thống thông tin'),
(13520144, 'Trần Thanh Dương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520145, 'Nguyễn Đức Dương', 'Khoa học máy tính'),
(13520146, 'Nguyễn Lê Minh Dương', 'BM Khoa học & Kỹ thuật thông tin'),
(13520147, 'Nguyễn Xuân Dưỡng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520148, 'Nguyễn Bá Duy', 'Kỹ sư tài năng ANTT'),
(13520149, 'Tạ Công Duy', 'Hệ thống thông tin'),
(13520150, 'Lê Nguyễn Anh Duy', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520151, 'Nguyễn Khánh Duy', 'Mạng máy tính & truyền thông'),
(13520152, 'Huỳnh Minh Duy', 'Mạng máy tính & truyền thông'),
(13520153, 'Đặng Thành Duy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520154, 'Nguyễn Nhật Duy', 'Khoa học máy tính'),
(13520155, 'Lê Bảo Duy', 'Khoa học máy tính'),
(13520156, 'Nguyễn Nhất Duy', 'Hệ thống thông tin'),
(13520157, 'Vũ Quốc Duy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520158, 'Trần Quang Duy', 'Mạng máy tính & truyền thông'),
(13520159, 'Phạm Lê Đình Duy', 'Kỹ thuật máy tính'),
(13520160, 'Nguyễn Văn Duy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520161, 'Phạm Đức Duy', 'Khoa học máy tính'),
(13520162, 'Nguyễn Ngọc Quỳnh Duy', 'Tân sinh viên'),
(13520163, 'Dương Huỳnh Duy', 'Công nghệ phần mềm'),
(13520164, 'Lê Cảnh Duy', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520165, 'Trần Lâm Duy', 'Khoa học máy tính'),
(13520166, 'Lê Đỗ Duy', 'Tân sinh viên'),
(13520167, 'Đỗ Đức Thanh Duy', 'Tân sinh viên'),
(13520168, 'Nguyễn Võ Khương Duy', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520169, 'Ngô Minh Duy', 'Khoa học máy tính'),
(13520170, 'Từ Duy', 'Công nghệ phần mềm'),
(13520171, 'Lê Văn Duyệt', 'Hệ thống thông tin'),
(13520172, 'Phạm Thế Duyệt', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520173, 'Nguyễn Hữu Đắc', 'Chương trình tiên tiến'),
(13520174, 'Nguyễn Vĩnh Trọng Đại', 'BM Khoa học & Kỹ thuật thông tin'),
(13520175, 'Jơ Nơng Sang Đại', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520176, 'Nguyễn Đại', 'Kỹ thuật máy tính'),
(13520177, 'Lê Hải Đăng', 'Công nghệ phần mềm'),
(13520178, 'Phan Nhật Đăng', 'Công nghệ phần mềm'),
(13520179, 'Lê Hải Đăng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520180, 'Huỳnh Văn Đặng', 'Kỹ sư tài năng ANTT'),
(13520181, 'Nguyễn Thành Đạt', 'Công nghệ phần mềm'),
(13520182, 'Trần Thành Đạt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520183, 'Nguyễn Tiến Đạt', 'Kỹ thuật máy tính'),
(13520184, 'Vũ Tiến Đạt', 'Kỹ sư tài năng ANTT'),
(13520185, 'Nguyễn Xuân Đạt', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520186, 'Phạm Tiến Đạt', 'Chương trình tiên tiến'),
(13520187, 'Tăng Tường Đạt', 'BM Khoa học & Kỹ thuật thông tin'),
(13520188, 'Ngô Đức Đạt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520189, 'Từ Thành Đạt', 'Công nghệ phần mềm'),
(13520190, 'Hoàng Đức Đạt', 'Kỹ thuật máy tính'),
(13520191, 'Châu Trí Đạt', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520192, 'Nguyễn Tiến Đạt', 'Khoa học máy tính'),
(13520193, 'Nguyễn Tuấn Đạt', 'Kỹ thuật máy tính'),
(13520194, 'Viên Trí Đạt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520195, 'Lê Tấn Đạt', 'Công nghệ phần mềm'),
(13520196, 'Lê Quốc Đạt', 'Mạng máy tính & truyền thông'),
(13520197, 'Phan Tất Đạt', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520198, 'Nguyễn Xuân Hoàng Đạt', 'Kỹ thuật máy tính'),
(13520199, 'Lê Thành Đạt', 'Khoa học máy tính'),
(13520200, 'Võ Thành Đạt', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520201, 'Quách Hữu Đạt', 'Công nghệ phần mềm'),
(13520202, 'Hồ Minh Đạt', 'Chương trình tiên tiến'),
(13520203, 'Nguyễn Tiến Đạt', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520205, 'Nguyáťn XuĂ˘n Äáťnh', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(13520206, 'Nguyễn Tấn Đô', 'Mạng máy tính & truyền thông'),
(13520207, 'Nguyễn Tấn Độ', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520208, 'Nguyễn Thái Anh Đông', 'Công nghệ phần mềm'),
(13520209, 'Đinh Ngọc Đông', 'Khoa học máy tính'),
(13520210, 'Võ Minh Đủ', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520211, 'Nguyễn Trung Đức', 'BM Khoa học & Kỹ thuật thông tin'),
(13520212, 'Lê Tấn Đức', 'Mạng máy tính & truyền thông'),
(13520213, 'Nguyễn Văn Đức', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520214, 'Nguyễn Lê Vĩnh Đức', 'Khoa học máy tính'),
(13520215, 'Võ Thanh Đức', 'An ninh thông tin'),
(13520216, 'Lê Trọng Đức', 'Khoa học máy tính'),
(13520217, 'Trượng Hoàng Gia', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520218, 'LĂŞ HoĂ i Giang', 'ChĆ°ĆĄng trĂŹnh tiĂŞn tiáşżn'),
(13520219, 'Trịnh Hoài Giang', 'Khoa học máy tính'),
(13520220, 'Nguyễn Thị Ngọc Giang', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520221, 'Trần Thị Thu Hà', 'Mạng máy tính & truyền thông'),
(13520222, 'Bùi Quang Hà', 'Công nghệ phần mềm'),
(13520223, 'Chu Ngọc Hà', 'Hệ thống thông tin'),
(13520224, 'Lê Thanh Hà', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520225, 'Trương Phú Hạ', 'Mạng máy tính & truyền thông'),
(13520226, 'Châu Khắc Hải', 'Công nghệ phần mềm'),
(13520227, 'Phạm Ngọc Hải', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520228, 'Hà Quang Hải', 'Công nghệ phần mềm'),
(13520229, 'Lữ Đình Hải', 'Mạng máy tính & truyền thông'),
(13520230, 'Hoàng Hải', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520231, 'Nguyễn Thanh Hải', 'Công nghệ phần mềm'),
(13520232, 'Trần Văn Hải', 'Khoa học máy tính'),
(13520233, 'Trang Sĩ Hải', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520234, 'Lê Hồ Minh Hải', 'Chương trình tiên tiến'),
(13520235, 'Nguyễn Văn Hải', 'Khoa học máy tính'),
(13520236, 'Lê Hoàng Hải', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520237, 'Lê Hoàng Hân', 'Mạng máy tính & truyền thông'),
(13520238, 'Đoàn Thạch Hãn', 'Công nghệ phần mềm'),
(13520239, 'Võ Thị Thuý Hằng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520240, 'Ngô Thị Thu Hằng', 'Công nghệ phần mềm'),
(13520241, 'Bùi Thị Thanh Hằng', 'Kỹ sư tài năng ANTT'),
(13520242, 'Bùi Thị Lệ Hằng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520243, 'Lê Thị ái Hằng', 'Tân sinh viên'),
(13520244, 'Nguyễn Thị Hằng', 'Công nghệ phần mềm'),
(13520245, 'Trần Thị Hạnh', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520246, 'Trần Diệu Đức Hạnh', 'BM Khoa học & Kỹ thuật thông tin'),
(13520247, 'Nguyễn Danh Hào', 'Mạng máy tính & truyền thông'),
(13520248, 'Phan Hồng Hào', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520249, 'Nguyễn Hoàng Hảo', 'Công nghệ phần mềm'),
(13520250, 'Trần Thị Thu Hậu', 'Mạng máy tính & truyền thông'),
(13520251, 'Lê Trung Hậu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520252, 'Đồng Phúc Hậu', 'Mạng máy tính & truyền thông'),
(13520253, 'Đỗ Tiến Hậu', 'Công nghệ phần mềm'),
(13520254, 'Huỳnh Trần Hiên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520255, 'Phạm Văn Hiến', 'Mạng máy tính & truyền thông'),
(13520256, 'Võ Văn Hiền', 'Khoa học máy tính'),
(13520257, 'Huỳnh Quốc Hiền', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520258, 'Nguyễn Thị Thu Hiền.', 'Mạng máy tính & truyền thông'),
(13520259, 'Lê Trọng Hiền', 'Công nghệ phần mềm'),
(13520260, 'Đỗ Thị Thu Hiền', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520261, 'Nguyễn Lê Hiển', 'Công nghệ phần mềm'),
(13520262, 'Trần Văn Hiệp', 'Khoa học máy tính'),
(13520263, 'Bùi Phú Hiệp', 'Tân sinh viên'),
(13520264, 'Vũ Hoàng Hiệp', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520265, 'Nguyễn Hoàng Hiệp', 'Công nghệ phần mềm'),
(13520266, 'Võ Văn Hiếu', 'An ninh thông tin'),
(13520267, 'Trần Minh Hiếu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520268, 'Lê Tiến Hiếu', 'Công nghệ phần mềm'),
(13520269, 'Lý Văn Hiếu', 'BM Khoa học & Kỹ thuật thông tin'),
(13520270, 'Lê Quý Hiếu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520271, 'Vũ Trung Hiếu', 'Công nghệ phần mềm'),
(13520272, 'Trần Ngọc Hiếu', 'Khoa học máy tính'),
(13520273, 'Nguyễn Trung Hiếu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520274, 'Hoàng Mạnh Hiếu', 'Hệ thống thông tin'),
(13520275, 'Nguyễn Trung Hiếu', 'Hệ thống thông tin'),
(13520276, 'Đỗ Văn Hiếu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520277, 'Trương Trung Hiếu', 'Khoa học máy tính'),
(13520278, 'Nguyễn Trung Hiếu', 'Mạng máy tính & truyền thông'),
(13520279, 'Trần Trung Hiếu', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520280, 'Đinh Quang Hình', 'Cử nhân tài năng'),
(13520281, 'Nguyễn Thị Ngọc Hoa', 'Hệ thống thông tin'),
(13520282, 'Huỳnh Hữu Hoá', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520283, 'Hoàng Nhật Hóa', 'Mạng máy tính & truyền thông'),
(13520284, 'Trần Văn Hóa', 'Mạng máy tính & truyền thông'),
(13520285, 'Huỳnh Thái Hòa', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520286, 'Trương Văn Hòa', 'An ninh thông tin'),
(13520287, 'Nguyễn Cao Hòa', 'Mạng máy tính & truyền thông'),
(13520289, 'Nguyễn Duy Hoài', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520290, 'Lê Văn Hoài', 'Công nghệ phần mềm'),
(13520291, 'Nguyễn Vũ Hoài', 'BM Khoa học & Kỹ thuật thông tin'),
(13520292, 'Trần Thanh Hoàn', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520293, 'Lý Trần Hoàn', 'Mạng máy tính & truyền thông'),
(13520294, 'Đặng Phan Xuân Hoàng', 'Kỹ sư tài năng ANTT'),
(13520295, 'Đinh Đức Hoàng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520296, 'Nguyễn Tiến Hoàng', 'Kỹ sư tài năng ANTT'),
(13520297, 'Nguyễn Ngọc Hoàng', 'Công nghệ phần mềm'),
(13520298, 'Từ Đức Hoàng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520299, 'Châu Nhật Hoàng', 'Kỹ thuật máy tính'),
(13520300, 'Nguyễn Trọng Hoàng', 'Kỹ thuật máy tính'),
(13520301, 'Trương Huy Hoàng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520302, 'Đặng Thế Hoàng', 'Công nghệ phần mềm'),
(13520303, 'Phạm Xuân Hoàng', 'Hệ thống thông tin'),
(13520304, 'Bùi Khoa Hoàng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520305, 'Nguyễn Minh Hoàng', 'BM Khoa học & Kỹ thuật thông tin'),
(13520306, 'Nguyễn Bảo Hoàng', 'Khoa học máy tính'),
(13520307, 'Trần Thế Hoàng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520308, 'Phan Minh Hoàng', 'Tân sinh viên'),
(13520309, 'Hà Huy Hoàng', 'Khoa học máy tính'),
(13520310, 'Đinh Nhật Hoàng', 'Kỹ thuật máy tính'),
(13520311, 'Tô Đức Hoàng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520312, 'Nguyễn Nhật Hoàng', 'Kỹ thuật máy tính'),
(13520313, 'Trần Nhật Hoàng', 'Mạng máy tính & truyền thông'),
(13520314, 'Nguyễn Tiến Hội', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520315, 'Lê Minh Khánh Hội', 'Mạng máy tính & truyền thông'),
(13520316, 'Đỗ Đắc Hợi', 'Mạng máy tính & truyền thông'),
(13520317, 'Nguyễn Ngọc Ánh Hồng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520319, 'Võ Văn Huấn', 'Mạng máy tính & truyền thông'),
(13520320, 'Biện Quốc Hùng', 'Tân sinh viên'),
(13520321, 'Nguyễn Đức Hùng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520322, 'Lê Sơn Hùng', 'Kỹ thuật máy tính'),
(13520323, 'Huỳnh Đặng Chí Hùng', 'Công nghệ phần mềm'),
(13520324, 'Nguyễn Duy Hùng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520325, 'Phạm Văn Hùng', 'Hệ thống thông tin'),
(13520326, 'Nguyễn Viết Hùng', 'Mạng máy tính & truyền thông'),
(13520327, 'Dương Văn Hùng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520329, 'Hoàng Quốc Hưng', 'Hệ thống thông tin'),
(13520330, 'Nguyễn Tấn Hưng', 'Công nghệ phần mềm'),
(13520331, 'Thân Đức Hưng', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520332, 'Vũ Khánh Hưng', 'Tân sinh viên'),
(13520333, 'Phan Tái Hưng', 'Tân sinh viên'),
(13520334, 'Châu Thiện Hưng', 'Kỹ sư tài năng ANTT'),
(13520335, 'Trần Nguyễn Minh Hưng', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520336, 'Huáťłnh ThĂ nh HĆ°ng', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(13520337, 'Nguyễn Đình Hiệp Hưng', 'Kỹ thuật máy tính'),
(13520338, 'Trần Bảo Hưng', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520339, 'Lê Thị Lan Hương', 'Hệ thống thông tin'),
(13520340, 'Trần Thị Hương', 'BM Khoa học & Kỹ thuật thông tin'),
(13520341, 'Phan Thị Hương', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520342, 'Lê Huỳnh Hương', 'Hệ thống thông tin'),
(13520343, 'Phạm Thị ánh Hường', 'Tân sinh viên'),
(13520344, 'TrĆ°ĆĄng Quáťc HĆ°áťng', 'Káťš sĆ° tĂ i nÄng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520345, 'Nguyễn Đình Huy', 'Công nghệ phần mềm'),
(13520346, 'Lê Ngọc Huy', 'Kỹ thuật máy tính'),
(13520347, 'Tráş§n KháşŻc Huy', 'Káťš thuáş­t mĂĄy tĂ­nh');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520348, 'Nguyễn Thanh Huy', 'Công nghệ phần mềm'),
(13520349, 'Lê Quốc Huy', 'Công nghệ phần mềm'),
(13520350, 'Dương Gia Huy', 'Khoa học máy tính'),
(13520351, 'Nguyễn Trường Huy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520352, 'Vũ Tiến Huy', 'Hệ thống thông tin'),
(13520353, 'Lê Trương Gia Huy', 'Cử nhân tài năng'),
(13520354, 'Lê Quang Huy', 'Khoa học máy tính'),
(13520355, 'Lê Huỳnh Vinh Huy', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520356, 'Tráťnh Thanh Huy', 'CĂ´ng ngháť pháş§n máťm'),
(13520357, 'Trần Ngọc Huy', 'Hệ thống thông tin'),
(13520358, 'Đoàn Khánh Huy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520359, 'Phạm Nguyễn Quốc Huy', 'Kỹ thuật máy tính'),
(13520360, 'Lê Bảo Huy', 'Chương trình tiên tiến'),
(13520361, 'Nguyễn Quốc Huy', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520362, 'Nguyễn Anh Huy', 'Mạng máy tính & truyền thông'),
(13520363, 'Trần Quốc Bảo Huy', 'Cử nhân tài năng'),
(13520364, 'Lâm Quốc Huy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520365, 'Phan Đăng Huy', 'Khoa học máy tính'),
(13520366, 'Lê Đức Huy', 'Hệ thống thông tin'),
(13520367, 'Vũ Đức Huy', 'Kỹ thuật máy tính'),
(13520368, 'Nguyễn Quang Huy', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520369, 'Phan Lê Minh Huy', 'Chương trình tiên tiến'),
(13520370, 'Trần Thị Thương Huyền', 'Mạng máy tính & truyền thông'),
(13520371, 'Lê Thị Minh Huyền', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520372, 'Đỗ Quang Huỳnh', 'Kỹ thuật máy tính'),
(13520373, 'Y Tuấn Hwing', 'Mạng máy tính & truyền thông'),
(13520374, 'Lương Gia Hy', 'Tân sinh viên'),
(13520375, 'Huỳnh Thiên Hy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520376, 'Hoàng Văn Kế', 'Cử nhân tài năng'),
(13520377, 'Đào Duy Kha', 'Kỹ sư tài năng ANTT'),
(13520378, 'Lê Văn Khải', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520379, 'Kiều Minh Khải', 'Mạng máy tính & truyền thông'),
(13520380, 'Trương Duy Khang', 'Tân sinh viên'),
(13520381, 'Nguyễn Hoàng Duy Khang', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520382, 'Cao Ngọc Khanh', 'BM Khoa học & Kỹ thuật thông tin'),
(13520383, 'Trà Quang Khánh', 'Công nghệ phần mềm'),
(13520384, 'Hoàng Nhật Khánh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520385, 'Nguyễn Quốc Khánh', 'Tân sinh viên'),
(13520386, 'Võ Quốc Khánh', 'BM Khoa học & Kỹ thuật thông tin'),
(13520387, 'Trần Duy Khánh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520388, 'Trần Quốc Khánh', 'Kỹ sư tài năng ANTT'),
(13520389, 'Phạm Quốc Khánh', 'BM Khoa học & Kỹ thuật thông tin'),
(13520390, 'Nguyễn Văn Khánh', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520391, 'Nguyễn Xuân Khánh', 'Mạng máy tính & truyền thông'),
(13520392, 'Nguyễn Văn Khánh', 'Kỹ sư tài năng ANTT'),
(13520393, 'Nguyễn Hoàng Khánh', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520394, 'Lâm Quang Khiêm', 'Kỹ thuật máy tính'),
(13520395, 'Nguyễn Thanh Khiêm', 'Kỹ thuật máy tính'),
(13520396, 'Phạm Đăng Khoa', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520397, 'Nguyễn Minh Đăng Khoa', 'Mạng máy tính & truyền thông'),
(13520398, 'Trần Đăng Khoa', 'BM Khoa học & Kỹ thuật thông tin'),
(13520399, 'Phạm Đỗ Khoa', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520400, 'Đồng Đăng Khoa', 'Khoa học máy tính'),
(13520401, 'Nghi Hoàng Khoa', 'Mạng máy tính & truyền thông'),
(13520402, 'Đặng Anh Khoa', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520403, 'Nguyễn Thành Đăng Khoa', 'Mạng máy tính & truyền thông'),
(13520404, 'Nguyễn Văn Khoa', 'Kỹ thuật máy tính'),
(13520405, 'Bùi Hữu Khôi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520406, 'Khương Hữu Anh Khôi', 'Tân sinh viên'),
(13520407, 'Hồ Minh Khôi', 'Công nghệ phần mềm'),
(13520408, 'Đỗ Đức Khôi', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520409, 'Nguyễn Hoàng Khôi', 'Mạng máy tính & truyền thông'),
(13520410, 'Nguyễn Duy Khương', 'Hệ thống thông tin'),
(13520411, 'Nguyễn Hữu Khương', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520412, 'Nguyễn Ngọc Trọng Khương', 'Mạng máy tính & truyền thông'),
(13520413, 'Tôn Bảo Khuyên', 'Kỹ thuật máy tính'),
(13520414, 'Trương Công Kiên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520415, 'Hoàng Trung Kiên', 'Khoa học máy tính'),
(13520416, 'Võ Anh Kiệt', 'Tân sinh viên'),
(13520417, 'Võ Huỳnh Quang Kiệt', ''),
(13520418, 'Phan Tuấn Kiệt', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520419, 'Huỳnh Anh Kiệt', 'Chương trình tiên tiến'),
(13520420, 'Từ Đại Kim', 'Tân sinh viên'),
(13520421, 'Vũ Đình Lại', 'Kỹ thuật máy tính'),
(13520422, 'Phan Thanh Lam', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520423, 'Nguyễn Văn Lâm', 'Kỹ thuật máy tính'),
(13520424, 'Bùi Đức Lâm', 'Mạng máy tính & truyền thông'),
(13520425, 'Lê Ngọc Lâm', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520426, 'Võ Hoàng Khánh Lâm', 'Khoa học máy tính'),
(13520427, 'Lê Quốc Lâm', 'Tân sinh viên'),
(13520428, 'Làu Minh Lâm', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520429, 'Ngô Sơn Lâm', 'Công nghệ phần mềm'),
(13520430, 'Nguyễn Trần Chí Lâm', 'BM Khoa học & Kỹ thuật thông tin'),
(13520431, 'Lê Hoàng Lâm', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520432, 'Trương Hoàng Lân', 'Tân sinh viên'),
(13520433, 'Nguyễn Thành Lập', 'Kỹ thuật máy tính'),
(13520434, 'Huỳnh Bá Lập', 'Khoa học máy tính'),
(13520435, 'Nguyễn Kom Lay', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520436, 'Nguyễn Quốc Đại Lễ', 'Khoa học máy tính'),
(13520437, 'Phạm Tuyết Lệ', 'Công nghệ phần mềm'),
(13520438, 'Trần Cao Thanh Lịch', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520439, 'Phạm Thị Huỳnh Liên', 'BM Khoa học & Kỹ thuật thông tin'),
(13520440, 'Nguyễn Văn Linh', 'Công nghệ phần mềm'),
(13520441, 'Nguyễn Thị Hoài Linh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520442, 'Võ Văn Linh', 'Công nghệ phần mềm'),
(13520443, 'Trần Phương Linh', 'Hệ thống thông tin'),
(13520444, 'Chu Cẩm Tú Linh', ''),
(13520445, 'Trần Nguyễn Thảo Linh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520446, 'Mai Văn Linh', 'Công nghệ phần mềm'),
(13520447, 'Trần Thị Mỹ Linh', 'Tân sinh viên'),
(13520448, 'Lương Thành Linh', 'Khoa học máy tính'),
(13520449, 'Lê Khánh Linh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520450, 'Trịnh Hoàng Linh', 'Công nghệ phần mềm'),
(13520451, 'Nguyễn Tuấn Linh', 'Công nghệ phần mềm'),
(13520453, 'Nguyễn Thị Kiều Loan', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520454, 'Nguyễn Thị Phương Loan', 'Mạng máy tính & truyền thông'),
(13520455, 'Phan Huỳnh Lộc', 'Tân sinh viên'),
(13520456, 'Phạm Nguyễn Hoàng Lộc', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520457, 'Nguyễn Hữu Lộc', 'Kỹ sư tài năng ANTT'),
(13520458, 'Nguyáťn Viáşżt Láťc', 'Káťš sĆ° tĂ i nÄng ANTT'),
(13520459, 'Nguyễn Phước Lộc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520460, 'Trương Văn Lộc', ''),
(13520461, 'Nguyễn Văn Duy Tiến Lộc', 'Hệ thống thông tin'),
(13520462, 'Trần Hoàng Lộc', 'Kỹ thuật máy tính'),
(13520463, 'Nguyễn Thành Lộc', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520464, 'Nguyễn Thành Lợi', 'BM Khoa học & Kỹ thuật thông tin'),
(13520465, 'Trịnh Ngọc Lợi', 'Công nghệ phần mềm'),
(13520466, 'Nguyễn Xuân Long', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520467, 'Trần Hữu Long', 'Khoa học máy tính'),
(13520468, 'Trần Thiên Long', 'Mạng máy tính & truyền thông'),
(13520469, 'Nguyễn Thành Long', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520470, 'Võ Hoàng Long', 'Khoa học máy tính'),
(13520472, 'Phạm Hoài Luân', 'Kỹ thuật máy tính'),
(13520473, 'Nguyễn Thành Luân', 'Công nghệ phần mềm'),
(13520474, 'Lê Tấn Luân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520475, 'Phan Hoài Bảo Luân', 'Mạng máy tính & truyền thông'),
(13520476, 'Nguyễn Tấn Luận', 'Công nghệ phần mềm'),
(13520477, 'Lê Văn Luận', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520478, 'Hồ Đức Luật', 'Hệ thống thông tin'),
(13520479, 'Nguyễn Ngọc Lực', 'Khoa học máy tính'),
(13520480, 'Phạm Văn Lực', 'Khoa học máy tính'),
(13520481, 'Võ Văn Lưỡng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520482, 'Nguyễn Thị Mộng Lưu', 'BM Khoa học & Kỹ thuật thông tin'),
(13520483, 'Từ Giang Tiểu Ly', 'Kỹ thuật máy tính'),
(13520484, 'Nguyễn Văn Lý', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520485, 'Lý Thành Lý', 'Mạng máy tính & truyền thông'),
(13520486, 'Đặng Trần Công Lý', 'Kỹ thuật máy tính'),
(13520487, 'Lê Công Lý', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520488, 'Nguyễn Công Lý', 'Công nghệ phần mềm'),
(13520489, 'Lê Thị Tuyết Mai', 'Khoa học máy tính'),
(13520490, 'Phạm Minh Mẫn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520491, 'Trần Văn Mạnh', 'Khoa học máy tính'),
(13520492, 'Nguyễn Đình Mạnh', 'BM Khoa học & Kỹ thuật thông tin'),
(13520493, 'Trần Thế Mạnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520494, 'Trương Đức Mạnh', 'Tân sinh viên'),
(13520495, 'Vũ Văn Mạnh', 'Kỹ thuật máy tính'),
(13520496, 'Trần Anh Minh', 'Kỹ thuật máy tính'),
(13520497, 'Nguyễn Khổng Minh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520498, 'Nguyễn Hoàng Tú Minh', 'An ninh thông tin'),
(13520499, 'Tạ Văn Minh', 'Công nghệ phần mềm'),
(13520500, 'Đinh Quang Minh', ''),
(13520501, 'Đoàn Nhật Minh', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520502, 'Phạm Quang Minh', 'Khoa học máy tính'),
(13520503, 'Nguyễn Trí Anh Minh', 'Hệ thống thông tin'),
(13520504, 'Nguyễn Quang Minh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520505, 'Hoàng Anh Minh', 'Công nghệ phần mềm'),
(13520506, 'Phạm Quang Minh', 'Khoa học máy tính'),
(13520507, 'Trần Công Minh', 'Khoa học máy tính'),
(13520508, 'Nguyễn Hoàng Minh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520509, 'Trần Nguyễn Anh Minh', 'Khoa học máy tính'),
(13520510, 'Nguyễn Anh Minh', 'Tân sinh viên'),
(13520511, 'Huỳnh Nguyễn Quang Minh', 'Tân sinh viên'),
(13520512, 'Nguyễn Hải Minh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520513, 'Trần Thanh Mộng', 'An ninh thông tin'),
(13520514, 'Nguyễn Văn Thế Mỹ', 'Tân sinh viên'),
(13520516, 'Nguyễn Thành Nam', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520517, 'Nguyễn Hoàng Nam', 'Mạng máy tính & truyền thông'),
(13520518, 'Nguyễn Trung Nam', 'BM Khoa học & Kỹ thuật thông tin'),
(13520519, 'Nguyễn Quốc Nam', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520520, 'Phạm Nhật Nam', 'Khoa học máy tính'),
(13520521, 'Đậu Xuân Nam', 'Khoa học máy tính'),
(13520522, 'Nguyễn Hoài Nam', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520523, 'Lâm Ngọc Nam', 'Kỹ sư tài năng ANTT'),
(13520524, 'Nguyễn Hà Nam', 'Hệ thống thông tin'),
(13520525, 'Hoàng Triệu Nam', 'Tân sinh viên'),
(13520526, 'Trần Hoàng Nam', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520527, 'Nguyễn Thành Nam', 'Công nghệ phần mềm'),
(13520528, 'Nguyễn Đình Nam', 'BM Khoa học & Kỹ thuật thông tin'),
(13520529, 'Kỷ Hoài Nam', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520530, 'Hoàng Mai Nam', 'Tân sinh viên'),
(13520532, 'Trương Thị Tố Nga', 'BM Khoa học & Kỹ thuật thông tin'),
(13520533, 'Nguyễn Thị Kiều Nga', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520534, 'Trần Thị Hằng Nga', 'Mạng máy tính & truyền thông'),
(13520535, 'Lê Thị Tài Ngân', 'BM Khoa học & Kỹ thuật thông tin'),
(13520536, 'Nguyễn Thị Yến Ngân', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520537, 'Hoàng Thị Thanh Ngân', 'Hệ thống thông tin'),
(13520538, 'Lê Vũ Thúy Ngân', 'Mạng máy tính & truyền thông'),
(13520539, 'Lương Thế Nghi', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520540, 'Nguyễn Quang Nghĩa', 'Công nghệ phần mềm'),
(13520541, 'Dương Vĩnh Nghĩa', 'Công nghệ phần mềm'),
(13520542, 'Mai Danh Nghĩa', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520543, 'Nguyễn Trọng Nghĩa', 'Hệ thống thông tin'),
(13520544, 'Nguyễn Phước Nghĩa', 'Mạng máy tính & truyền thông'),
(13520545, 'Lương Trung Nghĩa', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520546, 'Nguyễn Văn Nghĩa', 'Khoa học máy tính'),
(13520547, 'Trần Đại Nghĩa', 'Khoa học máy tính'),
(13520548, 'Lê Trọng Nghĩa', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520549, 'Phan Phước Nghiệp', 'Kỹ thuật máy tính'),
(13520550, 'Nguyễn Thiện Ngộ', 'Tân sinh viên'),
(13520551, 'Nguyễn Trọng Ngọc', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520552, 'Trần Tấn Ngọc', 'Công nghệ phần mềm'),
(13520553, 'Bùi Phạm Như Ngọc', 'Mạng máy tính & truyền thông'),
(13520554, 'Nguyễn Duy Ngọc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520555, 'Nguyễn Thị Ngọc', 'BM Khoa học & Kỹ thuật thông tin'),
(13520556, 'Trương Bảo Ngọc', 'Hệ thống thông tin'),
(13520557, 'Phạm Trung Nguyên', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520558, 'Nguyễn An Hoàng Nguyên', 'Công nghệ phần mềm'),
(13520559, 'Nguyáťn LĂŞ ThĂĄi NguyĂŞn', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520560, 'Lầm Dân Nguyên', 'Mạng máy tính & truyền thông'),
(13520561, 'Nguyễn Hoàng Kim Nguyên', 'Công nghệ phần mềm'),
(13520562, 'Võ Quang Khải Nguyên', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520563, 'Nguyễn Trang Cát Nguyên', 'Hệ thống thông tin'),
(13520564, 'Phan Khôi Nguyên', 'Khoa học máy tính'),
(13520566, 'Phạm Hồ Lê Nguyễn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520567, 'Nguyễn Văn Nguyện', 'Công nghệ phần mềm'),
(13520568, 'Võ Đình Nhã', 'Khoa học máy tính'),
(13520569, 'Nguyễn Trung Nhân', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520570, 'Phan Đình Nhân', 'BM Khoa học & Kỹ thuật thông tin'),
(13520571, 'Võ Tài Nhân', 'Công nghệ phần mềm'),
(13520572, 'Nguyễn Hồng Nhân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520573, 'Nguyễn Hà Trung Nhân', 'Tân sinh viên'),
(13520574, 'Nguyễn Thành Nhân', 'Hệ thống thông tin'),
(13520575, 'Huỳnh Hữu Nhân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520576, 'Trần Hoàng Nhân', 'Cử nhân tài năng'),
(13520577, 'Nguyễn Minh Trọng Nhân', 'Tân sinh viên'),
(13520578, 'Nguyáťn Thiáťn NhĂ˘n', 'Káťš thuáş­t mĂĄy tĂ­nh');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520580, 'Vũ Minh Nhật', 'Công nghệ phần mềm'),
(13520581, 'Lương Minh Nhật', 'Tân sinh viên'),
(13520582, 'Vũ Minh Nhật', 'Mạng máy tính & truyền thông'),
(13520583, 'Trần Minh Nhật', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520584, 'Hoàng Tiểu Nhật', 'Khoa học máy tính'),
(13520585, 'Nguyễn Huỳnh Minh Nhật', 'Mạng máy tính & truyền thông'),
(13520586, 'Lê Kim Tuyết Nhi', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520587, 'Nguyễn Thanh Nhi', 'Tân sinh viên'),
(13520588, 'Dương Thị ái Nhi', 'Tân sinh viên'),
(13520589, 'Đặng Văn Nhờ', 'Hệ thống thông tin'),
(13520590, 'Nguyễn Thị Nhơn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520591, 'Võ Thị Ngọc Nhơn', 'Tân sinh viên'),
(13520592, 'Nguyễn Huỳnh Như', 'Công nghệ phần mềm'),
(13520593, 'Trần Văn Nhứt', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520594, 'Nguyễn Lâm Thiên Nhựt', 'Hệ thống thông tin'),
(13520595, 'Nguyễn Minh Nhựt', 'Công nghệ phần mềm'),
(13520596, 'Mai Thị Kiều Oanh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520597, 'Trần Thị Kiều Oanh', 'Mạng máy tính & truyền thông'),
(13520598, 'Ngô Xuân Pháp', 'Khoa học máy tính'),
(13520599, 'Hùynh Ngọc Pháp', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520600, 'Phạm Tấn Phát', 'Công nghệ phần mềm'),
(13520601, 'Trần Văn Phát', 'Công nghệ phần mềm'),
(13520602, 'Nguyễn Đặng Phát', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520603, 'Nguyễn Thuận Phát', 'Khoa học máy tính'),
(13520604, 'Nguyễn Tấn Phát', 'Hệ thống thông tin'),
(13520605, 'Nguyễn Thành Phát', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520606, 'Lê Khắc Trường Phát', 'Kỹ thuật máy tính'),
(13520607, 'Nguyễn Hoàng Phát', 'Công nghệ phần mềm'),
(13520608, 'Trần Ngọc Phát', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520609, 'Nguyễn Anh Phát', 'Kỹ thuật máy tính'),
(13520610, 'Văn Tiến Phát', 'Khoa học máy tính'),
(13520611, 'Nguyễn Văn Phát', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520612, 'Nguyễn Tấn Phát', 'Kỹ thuật máy tính'),
(13520613, 'Nguyễn Hoàng Phi', 'Khoa học máy tính'),
(13520614, 'Nguyễn Viết Đăng Phi', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520615, 'Phạm Hồng Phi', 'Mạng máy tính & truyền thông'),
(13520616, 'Nguyễn Trung Phong', 'Mạng máy tính & truyền thông'),
(13520617, 'Võ Nguyễn Văn Phong', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520618, 'Trần Anh Phong', 'Công nghệ phần mềm'),
(13520619, 'Trần Hoài Phong', 'Mạng máy tính & truyền thông'),
(13520620, 'Lê Quốc Phong', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520621, 'Võ Thanh Phong', 'BM Khoa học & Kỹ thuật thông tin'),
(13520622, 'Trần Phong', 'Hệ thống thông tin'),
(13520623, 'Phan Thanh Phong', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520625, 'Phạm Nguyễn Tâm Phú', 'Khoa học máy tính'),
(13520626, 'Trần Đình Phú', 'Mạng máy tính & truyền thông'),
(13520627, 'Phạm Văn Phú', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520628, 'Lê Văn Phú', 'Công nghệ phần mềm'),
(13520629, 'Lê Minh Phú', 'Công nghệ phần mềm'),
(13520630, 'Huỳnh Ngọc Thanh Phú', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520631, 'Trần Thiên Phú', 'Kỹ thuật máy tính'),
(13520632, 'Trần Thiên Phú', 'Hệ thống thông tin'),
(13520633, 'Trần Văn Phúc', 'Khoa học máy tính'),
(13520634, 'Nguyễn Duy Phúc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520635, 'Phạm Nhật Phúc', 'Công nghệ phần mềm'),
(13520636, 'Trần Đình Phúc', 'Công nghệ phần mềm'),
(13520637, 'Cao Hữu Phúc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520638, 'Nguyễn Minh Phúc', 'Khoa học máy tính'),
(13520639, 'Tạ Văn Phúc', 'Kỹ thuật máy tính'),
(13520640, 'Phạm Dương Ngọc Phúc', 'Khoa học máy tính'),
(13520641, 'Nhan Kim Phúc', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520642, 'Nguyễn Tấn Phúc', 'Hệ thống thông tin'),
(13520643, 'Trần Ngọc Phúc', 'Khoa học máy tính'),
(13520644, 'Trần Đình Phúc', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520645, 'Nguyễn Trần Quang Phục', 'Hệ thống thông tin'),
(13520646, 'Phạm Minh Phụng', 'BM Khoa học & Kỹ thuật thông tin'),
(13520647, 'Phan Phi Phụng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520648, 'Trần Linh Phụng', 'Kỹ sư tài năng ANTT'),
(13520649, 'Trần Sơn Phước', 'Tân sinh viên'),
(13520650, 'Võ Văn Phước', 'Kỹ sư tài năng ANTT'),
(13520651, 'Cao Khả Phước', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520652, 'Nguyễn Văn Phước', 'Khoa học máy tính'),
(13520653, 'Phạm Ngọc Phước', 'Cử nhân tài năng'),
(13520654, 'Huỳnh Tấn Phương', 'Kỹ sư tài năng ANTT'),
(13520655, 'Lê Duy Phương', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520657, 'Đoàn Duy Phương', 'Công nghệ phần mềm'),
(13520658, 'Hoàng Duy Phương', 'Kỹ thuật máy tính'),
(13520659, 'Nguyễn Văn Phương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520660, 'Châu Minh Phương', 'Mạng máy tính & truyền thông'),
(13520661, 'Nguyễn Tuấn Phương', 'Mạng máy tính & truyền thông'),
(13520662, 'Hồ Giang Phương', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520663, 'Huỳnh Ponl', 'Khoa học máy tính'),
(13520664, 'Nguyễn Thanh Quân', 'Công nghệ phần mềm'),
(13520665, 'Tăng Phước Quân', 'An ninh thông tin'),
(13520666, 'Nguyễn Bảo Quân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520667, 'Student', 'ChĆ°ĆĄng trĂŹnh tiĂŞn tiáşżn'),
(13520668, 'Võ Minh Quân', 'Kỹ thuật máy tính'),
(13520669, 'Võ Ngọc Minh Quân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520670, 'Đoàn Quang Nhật Quân', 'Mạng máy tính & truyền thông'),
(13520671, 'Nguyễn Sinh Quân', 'Khoa học máy tính'),
(13520672, 'Hoàng Minh Quân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520673, 'Huỳnh Nhật Quang', 'Kỹ thuật máy tính'),
(13520674, 'Lâm Quang', 'Kỹ thuật máy tính'),
(13520675, 'Nguyáťn VÄn Quang', 'CĂ´ng ngháť pháş§n máťm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520676, 'Võ Trần Quang', 'Khoa học máy tính'),
(13520677, 'Phan Duy Quang', 'Mạng máy tính & truyền thông'),
(13520678, 'Thái Nhật Quang', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520679, 'Nguyễn Lê Minh Quí', 'Khoa học máy tính'),
(13520680, 'Nguyễn Văn Quốc', 'Kỹ thuật máy tính'),
(13520681, 'Mai Minh Quý', 'Tân sinh viên'),
(13520682, 'Lê Mạnh Quý', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520683, 'Lê Nguyễn Quý', 'Công nghệ phần mềm'),
(13520684, 'Ngô Thanh Quý', 'Khoa học máy tính'),
(13520685, 'Nguyễn Đình Quý', 'Công nghệ phần mềm'),
(13520686, 'Vòng Anh Quyền', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520687, 'Nguyễn Thanh Quyết', 'Công nghệ phần mềm'),
(13520688, 'Trần Văn Quỳnh', ''),
(13520689, 'Tôn Nữ Như Quỳnh', 'Tân sinh viên'),
(13520690, 'Huỳnh Trường San', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520691, 'Đinh Tuấn San', 'Mạng máy tính & truyền thông'),
(13520692, 'Lý Ngọc Sang', 'Kỹ sư tài năng ANTT'),
(13520693, 'Nguyễn Ngọc Sang', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520694, 'Lương Phước Sang', 'Khoa học máy tính'),
(13520695, 'Bùi Như Sang', 'Khoa học máy tính'),
(13520696, 'Nguyễn Thái Sang', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520697, 'Cao Bá Thanh Sang', 'Chương trình tiên tiến'),
(13520698, 'Phạm Ngọc Quang Sang', 'Công nghệ phần mềm'),
(13520699, 'Nguyễn Thanh Sang', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520700, 'Trần Gia Sang', 'Công nghệ phần mềm'),
(13520701, 'Nguyễn Văn Sang', 'Tân sinh viên'),
(13520702, 'Lê Văn Sáu', 'Công nghệ phần mềm'),
(13520703, 'Lê Hoàng Sinh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520704, 'ChĂ˘u Ngáťc ThĂĄi SĆĄn', 'CĂ´ng ngháť pháş§n máťm'),
(13520705, 'Nguyễn Ngọc Sơn', 'BM Khoa học & Kỹ thuật thông tin'),
(13520706, 'Bùi Thái Sơn', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520707, 'Châu Đình Sơn', 'Khoa học máy tính'),
(13520708, 'Phạm Hoàng Hải Sơn', 'Công nghệ phần mềm'),
(13520709, 'Trần Ngọc Sơn', 'Tân sinh viên'),
(13520710, 'Nguyễn Hữu Sơn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520711, 'Đinh Thanh Sơn', 'Hệ thống thông tin'),
(13520712, 'Nguyễn Hoàng Sơn', 'Hệ thống thông tin'),
(13520713, 'Trần Hồng Sơn', 'Tân sinh viên'),
(13520714, 'Nguyễn Hoàng Sơn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520715, 'Trương Ngọc Sơn', 'Công nghệ phần mềm'),
(13520716, 'Nguyễn Thanh Sơn', 'Kỹ thuật máy tính'),
(13520718, 'Nguyễn Thế Song', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520719, 'Nguyễn Mậu Sứ', 'Hệ thống thông tin'),
(13520720, 'Nguyễn Thị Sương', 'Tân sinh viên'),
(13520721, 'Nguyễn Minh Tài', 'Tân sinh viên'),
(13520722, 'Huỳnh Minh Tài', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520723, 'Trần Đức Tài', 'BM Khoa học & Kỹ thuật thông tin'),
(13520724, 'Chu Phú Tài', 'Mạng máy tính & truyền thông'),
(13520725, 'Nguyễn Phước Quí Tài', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520726, 'Nguyễn Văn Tài', 'Khoa học máy tính'),
(13520727, 'Huỳnh Hữu Tài', 'Kỹ thuật máy tính'),
(13520728, 'Lâm Thành Tài', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520729, 'Nguyễn Văn Tài', 'Khoa học máy tính'),
(13520730, 'Nguyễn Đức Tài', 'Kỹ thuật máy tính'),
(13520731, 'Student', 'Hệ thống thông tin'),
(13520732, 'Trần Hữu Tài', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520733, 'Lê Hửu Tài', 'Kỹ sư tài năng ANTT'),
(13520734, 'Nguyễn Thành Tài', 'BM Khoa học & Kỹ thuật thông tin'),
(13520735, 'Huỳnh Văn Tâm', 'Khoa học máy tính'),
(13520736, 'Cao Chí Tâm', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520737, 'Trương Vĩnh Tâm', 'Tân sinh viên'),
(13520738, 'Ninh Khắc Tâm', 'An ninh thông tin'),
(13520739, 'Trần Thế Tâm', 'Mạng máy tính & truyền thông'),
(13520740, 'Phan Đặng Tâm', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520741, 'Nguyễn Thành Tâm', 'Công nghệ phần mềm'),
(13520742, 'Nguyễn Văn Tâm', 'Mạng máy tính & truyền thông'),
(13520743, 'Nguyễn Phan Tâm', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520744, 'Phạm Nguyễn Huy Tâm', 'Kỹ thuật máy tính'),
(13520745, 'Lê Thị Minh Tâm', 'Khoa học máy tính'),
(13520746, 'Nguyễn Văn Tân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520747, 'Nguyáťn Tráş§n Minh TĂ˘n', 'Háť tháťng thĂ´ng tin'),
(13520748, 'Đào Duy Tân', 'Cử nhân tài năng'),
(13520749, 'Nguyễn Ngọc Tân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520750, 'Đỗ Quang Tân', 'Kỹ thuật máy tính'),
(13520751, 'Trần Nhựt Tân', 'Mạng máy tính & truyền thông'),
(13520752, 'Phan Lê Duy Tân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520753, 'Nguyễn Phúc Tấn', 'Mạng máy tính & truyền thông'),
(13520754, 'Nguyễn Hồng Tấn', 'Mạng máy tính & truyền thông'),
(13520755, 'Nguyễn Minh Tấn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520756, 'Lê Nhật Tánh', 'Khoa học máy tính'),
(13520757, 'Huỳnh Ngọc Thạch', 'Mạng máy tính & truyền thông'),
(13520758, 'Phạm Ngọc Thạch', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520759, 'Nguyễn Văn Thái', 'An ninh thông tin'),
(13520760, 'Lê Hà Thái', 'Kỹ sư tài năng ANTT'),
(13520761, 'Văng Quốc Thái', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520762, 'Nguyễn Ngọc Thái', 'Mạng máy tính & truyền thông'),
(13520763, 'Ngô Văn Thái', 'Kỹ thuật máy tính'),
(13520764, 'Nguyễn Quốc Thái', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520765, 'Lê Xuân Thái', 'Mạng máy tính & truyền thông'),
(13520766, 'Bùi Thị Thắm', 'Mạng máy tính & truyền thông'),
(13520767, 'Lê Thị Hồng Thắm', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520768, 'Lê Văn Thắng', 'Hệ thống thông tin'),
(13520769, 'Nguyễn Quốc Thắng', 'Công nghệ phần mềm'),
(13520770, 'Trần Thị Thắng', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520771, 'Lê Chí Thắng', 'Kỹ sư tài năng ANTT'),
(13520772, 'Hoàng Mạnh Thắng', 'Công nghệ phần mềm'),
(13520773, 'Nguyễn Đặng Thắng', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520774, 'Nguyễn Phước Thắng', 'Kỹ thuật máy tính'),
(13520775, 'Huỳnh Ngọc Thắng', 'Công nghệ phần mềm'),
(13520776, 'Văn Trương Quốc Thắng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520777, 'Lê Thị Thanh', 'Mạng máy tính & truyền thông'),
(13520778, 'Huỳnh Thị Hoài Thanh.', 'Hệ thống thông tin'),
(13520779, 'Trần Hoài Thanh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520780, 'Huỳnh Phú Thanh', 'Mạng máy tính & truyền thông'),
(13520781, 'Nguyễn Hoài Thanh', 'Hệ thống thông tin'),
(13520782, 'La Quốc Thanh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520783, 'Nguyễn Đức Thành', 'Mạng máy tính & truyền thông'),
(13520784, 'Nguyễn Tấn Thành', 'Hệ thống thông tin'),
(13520785, 'Nguyễn Hải Thành', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520786, 'Trần Văn Thành', 'Công nghệ phần mềm'),
(13520787, 'Đỗ Xuân Thành', 'BM Khoa học & Kỹ thuật thông tin'),
(13520788, 'Nguyễn Minh Thành', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520789, 'Ngô Tấn Thành', 'Kỹ thuật máy tính'),
(13520790, 'Nguyễn Phước Thành', 'Khoa học máy tính'),
(13520791, 'Lê Liên Thành', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520792, 'Nguyễn Trần Trường Thành', 'BM Khoa học & Kỹ thuật thông tin'),
(13520793, 'Ngô Tống Lộc Thành', 'Mạng máy tính & truyền thông'),
(13520794, 'Hà Văn Thành', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520796, 'Nguyễn Phúc Thạnh', 'Công nghệ phần mềm'),
(13520797, 'Đỗ Duy Thảo', 'Cử nhân tài năng'),
(13520798, 'Trần Quốc Thảo', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520799, 'Phạm Thị Phương Thảo', 'Công nghệ phần mềm'),
(13520800, 'Nguyễn Thị Thu Thảo', 'Hệ thống thông tin'),
(13520801, 'Trần Thạch Thảo', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520802, 'Lê Thị Thu Thảo', 'Mạng máy tính & truyền thông'),
(13520803, 'Huỳnh Thanh Thảo', 'Cử nhân tài năng'),
(13520804, 'Trần Thị Thảo', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520805, 'Nguyễn Huỳnh Phương Thảo', 'Tân sinh viên'),
(13520806, 'Lê Minh Thế', 'Công nghệ phần mềm'),
(13520807, 'Nguyễn Thị Hồng Thi', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520808, 'Võ Văn Thi', 'Mạng máy tính & truyền thông'),
(13520809, 'Nguyễn Thái Xuân Thi', 'Kỹ thuật máy tính'),
(13520810, 'Phạm Thị Anh Thi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520811, 'Bùi Trung Thiên', 'Kỹ thuật máy tính'),
(13520812, 'Nguyễn Văn Thiên', 'Kỹ thuật máy tính'),
(13520813, 'Nguyễn Hoàng Thiên', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520814, 'Nguyễn Tăng Thiên', 'Công nghệ phần mềm'),
(13520815, 'Nguyễn Hoàng Thuận Thiên', 'BM Khoa học & Kỹ thuật thông tin'),
(13520817, 'Nguyễn Anh Thiện', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520818, 'Phạm Hoàng Thiện', 'Công nghệ phần mềm'),
(13520819, 'Phạm Văn Thiện', 'An ninh thông tin'),
(13520820, 'Nguyễn Thanh Thiện', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520821, 'Nguyễn Đăng Kế Thiện', 'Hệ thống thông tin'),
(13520822, 'Nguyễn Đình Thiện', 'Công nghệ phần mềm'),
(13520823, 'Nguyễn Vũ Quốc Thiện', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520824, 'Diệp Hữu Thiện', 'BM Khoa học & Kỹ thuật thông tin'),
(13520825, 'Vương Huỳnh Lê Thiện', 'Kỹ thuật máy tính'),
(13520826, 'Trần Văn Thiệt', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520827, 'Dương Văn Thiệu', 'Kỹ thuật máy tính'),
(13520828, 'Đặng Văn Thìn', 'Cử nhân tài năng'),
(13520829, 'Lê Minh Thinh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520830, 'Trần Huy Thịnh', 'Công nghệ phần mềm'),
(13520831, 'Đỗ Trường Thịnh', 'Tân sinh viên'),
(13520832, 'Vũ Ngọc Thịnh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520833, 'Lê Hữu Thịnh', 'Mạng máy tính & truyền thông'),
(13520834, 'Nguyễn Phúc Thịnh', 'Kỹ thuật máy tính'),
(13520835, 'Nguyễn Viết Thịnh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520836, 'Lê Tấn Thịnh', 'Công nghệ phần mềm'),
(13520837, 'Trần Đức Thịnh', 'Công nghệ phần mềm'),
(13520838, 'Phan Văn Thịnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520839, 'Nguyễn Phú Thịnh', 'Mạng máy tính & truyền thông'),
(13520840, 'Trần Anh Thịnh', 'BM Khoa học & Kỹ thuật thông tin'),
(13520841, 'Khưu Dũ Thịnh', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520842, 'Phạm Thị Oanh Thơ', 'An ninh thông tin'),
(13520843, 'Trương Đức Thọ', 'Hệ thống thông tin'),
(13520844, 'Bùi Đình Lộc Thọ', 'Công nghệ phần mềm'),
(13520845, 'Cù Văn Thọ', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520846, 'Huỳnh Hữu Thọ', 'Mạng máy tính & truyền thông'),
(13520847, 'Bùi Thị Thoa', 'Tân sinh viên'),
(13520848, 'Lê Ngọc Thông', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520849, 'Nguyễn Văn Thông', 'Mạng máy tính & truyền thông'),
(13520850, 'Đỗ Huy Thông', 'Tân sinh viên'),
(13520851, 'Bùi Trung Thông', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520852, 'Lê Hữu Thông', 'Mạng máy tính & truyền thông'),
(13520853, 'Trần Nguyên Thống', 'Mạng máy tính & truyền thông'),
(13520854, 'Nguyễn Cao Thống', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520855, 'Lê Thị Thu', 'An ninh thông tin'),
(13520856, 'Nguyễn Thị Anh Thư', 'Hệ thống thông tin'),
(13520857, 'Văn Hồng Thư', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520858, 'Nguyễn Văn Thanh Thuận', 'Khoa học máy tính'),
(13520859, 'Huỳnh Tấn Thuận', 'Công nghệ phần mềm'),
(13520860, 'Trần Công Thức', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520861, 'Phạm Tri Thức', 'Công nghệ phần mềm'),
(13520862, 'Tô Thành Thương', 'Công nghệ phần mềm'),
(13520863, 'Nguyễn Thị Diệu Thương', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520864, 'Trần Xuân Trình Thương', 'Khoa học máy tính'),
(13520865, 'Hồ Xuân Thương', 'Khoa học máy tính'),
(13520866, 'Tạ Kim Thương', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520867, 'Hoàng Thị Diệu Thường', 'BM Khoa học & Kỹ thuật thông tin'),
(13520868, 'Phạm Thu Thuỷ', 'Mạng máy tính & truyền thông'),
(13520869, 'Đặng Thị Xuân Thúy', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520870, 'Nguyễn Kim Thùy', 'Mạng máy tính & truyền thông'),
(13520871, 'Lê Thị Thanh Thùy', 'Mạng máy tính & truyền thông'),
(13520872, 'Lê Thanh Thủy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520874, 'Nguyễn Hạnh Tiên', 'Mạng máy tính & truyền thông'),
(13520875, 'Lê Văn Tiên', 'Công nghệ phần mềm'),
(13520876, 'Nguyễn Thị Cẩm Tiên', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520877, 'Phạm Nguyễn Thủy Tiên', 'Khoa học máy tính'),
(13520878, 'Trần Tiến', 'Kỹ thuật máy tính'),
(13520879, 'Nguyễn Ngọc Tiến', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520880, 'Dương Trọng Tiến', 'Kỹ thuật máy tính'),
(13520881, 'Trần Quang Tiến', 'Mạng máy tính & truyền thông'),
(13520882, 'BĂši Quang Tiáşżn', 'Káťš sĆ° tĂ i nÄng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520883, 'Vũ Văn Tiến', 'BM Khoa học & Kỹ thuật thông tin'),
(13520884, 'Trần Văn Tiến', 'BM Khoa học & Kỹ thuật thông tin'),
(13520885, 'Dư Cao Tiến', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520886, 'Đinh Mạnh Tiến', 'Kỹ thuật máy tính'),
(13520887, 'Lê Trung Tín', 'Tân sinh viên'),
(13520888, 'Đoàn Quốc Tín', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520889, 'Nguyễn Trọng Tín', 'Hệ thống thông tin'),
(13520890, 'Đặng Trung Tín', 'Công nghệ phần mềm'),
(13520891, 'Nguyễn Trọng Tín', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520892, 'Hoàng Đức Tín', 'Chương trình tiên tiến'),
(13520893, 'PháşĄm Quáťc Táťnh', 'Khoa háťc mĂĄy tĂ­nh'),
(13520894, 'Huỳnh Ngọc Tịnh', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520895, 'Huỳnh Bảo Tịnh', 'Khoa học máy tính'),
(13520896, 'Cao Văn Toàn', 'Kỹ sư tài năng ANTT'),
(13520897, 'Trần Thanh Toàn', 'Khoa học máy tính'),
(13520898, 'Trần Văn Vũ Toàn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520899, 'Nguyễn Chí Toàn', 'Kỹ sư tài năng ANTT'),
(13520900, 'Nguyễn Xuân Toản', 'Khoa học máy tính'),
(13520901, 'Trần Thanh Toản', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520902, 'Đặng Thời Trác', 'Công nghệ phần mềm'),
(13520903, 'Lê Thị Thùy Trâm', 'Tân sinh viên'),
(13520904, 'Trương Thị Phương Trâm', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520905, 'Lê Thị Thùy Trang', 'Hệ thống thông tin'),
(13520906, 'Nguyễn Thị Trang', 'Hệ thống thông tin'),
(13520907, 'Trần Thị Huyền Trang', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520908, 'Hoàng Minh Trang', 'Mạng máy tính & truyền thông'),
(13520909, 'Võ Thuỳ Phương Trang', 'Hệ thống thông tin'),
(13520910, 'Bùi Thị Quỳnh Trang', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520911, 'Bùi Trương Minh Trang', 'Mạng máy tính & truyền thông'),
(13520912, 'Lê Quốc Trạng', 'Kỹ thuật máy tính'),
(13520913, 'Trần Đình Trí', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520914, 'Ông Minh Trí', 'Công nghệ phần mềm'),
(13520915, 'Huỳnh Minh Trí', 'Công nghệ phần mềm'),
(13520916, 'Hà Minh Trí', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520917, 'Trần Minh Trí', 'Khoa học máy tính'),
(13520918, 'Nguyễn Minh Trí', 'Công nghệ phần mềm'),
(13520919, 'Đậu Minh Trí', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520920, 'Phan Trần Minh Trí', 'Kỹ thuật máy tính'),
(13520921, 'Võ Đình Cao Minh Trí', 'Công nghệ phần mềm'),
(13520922, 'Trần Minh Trí', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520923, 'Trần Minh Trí', 'Khoa học máy tính'),
(13520924, 'Nguyễn Văn Trí', 'Khoa học máy tính'),
(13520925, 'Đỗ Khắc Trí', 'Hệ thống thông tin'),
(13520926, 'Huỳnh Đỗ Minh Trí', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520927, 'Lương Quang Triết', 'Tân sinh viên'),
(13520928, 'Phạm Cao Triết', 'Khoa học máy tính'),
(13520929, 'Nguyễn Minh Triết', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520930, 'Võ Nguyễn Hoàng Triều', 'Khoa học máy tính'),
(13520931, 'Đỗ Đăng Triều', 'Mạng máy tính & truyền thông'),
(13520932, 'Lê Minh Triều', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520933, 'Nguyễn Đình Phương Trinh', 'Chương trình tiên tiến'),
(13520934, 'Lê Nguyễn Ngọc Trinh', 'Khoa học máy tính'),
(13520935, 'Nguyễn Tiến Trình', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520936, 'Lê Khánh Trình', 'Mạng máy tính & truyền thông'),
(13520937, 'Lê Hữu Trịnh', 'Khoa học máy tính'),
(13520938, 'Phạm Lê Trịnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520939, 'LĂŞ VÄn Hiáşżu Tráťng', 'Khoa háťc mĂĄy tĂ­nh'),
(13520940, 'Nguyễn Đình Tấn Trọng', 'Hệ thống thông tin'),
(13520941, 'Huỳnh Đông Trúc', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520942, 'Nguyễn Bá Trực', 'Kỹ thuật máy tính'),
(13520943, 'Tráş§n CĂ´ng BáşŁo Trung', 'CĂ´ng ngháť pháş§n máťm'),
(13520944, 'Mai Bảo Trung', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520945, 'Trịnh Tấn Trung', 'Tân sinh viên'),
(13520946, 'Lâm Thành Trung', 'BM Khoa học & Kỹ thuật thông tin'),
(13520947, 'Trần Khánh Trung', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520948, 'Nguyễn Thái Trung', 'Mạng máy tính & truyền thông'),
(13520949, 'Phan Minh Trung', 'Tân sinh viên'),
(13520950, 'Hoàng Đình Trung', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520951, 'Lê Viết Hoàng Trung', 'Hệ thống thông tin'),
(13520952, 'Trần Thế Trung', 'Kỹ thuật máy tính'),
(13520953, 'Hồ Đức Trung', 'Khoa học máy tính'),
(13520954, 'Hoàng Lý Trung', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520955, 'Lê Đức Trung', 'Tân sinh viên'),
(13520956, 'Nguyễn Viết Trung', 'An ninh thông tin'),
(13520957, 'Nguyễn Hữu Trung', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520958, 'Hoàng Ngọc Trung', 'Hệ thống thông tin'),
(13520959, 'Nguyễn Nam Trung', 'Công nghệ phần mềm'),
(13520962, 'Nguyễn Nhật Trường', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520963, 'Giang Nhật Trường', 'Khoa học máy tính'),
(13520964, 'Phan Nhật Trường', 'Mạng máy tính & truyền thông'),
(13520965, 'Nguyễn Vũ Trường', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520966, 'Nguyễn Minh Trường', 'BM Khoa học & Kỹ thuật thông tin'),
(13520967, 'Nguyễn Thanh Truyền', 'Kỹ sư tài năng ANTT'),
(13520968, 'Hồ Thị Cẩm Tú', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520969, 'Trần Ngọc Tú', 'Công nghệ phần mềm'),
(13520970, 'Trần Đình Tú', 'Mạng máy tính & truyền thông'),
(13520971, 'Nguyễn Cao Quỳnh Tú', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520972, 'Nguyễn Ngọc Tú', 'Hệ thống thông tin'),
(13520973, 'Nguyễn Công Thành Tú', 'Kỹ sư tài năng ANTT'),
(13520974, 'Nguyễn Trần Anh Tú', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520975, 'Hồ Hoàng Tú', 'Khoa học máy tính'),
(13520976, 'Hoàng Công Tú', 'Mạng máy tính & truyền thông'),
(13520977, 'Trần Anh Tú', 'Khoa học máy tính'),
(13520978, 'Bùi Công Tự', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520979, 'Hồ Thanh Tuân', 'Mạng máy tính & truyền thông'),
(13520980, 'Hồ Sĩ Tuân', 'Mạng máy tính & truyền thông'),
(13520981, 'Nguyễn Trí Tuân', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520982, 'Đặng Hữu Tuấn', 'Hệ thống thông tin'),
(13520983, 'Hoàng Ngọc Tuấn', 'Công nghệ phần mềm'),
(13520984, 'Nguyễn Thanh Tuấn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520985, 'Nguyễn Văn Tuấn', 'Khoa học máy tính'),
(13520986, 'Đoàn Quang Tuấn', 'Khoa học máy tính'),
(13520987, 'Nguyễn Thanh Tuấn', 'Kỹ thuật máy tính'),
(13520988, 'Bùi Đức Tuấn', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520989, 'Mai Hoàng Anh Tuấn', 'Tân sinh viên'),
(13520990, 'Võ Duy Tuấn', 'Công nghệ phần mềm'),
(13520991, 'Phạm Ngọc Tuấn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520992, 'Nguyễn Minh Tuấn', 'Mạng máy tính & truyền thông'),
(13520993, 'Đỗ Quốc Tuấn', 'Kỹ thuật máy tính'),
(13520994, 'Bùi Minh Tuấn', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520995, 'Vũ Anh Tuấn', 'Kỹ thuật máy tính'),
(13520996, 'Trần Linh Tuấn', 'Kỹ thuật máy tính'),
(13520997, 'Hoàng Minh Tuấn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13520998, 'Hà Thanh Tuấn', 'Công nghệ phần mềm'),
(13520999, 'Nguyễn Anh Tuấn', 'Công nghệ phần mềm'),
(13521000, 'Lưu Thiên Tuấn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521002, 'Bùi Minh Tuấn', 'Công nghệ phần mềm'),
(13521003, 'Trần Anh Tuất', 'Công nghệ phần mềm'),
(13521004, 'Đặng Thanh Túc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521005, 'Hồ Hoàng Tùng', 'Công nghệ phần mềm'),
(13521006, 'Hoàng Bách Tùng', 'Công nghệ phần mềm'),
(13521007, 'Phan Văn Tùng', 'Công nghệ phần mềm'),
(13521008, 'Bùi Thanh Tùng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521009, 'Nguyáťn Tráťnh TĂšng', 'Khoa háťc mĂĄy tĂ­nh'),
(13521010, 'Mai Thanh Tùng', 'Tân sinh viên'),
(13521011, 'Phạm Ngọc Tùng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521012, 'Hồ Nhật Tường', 'Kỹ thuật máy tính'),
(13521013, 'Tạ Minh Tuyên', 'Khoa học máy tính'),
(13521014, 'Nguyễn Thị Thu Tuyền', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521015, 'Trương Thị Thanh Tuyền', 'Hệ thống thông tin'),
(13521016, 'Phạm Thị Tuyết', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521017, 'Nguyáťn Tháť Tuyáşżt', 'MáşĄng mĂĄy tĂ­nh & truyáťn thĂ´ng'),
(13521018, 'Lưu Đình Tý', 'Kỹ sư tài năng ANTT'),
(13521019, 'Nguyễn Thanh Tỵ', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521021, 'Nguyễn Văn Uy', 'Kỹ thuật máy tính'),
(13521022, 'Nguyễn Thiên Uy', 'Tân sinh viên'),
(13521023, 'Lê Diệp Nguyên Văn', 'Công nghệ phần mềm'),
(13521024, 'Trần Xuân Văn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521025, 'Nguyễn Văn', 'Khoa học máy tính'),
(13521026, 'Vương Vinh Viễn', 'Kỹ thuật máy tính'),
(13521027, 'Nguyễn Xuân Viễn', 'Kỹ thuật máy tính'),
(13521028, 'Lê Hoằng Viễn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521029, 'Lê Bá Việt', 'Kỹ thuật máy tính'),
(13521030, 'Lê Thành Việt', 'An ninh thông tin'),
(13521031, 'Nguyễn Hữu Việt', 'Hệ thống thông tin'),
(13521032, 'Phan Huy Việt', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521033, 'Phan Trung Việt', 'Công nghệ phần mềm'),
(13521034, 'Trần Thanh Việt', 'Mạng máy tính & truyền thông'),
(13521035, 'Võ Hoàng Việt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521036, 'Phùng Quốc Việt', 'BM Khoa học & Kỹ thuật thông tin'),
(13521037, 'Nguyễn Thành Vin', 'Kỹ sư tài năng ANTT'),
(13521038, 'Hoàng Thế Vinh', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521039, 'Nguyễn Lâm Vinh', 'An ninh thông tin'),
(13521040, 'Huỳnh Ngọc Vinh', 'Khoa học máy tính'),
(13521041, 'Phạm Trọng Vinh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521042, 'Trịnh Quốc Vinh', 'Hệ thống thông tin'),
(13521043, 'Lưu Thế Vinh', 'Công nghệ phần mềm'),
(13521044, 'Lê Nguyễn Tiến Vọng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521045, 'Trần Duy Vũ', 'Kỹ thuật máy tính'),
(13521046, 'Lê Tuấn Vũ', 'Công nghệ phần mềm'),
(13521047, 'Bùi Quang Vũ', 'Khoa học máy tính'),
(13521048, 'Trương Hoàng Vũ', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521049, 'Nguyễn Công Vũ', 'Mạng máy tính & truyền thông'),
(13521050, 'Lê Huỳnh Tấn Vũ', 'Công nghệ phần mềm'),
(13521051, 'Nguyễn Thanh Hoài Vũ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521052, 'Phạm Hoàng Vũ', 'Kỹ thuật máy tính'),
(13521053, 'Đàm Minh Vũ', 'Công nghệ phần mềm'),
(13521054, 'Đỗ Minh Hoàng Vũ', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521055, 'Trần Văn Vũ', 'Kỹ thuật máy tính'),
(13521056, 'Nguyễn Ngọc Vương', 'Mạng máy tính & truyền thông'),
(13521057, 'Nguyễn Quốc Vương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521058, 'Phan Long Vương', 'Tân sinh viên'),
(13521059, 'Thái Viết Vương', 'Tân sinh viên'),
(13521060, 'Nguyễn Văn Thiên Vương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521061, 'Nguyễn Lê Đức Vương', 'Mạng máy tính & truyền thông'),
(13521062, 'Đặng Khắc Vượng', 'Mạng máy tính & truyền thông'),
(13521063, 'Võ Thị Cẩm Vy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521064, 'Nguyễn Thụy Vy', 'Cử nhân tài năng'),
(13521065, 'Văn Thạch Xuân Vy', 'Hệ thống thông tin'),
(13521066, 'Vũ Thị Thanh Xuân', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521067, 'Bùi Văn Xứng', 'Kỹ thuật máy tính'),
(13521068, 'Chung Thị Như Ý', 'Hệ thống thông tin'),
(13521069, 'Dương Nguyễn Quốc Yên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521070, 'Lê Văn Hùng', 'Kỹ sư tài năng ANTT'),
(13521071, 'Huỳnh Văn Thống', 'Kỹ sư tài năng ANTT'),
(13521072, 'Trần Hữu Tiến', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521073, 'Trần Nguyễn Vương Ái', 'Cử nhân tài năng'),
(13521074, 'Trần Nguyễn Đông Ban', ''),
(13521075, 'Phạm Thành Chung', 'Khoa học máy tính'),
(13521076, 'Hoàng Hồ Hải Đăng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521077, 'Phạm Ngọc Hà Giang', 'Cử nhân tài năng'),
(13521078, 'Lê Đình Giáp', 'Khoa học máy tính'),
(13521079, 'Trần Quang Hân', 'Cử nhân tài năng'),
(13521080, 'Lê Mạnh Hùng', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521081, 'Phạm Thành Lộc', 'Cử nhân tài năng'),
(13521082, 'Ngô Thanh Lợi', 'Cử nhân tài năng'),
(13521083, 'Hồ Minh Mẫn', 'Cử nhân tài năng'),
(13521084, 'Nguyễn Trần Phụng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521085, 'Trần Hoàng Sơn', 'Khoa học máy tính'),
(13521086, 'Trương Vĩnh Tiến', 'Tân sinh viên'),
(13521087, 'Lưu Quang Vinh', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521088, 'Lương Hoàng Nhật Đăng', 'Chương trình tiên tiến'),
(13521089, 'Lê Huỳnh Hữu Nhân', 'Chương trình tiên tiến'),
(13521090, 'Lê Vũ Phát', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521091, 'Nguyễn Hoàng Phú  Qúy', 'Tân sinh viên'),
(13521092, 'Đặng Thái Sơn', 'Chương trình tiên tiến'),
(13521093, 'Hoàng Phạm Thanh Tài', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521094, 'Huỳnh Viết Trường', 'Chương trình tiên tiến'),
(13521095, 'Nguyễn Đoàn Minh Vũ', 'Tân sinh viên'),
(13521096, 'Ngô Quốc  Tiến', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521097, 'Đào Duy Tùng', 'Công nghệ phần mềm'),
(13521098, 'Đào Duy  Tùng', 'Tân sinh viên'),
(13521099, 'Phùng Đào Vĩnh Chung', 'Kỹ thuật máy tính'),
(13521100, 'Phùng Hữu  Đăng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521101, 'Đặng Quốc Dũng', 'Tân sinh viên'),
(13521102, 'Lê Nhật Huy', 'Kỹ thuật máy tính'),
(13521103, 'Võ Nhựt Thường', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(13521105, 'Nguyễn Huỳnh Anh Tuấn', 'Chương trình tiên tiến'),
(14520001, 'Huỳnh Tấn Ái', 'BM Khoa học & Kỹ thuật thông tin'),
(14520002, 'Đỗ Phú An', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520003, 'Đoàn Thành An', 'An ninh thông tin'),
(14520004, 'Hoàng Văn An', 'Kỹ thuật máy tính'),
(14520005, 'Lê Đức Ân', 'Tân sinh viên'),
(14520006, 'Lê Phan Trường An', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520007, 'Ngô Duy Ân', 'Công nghệ phần mềm'),
(14520008, 'Nguyễn Trần An', 'Tân sinh viên'),
(14520009, 'Nguyễn Trần Minh An', 'Hệ thống thông tin'),
(14520010, 'Phạm Nữ Tuyết An', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520011, 'Tạ Thoại Ân', 'Kỹ thuật máy tính'),
(14520012, 'Trần Minh An', ''),
(14520013, 'Vũ Nguyễn Hồng Ân', 'An ninh thông tin'),
(14520014, 'Bùi Hoàng Anh', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520015, 'Đàm Nhật Anh', 'Tân sinh viên'),
(14520016, 'Hoàng Văn Anh', 'Kỹ thuật máy tính'),
(14520017, 'Lê Hùng Anh', 'Công nghệ phần mềm'),
(14520018, 'Lê Huỳnh Tuấn Anh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520019, 'Lê Nguyễn Hoàng Anh', 'Khoa học máy tính'),
(14520020, 'Lương Quốc Anh', 'Kỹ thuật máy tính'),
(14520021, 'Nghiêm Lan Anh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520022, 'Nguyễn Đức Anh', 'BM Khoa học & Kỹ thuật thông tin'),
(14520023, 'Nguyễn Kỳ Anh', 'Mạng máy tính & truyền thông'),
(14520024, 'Nguyễn Lê Tuấn Anh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520025, 'Nguyễn Ngọc Anh', 'Khoa học máy tính'),
(14520026, 'Nguyễn Quốc Anh', 'Hệ thống thông tin'),
(14520027, 'Nguyễn Tuấn Anh', 'Tân sinh viên'),
(14520028, 'Nguyễn Tuấn Anh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520029, 'Nguyễn Tuấn Anh', 'Công nghệ phần mềm'),
(14520030, 'Phạm Hoàng Anh', 'Hệ thống thông tin'),
(14520031, 'Phạm Quốc Anh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520032, 'Phan Minh Ánh', 'Mạng máy tính & truyền thông'),
(14520033, 'Phan Việt Anh', 'Kỹ thuật máy tính'),
(14520034, 'Tạ Thành Việt Anh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520035, 'Trần Đức Anh', 'Kỹ thuật máy tính'),
(14520036, 'Trần Lưu Anh', 'Mạng máy tính & truyền thông'),
(14520037, 'Trần Như Tuấn Anh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520038, 'Trần Văn Anh', 'BM Khoa học & Kỹ thuật thông tin'),
(14520039, 'Trần Việt Anh', 'Công nghệ phần mềm'),
(14520040, 'Trương Phúc Anh', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520041, 'Nguyễn Ngọc Hải Âu', 'An ninh thông tin'),
(14520042, 'Nguyễn Hoài Bắc', 'Hệ thống thông tin'),
(14520043, 'Nguyễn Văn Bắc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520044, 'Trịnh Nguyên Bác', 'An ninh thông tin'),
(14520045, 'Bùi Đình Bảo', 'Kỹ sư tài năng ANTT'),
(14520046, 'Đặng Quốc Bảo', 'Khoa học máy tính'),
(14520047, 'Đặng Thiên Bảo', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520048, 'Đỗ Vy Bảo', 'Kỹ thuật máy tính'),
(14520049, 'Hoàng Gia Bảo', 'Mạng máy tính & truyền thông'),
(14520050, 'Hoàng Nhật Bảo', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520051, 'Huỳnh Nguyễn Hoài Bão', 'Công nghệ phần mềm'),
(14520052, 'Lâm Minh Bảo', 'Kỹ sư tài năng ANTT'),
(14520053, 'Lê Thiện Bảo', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520054, 'Lê Văn Bảo', 'BM Khoa học & Kỹ thuật thông tin'),
(14520055, 'Mai Văn Bảo', 'Khoa học máy tính'),
(14520056, 'Ngô Quang Bảo', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520057, 'Nguyễn Chí Bảo', 'Hệ thống thông tin'),
(14520058, 'Nguyễn Hoàng Gia Bảo', 'Hệ thống thông tin'),
(14520059, 'Nguyễn Văn Bảo', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520060, 'Nguyễn Vương Bảo', 'Hệ thống thông tin'),
(14520061, 'Phạm Chí Bảo', 'Kỹ thuật máy tính'),
(14520062, 'Phạm Thế Bảo', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520063, 'Trần Gia Bảo', 'BM Khoa học & Kỹ thuật thông tin'),
(14520064, 'Trương Trần Bảo', 'Tân sinh viên'),
(14520065, 'Vũ Thái Bảo', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520066, 'Đỗ Văn Bình', 'Công nghệ phần mềm'),
(14520067, 'Hoàng Văn Bình', 'BM Khoa học & Kỹ thuật thông tin'),
(14520068, 'Lê Khắc Bình', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520069, 'Ngô Thanh Bình', 'Hệ thống thông tin'),
(14520070, 'Nguyễn An Bình', 'Hệ thống thông tin'),
(14520071, 'Nguyễn Đức Bình', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520072, 'Nguyễn Xuân Bình', 'Chương trình tiên tiến'),
(14520073, 'Trương Lử Thiên Bình', 'Cử nhân tài năng'),
(14520074, 'Lê Hoàng Bửu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520075, 'Đinh Văn Cảnh', 'Khoa học máy tính'),
(14520076, 'Hồ Quang Cảnh', 'Kỹ thuật máy tính'),
(14520077, 'Nguyễn Minh Cảnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520078, 'Trần Văn Cảnh', 'Mạng máy tính & truyền thông'),
(14520079, 'Lưu Hải Châu', 'Mạng máy tính & truyền thông'),
(14520080, 'Nguyễn Tấn Minh Châu', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520081, 'Phạm Ngọc Châu', 'Hệ thống thông tin'),
(14520082, 'Hồ Mai Kim Chi', 'Kỹ thuật máy tính'),
(14520083, 'Nguyễn Bảo Chi', 'Tân sinh viên'),
(14520084, 'Nguyễn Quốc Chí', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520085, 'Hồ Minh Chiến', 'Kỹ sư tài năng ANTT'),
(14520086, 'Phạm Văn Minh Chiến', 'Mạng máy tính & truyền thông'),
(14520087, 'Đỗ Đình Chiểu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520088, 'Trần Phạm Phước Chung', 'Tân sinh viên'),
(14520089, 'Trần Văn Chung', 'Kỹ thuật máy tính'),
(14520090, 'Lâm Cần Chương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520091, 'Nguyễn Viết Thành Chương', 'Công nghệ phần mềm'),
(14520092, 'Phan Huy Chương', 'BM Khoa học & Kỹ thuật thông tin'),
(14520093, 'Trần Ngọc Chương', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520094, 'Đặng Sỹ Minh Công', 'Mạng máy tính & truyền thông'),
(14520095, 'Hứa Hoàng Công', 'BM Khoa học & Kỹ thuật thông tin'),
(14520096, 'Huỳnh Văn Công', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520097, 'Lê Chí Công', 'Khoa học máy tính'),
(14520098, 'Lê Văn Công', 'Mạng máy tính & truyền thông'),
(14520099, 'Lê Xuân Công', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520100, 'Trần Minh Công', 'Công nghệ phần mềm'),
(14520101, 'Chống Nhật Cường', 'Kỹ thuật máy tính'),
(14520102, 'Đặng Quốc Cường', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520103, 'Hoàng Trọng Cường', 'Khoa học máy tính'),
(14520104, 'Huỳnh Tấn Cường', 'Hệ thống thông tin'),
(14520105, 'Lê Văn Cường', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520106, 'Mai Hoàng Cường', 'BM Khoa học & Kỹ thuật thông tin'),
(14520107, 'Ngô Nhật Cường', 'Kỹ thuật máy tính'),
(14520108, 'Nguyễn Cao Cường', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520109, 'Nguyễn Chí Cường', 'Tân sinh viên'),
(14520110, 'Nguyễn Du Cường', 'Tân sinh viên'),
(14520111, 'Nguyễn Hồng Cường', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520112, 'Nguyễn Phi Cường', 'An ninh thông tin'),
(14520113, 'Nguyễn Văn Thành Cường', 'Mạng máy tính & truyền thông'),
(14520114, 'Phan Nhựt Cường', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520115, 'Trần Kiên Cường', 'Khoa học máy tính'),
(14520116, 'Trần Việt Cường', 'Công nghệ phần mềm'),
(14520117, 'Trịnh Quốc Cường', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520118, 'Lưu Vĩnh Cửu', 'BM Khoa học & Kỹ thuật thông tin'),
(14520119, 'Bùi Tấn Đại', 'Công nghệ phần mềm'),
(14520120, 'Đặng Văn Đại', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520121, 'Nguyễn Quang Đại', 'Hệ thống thông tin'),
(14520122, 'Trần Hiếu Đại', 'Hệ thống thông tin'),
(14520123, 'Vũ Minh Đại', 'Khoa học máy tính'),
(14520124, 'Vũ Quốc Đại', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520125, 'Lê Sỹ Đan', 'An ninh thông tin'),
(14520126, 'Bùi Minh Đăng', 'Kỹ thuật máy tính'),
(14520127, 'Đặng Lâm Hải Đăng', 'Khoa học máy tính'),
(14520128, 'Nguyễn Hải Đăng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520129, 'Phạm Hải Đăng', 'Khoa học máy tính'),
(14520130, 'Trần Minh Đăng', 'Cử nhân tài năng'),
(14520131, 'Vũ Nguyễn Hải Đăng', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520132, 'Nguyễn Công Danh', 'An ninh thông tin'),
(14520133, 'Nguyễn Thanh Danh', 'Khoa học máy tính'),
(14520134, 'Phạm Hữu Danh', 'Công nghệ phần mềm'),
(14520135, 'Quách Công Danh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520136, 'Vũ Văn Danh', 'BM Khoa học & Kỹ thuật thông tin'),
(14520137, 'Phạm Anh Đào', 'Tân sinh viên'),
(14520138, 'Bùi Minh Tiến Đạt', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520139, 'Hồng Tấn Đạt', 'Hệ thống thông tin'),
(14520140, 'Huỳnh Tất Đạt', 'Công nghệ phần mềm'),
(14520141, 'Lê Phước Đạt', 'Hệ thống thông tin'),
(14520142, 'Lương Công Đạt', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520143, 'Lý Hồng Đạt', 'Mạng máy tính & truyền thông'),
(14520144, 'Nguyễn Lê Thành Đạt', 'Tân sinh viên'),
(14520145, 'Nguyễn Phát Đạt', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520146, 'Nguyễn Quốc Đạt', 'Khoa học máy tính'),
(14520147, 'Nguyễn Tấn Đạt', 'Khoa học máy tính'),
(14520148, 'Nguyễn Tấn Đạt', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520149, 'Nguyễn Thành Đạt', 'Công nghệ phần mềm'),
(14520150, 'Nguyễn Tiến Đạt', 'Hệ thống thông tin'),
(14520151, 'Nguyễn Tuấn Đạt', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520152, 'Phạm Kim Đạt', 'Công nghệ phần mềm'),
(14520153, 'Phan Vũ Đạt', 'Mạng máy tính & truyền thông'),
(14520154, 'Trần Công Đạt', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520155, 'Trần Hữu Đạt', 'Mạng máy tính & truyền thông'),
(14520156, 'Trần Quang Đạt', 'Cử nhân tài năng'),
(14520157, 'Vũ Thành Đạt', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520158, 'Nguyễn Trọng Đến', 'Hệ thống thông tin'),
(14520159, 'Lê Đình Đích', 'BM Khoa học & Kỹ thuật thông tin'),
(14520160, 'Bùi Trung Điền', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520161, 'Đào Văn Định', 'Tân sinh viên'),
(14520162, 'Nguyễn Ngọc Thiên Định', 'Tân sinh viên'),
(14520163, 'Phạm Văn Định', 'Kỹ thuật máy tính'),
(14520164, 'Trần Thanh Định', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520165, 'Trương Khai Định', 'Công nghệ phần mềm'),
(14520166, 'Trương Long Đình', 'BM Khoa học & Kỹ thuật thông tin'),
(14520167, 'Nguyễn Văn Độ', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520168, 'Đoàn Văn Đoàn', 'Hệ thống thông tin'),
(14520169, 'Vũ Minh Đoàn', 'Tân sinh viên'),
(14520170, 'Hoàng Tiến Đông', 'Cử nhân tài năng'),
(14520171, 'Ngô Hưng Đông', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520172, 'Nguyễn Phú Đông', 'Mạng máy tính & truyền thông'),
(14520173, 'Trương Minh Đông', 'Khoa học máy tính'),
(14520174, 'VĂľ VÄn ÄĂ´ng', 'Háť tháťng thĂ´ng tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520175, 'Bùi Ngọc Du', 'Tân sinh viên'),
(14520176, 'Trần Văn Dự', 'BM Khoa học & Kỹ thuật thông tin'),
(14520177, 'Đinh Minh Đức', 'Hệ thống thông tin'),
(14520178, 'Đoàn Trí Đức', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520179, 'Hoàng Trung Đức', 'Mạng máy tính & truyền thông'),
(14520180, 'Huỳnh Hoàng Đức', 'Khoa học máy tính'),
(14520181, 'Lê Minh Đức', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520182, 'Lê Minh Đức', 'Kỹ sư tài năng ANTT'),
(14520183, 'Nguyễn Hoàng Đức', 'Hệ thống thông tin'),
(14520184, 'Nguyễn Hồng Đức', 'Tân sinh viên'),
(14520185, 'Nguyễn Thế Đức', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520186, 'Nguyễn Trung Đức', 'Mạng máy tính & truyền thông'),
(14520187, 'Phan Huỳnh Đức', 'Khoa học máy tính'),
(14520188, 'Thái Bá Đức', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520189, 'Trần Anh Đức', 'Hệ thống thông tin'),
(14520190, 'Trần Khắc Đức', 'Kỹ sư tài năng ANTT'),
(14520191, 'Võ Trần Duy Đức', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520192, 'Hoàng Anh Dũng', 'Công nghệ phần mềm'),
(14520193, 'Hoàng Vũ Trí Dũng', 'Mạng máy tính & truyền thông'),
(14520194, 'Lê Hoàng Dững', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520195, 'Mai Hoàng Dũng', 'Khoa học máy tính'),
(14520196, 'Nguyễn Đăng Tuấn Dũng', 'Tân sinh viên'),
(14520197, 'Nguyễn Hoài Dũng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520198, 'Nguyễn Hoàng Dũng', 'Khoa học máy tính'),
(14520199, 'Nguyễn Mạnh Dũng', 'Hệ thống thông tin'),
(14520200, 'Nguyễn Ngọc Hoàng Dung', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520201, 'Nguyễn Việt Dũng', 'Kỹ sư tài năng ANTT'),
(14520202, 'Phạm Thị Dung', 'Tân sinh viên'),
(14520203, 'Phan Trí Dũng', 'Kỹ thuật máy tính'),
(14520204, 'Trần Đại Dũng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520205, 'Vũ Thế Dũng', 'Khoa học máy tính'),
(14520206, 'Lâm Hải Dương', 'Tân sinh viên'),
(14520207, 'Lê Hải Dương', 'Mạng máy tính & truyền thông'),
(14520208, 'Lê Vũ Dương', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520209, 'Nguyễn Công Dương', 'Tân sinh viên'),
(14520210, 'Nguyễn Thế Dương', 'Khoa học máy tính'),
(14520211, 'Phan Tấn Thái Dương', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520212, 'Trương Hoàng Minh Dương', 'Mạng máy tính & truyền thông'),
(14520213, 'Bùi Văn Duy', 'Công nghệ phần mềm'),
(14520214, 'Huỳnh Tấn Duy', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520215, 'Lê Hoàng Duy', 'Công nghệ phần mềm'),
(14520216, 'Lê Trung Duy', 'Hệ thống thông tin'),
(14520217, 'Lương Hoàng Duy', 'Công nghệ phần mềm'),
(14520218, 'Mao Đình Duy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520219, 'Nguyễn Bảo Duy', 'Mạng máy tính & truyền thông'),
(14520220, 'Nguyễn Bảo Duy', 'Công nghệ phần mềm'),
(14520221, 'Nguyễn Đức Duy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520222, 'Nguyễn Nguyên Duy', 'Công nghệ phần mềm'),
(14520223, 'Nguyễn Trọng Duy', 'Tân sinh viên'),
(14520224, 'Trần Đức Duy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520225, 'Trần Khánh Duy', 'Mạng máy tính & truyền thông'),
(14520226, 'Trần Quang Quốc Duy', 'BM Khoa học & Kỹ thuật thông tin'),
(14520227, 'Trịnh Đức Duy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520228, 'Võ Minh Duy', 'Tân sinh viên'),
(14520229, 'Nguyễn Trung Duyên', 'Mạng máy tính & truyền thông'),
(14520230, 'Đặng Ngọc Thanh Giang', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520231, 'Thái Nguyễn Minh Giang', 'Mạng máy tính & truyền thông'),
(14520232, 'Trương Quang Giàu', 'Kỹ thuật máy tính'),
(14520233, 'Phạm Trọng Hoàng Hà', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520234, 'Trần Việt Hạ', 'Mạng máy tính & truyền thông'),
(14520235, 'Văn Hồng Hà', 'Công nghệ phần mềm'),
(14520236, 'Bùi Thanh Hải', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520237, 'Bùi Thanh Hải', 'Kỹ thuật máy tính'),
(14520238, 'Đặng Hồng Hải', 'Khoa học máy tính'),
(14520239, 'Đặng Thanh Hải', 'Tân sinh viên'),
(14520240, 'Đào Thanh Hải', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520241, 'Đỗ Thanh Hải', 'Hệ thống thông tin'),
(14520242, 'Lê Khắc Hải', 'Mạng máy tính & truyền thông'),
(14520243, 'Nguyễn Vũ Phong Hải', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520244, 'Phùng Nhật Hải', 'Mạng máy tính & truyền thông'),
(14520245, 'Thái Ngọc Hải', 'Mạng máy tính & truyền thông'),
(14520246, 'Trần Văn Hải', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520247, 'Trần Xuân Hải', 'Khoa học máy tính'),
(14520248, 'Nguyễn Hoàng Bảo Hân', 'Mạng máy tính & truyền thông'),
(14520249, 'Nguyễn Hữu Hân', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520250, 'Nguyễn Thị Ngọc Hân', 'Mạng máy tính & truyền thông'),
(14520251, 'Trần Thị Ngọc Hân', 'Hệ thống thông tin'),
(14520252, 'Lê Ngô Thuý Hằng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520253, 'Lê Thị Diễm Hằng', 'Tân sinh viên'),
(14520254, 'Nguyễn Thị Hằng', 'Mạng máy tính & truyền thông'),
(14520255, 'Phạm Phước Hạnh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520256, 'Trần Thị Hạnh', 'Tân sinh viên'),
(14520257, 'Văn Thị Hồng Hạnh', ''),
(14520258, 'Bùi Anh Hào', 'An ninh thông tin'),
(14520259, 'Lê Anh Hào', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520260, 'Nguyễn Phát Nhật Hào', 'Kỹ thuật máy tính'),
(14520261, 'Bùi Phong Hậu', 'Kỹ thuật máy tính'),
(14520262, 'Huỳnh Minh Hậu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520263, 'Lê Công Hậu', 'Hệ thống thông tin'),
(14520264, 'Nguyễn Phước Hậu', 'Hệ thống thông tin'),
(14520265, 'Võ Hoàng Hậu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520266, 'Äinh CĂ´ng Vinh Hiáťn', 'An ninh thĂ´ng tin'),
(14520267, 'Đoàn Trung Hiền', 'Công nghệ phần mềm'),
(14520268, 'GiĂĄp VÄn Hiáťn', 'Háť tháťng thĂ´ng tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520269, 'Lê Tấn Vinh Hiển', 'Khoa học máy tính'),
(14520270, 'Ngô Trọng Hiền', 'Mạng máy tính & truyền thông'),
(14520271, 'Nguyễn Thanh Hiền', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520272, 'Nguyễn Thị Hiền', 'Công nghệ phần mềm'),
(14520273, 'Nguyễn Thị Hiền', 'Hệ thống thông tin'),
(14520274, 'Phạm Vinh Hiển', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520275, 'Trần Hữu Hiền', 'Mạng máy tính & truyền thông'),
(14520276, 'Trần Mạc Tôn Hiển', 'Chương trình tiên tiến'),
(14520277, 'Trần Thị Hiền', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520278, 'Lê Quang Hiệp', 'Khoa học máy tính'),
(14520279, 'Mai Quang Hiệp', 'An ninh thông tin'),
(14520280, 'Nguyễn Văn Hiệp', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520281, 'Đỗ Trung Hiếu', 'BM Khoa học & Kỹ thuật thông tin'),
(14520282, 'Huỳnh Trung Hiếu', 'Công nghệ phần mềm'),
(14520283, 'Lưu Trung Hiếu', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520284, 'Ngô Hoàng Trí Hiếu', 'Khoa học máy tính'),
(14520285, 'Nguyễn Duy Hiếu', 'Kỹ thuật máy tính'),
(14520286, 'Nguyễn Lê Minh Hiếu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520287, 'Nguyễn Minh Hiếu', 'Công nghệ phần mềm'),
(14520288, 'Nguyễn Minh Hiếu', 'Công nghệ phần mềm'),
(14520289, 'Nguyễn Quang Hiếu', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520290, 'Phạm Hữu Hiệu', 'Kỹ thuật máy tính'),
(14520291, 'Trần Huỳnh Trung Hiếu', 'An ninh thông tin'),
(14520292, 'Trần Trọng Hiếu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520293, 'Võ Đình Trung Hiếu', 'Mạng máy tính & truyền thông'),
(14520294, 'Võ Duy Hiếu', 'An ninh thông tin'),
(14520295, 'Võ Trọng Hiếu', 'Tân sinh viên'),
(14520296, 'Vũ Văn Hiếu', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520297, 'Nguyễn Quang Hổ', 'Khoa học máy tính'),
(14520298, 'Nguyễn Tấn Hổ', 'Khoa học máy tính'),
(14520299, 'Dương Chí Hoa', 'Kỹ thuật máy tính'),
(14520300, 'Phạm Thị Kim Hòa', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520301, 'Tô Đức Hoài', 'Mạng máy tính & truyền thông'),
(14520302, 'Trần Sĩ Hoài', 'Mạng máy tính & truyền thông'),
(14520303, 'Bùi Văn Hoàn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520304, 'Đinh Viết Hoàn', 'Kỹ thuật máy tính'),
(14520305, 'Nguyễn Khải Hoàn', 'Tân sinh viên'),
(14520306, 'Phạm Văn Hoàn', 'Hệ thống thông tin'),
(14520307, 'Bùi Ngọc Hoàng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520308, 'Hồ Thị Kim Hoàng', 'Hệ thống thông tin'),
(14520309, 'Lâm Đức Hoàng', 'Kỹ sư tài năng ANTT'),
(14520310, 'Nguyễn Minh Hoàng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520311, 'Nguyễn Minh Hoàng', 'Công nghệ phần mềm'),
(14520312, 'Nguyễn Nhật Hoàng', 'Khoa học máy tính'),
(14520313, 'Nguyễn Phương Hoàng', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520314, 'Nguyễn Văn Hoàng', 'Kỹ thuật máy tính'),
(14520315, 'Phạm Đăng Hoàng', 'BM Khoa học & Kỹ thuật thông tin'),
(14520316, 'Phạm Huy Hoàng', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520317, 'Phan Minh Hoàng', 'Công nghệ phần mềm'),
(14520318, 'Trần Khánh Hoàng', 'Tân sinh viên'),
(14520319, 'Trần Minh Hoàng', 'An ninh thông tin'),
(14520320, 'Trịnh Mẫn Hoàng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520321, 'Trịnh Minh Hoàng', 'Khoa học máy tính'),
(14520322, 'Trương Thái Minh Hoàng', 'BM Khoa học & Kỹ thuật thông tin'),
(14520323, 'Trần Thị Hoành', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520324, 'Nguyễn Thị Thu Hồng', ''),
(14520325, 'Đoàn Hữu Lê Huân', 'Mạng máy tính & truyền thông'),
(14520326, 'Nguyễn Ngọc Huân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520327, 'Nguyễn Văn Huân', 'Kỹ thuật máy tính'),
(14520328, 'Nguyễn Xuân Huấn', 'Công nghệ phần mềm'),
(14520329, 'Phạm Công Huấn', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520330, 'Nguyễn Thị Minh Huệ', 'Tân sinh viên'),
(14520331, 'Bùi Huy Hùng', 'Kỹ thuật máy tính'),
(14520332, 'Cao Thăng Hưng', 'Kỹ thuật máy tính'),
(14520333, 'Đặng Nguyễn Thế Hưng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520334, 'Huỳnh Quốc Hùng', 'Hệ thống thông tin'),
(14520335, 'Huỳnh Thế Hùng', 'Mạng máy tính & truyền thông'),
(14520336, 'Lê Mai Khánh Hưng', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520337, 'Lê Minh Hưng', 'BM Khoa học & Kỹ thuật thông tin'),
(14520338, 'Lê Quốc Hùng', 'Công nghệ phần mềm'),
(14520339, 'Lê Viết Hưng', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520340, 'Lưu Phi Hùng', 'Kỹ thuật máy tính'),
(14520341, 'Lưu Quang Hùng', 'Hệ thống thông tin'),
(14520342, 'Ngô Mạnh Hùng', 'Kỹ thuật máy tính'),
(14520343, 'Nguyễn Lê Hưng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520344, 'Nguyễn Mạnh Hùng', 'Hệ thống thông tin'),
(14520345, 'Nguyễn Mạnh Hùng', 'Kỹ sư tài năng ANTT'),
(14520346, 'Nguyễn Minh Hùng', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520347, 'Nguyễn Minh Hưng', 'Công nghệ phần mềm'),
(14520348, 'Nguyễn Ngọc Hưng', 'Hệ thống thông tin'),
(14520349, 'Nguyễn Thị Mỹ Hưng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520350, 'Nguyễn Vũ Hùng', 'Kỹ thuật máy tính'),
(14520351, 'Phạm Văn Hưng', 'BM Khoa học & Kỹ thuật thông tin'),
(14520352, 'Phan Xuân Uy Hùng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520353, 'Trần Minh Hùng', 'Mạng máy tính & truyền thông'),
(14520354, 'Trần Thanh Hùng', 'Công nghệ phần mềm'),
(14520355, 'Trịnh Công Hùng', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520356, 'Đặng Văn Xuân Hương', 'Kỹ thuật máy tính'),
(14520357, 'Phạm Văn Hữu', 'Mạng máy tính & truyền thông'),
(14520358, 'Trần Minh Hữu', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520359, 'Đặng Hoàng Huy', 'Hệ thống thông tin'),
(14520360, 'Đỗ Quang Huy', 'Kỹ thuật máy tính'),
(14520361, 'Hoàng Anh Huy', 'Công nghệ phần mềm'),
(14520362, 'Huỳnh Hoàng Huy', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520363, 'Lâm Tuấn Huy', 'Kỹ thuật máy tính'),
(14520364, 'Lê Huy', 'Hệ thống thông tin'),
(14520365, 'Lê Mậu Gia Huy', 'Kỹ thuật máy tính'),
(14520366, 'Lý Đăng Huy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520367, 'Ngô Ngọc Huy', 'Hệ thống thông tin'),
(14520368, 'Nguyễn Anh Huy', 'Kỹ sư tài năng ANTT'),
(14520369, 'Nguyễn Đình Huy', 'Kỹ thuật máy tính'),
(14520370, 'Nguyễn Quang Huy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520371, 'Nguyễn Quang Huy', 'Mạng máy tính & truyền thông'),
(14520372, 'Nguyễn Quốc Huy', 'Công nghệ phần mềm'),
(14520373, 'Nguyễn Quốc Huy', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520374, 'Nguyễn Thanh Huy', 'Kỹ thuật máy tính'),
(14520375, 'Nguyễn Thế Huy', 'Tân sinh viên'),
(14520376, 'Nguyễn Tiến Huy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520377, 'Nguyễn Trường Huy', 'Tân sinh viên'),
(14520378, 'Nguyễn Văn Anh Huy', 'Kỹ sư tài năng ANTT'),
(14520379, 'Nguyễn Xuân Huy', 'Khoa học máy tính'),
(14520380, 'Nguyễn Xuân Huy', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520381, 'Phạm Huy', 'An ninh thông tin'),
(14520382, 'Phan Thanh Huy', 'Mạng máy tính & truyền thông'),
(14520383, 'Phùng Trọng Huy', 'Công nghệ phần mềm'),
(14520384, 'Tăng Quang Huy', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520385, 'Trần Minh Huy', 'Công nghệ phần mềm'),
(14520386, 'Trần Quang Huy', 'Khoa học máy tính'),
(14520387, 'Trần Thanh Huy', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520388, 'Trương Quốc Gia Huy', 'Công nghệ phần mềm'),
(14520389, 'Võ Quang Huy', 'Công nghệ phần mềm'),
(14520390, 'Bùi Thị Thanh Huyền', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520391, 'Nguyễn Thị Huyền', 'Công nghệ phần mềm'),
(14520392, 'Nguyễn Thị Như Huyền', 'Tân sinh viên'),
(14520393, 'Trần Khánh Huyền', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520394, 'Bùi Lê Huỳnh', 'Hệ thống thông tin'),
(14520395, 'Nguyễn Thị Như Huỳnh', 'An ninh thông tin'),
(14520396, 'Đỗ Nhật Kha', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520397, 'Hồ Bảo Kha', 'Công nghệ phần mềm'),
(14520398, 'Huỳnh Quốc Kha', 'BM Khoa học & Kỹ thuật thông tin'),
(14520399, 'Nguyễn Chu Kha', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520400, 'Nguyễn Huệ Khả', 'Kỹ thuật máy tính'),
(14520401, 'Trương Ngọc Kha', 'Khoa học máy tính'),
(14520402, 'Nguyễn Khắc Khải', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520403, 'Nguyễn Việt Khải', 'Kỹ thuật máy tính'),
(14520404, 'Đinh Hoàng Khang', 'BM Khoa học & Kỹ thuật thông tin'),
(14520405, 'Hồ Hoàng Khang', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520406, 'Nguyễn An Khang', 'BM Khoa học & Kỹ thuật thông tin'),
(14520407, 'Nguyễn Diệp Thanh Khang', 'BM Khoa học & Kỹ thuật thông tin'),
(14520408, 'Nguyễn Duy Khang', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520409, 'Trần Đình Khang', 'Công nghệ phần mềm'),
(14520410, 'Trần Võ Trọng Khang', 'Mạng máy tính & truyền thông'),
(14520411, 'Đỗ Quang Khánh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520412, 'Lê Nguyễn Đình Khánh', 'Mạng máy tính & truyền thông'),
(14520413, 'Lê Nhật Khánh', 'Công nghệ phần mềm'),
(14520414, 'Nguyễn Bá Khánh', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520415, 'Nguyễn Nhựt Khánh', 'Công nghệ phần mềm'),
(14520416, 'Phạm Văn Khánh', 'Công nghệ phần mềm'),
(14520417, 'Phùng Thái Khanh', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520418, 'VĹŠ HoĂ ng KhĂĄnh', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(14520419, 'Hà Duy Khiêm', 'Công nghệ phần mềm'),
(14520420, 'Chung Quang Anh Khoa', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520421, 'Đặng Anh Khoa', 'Công nghệ phần mềm'),
(14520422, 'Huỳnh Đăng Khoa', 'Khoa học máy tính'),
(14520423, 'Ngô Khánh Khoa', 'An ninh thông tin'),
(14520424, 'Nguyễn Đăng Khoa', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520425, 'Nguyễn Đào Anh Khoa', 'Kỹ sư tài năng ANTT'),
(14520426, 'Nguyễn Đình Văn Khoa', 'Hệ thống thông tin'),
(14520427, 'Nguyễn Phạm Đăng Khoa', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520428, 'Nguyễn Trọng Văn Khoa', 'An ninh thông tin'),
(14520429, 'Nguyáťn VÄn Khoa', 'Káťš thuáş­t mĂĄy tĂ­nh'),
(14520430, 'Phạm Đăng Khoa', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520431, 'Trương Đăng Khoa', 'Khoa học máy tính'),
(14520432, 'Cao Minh Khôi', 'Mạng máy tính & truyền thông'),
(14520433, 'Huỳnh Anh Khôi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520434, 'Võ Tuấn Khôi', 'Hệ thống thông tin'),
(14520435, 'Phùng Nguyễn Mạnh Khương', 'Kỹ thuật máy tính'),
(14520436, 'Trương Nguyên Quang Khương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520437, 'Chung Vĩnh Kiện', 'Kỹ thuật máy tính'),
(14520438, 'Hà Văn Kiên', 'Tân sinh viên'),
(14520439, 'Huỳnh Hoa Trung Kiên', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520440, 'Dương Tấn Kiệt', 'Công nghệ phần mềm'),
(14520441, 'Lê Tuấn Kiệt', 'BM Khoa học & Kỹ thuật thông tin'),
(14520442, 'Lưu Tuấn Kiệt', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520443, 'Nguyễn Tấn Kiệt', 'Mạng máy tính & truyền thông'),
(14520444, 'Nguyễn Thế Kiệt', 'Kỹ thuật máy tính'),
(14520445, 'Trần Diễm Kiều', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520446, 'Huỳnh Hoàng Kim', 'Kỹ thuật máy tính'),
(14520447, 'Lê Đức Tương Kỳ', 'Tân sinh viên'),
(14520448, 'Nguyễn Mạnh Kỳ', 'Kỹ thuật máy tính'),
(14520449, 'Nguyễn Thị Lài', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520450, 'Trần Văn Lai', 'Tân sinh viên'),
(14520451, 'Bùi Duy Lâm', 'Khoa học máy tính'),
(14520452, 'Huỳnh Ngọc Bảo Lâm', 'Hệ thống thông tin'),
(14520453, 'Mộc Hà Lâm', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520454, 'Nguyễn Đức Lâm', 'Cử nhân tài năng'),
(14520455, 'Trần Thuỵ Xuân Lâm', 'Mạng máy tính & truyền thông'),
(14520456, 'Trần Văn Lâm', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520457, 'Hoàng Lân', 'Hệ thống thông tin'),
(14520458, 'Nguyễn Mậu Hoàng Lân', 'Cử nhân tài năng'),
(14520459, 'Hà Thành Lập', 'Công nghệ phần mềm'),
(14520460, 'Nông Thị Lệ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520461, 'Bùi Thanh Liêm', 'Kỹ thuật máy tính'),
(14520462, 'Nguyễn Thanh Liêm', 'Công nghệ phần mềm'),
(14520463, 'Trương Thị Ngọc Lil', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520464, 'Hoàng Trọng Duy Linh', 'Khoa học máy tính'),
(14520465, 'Nguyễn Dương Thảo Linh', 'Chương trình tiên tiến'),
(14520466, 'Nguyễn Thị Trúc Linh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520467, 'Nguyễn Trọng Duy Linh', 'Hệ thống thông tin'),
(14520468, 'Phạm Ngọc Lịnh', ''),
(14520469, 'Phạm Văn Linh', 'Hệ thống thông tin'),
(14520470, 'Phan Gia Linh', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520471, 'Trần Dương Thúy Linh', 'Mạng máy tính & truyền thông'),
(14520472, 'Trần Khánh Linh', 'Mạng máy tính & truyền thông'),
(14520473, 'Võ Cao Thuỳ Linh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520474, 'Lê Thị Loan', 'Tân sinh viên'),
(14520475, 'Đỗ Quang Lộc', 'Mạng máy tính & truyền thông'),
(14520476, 'Hoàng Minh Lộc', 'Tân sinh viên'),
(14520477, 'Lê Đình Khánh Lộc', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520478, 'Lê Phước Lộc', 'Khoa học máy tính'),
(14520479, 'Nguyễn Thành Lộc', 'Mạng máy tính & truyền thông'),
(14520480, 'Huỳnh Hữu Lợi', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520481, 'Lý Tấn Lợi', 'An ninh thông tin'),
(14520482, 'Nguyễn Minh Lợi', 'Mạng máy tính & truyền thông'),
(14520483, 'Đặng Nhật Hải Long', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520484, 'Huỳnh Thanh Long', 'Kỹ thuật máy tính'),
(14520485, 'Lê Xuân Long', 'Công nghệ phần mềm'),
(14520486, 'Lương Thành Long', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520487, 'Ngô Đoàn Long', 'Mạng máy tính & truyền thông'),
(14520488, 'Nguyễn Văn Long', 'Hệ thống thông tin'),
(14520489, 'Phạm Tùng Long', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520490, 'Trần Quốc Long', 'Cử nhân tài năng'),
(14520491, 'Hồ Sĩ Luân', 'Kỹ thuật máy tính'),
(14520492, 'Nguyễn Minh Luân', 'Kỹ thuật máy tính'),
(14520493, 'Nguyễn Thanh Luân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520494, 'Phạm Văn Luận', 'An ninh thông tin'),
(14520495, 'Phan Đình Luân', 'Công nghệ phần mềm'),
(14520496, 'Phan Văn Luân', 'Khoa học máy tính'),
(14520497, 'Trần Minh Luân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520498, 'Võ Thành Luân', 'Tân sinh viên'),
(14520499, 'Nguyễn Định Luật', 'Hệ thống thông tin'),
(14520500, 'Hoàng Trung Lực', 'Công nghệ phần mềm'),
(14520501, 'Nhiêu Sĩ Lực', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520502, 'Đoàn Thị Trúc Ly', 'Khoa học máy tính'),
(14520503, 'Hồ Ngọc Ly', 'Mạng máy tính & truyền thông'),
(14520504, 'Mai Nguyễn Lưu Ly', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520505, 'Huỳnh Thị Ngọc Mai', 'Tân sinh viên'),
(14520506, 'Lê Thị Mai', 'Tân sinh viên'),
(14520507, 'Phạm Xuân Mai', 'Hệ thống thông tin'),
(14520508, 'Trương Quỳnh Mai', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520509, 'Lê Sinh Mẫn', 'An ninh thông tin'),
(14520510, 'Phạm Thế Mẫn', 'Tân sinh viên'),
(14520511, 'Trần Minh Mẩn', 'Hệ thống thông tin'),
(14520512, 'Hoàng Vi Mạnh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520513, 'Võ Sĩ Mến', 'Hệ thống thông tin'),
(14520514, 'Nguyễn Văn Miên', 'Hệ thống thông tin'),
(14520515, 'Đặng Quang Nhật Minh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520516, 'Đào Công Nhật Minh', 'Công nghệ phần mềm'),
(14520517, 'Diệp Huy Minh', 'BM Khoa học & Kỹ thuật thông tin'),
(14520518, 'Đoàn Lê Minh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520519, 'Đoàn Quang Minh', 'Hệ thống thông tin'),
(14520520, 'Dương Thanh Minh', 'Tân sinh viên'),
(14520521, 'Hứa Nguyên Khải Minh', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520522, 'Lê Anh Minh', 'Khoa học máy tính'),
(14520523, 'Lê Hoàng Anh Minh', 'Hệ thống thông tin'),
(14520524, 'Lê Ngọc Minh', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520525, 'Lê Văn Minh', 'Công nghệ phần mềm'),
(14520526, 'Lương Hữu Minh', 'Kỹ thuật máy tính'),
(14520527, 'Ma Văn Minh', 'Tân sinh viên'),
(14520528, 'Nguyễn Cao Minh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520529, 'Nguyễn Cao Minh', 'Khoa học máy tính'),
(14520530, 'Nguyễn Đức Minh', 'Mạng máy tính & truyền thông'),
(14520531, 'Nguyễn Hoàng Minh', 'Tân sinh viên'),
(14520532, 'Nguyễn Văn Minh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520533, 'Phạm Ngọc Hiếu Minh', 'Mạng máy tính & truyền thông'),
(14520534, 'Phạm Văn Minh', 'Hệ thống thông tin'),
(14520535, 'Phan Vũ Quang Minh', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520536, 'Trương Hoàng Minh', 'Kỹ thuật máy tính'),
(14520537, 'Võ Hoàng Minh', 'Kỹ thuật máy tính'),
(14520538, 'Võ Thân Nhật Minh', 'Kỹ sư tài năng ANTT'),
(14520539, 'Vũ Công Minh', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520540, 'Nguyễn Thạch Mộng', 'Hệ thống thông tin'),
(14520541, 'Đỗ Bá Tứ Mỹ', 'An ninh thông tin'),
(14520542, 'Lê Phước Mỹ', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520543, 'Nguyễn Hoài Tố My', 'Hệ thống thông tin'),
(14520544, 'Nguyễn Quang Mỹ', 'Hệ thống thông tin'),
(14520545, 'Nguyễn Thị Tuyết My', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520546, 'Đỗ Nhật Nam', 'BM Khoa học & Kỹ thuật thông tin'),
(14520547, 'Lê Phương Nam', 'BM Khoa học & Kỹ thuật thông tin'),
(14520548, 'Lê Phương Nam', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520549, 'Nguyễn Hoài Nam', 'Công nghệ phần mềm'),
(14520550, 'Nguyễn Hoàng Nam', 'Khoa học máy tính'),
(14520551, 'Nguyễn Hoàng Nam', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520552, 'Nguyễn Hoàng Nam', 'BM Khoa học & Kỹ thuật thông tin'),
(14520553, 'Nguyễn Phương Nam', 'BM Khoa học & Kỹ thuật thông tin'),
(14520554, 'Nguyễn Phương Nam', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520555, 'Nguyễn Thành Nam', 'Kỹ thuật máy tính'),
(14520556, 'Nguyễn Thanh Nam', 'BM Khoa học & Kỹ thuật thông tin'),
(14520557, 'Nguyễn Thành Nam', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520558, 'Nguyễn Thế Nam', 'BM Khoa học & Kỹ thuật thông tin'),
(14520559, 'Nguyễn Văn Nam', 'Kỹ thuật máy tính'),
(14520560, 'Nguyễn Việt Nam', ''),
(14520561, 'Phạm Dương Nhật Nam', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520562, 'Thái Hoàng Nam', 'Mạng máy tính & truyền thông'),
(14520563, 'Tống Hoàng Nam', 'Khoa học máy tính'),
(14520564, 'Trần Chí Nam', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520565, 'Trần Hoàng Nam', 'Công nghệ phần mềm'),
(14520566, 'Trần Phương Nam', 'Tân sinh viên'),
(14520567, 'Trần Quang Nam', 'Khoa học máy tính'),
(14520568, 'Nguyễn Quý Năng', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520569, 'Dương Thị Thúy Nga', 'Khoa học máy tính'),
(14520570, 'Nguyễn Thị Anh Nga', 'Hệ thống thông tin'),
(14520571, 'Võ Thị Thúy Nga', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520572, 'Đặng Thị Ngân', 'An ninh thông tin'),
(14520573, 'Lê Hoàng Kim Ngân', 'Tân sinh viên'),
(14520574, 'Lê Thị Châu Ngân', 'An ninh thông tin'),
(14520575, 'Nguyễn Thị Kim Ngân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520576, 'Nguyễn Thị Tuyết Ngân', 'Tân sinh viên'),
(14520577, 'Võ Hữu Ngân', 'Mạng máy tính & truyền thông'),
(14520578, 'Cáp Doãn Nghĩa', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520579, 'Nguyễn Hữu Nghĩa', 'Tân sinh viên'),
(14520580, 'Trần Hoài Nghĩa', 'Công nghệ phần mềm'),
(14520581, 'Trần Minh Nghĩa', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520582, 'Trần Ngọc Nghĩa', 'Công nghệ phần mềm'),
(14520583, 'Võ Ngô Trung Nghĩa', 'Chương trình tiên tiến'),
(14520584, 'Vũ Ngọc Minh Nghĩa', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520585, 'Cao Như Ngọc', 'Kỹ thuật máy tính'),
(14520586, 'Đoàn Đại Ngọc', 'Khoa học máy tính'),
(14520587, 'Lâm Khánh Ngọc', 'Cử nhân tài năng');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520588, 'Lương Sĩ Ngọc', 'BM Khoa học & Kỹ thuật thông tin'),
(14520589, 'Trần Lê Tuấn Ngọc', 'Kỹ sư tài năng ANTT'),
(14520590, 'Võ Minh Ngọc', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520591, 'Huỳnh Văn Ngữ', 'Khoa học máy tính'),
(14520592, 'Dương Hiển Trung Nguyên', 'Kỹ thuật máy tính'),
(14520593, 'Hoàng Mạnh Nguyên', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520594, 'Huỳnh Khoa Nguyên', 'Tân sinh viên'),
(14520595, 'Lâm Vĩnh Nguyên', 'An ninh thông tin'),
(14520596, 'Lê Nguyễn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520597, 'Nguyễn Cao Nguyên', 'Mạng máy tính & truyền thông'),
(14520598, 'Nguyễn Hoàng Phương Nguyên', 'Kỹ thuật máy tính'),
(14520599, 'Nguyễn Khôi Nguyên', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520600, 'Nguyễn Khương Nguyên', 'Khoa học máy tính'),
(14520601, 'Nguyễn Phương Nguyên', 'Công nghệ phần mềm'),
(14520602, 'Nguyễn Thành Nguyên', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520603, 'Nguyễn Trần Đình Nguyên', 'Kỹ thuật máy tính'),
(14520604, 'Nguyễn Y Nguyên', 'Kỹ thuật máy tính'),
(14520605, 'Phạm Hoài Nguyên', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520606, 'Phạm Kim Nguyên', 'Kỹ thuật máy tính'),
(14520607, 'Phạm Trung Nguyên', 'Công nghệ phần mềm'),
(14520608, 'Phan Đình Nguyên', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520609, 'Trần Hoàng Hải Nguyên', 'Mạng máy tính & truyền thông'),
(14520610, 'Trần Khánh Nguyên', 'Công nghệ phần mềm'),
(14520611, 'Trần Lê Minh Nguyên', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520612, 'Trần Trí Nguyên', 'Chương trình tiên tiến'),
(14520613, 'Trần Võ Tân Nguyên', 'Mạng máy tính & truyền thông'),
(14520614, 'Trịnh Bảo Khai Nguyên', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520615, 'Từ Vĩnh Nguyên', 'Kỹ thuật máy tính'),
(14520616, 'Văn Minh Nguyên', 'Công nghệ phần mềm'),
(14520617, 'Nguyễn Thị Thu Nguyệt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520618, 'Nguyễn Trọng Nhã', 'Kỹ thuật máy tính'),
(14520619, 'Diệp Quang Nhân', 'Khoa học máy tính'),
(14520620, 'Dương Ngọc Nhẫn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520621, 'Huỳnh Thanh Nhân', 'Kỹ thuật máy tính'),
(14520622, 'Lê Đức Nhân', 'Chương trình tiên tiến'),
(14520623, 'Nguyễn Hoàng Nhân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520624, 'Nguyễn Thanh Nhàn', 'Khoa học máy tính'),
(14520625, 'Nguyễn Thành Nhân', 'Kỹ thuật máy tính'),
(14520626, 'Nguyễn Thiện Nhân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520627, 'Phạm Hưng Nhãn', 'Khoa học máy tính'),
(14520628, 'Phan Xuân Nhân', 'Tân sinh viên'),
(14520629, 'Thái Trí Nhân', 'Tân sinh viên'),
(14520630, 'Trần Trọng Thành Nhân', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520631, 'Nguyễn Minh Nhật', 'Mạng máy tính & truyền thông'),
(14520632, 'Nguyễn Minh Nhật', 'Kỹ thuật máy tính'),
(14520633, 'Phạm Huỳnh Minh Nhật', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520634, 'Trần Minh Nhật', 'BM Khoa học & Kỹ thuật thông tin'),
(14520635, 'Lê Thị Thanh Nhi', 'Tân sinh viên'),
(14520636, 'Nguyễn Thị Thảo Nhi', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520637, 'Nguyễn Thị Yến Nhi', 'Hệ thống thông tin'),
(14520638, 'Võ Sĩ Nhiều', 'Mạng máy tính & truyền thông'),
(14520639, 'Hồ Hồng Như', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520640, 'Huỳnh Bích Như', 'BM Khoa học & Kỹ thuật thông tin'),
(14520641, 'Nguyễn Thanh Như', 'Tân sinh viên'),
(14520642, 'Phạm Văn Nhu', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520643, 'Ngô Thị Phương Nhuân', 'BM Khoa học & Kỹ thuật thông tin'),
(14520644, 'Nguyễn Hùng Nhuần', 'Mạng máy tính & truyền thông'),
(14520645, 'Ngô Thị Tuyết Nhung', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520646, 'Trịnh Thị Nhung', 'Tân sinh viên'),
(14520647, 'Nguyễn Ngọc Nhựt', 'Hệ thống thông tin'),
(14520648, 'Lê Tuấn Ninh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520649, 'Tạ Đình Núi', 'Mạng máy tính & truyền thông'),
(14520650, 'Đậu Thị Kim Oanh', 'BM Khoa học & Kỹ thuật thông tin'),
(14520651, 'Phạm Duy Phương Oanh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520652, 'Lê Hà Phan', 'Tân sinh viên'),
(14520653, 'Hoàng Đặng Tấn Phát', 'Kỹ thuật máy tính'),
(14520654, 'Lê Tấn Phát', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520655, 'Lê Tiến Phát', 'BM Khoa học & Kỹ thuật thông tin'),
(14520656, 'Lương Tấn Phát', 'Kỹ thuật máy tính'),
(14520657, 'Lưu Trọng Phát', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520658, 'Nguyễn Hồng Phát', 'An ninh thông tin'),
(14520659, 'Nguyễn Mạnh Phát', 'Mạng máy tính & truyền thông'),
(14520660, 'Nguyễn Minh Phát', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520661, 'Nguyễn Nhi Phát', 'Mạng máy tính & truyền thông'),
(14520662, 'Nguyễn Tấn Phát', 'Kỹ sư tài năng ANTT'),
(14520663, 'Đào Văn Phi', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520664, 'Đinh Hồng Phi', 'Mạng máy tính & truyền thông'),
(14520665, 'Dương Công Phi', 'Tân sinh viên'),
(14520666, 'Trương Văn Phiên', 'Khoa học máy tính'),
(14520667, 'Hà Thanh Phong', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520668, 'Hồ Nguyễn Anh Phong', 'Khoa học máy tính'),
(14520669, 'Mai Quốc Phong', 'Khoa học máy tính'),
(14520670, 'Nguyễn Hoài Phong', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520671, 'Nguyễn Thanh Phong', 'BM Khoa học & Kỹ thuật thông tin'),
(14520672, 'Phan Thái Phong', 'Hệ thống thông tin'),
(14520673, 'Phan Thanh Phong', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520674, 'Thái Viết Phong', 'Mạng máy tính & truyền thông'),
(14520675, 'Trần Đình Phong', 'Khoa học máy tính'),
(14520676, 'Trần Xuân Phong', 'Tân sinh viên'),
(14520677, 'Vũ Tấn Phong', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520678, 'Bùi Thiên Phú', 'BM Khoa học & Kỹ thuật thông tin'),
(14520679, 'Cao Văn Phú', 'Kỹ thuật máy tính'),
(14520680, 'Lê Quang Phú', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520681, 'Lưu Đức Phú', 'Kỹ sư tài năng ANTT'),
(14520682, 'Mai Vũ Thiên Phú', 'Chương trình tiên tiến'),
(14520683, 'Nguyễn Hoài Phú', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520684, 'Nguyễn Hoàng Phú', 'Kỹ thuật máy tính'),
(14520685, 'Nguyễn Xuân Vĩnh Phú', 'BM Khoa học & Kỹ thuật thông tin'),
(14520686, 'Trương Vĩnh Phú', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520687, 'Văn Phú', 'Hệ thống thông tin'),
(14520688, 'Vương Gia Phú', 'Kỹ thuật máy tính'),
(14520689, 'Cao Thiên Phúc', ''),
(14520690, 'Đinh Văn Phúc', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520691, 'Đỗ Hồng Phúc', 'Công nghệ phần mềm'),
(14520692, 'Đoàn Thiên Phúc', 'Kỹ sư tài năng ANTT'),
(14520693, 'Hứa Văn Phúc', 'An ninh thông tin'),
(14520694, 'Lê Văn Phúc', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520695, 'Lưu Vĩnh Phúc', 'Khoa học máy tính'),
(14520696, 'Mai Xuân Phúc', 'Hệ thống thông tin'),
(14520697, 'Nguyễn Ân Phúc', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520698, 'Nguyễn Hữu Phúc', 'Chương trình tiên tiến'),
(14520699, 'Nguyễn Ngọc Phúc', 'Kỹ thuật máy tính'),
(14520700, 'Phan Hồng Phúc', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520701, 'Thái Hoàng Phúc', 'Khoa học máy tính'),
(14520702, 'Trần Vĩnh Phúc', 'Kỹ thuật máy tính'),
(14520703, 'Võ Nguyễn Thiên Phúc', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520704, 'Nguyễn Đình Phùng', 'Công nghệ phần mềm'),
(14520705, 'Nguyễn Lê Gia Phụng', 'Mạng máy tính & truyền thông'),
(14520706, 'Bùi Hữu Phước', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520707, 'Lê Đại Phước', 'Khoa học máy tính'),
(14520708, 'Lê Ngọc Hoàng Phước', 'Công nghệ phần mềm'),
(14520709, 'Nguyễn Duy Phước', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520710, 'Nguyễn Ngọc Phước', 'Tân sinh viên'),
(14520711, 'Phạm Ngọc Phước', 'Cử nhân tài năng'),
(14520712, 'Phan Đại Phước', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520713, 'Dương Thị Mỹ Phương', 'Công nghệ phần mềm'),
(14520714, 'Hà Việt Phương', 'Kỹ thuật máy tính'),
(14520715, 'Hồ Nguyên Phương', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520716, 'Huỳnh Hoàng Phương', 'An ninh thông tin'),
(14520717, 'Lê Phan Hoài Phương', 'BM Khoa học & Kỹ thuật thông tin'),
(14520718, 'Nguyễn Đình Phương', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520719, 'Nguyễn Lan Phương', 'Công nghệ phần mềm'),
(14520720, 'Nguyễn Tấn Phương', 'Tân sinh viên'),
(14520721, 'Phạm Lê Vĩnh Phương', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520722, 'Trần Thị Hiền Phương', 'Hệ thống thông tin'),
(14520723, 'Đoàn Hồng Quân', 'Cử nhân tài năng'),
(14520724, 'Hồ Hoàng Quân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520725, 'Hoàng Minh Quân', 'Cử nhân tài năng'),
(14520726, 'Hoàng Vũ Minh Quân', 'Tân sinh viên'),
(14520727, 'Huỳnh Nguyễn Ngọc Quân', 'Kỹ thuật máy tính'),
(14520728, 'Lê Công Quân', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520729, 'Lê Hoàng Quân', 'Cử nhân tài năng'),
(14520730, 'Lê Minh Quân', 'Tân sinh viên'),
(14520731, 'Lê Tiến Quân', 'Tân sinh viên'),
(14520732, 'Nguyễn Bá Quân', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520733, 'Nguyễn Công Trần Quân', 'Mạng máy tính & truyền thông'),
(14520734, 'Nguyễn Hồng Quân', 'Kỹ thuật máy tính'),
(14520735, 'Tôn Hồng Quân', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520736, 'Võ Minh Quân', 'Kỹ thuật máy tính'),
(14520737, 'Võ Nguyên Quân', 'Kỹ thuật máy tính'),
(14520738, 'Lưu Chí Quang', 'Tân sinh viên'),
(14520739, 'Nguyễn Hào Quang', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520740, 'Nguyễn Lê Quang', 'Công nghệ phần mềm'),
(14520741, 'Phạm Ngọc Quang', 'Khoa học máy tính'),
(14520742, 'Phan Ngọc Quang', 'Hệ thống thông tin'),
(14520743, 'Võ Đăng Quang', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520744, 'Lê Văn Quế', 'Kỹ thuật máy tính'),
(14520745, 'Mai Văn Quốc', 'Mạng máy tính & truyền thông'),
(14520746, 'Lê Quang Quý', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520747, 'Phạm Trần Thiện Quý', 'Tân sinh viên'),
(14520748, 'Ngô Vũ Quyền', 'Công nghệ phần mềm'),
(14520749, 'Phan Công Quyền', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520750, 'Cao Hà Minh Quyết', 'Công nghệ phần mềm'),
(14520751, 'Lại Văn Quyết', 'Khoa học máy tính'),
(14520752, 'Vũ Văn Quyết', 'Tân sinh viên'),
(14520753, 'Hồ Tố Quỳnh', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520754, 'Phùng Vĩnh Sâm', 'Công nghệ phần mềm'),
(14520755, 'Đỗ Hoài Sang', 'Tân sinh viên'),
(14520756, 'Huỳnh Thanh Sang', 'Mạng máy tính & truyền thông'),
(14520757, 'Nguyễn Kim Sang', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520758, 'Nguyễn Minh Sáng', 'Kỹ sư tài năng ANTT'),
(14520759, 'Nguyễn Phước Sang', 'Chương trình tiên tiến'),
(14520760, 'Phạm Hửu Sang', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520761, 'Thạch Kỳ Sanh', 'Công nghệ phần mềm'),
(14520762, 'Phùng Nhục Sầu', 'Mạng máy tính & truyền thông'),
(14520763, 'Phạm Văn Sĩ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520764, 'Nguyễn Tri Sinh', 'Công nghệ phần mềm'),
(14520765, 'Âu Dương Sơn', 'Mạng máy tính & truyền thông'),
(14520766, 'Cao Thế Sơn', 'Tân sinh viên'),
(14520767, 'Đỗ Lưu Sơn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520768, 'Đỗ Văn Sơn', 'Công nghệ phần mềm'),
(14520769, 'Lã Hoàng Thái Sơn', 'Kỹ thuật máy tính'),
(14520770, 'Lê Minh Sơn', 'Tân sinh viên'),
(14520771, 'Lê Quan Sơn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520772, 'Lưu Thanh Sơn', 'Công nghệ phần mềm'),
(14520773, 'Nguyễn Ngọc Sơn', 'Khoa học máy tính'),
(14520774, 'Nguyễn Trần Hải Sơn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520775, 'Nguyễn Trần Hoàng Sơn', 'Tân sinh viên'),
(14520776, 'Trần Hoàng Sơn', 'Hệ thống thông tin'),
(14520777, 'Tráş§n Quang SĆĄn', 'CĂ´ng ngháť pháş§n máťm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520778, 'Võ Ngọc Sơn', 'Mạng máy tính & truyền thông'),
(14520779, 'Phạm Thành Sự', 'Khoa học máy tính'),
(14520780, 'Nguyễn Huỳnh Tuấn Sỹ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520781, 'Huỳnh Phương Tài', 'Kỹ sư tài năng ANTT'),
(14520782, 'Lê Trọng Tài', 'BM Khoa học & Kỹ thuật thông tin'),
(14520783, 'Lê Văn Tài', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520784, 'Nguyễn Phúc Tài', 'BM Khoa học & Kỹ thuật thông tin'),
(14520785, 'Phạm Anh Tài', 'Tân sinh viên'),
(14520786, 'Phùng Thanh Tài', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520787, 'Võ Chí Tài', 'BM Khoa học & Kỹ thuật thông tin'),
(14520788, 'Võ Nguyễn Đức Tài', 'Tân sinh viên'),
(14520789, 'Cao Thành Tâm', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520790, 'Đỗ Anh Tâm', 'Công nghệ phần mềm'),
(14520791, 'Giang Đinh Thành Tâm', 'Mạng máy tính & truyền thông'),
(14520792, 'Lê Gia Ngọc Tâm', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520793, 'Lê Trần Phương Tâm', 'Công nghệ phần mềm'),
(14520794, 'Nguyễn Hồ Minh Tâm', 'Mạng máy tính & truyền thông'),
(14520795, 'Nguyễn Minh Tâm', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520796, 'Nguyễn Minh Tâm', 'Hệ thống thông tin'),
(14520797, 'Phạm Đào Văn Tẩm', 'Kỹ thuật máy tính'),
(14520798, 'Phạm Văn Tâm', 'Tân sinh viên'),
(14520799, 'Phan Hoàng Tâm', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520800, 'Trần Thanh Tâm', 'BM Khoa học & Kỹ thuật thông tin'),
(14520801, 'Trương Sĩ Tam', 'Kỹ thuật máy tính'),
(14520802, 'Đặng Phước Tấn', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520803, 'Hoàng Ngọc Tấn', 'Công nghệ phần mềm'),
(14520804, 'Huỳnh Hoàng Tân', 'Kỹ thuật máy tính'),
(14520805, 'Lê Phước Tân', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520806, 'Phạm Đức Minh Tân', 'Tân sinh viên'),
(14520807, 'Phạm Nhật Tân', 'Công nghệ phần mềm'),
(14520808, 'Phạm Nhật Tân', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520809, 'Tô Nguyễn Duy Tân', 'Kỹ thuật máy tính'),
(14520810, 'Giang Kim Thạch', 'Kỹ thuật máy tính'),
(14520811, 'Hoàng Ngọc Thạch', 'Kỹ thuật máy tính'),
(14520812, 'Bùi Minh Thái', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520813, 'Chu Hoàng Thái', 'Mạng máy tính & truyền thông'),
(14520814, 'Đàm Gia Thái', 'Công nghệ phần mềm'),
(14520815, 'Đinh Quang Thái', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520816, 'Đỗ Văn Thái', 'Kỹ thuật máy tính'),
(14520817, 'Dương Hồng Thái', 'Mạng máy tính & truyền thông'),
(14520818, 'Nguyễn Quốc Thái', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520819, 'Nguyễn Trần Thái', 'Hệ thống thông tin'),
(14520820, 'Nguyễn Văn Thái', 'Mạng máy tính & truyền thông'),
(14520821, 'Phan Phạm Quốc Thái', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520822, 'Tô Văn Thái', 'Mạng máy tính & truyền thông'),
(14520823, 'Vương Quốc Thái', 'Tân sinh viên'),
(14520824, 'Trương Thị Hồng Thắm', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520825, 'Lê Quang Thắng', 'Hệ thống thông tin'),
(14520826, 'Nguyễn Đức Thắng', 'Kỹ thuật máy tính'),
(14520827, 'Nguyễn Văn Thắng', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520828, 'Phạm Quốc Thắng', 'Công nghệ phần mềm'),
(14520829, 'Trần Tiến Thắng', 'Kỹ thuật máy tính'),
(14520830, 'Bùi Xuân Thành', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520831, 'Châu Lê Phước Thành', 'Tân sinh viên'),
(14520832, 'Đặng Phước Thành', 'Công nghệ phần mềm'),
(14520833, 'Đặng Văn Thành', 'Tân sinh viên'),
(14520834, 'Đào Thị Thanh Thanh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520835, 'Đào Văn Thanh', 'Tân sinh viên'),
(14520836, 'Dương Văn Thành', 'Hệ thống thông tin'),
(14520837, 'Hoàng Bá Thanh', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520838, 'Hoàng Trung Thành', 'Mạng máy tính & truyền thông'),
(14520839, 'Lại Kiều Mai Thanh', 'Tân sinh viên'),
(14520840, 'Lộ Đạt Thành', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520841, 'Nguyễn Chí Thành', 'Hệ thống thông tin'),
(14520842, 'Nguyễn Hoàng Thanh', 'An ninh thông tin'),
(14520843, 'Nguyễn Hoàng Thiên Thanh', ''),
(14520844, 'Nguyễn Kỳ Thanh', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520845, 'Nguyễn Thế Thành', 'Mạng máy tính & truyền thông'),
(14520846, 'Phan Tấn Thành', 'BM Khoa học & Kỹ thuật thông tin'),
(14520847, 'Phan Thị Trường Thanh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520848, 'Phan TrĆ°áťng ThĂ nh', 'CĂ´ng ngháť pháş§n máťm'),
(14520849, 'Trần Đình Thành', 'Mạng máy tính & truyền thông'),
(14520850, 'Trần Thành Vi Thanh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520851, 'Trịnh Tấn Thành', 'Kỹ thuật máy tính'),
(14520852, 'Trương Nguyên Thành', 'BM Khoa học & Kỹ thuật thông tin'),
(14520853, 'Nguyễn Mạnh Thảo', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520854, 'Nguyễn Thị Phương Thảo', 'Tân sinh viên'),
(14520855, 'Nguyễn Thị Thu Thảo', 'Tân sinh viên'),
(14520856, 'Trịnh Lê Nhật Thảo', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520857, 'Võ Thị Thanh Thảo', 'Công nghệ phần mềm'),
(14520858, 'Lê Thiên Thi', 'Tân sinh viên'),
(14520859, 'Lý Xuân Thiên Thi', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520860, 'Mai Thi', 'Mạng máy tính & truyền thông'),
(14520861, 'Nguyễn Vũ Hoàng Thi', 'Công nghệ phần mềm'),
(14520862, 'Đỗ Minh Thiện', 'Mạng máy tính & truyền thông'),
(14520863, 'Student', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520864, 'Dương Văn Thiện', 'Khoa học máy tính'),
(14520865, 'Lê Hữu Thiện', ''),
(14520866, 'Lê Minh Thiện', 'Mạng máy tính & truyền thông'),
(14520867, 'Lê Minh Thiện', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520868, 'Nguyễn Minh Thiện', 'Kỹ thuật máy tính'),
(14520869, 'Nguyễn Tứ Thiện', ''),
(14520870, 'Thạch Thanh Thiên', 'Công nghệ phần mềm'),
(14520871, 'Trần Minh Thiện', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520872, 'Trần Ngọc Khoa Thiên', 'Công nghệ phần mềm'),
(14520873, 'Trần Quang Thiên', 'Công nghệ phần mềm'),
(14520874, 'Trương Vĩ Thiên', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520875, 'Bùi Đức Thịnh', 'Tân sinh viên'),
(14520876, 'Đào Phước Thịnh', 'Mạng máy tính & truyền thông'),
(14520877, 'Đỗ Duy Thịnh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520878, 'Đỗ Trường Thịnh', 'Kỹ thuật máy tính'),
(14520879, 'Hoàng Thịnh', 'Chương trình tiên tiến'),
(14520880, 'Lê Hoàng Phúc Thịnh', 'Tân sinh viên'),
(14520881, 'Nguyễn Đức Thịnh', '');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520882, 'Nguyễn Đức Thịnh', 'Kỹ thuật máy tính'),
(14520883, 'Nguyễn Hữu Thịnh', 'Công nghệ phần mềm'),
(14520884, 'Nguyễn Ngọc Thịnh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520885, 'Phạm Hoàng Thịnh', 'Mạng máy tính & truyền thông'),
(14520886, 'Phạm Nguyễn Khánh Thịnh', 'Chương trình tiên tiến'),
(14520887, 'Phạm Trường Thịnh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520888, 'Phạm Văn Thịnh', 'BM Khoa học & Kỹ thuật thông tin'),
(14520889, 'Trần Văn Thịnh', 'Mạng máy tính & truyền thông'),
(14520890, 'Lê Ngọc Thọ', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520891, 'Nguyễn Bá Thọ', 'Cử nhân tài năng'),
(14520892, 'Nguyễn Hữu Thọ', 'An ninh thông tin'),
(14520893, 'Quách Hải Thọ', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520894, 'Nguyễn Thị Kim Thoa', 'Mạng máy tính & truyền thông'),
(14520895, 'Nguyễn Thị Thơm', 'BM Khoa học & Kỹ thuật thông tin'),
(14520896, 'Bùi Hữu Thông', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520897, 'Lê Khắc Thông', 'Khoa học máy tính'),
(14520898, 'Lê Quốc Thông', 'Hệ thống thông tin'),
(14520899, 'Lê Văn Thống', 'Kỹ thuật máy tính'),
(14520900, 'Lỡ Trí Thông', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520901, 'Nguyễn Đức Thông', 'Mạng máy tính & truyền thông'),
(14520902, 'Nguyễn Huy Thông', 'Hệ thống thông tin'),
(14520903, 'Nguyễn Văn Thông', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520904, 'Phạm Văn Thông', 'Hệ thống thông tin'),
(14520905, 'Phan Hoàng Thông', 'Tân sinh viên'),
(14520906, 'Võ Minh Thông', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520907, 'Đặng Thị Anh Thư', 'Tân sinh viên'),
(14520908, 'Đỗ Đức Thụ', 'Hệ thống thông tin'),
(14520909, 'Nguyễn Phi Thủ', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520910, 'Nguyễn Thị Kim Thứ', 'BM Khoa học & Kỹ thuật thông tin'),
(14520911, 'Trần Thị Anh Thư', 'Tân sinh viên'),
(14520912, 'Hoàng Văn Thuần', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520913, 'Lê Minh Thuận', 'Kỹ thuật máy tính'),
(14520914, 'Nguyễn Quốc Thuận', 'Khoa học máy tính'),
(14520915, 'Nguyễn Văn Thuận', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520916, 'Trần Minh Thuận', 'Hệ thống thông tin'),
(14520917, 'Trang Hoài Thuận', 'Kỹ thuật máy tính'),
(14520918, 'Từ Vạn Thuận', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520919, 'Nguyễn Quốc Tri Thức', 'Kỹ sư tài năng ANTT'),
(14520920, 'Phạm Tri Thức', 'Công nghệ phần mềm'),
(14520921, 'Phan Văn Thức', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520922, 'Trần Lê Trọng Thức', 'Công nghệ phần mềm'),
(14520923, 'Trần Thị Nhã Thục', 'Tân sinh viên'),
(14520924, 'Bùi Linh Thương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520925, 'Bùi Từ Vũ Thương', 'Công nghệ phần mềm'),
(14520926, 'Đỗ Trọng Thưởng', 'Kỹ thuật máy tính'),
(14520927, 'Dương Hoài Thương', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520928, 'Hồ Thị Mỹ Thương', 'Hệ thống thông tin'),
(14520929, 'Hoàng Thị Thượng', 'Khoa học máy tính'),
(14520930, 'Nguyễn Thị Trúc Thương', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520931, 'Hồ Thị Thúy', 'BM Khoa học & Kỹ thuật thông tin'),
(14520932, 'Lê Thị Ngọc Thúy', 'Hệ thống thông tin'),
(14520933, 'Ngô Thị Bich Thủy', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520934, 'Nguyễn Thị Thanh Thùy', 'Mạng máy tính & truyền thông'),
(14520935, 'Trần Thị Thu Thủy', 'Khoa học máy tính'),
(14520936, 'Đặng Thị Mỹ Tiên', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520937, 'Đậu Thế Tiến', 'Khoa học máy tính'),
(14520938, 'Hồ Bảo Tiến', 'Tân sinh viên'),
(14520939, 'Hoàng Việt Tiến', 'Tân sinh viên'),
(14520940, 'Lê Huỳnh Thủy Tiên', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520941, 'Lưu Vĩnh Tiến', 'Tân sinh viên'),
(14520942, 'Nguyễn Quốc Tiến', 'Kỹ thuật máy tính'),
(14520943, 'Nguyễn Thiện Hoàng Tiên', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520944, 'Nguyễn Viết Tiến', 'Khoa học máy tính'),
(14520945, 'Nguyễn Vĩnh Tiến', 'Hệ thống thông tin'),
(14520946, 'Trần Huỳnh Ngọc Tiên', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520947, 'Trần Mạnh Tiến', 'Kỹ thuật máy tính'),
(14520948, 'Trần Minh Tiến', 'Kỹ thuật máy tính'),
(14520949, 'Trần Trung Tiến', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520950, 'Trần Văn Tiến', 'Kỹ thuật máy tính'),
(14520951, 'Trương Vĩnh Tiến', 'BM Khoa học & Kỹ thuật thông tin'),
(14520952, 'Văn Minh Tiến', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520953, 'Võ Hữu Tiến', 'Kỹ thuật máy tính'),
(14520954, 'Vũ Văn Tiến', 'Khoa học máy tính'),
(14520955, 'Lê Văn Tiệp', 'Hệ thống thông tin'),
(14520956, 'Hoàng Hữu Tín', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520957, 'Huỳnh Minh Tín', 'Khoa học máy tính'),
(14520958, 'Trần Hữu Tín', 'Kỹ thuật máy tính'),
(14520959, 'Trần Quang Tín', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520960, 'Trần Thanh Tín', 'Mạng máy tính & truyền thông'),
(14520961, 'Đào Khả Tỉnh', 'Hệ thống thông tin'),
(14520962, 'Dương Trung Tính', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520963, 'Nguyễn Minh Tính', 'An ninh thông tin'),
(14520964, 'Trần Thanh Tỉnh', 'Kỹ thuật máy tính'),
(14520965, 'Trần Văn Tịnh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520966, 'Đinh Đức Toàn', 'Mạng máy tính & truyền thông'),
(14520967, 'Huỳnh Duy Anh Toàn', 'Hệ thống thông tin'),
(14520968, 'Lê Trần Thế Toản', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520969, 'Lê Việt Toàn', 'Khoa học máy tính'),
(14520970, 'Lương Thiện Toàn', 'An ninh thông tin'),
(14520971, 'Nguyễn Huy Toàn', 'An ninh thông tin'),
(14520972, 'Nguyễn Nhật Toàn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520973, 'Nguyễn Thanh Toàn', 'Hệ thống thông tin'),
(14520974, 'Nguyễn Thành Toản', 'BM Khoa học & Kỹ thuật thông tin'),
(14520975, 'Nguyễn Trọng Toàn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520976, 'Nguyễn Văn Toan', 'Khoa học máy tính'),
(14520977, 'Nguyễn Vũ Thành Toàn', 'Kỹ thuật máy tính'),
(14520978, 'Trần Hữu Toàn', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520979, 'Trần Khánh Toàn', 'Hệ thống thông tin'),
(14520980, 'Trần Quốc Toàn', 'Công nghệ phần mềm'),
(14520981, 'Võ Thanh Thiên Toán', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520982, 'Dương Xuân Tới', 'Kỹ thuật máy tính'),
(14520983, 'Trần Thanh Trà', 'Khoa học máy tính'),
(14520984, 'Nguyễn Thị Ngọc Trâm', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520985, 'Nguyễn Thị Thanh Trâm', 'BM Khoa học & Kỹ thuật thông tin'),
(14520986, 'Nguyễn Vũ Bảo Trâm', 'Công nghệ phần mềm'),
(14520987, 'Trần Thị Mai Trâm', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520988, 'Trương Kiếm Ngọc Trâm', 'Mạng máy tính & truyền thông'),
(14520989, 'Hồ Khắc Tráng', 'Kỹ thuật máy tính'),
(14520990, 'Trần Thị Minh Trang', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520991, 'Kiều Minh Trí', 'An ninh thông tin'),
(14520992, 'Lâm Việt Trí', 'Kỹ thuật máy tính'),
(14520993, 'Nguyễn Đức Trí', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520994, 'Nguyễn Minh Trí', 'Mạng máy tính & truyền thông'),
(14520995, 'Nguyễn Minh Trí', 'Tân sinh viên'),
(14520996, 'Nguyễn Minh Trí', 'Kỹ thuật máy tính'),
(14520997, 'Nguyễn Tri Minh Trí', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14520998, 'Phạm Lê Minh Trí', 'Kỹ sư tài năng ANTT'),
(14520999, 'Phạm Minh Trí', 'Chương trình tiên tiến'),
(14521000, 'Tống Minh Trí', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521001, 'Trần Minh Trí', 'Công nghệ phần mềm'),
(14521002, 'Trần Phan Minh Trí', 'Kỹ thuật máy tính'),
(14521003, 'Trương Thành Trí', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521004, 'Đặng Văn Triều', 'Công nghệ phần mềm'),
(14521005, 'Nguyễn Thành Triều', 'Mạng máy tính & truyền thông'),
(14521006, 'Đỗ Yến Trinh', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521007, 'Hà Mạnh Trình', 'Công nghệ phần mềm'),
(14521008, 'Nguyễn Lê Lập Trình', 'Mạng máy tính & truyền thông'),
(14521009, 'Nguyễn Thị Tuyết Trinh', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521010, 'Hồ Đức Trọng', 'Mạng máy tính & truyền thông'),
(14521011, 'Lê Đặng Phương Trúc', 'Hệ thống thông tin'),
(14521012, 'Ngô Thanh Trúc', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521013, 'Phạm Minh Trực', 'BM Khoa học & Kỹ thuật thông tin'),
(14521014, 'Bùi Quang Trung', 'Khoa học máy tính'),
(14521015, 'Đỗ Quốc Trung', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521016, 'Đỗ Thành Trung', 'BM Khoa học & Kỹ thuật thông tin'),
(14521017, 'Hồ Đắc Trung', 'Kỹ sư tài năng ANTT'),
(14521018, 'Huỳnh Minh Trung', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521019, 'Nguyễn Bảo Trung', 'Tân sinh viên'),
(14521020, 'Nguyễn Duy Trung', 'Kỹ thuật máy tính'),
(14521021, 'Nguyễn Quang Trung', 'Khoa học máy tính'),
(14521022, 'Nguyễn Quốc Trung', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521023, 'Nguyễn Quốc Trung', 'Công nghệ phần mềm'),
(14521024, 'Nguyễn Thành Trung', 'Mạng máy tính & truyền thông'),
(14521025, 'Phạm Viết Quang Trung', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521026, 'Thái Thành Trung', 'Mạng máy tính & truyền thông'),
(14521027, 'Đống Minh Trường', 'Khoa học máy tính'),
(14521028, 'Nguyễn Hữu Trường', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521029, 'Võ Nhựt Trường', 'Kỹ thuật máy tính'),
(14521030, 'Vũ Khắc Trường', 'Mạng máy tính & truyền thông'),
(14521031, 'Nguyễn Xuân Truyền', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521032, 'Huỳnh Lê Anh Tú', 'Công nghệ phần mềm'),
(14521033, 'Lê Thị Cẩm Tú', 'Tân sinh viên'),
(14521034, 'Mai Văn Tự', 'Khoa học máy tính'),
(14521035, 'Nguyễn Huỳnh Anh Tú', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521036, 'Nguyễn Thanh Tú', 'Hệ thống thông tin'),
(14521037, 'Văn Công Tú', 'Khoa học máy tính'),
(14521038, 'Vũ Hoàng Anh Tú', ''),
(14521039, 'Đặng Minh Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521040, 'Đinh Ngọc Tuấn', 'Khoa học máy tính'),
(14521041, 'Đỗ Văn Tuân', 'Tân sinh viên'),
(14521042, 'Hoàng Kim Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521043, 'Huỳnh Anh Tuấn', 'Mạng máy tính & truyền thông'),
(14521044, 'Lê Anh Tuấn', 'Kỹ thuật máy tính'),
(14521045, 'Lê Đình Tuấn', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521046, 'Nguyễn Anh Tuấn', 'Mạng máy tính & truyền thông'),
(14521047, 'Nguyễn Lê Hoàng Tuấn', 'Hệ thống thông tin'),
(14521048, 'Nguyễn Minh Tuấn', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521049, 'Nguyễn Ngọc Anh Tuấn', 'Hệ thống thông tin'),
(14521050, 'Nguyễn Văn Tuân', 'Kỹ thuật máy tính'),
(14521051, 'Nguyễn Văn Tuân', 'An ninh thông tin'),
(14521052, 'Trần Thanh Tuấn', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521053, 'Đào Duy Tùng', 'Kỹ sư tài năng ANTT'),
(14521054, 'Lưu Thiên Tùng', 'Hệ thống thông tin'),
(14521055, 'Nguyễn Sơn Tùng', 'Công nghệ phần mềm'),
(14521056, 'Nguyễn Thanh Tùng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521057, 'Nguyễn Thanh Tùng', 'Hệ thống thông tin'),
(14521058, 'Nguyễn Văn Tùng', 'Mạng máy tính & truyền thông'),
(14521059, 'Phạm Văn Tùng', 'BM Khoa học & Kỹ thuật thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521060, 'Trần Sơn Tùng', 'Kỹ thuật máy tính'),
(14521061, 'Từ Thế Tùng', 'Tân sinh viên'),
(14521062, 'Lê Quốc Tường', 'Kỹ thuật máy tính'),
(14521063, 'Nguyễn Ngọc Tường', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521064, 'Phạm Văn Tưởng', 'Khoa học máy tính'),
(14521065, 'Đinh Văn Tuyền', 'Tân sinh viên'),
(14521066, 'Trần Văn Tuyến', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521067, 'Đinh Thị Tuyết', 'Mạng máy tính & truyền thông'),
(14521068, 'Võ Huyền Lan Uyên', 'Mạng máy tính & truyền thông'),
(14521069, 'Đào Hữu Văn', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521070, 'Nguyễn Lâm Văn', 'Hệ thống thông tin'),
(14521071, 'Nguyễn Phan Quang Vạn', 'Mạng máy tính & truyền thông'),
(14521072, 'Nguyễn Thị Hải Vân', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521073, 'Trần Tích Văn', 'Công nghệ phần mềm'),
(14521074, 'Lê Khánh Vi', 'Tân sinh viên'),
(14521075, 'Nguyễn Trường Vĩ', 'Tân sinh viên'),
(14521076, 'Phạm Quang Vĩ', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521077, 'Trần Triều Vĩ', 'Tân sinh viên'),
(14521078, 'Nguyễn Duy Viễn', 'Kỹ thuật máy tính'),
(14521079, 'Hồ Quốc Việt', 'Khoa học máy tính'),
(14521080, 'Hoàng Quốc Việt', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521081, 'Huỳnh Quốc Việt', 'Khoa học máy tính'),
(14521082, 'Lê Hoàng Việt', 'Tân sinh viên'),
(14521083, 'Lê Thành Việt', 'An ninh thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521084, 'Nguyễn Thành Việt', 'BM Khoa học & Kỹ thuật thông tin'),
(14521085, 'Thái Quốc Việt', 'Công nghệ phần mềm'),
(14521086, 'Võ Hoàng Việt', ''),
(14521087, 'Lê Phù Nhật Vinh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521088, 'Lê Võ Quang Vinh', 'Hệ thống thông tin'),
(14521089, 'Nguyễn Hoàng Vinh', 'BM Khoa học & Kỹ thuật thông tin'),
(14521090, 'Nguyễn Quốc Vinh', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521091, 'Nguyễn Tấn Vinh', 'Kỹ thuật máy tính'),
(14521092, 'Phạm Hữu Vinh', 'Kỹ thuật máy tính'),
(14521093, 'Phan Xuân Vinh', 'Kỹ sư tài năng ANTT');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521094, 'Thái Quang Vinh', 'Mạng máy tính & truyền thông'),
(14521095, 'Trần Anh Vinh', 'Hệ thống thông tin'),
(14521096, 'Trần Quang Vinh', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521097, 'Triệu Tráng Vinh', 'Công nghệ phần mềm'),
(14521098, 'Chu Hoàn Vũ', 'Kỹ thuật máy tính'),
(14521099, 'Lê Tuấn Vũ', 'Hệ thống thông tin');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521100, 'Nguyễn Đức Vũ', 'Mạng máy tính & truyền thông'),
(14521101, 'Nguyễn Phi Hoàng Vũ', 'An ninh thông tin'),
(14521102, 'Nguyễn Quang Vũ', ''),
(14521103, 'Nguyễn Xuân Vũ', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521104, 'Trần Đại Vũ', 'Mạng máy tính & truyền thông'),
(14521105, 'Hoàng Quốc Vương', 'BM Khoa học & Kỹ thuật thông tin'),
(14521106, 'Lâm Hàn Vương', 'Khoa học máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521107, 'Lê Văn Vượng', 'Hệ thống thông tin'),
(14521108, 'Nguyễn Văn Vượng', 'An ninh thông tin'),
(14521109, 'Phạm Hoàng Ngọc Vương', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521110, 'Võ Xuân Vương', 'Hệ thống thông tin'),
(14521111, 'Võ Hồng Như Ý', 'An ninh thông tin'),
(14521112, 'Hoàng Yêm', 'An ninh thông tin'),
(14521113, 'Mộng Lý Thu Yến', 'Mạng máy tính & truyền thông');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521114, 'Ngô Cao Tuấn Anh', 'Hệ thống thông tin'),
(14521115, 'Phạm Tuấn Anh', 'Tân sinh viên'),
(14521116, 'Lê Văn Cường', 'Công nghệ phần mềm'),
(14521117, 'Phạm Trang Linh Đan', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521118, 'Nguyễn Phạm Kỳ Điền', 'Hệ thống thông tin'),
(14521119, 'Trần Anh Đức', 'Công nghệ phần mềm'),
(14521120, 'Bùi Thị Thúy Dung', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521121, 'Đinh Bảo Duy', 'Hệ thống thông tin'),
(14521122, 'Nguyễn Văn Giang', 'Tân sinh viên'),
(14521123, 'Phan Hoàng Hải', 'Tân sinh viên'),
(14521124, 'Quách Thế Hào', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521125, 'Võ Hoàng Hảo', 'Tân sinh viên'),
(14521126, 'Lê Văn Hiếu', 'Tân sinh viên'),
(14521127, 'Đoàn Thiện Hòa', 'Hệ thống thông tin'),
(14521128, 'Trịnh Minh Hoàng', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521129, 'Đoàn Việt Hùng', 'Công nghệ phần mềm'),
(14521130, 'Lý Gia Hùng', 'Hệ thống thông tin'),
(14521131, 'Phạm Quang Hùng', 'Tân sinh viên'),
(14521132, 'Nguyễn Hữu Lợi', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521133, 'Bùi Quang Minh', 'Hệ thống thông tin'),
(14521134, 'Đặng Văn Nam', 'Công nghệ phần mềm'),
(14521135, 'Nguyễn Thanh Nga', 'Tân sinh viên'),
(14521136, 'Phan Minh Ngàn', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521137, 'Cà Hoàng Thiện Nhân', 'Tân sinh viên'),
(14521138, 'Trần Mai Thảo Nhi', 'Hệ thống thông tin'),
(14521139, 'Lê Thị My Ny', 'Tân sinh viên'),
(14521140, 'Lê Tuấn Phong', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521141, 'Nguyễn Hồng Sơn', 'Tân sinh viên'),
(14521142, 'Phạm Ngọc Sung', 'Tân sinh viên'),
(14521143, 'Đoàn Thị Minh Tâm', 'Tân sinh viên'),
(14521144, 'Phạm Qúy Tâm', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521145, 'Phan Phước Tân', 'Tân sinh viên'),
(14521146, 'Nguyễn Tấn Thắng', 'Kỹ thuật máy tính'),
(14521147, 'Bùi Thị Thu Thảo', 'Tân sinh viên'),
(14521148, 'Đoàn Thị Thu Thảo', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521149, 'Cao Thanh Thi', 'Tân sinh viên'),
(14521150, 'Hàng Tuấn Thiên', 'Công nghệ phần mềm'),
(14521151, 'Trần Đức Thuận', 'Hệ thống thông tin'),
(14521152, 'Nguyễn Anh Tú', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521153, 'Vương Đức Tuấn', 'Kỹ thuật máy tính'),
(14521154, 'Trần Thành Văn', 'Hệ thống thông tin'),
(14521155, 'Nguyễn Hữu Vũ', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521156, 'Dương Tuấn Anh', 'Công nghệ phần mềm'),
(14521157, 'Nguyễn Vân Anh', 'Công nghệ phần mềm'),
(14521158, 'Dương Trí Bảo', 'Tân sinh viên'),
(14521159, 'Nguyễn Hữu Chí', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521160, 'Trương Phan Thành Đại', 'Công nghệ phần mềm'),
(14521161, 'Phan Quang Duy', 'Công nghệ phần mềm'),
(14521162, 'Huỳnh Huy Hiệp', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521163, 'Nguyễn Trần Hoàng', 'Tân sinh viên'),
(14521164, 'Nguyễn Văn Hoàng', 'Tân sinh viên'),
(14521165, 'Lê Huy', 'Chương trình tiên tiến'),
(14521166, 'Nguyễn Đức Huy', 'Chương trình tiên tiến');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521167, 'Nguyễn Định Khương', 'Chương trình tiên tiến'),
(14521169, 'Nguyễn Hồng Phúc', 'Tân sinh viên'),
(14521170, 'Nguyễn Trung Phước', 'Tân sinh viên'),
(14521171, 'Phạm Minh Phương', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521172, 'Nguyễn Huỳnh Tài', 'Tân sinh viên'),
(14521173, 'Trần Minh Thắng', 'Công nghệ phần mềm'),
(14521174, 'Bùi Thị Thu Thảo', 'Tân sinh viên'),
(14521175, 'Dư Anh Tú', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521176, 'Lê Thị Vân Vi', 'Tân sinh viên'),
(14521177, 'Nguyễn Tường Vi', 'Tân sinh viên'),
(14521178, 'Trịnh Hoàng Thông', 'Chương trình tiên tiến'),
(14521179, 'Nguyễn Quốc Anh Tuấn', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521180, 'Nguyễn Đình Huy', 'Kỹ thuật máy tính'),
(14521181, 'Nguyễn Đức Hiền', 'Tân sinh viên'),
(14521182, 'Lê Anh Khôi', 'Hệ thống thông tin'),
(14521183, 'Đặng Thành Long', 'Tân sinh viên');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521184, 'Xa Tấn Tài', 'Tân sinh viên'),
(14521185, 'Nguyễn Kim Thiện', 'Tân sinh viên'),
(14521186, 'Bùi Thị Xuân Tiền', 'Công nghệ phần mềm'),
(14521187, 'Nguyễn Trần Hoàng Tôn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521188, 'Nguyễn Ngọc Bảo Trang', 'Tân sinh viên'),
(14521189, 'Nguyễn Anh Huy Vũ', 'Công nghệ phần mềm'),
(14521190, 'Nguyễn Trung Dũng Chinh', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521191, 'Trần Xuân Hiếu', 'Tân sinh viên'),
(14521192, 'Hồ Thị Thúy', 'Tân sinh viên'),
(14521193, 'Nguyễn Tri Ân', 'Tân sinh viên'),
(14521194, 'Nguyễn Minh Tuấn', 'Công nghệ phần mềm');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521195, 'Nguyễn Gia Luân', 'Công nghệ phần mềm'),
(14521196, 'Nguyễn Thanh Nga', 'Tân sinh viên'),
(14521197, 'Phan Huỳnh Trâm', 'Tân sinh viên'),
(14521198, 'Nguyễn Minh Đức', 'Kỹ thuật máy tính');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(14521199, 'Phan Thanh Duy', 'Kỹ thuật máy tính'),
(705000305, 'Trần Dương Hiếu', 'Đào tạo từ xa'),
(705000333, 'Nguyễn Ngọc Hải', 'Đào tạo từ xa'),
(705000359, 'Nguyễn Dũng', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(705000361, 'Trần Hoaøng Anh', 'Đào tạo từ xa'),
(705000363, 'Trần Hữu Nha Trang', 'Đào tạo từ xa'),
(705000366, 'Leâ Thị Bích Thủy', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(705000389, 'Nguyễn Haø Ngọc Hảo', 'Đào tạo từ xa'),
(705000427, 'Hồ Trung Khueâ', 'Đào tạo từ xa'),
(705000437, 'Nguyễn Minh Taâm', 'Đào tạo từ xa'),
(705000441, 'Nguyễn Bửu Thọ', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(705000449, 'Hồ Đức Việt', 'Đào tạo từ xa'),
(705000450, 'Nguyễn Trọng Quỳnh', 'Đào tạo từ xa'),
(705000459, 'Leâ Huỳnh Phước Taân', 'Đào tạo từ xa');
INSERT INTO `Students` (`student_id`, `name`, `subject`) VALUES
(705000485, 'Lữ Lương Chinh', 'Đào tạo từ xa'),
(705000499, 'Nguyễn Công Chỉnh', 'Đào tạo từ xa'),
(705000500, 'name', 'subject');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `AccessLogs`
--
ALTER TABLE `AccessLogs`
 ADD PRIMARY KEY (`id`,`user_id`), ADD KEY `fk_AccessLogs_1_idx` (`user_id`);

--
-- Indexes for table `Authors`
--
ALTER TABLE `Authors`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Books`
--
ALTER TABLE `Books`
 ADD PRIMARY KEY (`id`,`category_id`,`authors_id`,`language_id`), ADD KEY `fk_Books_1_idx` (`category_id`), ADD KEY `fk_Books_Authors1_idx` (`authors_id`), ADD KEY `fk_Books_Language_idx` (`language_id`), ADD KEY `fk_Books_Publisher_idx` (`publisher_id`);

--
-- Indexes for table `Categories`
--
ALTER TABLE `Categories`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Languages`
--
ALTER TABLE `Languages`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `LoanDetails`
--
ALTER TABLE `LoanDetails`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_LoanDetails_load_idx` (`loan_id`), ADD KEY `fk_LoanDetails_book_idx` (`book_id`);

--
-- Indexes for table `Loans`
--
ALTER TABLE `Loans`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_Loans_studentId_idx` (`student_id`), ADD KEY `fk_Loans_staffId_idx` (`staff_id`);

--
-- Indexes for table `Permissions`
--
ALTER TABLE `Permissions`
 ADD PRIMARY KEY (`id`,`staff_id`,`role_id`), ADD KEY `fk_Permissions_1_idx` (`staff_id`), ADD KEY `fk_Permissions_2_idx` (`role_id`);

--
-- Indexes for table `Publisher`
--
ALTER TABLE `Publisher`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ReturnDetails`
--
ALTER TABLE `ReturnDetails`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_ReturnDetails_loadDetail_idx` (`loan_detail_id`);

--
-- Indexes for table `Returns`
--
ALTER TABLE `Returns`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_Returns_loadId_idx` (`loan_id`);

--
-- Indexes for table `Sessions`
--
ALTER TABLE `Sessions`
 ADD PRIMARY KEY (`id`,`staff_id`), ADD KEY `fk_Sessions_1_idx` (`staff_id`);

--
-- Indexes for table `Staff`
--
ALTER TABLE `Staff`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `StaffRoles`
--
ALTER TABLE `StaffRoles`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Students`
--
ALTER TABLE `Students`
 ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `AccessLogs`
--
ALTER TABLE `AccessLogs`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Authors`
--
ALTER TABLE `Authors`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Categories`
--
ALTER TABLE `Categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Languages`
--
ALTER TABLE `Languages`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `LoanDetails`
--
ALTER TABLE `LoanDetails`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Loans`
--
ALTER TABLE `Loans`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Permissions`
--
ALTER TABLE `Permissions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Publisher`
--
ALTER TABLE `Publisher`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ReturnDetails`
--
ALTER TABLE `ReturnDetails`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Returns`
--
ALTER TABLE `Returns`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Sessions`
--
ALTER TABLE `Sessions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Staff`
--
ALTER TABLE `Staff`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `StaffRoles`
--
ALTER TABLE `StaffRoles`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Students`
--
ALTER TABLE `Students`
MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=705000501;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `AccessLogs`
--
ALTER TABLE `AccessLogs`
ADD CONSTRAINT `fk_AccessLogs_1` FOREIGN KEY (`user_id`) REFERENCES `Staff` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Books`
--
ALTER TABLE `Books`
ADD CONSTRAINT `fk_Books_Authors` FOREIGN KEY (`authors_id`) REFERENCES `Authors` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Books_Category` FOREIGN KEY (`category_id`) REFERENCES `Categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Books_Language` FOREIGN KEY (`language_id`) REFERENCES `Languages` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Books_Publisher` FOREIGN KEY (`publisher_id`) REFERENCES `Publisher` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `LoanDetails`
--
ALTER TABLE `LoanDetails`
ADD CONSTRAINT `fk_LoanDetails_book` FOREIGN KEY (`book_id`) REFERENCES `Books` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_LoanDetails_load` FOREIGN KEY (`loan_id`) REFERENCES `Loans` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Loans`
--
ALTER TABLE `Loans`
ADD CONSTRAINT `fk_Loans_staffId` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Loans_studentId` FOREIGN KEY (`student_id`) REFERENCES `Students` (`student_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Permissions`
--
ALTER TABLE `Permissions`
ADD CONSTRAINT `fk_Permissions_1` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Permissions_2` FOREIGN KEY (`role_id`) REFERENCES `StaffRoles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `ReturnDetails`
--
ALTER TABLE `ReturnDetails`
ADD CONSTRAINT `fk_ReturnDetails_loadDetail` FOREIGN KEY (`loan_detail_id`) REFERENCES `LoanDetails` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_ReturnDetails_return` FOREIGN KEY (`loan_detail_id`) REFERENCES `Returns` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Returns`
--
ALTER TABLE `Returns`
ADD CONSTRAINT `fk_Returns_loadId` FOREIGN KEY (`loan_id`) REFERENCES `Loans` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Sessions`
--
ALTER TABLE `Sessions`
ADD CONSTRAINT `fk_Sessions_1` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
