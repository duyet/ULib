-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 30, 2015 at 11:57 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ULib`
--

-- --------------------------------------------------------

--
-- Table structure for table `AccessLogs`
--

DROP TABLE IF EXISTS `AccessLogs`;
CREATE TABLE IF NOT EXISTS `AccessLogs` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `access_time` datetime NOT NULL,
  `access_type` varchar(10) DEFAULT NULL,
  `log_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Authors`
--

DROP TABLE IF EXISTS `Authors`;
CREATE TABLE IF NOT EXISTS `Authors` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` text,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Authors`
--

INSERT INTO `Authors` (`id`, `name`, `description`, `status`) VALUES
(1, 'Dang Tuan Nguyen', 'University of Information Technology, VNU- HCM', 1),
(2, '?? Phúc', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Books`
--

DROP TABLE IF EXISTS `Books`;
CREATE TABLE IF NOT EXISTS `Books` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `publisher_id` int(11) DEFAULT NULL,
  `authors_id` int(11) NOT NULL,
  `number` int(11) NOT NULL DEFAULT '0',
  `description` text,
  `available_number` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publish_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `BookToAuthor`
--

DROP TABLE IF EXISTS `BookToAuthor`;
CREATE TABLE IF NOT EXISTS `BookToAuthor` (
  `book_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='A book can have a lots of author.';

-- --------------------------------------------------------

--
-- Table structure for table `Categories`
--

DROP TABLE IF EXISTS `Categories`;
CREATE TABLE IF NOT EXISTS `Categories` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `loan_time` int(11) DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Categories`
--

INSERT INTO `Categories` (`id`, `name`, `description`, `loan_time`, `status`) VALUES
(1, 'ssssssssssss', 'ssssssssssss', 6, 1),
(2, 'aaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 15, 1),
(3, 'Alpha Wordpress Framework', 'Alpha Wordpress Framework', 15, 1),
(4, 'âsasasa', 'âsasasaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 15, 1),
(5, 'aaaa', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 15, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Groups`
--

DROP TABLE IF EXISTS `Groups`;
CREATE TABLE IF NOT EXISTS `Groups` (
`id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `status` int(11) DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Groups`
--

INSERT INTO `Groups` (`id`, `name`, `description`, `status`) VALUES
(1, 'Supper Admin', 'Supper Admin Can do anythings', 1),
(2, 'Admin', 'Admin for System', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Languages`
--

DROP TABLE IF EXISTS `Languages`;
CREATE TABLE IF NOT EXISTS `Languages` (
`id` int(11) NOT NULL,
  `key` varchar(2) NOT NULL,
  `name` varchar(45) NOT NULL DEFAULT '',
  `description` varchar(250) DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Languages`
--

INSERT INTO `Languages` (`id`, `key`, `name`, `description`, `status`) VALUES
(1, 'en', 'English', 'English Books', 1),
(2, 'vi', 'Vietnamese', 'Vietnamese Books', 1),
(3, 'qa', 'Iraq', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `LibRules`
--

DROP TABLE IF EXISTS `LibRules`;
CREATE TABLE IF NOT EXISTS `LibRules` (
`id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `value` text,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LoanDetails`
--

DROP TABLE IF EXISTS `LoanDetails`;
CREATE TABLE IF NOT EXISTS `LoanDetails` (
`id` int(11) NOT NULL,
  `loan_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `time_return` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `is_return` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Loans`
--

DROP TABLE IF EXISTS `Loans`;
CREATE TABLE IF NOT EXISTS `Loans` (
`id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `time_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Offices`
--

DROP TABLE IF EXISTS `Offices`;
CREATE TABLE IF NOT EXISTS `Offices` (
`id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `leader` int(11) DEFAULT NULL,
  `description` text,
  `status` tinyint(4) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Permissions`
--

DROP TABLE IF EXISTS `Permissions`;
CREATE TABLE IF NOT EXISTS `Permissions` (
`id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Permissions`
--

INSERT INTO `Permissions` (`id`, `group_id`, `role_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `Publisher`
--

DROP TABLE IF EXISTS `Publisher`;
CREATE TABLE IF NOT EXISTS `Publisher` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` text,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Reports`
--

DROP TABLE IF EXISTS `Reports`;
CREATE TABLE IF NOT EXISTS `Reports` (
`id` int(11) NOT NULL,
  `template_id` int(11) NOT NULL,
  `report_data` longtext,
  `time_created` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(4) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ReportTemplates`
--

DROP TABLE IF EXISTS `ReportTemplates`;
CREATE TABLE IF NOT EXISTS `ReportTemplates` (
`id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `template_file` varchar(250) DEFAULT NULL,
  `time_created` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ReturnDetails`
--

DROP TABLE IF EXISTS `ReturnDetails`;
CREATE TABLE IF NOT EXISTS `ReturnDetails` (
`id` int(11) NOT NULL,
  `return_id` int(11) DEFAULT NULL,
  `loan_detail_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Returns`
--

DROP TABLE IF EXISTS `Returns`;
CREATE TABLE IF NOT EXISTS `Returns` (
`id` int(11) NOT NULL,
  `loan_id` int(11) NOT NULL,
  `time_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ServiceLogs`
--

DROP TABLE IF EXISTS `ServiceLogs`;
CREATE TABLE IF NOT EXISTS `ServiceLogs` (
`id` int(11) NOT NULL,
  `service_type_id` int(11) NOT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `prices` int(11) DEFAULT NULL,
  `note` text,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(4) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Services`
--

DROP TABLE IF EXISTS `Services`;
CREATE TABLE IF NOT EXISTS `Services` (
`id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `description` text,
  `status` tinyint(4) DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Services`
--

INSERT INTO `Services` (`id`, `name`, `description`, `status`) VALUES
(1, 'In ?n', '', 1),
(2, 'M??n phòng h?p', '', 1),
(3, 'N??c', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Sessions`
--

DROP TABLE IF EXISTS `Sessions`;
CREATE TABLE IF NOT EXISTS `Sessions` (
`id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `login_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Settings`
--

DROP TABLE IF EXISTS `Settings`;
CREATE TABLE IF NOT EXISTS `Settings` (
`id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `value` text,
  `status` tinyint(4) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Staff`
--

DROP TABLE IF EXISTS `Staff`;
CREATE TABLE IF NOT EXISTS `Staff` (
`id` int(11) NOT NULL,
  `username` varchar(16) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `phone_number` varchar(45) DEFAULT NULL,
  `office_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT '1',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `birthday` date DEFAULT NULL,
  `start_day` date DEFAULT NULL,
  `last_modify` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Staff`
--

INSERT INTO `Staff` (`id`, `username`, `email`, `password`, `name`, `phone_number`, `office_id`, `group_id`, `sex`, `create_time`, `birthday`, `start_day`, `last_modify`, `status`) VALUES
(1, 'lvduit', 'lvduit08@gmail.com', '$2a$08$DPd0cw/Dtccoclhv3ySXquq67JuHWytNVm1xsieq4I481H5WHnr/K', 'Van-Duyet Le', '01662626009', NULL, NULL, 1, '2015-03-22 03:24:24', NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `StaffRoles`
--

DROP TABLE IF EXISTS `StaffRoles`;
CREATE TABLE IF NOT EXISTS `StaffRoles` (
`id` int(11) NOT NULL,
  `key` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `StaffRoles`
--

INSERT INTO `StaffRoles` (`id`, `key`, `name`, `description`) VALUES
(1, 'user-manager', 'User manager', 'Manager for User'),
(2, 'groups', 'Group manager', 'Manager for Groups'),
(3, 'categories', 'Categories Manager', 'Manager for Categories'),
(4, 'books', 'Books Manager', 'Manager for Books');

-- --------------------------------------------------------

--
-- Table structure for table `Students`
--

DROP TABLE IF EXISTS `Students`;
CREATE TABLE IF NOT EXISTS `Students` (
`student_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `subject` varchar(45) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT '1',
  `email` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `AccessLogs`
--
ALTER TABLE `AccessLogs`
 ADD PRIMARY KEY (`id`,`user_id`), ADD KEY `fk_AccessLogs_1_idx` (`user_id`);

--
-- Indexes for table `Authors`
--
ALTER TABLE `Authors`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Books`
--
ALTER TABLE `Books`
 ADD PRIMARY KEY (`id`,`category_id`,`authors_id`,`language_id`), ADD KEY `fk_Books_1_idx` (`category_id`), ADD KEY `fk_Books_Language_idx` (`language_id`), ADD KEY `fk_Books_Publisher_idx` (`publisher_id`);

--
-- Indexes for table `BookToAuthor`
--
ALTER TABLE `BookToAuthor`
 ADD KEY `fk_BookToAuthor_toAuthor_idx` (`author_id`), ADD KEY `fk_BookToAuthor_toBook` (`book_id`);

--
-- Indexes for table `Categories`
--
ALTER TABLE `Categories`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Groups`
--
ALTER TABLE `Groups`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Languages`
--
ALTER TABLE `Languages`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `LibRules`
--
ALTER TABLE `LibRules`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `LoanDetails`
--
ALTER TABLE `LoanDetails`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_LoanDetails_load_idx` (`loan_id`), ADD KEY `fk_LoanDetails_book_idx` (`book_id`);

--
-- Indexes for table `Loans`
--
ALTER TABLE `Loans`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_Loans_studentId_idx` (`student_id`), ADD KEY `fk_Loans_staffId_idx` (`staff_id`);

--
-- Indexes for table `Offices`
--
ALTER TABLE `Offices`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Permissions`
--
ALTER TABLE `Permissions`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_Permissions_2_idx` (`role_id`), ADD KEY `fk_Permissions_group_idx` (`group_id`);

--
-- Indexes for table `Publisher`
--
ALTER TABLE `Publisher`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Reports`
--
ALTER TABLE `Reports`
 ADD PRIMARY KEY (`id`,`template_id`), ADD KEY `fk_Reports_1_idx` (`template_id`);

--
-- Indexes for table `ReportTemplates`
--
ALTER TABLE `ReportTemplates`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ReturnDetails`
--
ALTER TABLE `ReturnDetails`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_ReturnDetails_loadDetail_idx` (`loan_detail_id`);

--
-- Indexes for table `Returns`
--
ALTER TABLE `Returns`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_Returns_loadId_idx` (`loan_id`);

--
-- Indexes for table `ServiceLogs`
--
ALTER TABLE `ServiceLogs`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_ServiceLogs_staff_idx` (`staff_id`), ADD KEY `fk_ServiceLogs_service_type_idx` (`service_type_id`);

--
-- Indexes for table `Services`
--
ALTER TABLE `Services`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Sessions`
--
ALTER TABLE `Sessions`
 ADD PRIMARY KEY (`id`,`staff_id`), ADD KEY `fk_Sessions_1_idx` (`staff_id`);

--
-- Indexes for table `Settings`
--
ALTER TABLE `Settings`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Staff`
--
ALTER TABLE `Staff`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_Staff_1_idx` (`office_id`), ADD KEY `fk_Staff_group_idx` (`group_id`);

--
-- Indexes for table `StaffRoles`
--
ALTER TABLE `StaffRoles`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Students`
--
ALTER TABLE `Students`
 ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `AccessLogs`
--
ALTER TABLE `AccessLogs`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Authors`
--
ALTER TABLE `Authors`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Categories`
--
ALTER TABLE `Categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `Groups`
--
ALTER TABLE `Groups`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Languages`
--
ALTER TABLE `Languages`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `LibRules`
--
ALTER TABLE `LibRules`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `LoanDetails`
--
ALTER TABLE `LoanDetails`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Loans`
--
ALTER TABLE `Loans`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Offices`
--
ALTER TABLE `Offices`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Permissions`
--
ALTER TABLE `Permissions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `Publisher`
--
ALTER TABLE `Publisher`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Reports`
--
ALTER TABLE `Reports`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ReportTemplates`
--
ALTER TABLE `ReportTemplates`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ReturnDetails`
--
ALTER TABLE `ReturnDetails`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Returns`
--
ALTER TABLE `Returns`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ServiceLogs`
--
ALTER TABLE `ServiceLogs`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Services`
--
ALTER TABLE `Services`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Sessions`
--
ALTER TABLE `Sessions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Settings`
--
ALTER TABLE `Settings`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Staff`
--
ALTER TABLE `Staff`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `StaffRoles`
--
ALTER TABLE `StaffRoles`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `Students`
--
ALTER TABLE `Students`
MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `AccessLogs`
--
ALTER TABLE `AccessLogs`
ADD CONSTRAINT `fk_AccessLogs_1` FOREIGN KEY (`user_id`) REFERENCES `Staff` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Books`
--
ALTER TABLE `Books`
ADD CONSTRAINT `fk_Books_Category` FOREIGN KEY (`category_id`) REFERENCES `Categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Books_Language` FOREIGN KEY (`language_id`) REFERENCES `Languages` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Books_Publisher` FOREIGN KEY (`publisher_id`) REFERENCES `Publisher` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `BookToAuthor`
--
ALTER TABLE `BookToAuthor`
ADD CONSTRAINT `fk_BookToAuthor_toAuthor` FOREIGN KEY (`author_id`) REFERENCES `Authors` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_BookToAuthor_toBook` FOREIGN KEY (`book_id`) REFERENCES `Books` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `LoanDetails`
--
ALTER TABLE `LoanDetails`
ADD CONSTRAINT `fk_LoanDetails_book` FOREIGN KEY (`book_id`) REFERENCES `Books` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_LoanDetails_load` FOREIGN KEY (`loan_id`) REFERENCES `Loans` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Loans`
--
ALTER TABLE `Loans`
ADD CONSTRAINT `fk_Loans_staffId` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Loans_studentId` FOREIGN KEY (`student_id`) REFERENCES `Students` (`student_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Permissions`
--
ALTER TABLE `Permissions`
ADD CONSTRAINT `fk_Permissions_group` FOREIGN KEY (`group_id`) REFERENCES `Groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Permissions_role` FOREIGN KEY (`role_id`) REFERENCES `StaffRoles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Reports`
--
ALTER TABLE `Reports`
ADD CONSTRAINT `fk_Reports_1` FOREIGN KEY (`template_id`) REFERENCES `ReportTemplates` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `ReturnDetails`
--
ALTER TABLE `ReturnDetails`
ADD CONSTRAINT `fk_ReturnDetails_loadDetail` FOREIGN KEY (`loan_detail_id`) REFERENCES `LoanDetails` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_ReturnDetails_return` FOREIGN KEY (`loan_detail_id`) REFERENCES `Returns` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Returns`
--
ALTER TABLE `Returns`
ADD CONSTRAINT `fk_Returns_loadId` FOREIGN KEY (`loan_id`) REFERENCES `Loans` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `ServiceLogs`
--
ALTER TABLE `ServiceLogs`
ADD CONSTRAINT `fk_ServiceLogs_service_type` FOREIGN KEY (`service_type_id`) REFERENCES `Services` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_ServiceLogs_staff` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Sessions`
--
ALTER TABLE `Sessions`
ADD CONSTRAINT `fk_Sessions_1` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Staff`
--
ALTER TABLE `Staff`
ADD CONSTRAINT `fk_Staff_group` FOREIGN KEY (`group_id`) REFERENCES `Groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Staff_office` FOREIGN KEY (`office_id`) REFERENCES `Offices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
