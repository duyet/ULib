-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Sam 21 Mars 2015 à 21:50
-- Version du serveur :  5.6.20
-- Version de PHP :  5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `ULib`
--

-- --------------------------------------------------------

--
-- Structure de la table `AccessLogs`
--

DROP TABLE IF EXISTS `AccessLogs`;
CREATE TABLE IF NOT EXISTS `AccessLogs` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `access_time` datetime NOT NULL,
  `access_type` varchar(10) DEFAULT NULL,
  `log_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `Authors`
--

DROP TABLE IF EXISTS `Authors`;
CREATE TABLE IF NOT EXISTS `Authors` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` text,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `Books`
--

DROP TABLE IF EXISTS `Books`;
CREATE TABLE IF NOT EXISTS `Books` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `publisher_id` int(11) DEFAULT NULL,
  `authors_id` int(11) NOT NULL,
  `number` int(11) NOT NULL DEFAULT '0',
  `description` text,
  `available_number` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `Categories`
--

DROP TABLE IF EXISTS `Categories`;
CREATE TABLE IF NOT EXISTS `Categories` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `loan_time` int(11) DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `Languages`
--

DROP TABLE IF EXISTS `Languages`;
CREATE TABLE IF NOT EXISTS `Languages` (
`id` int(11) NOT NULL,
  `key` varchar(2) NOT NULL,
  `name` varchar(45) NOT NULL DEFAULT '',
  `description` varchar(250) DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `LoanDetails`
--

DROP TABLE IF EXISTS `LoanDetails`;
CREATE TABLE IF NOT EXISTS `LoanDetails` (
`id` int(11) NOT NULL,
  `loan_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `time_return` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `is_return` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `Loans`
--

DROP TABLE IF EXISTS `Loans`;
CREATE TABLE IF NOT EXISTS `Loans` (
`id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `time_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `Permissions`
--

DROP TABLE IF EXISTS `Permissions`;
CREATE TABLE IF NOT EXISTS `Permissions` (
`id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `Publisher`
--

DROP TABLE IF EXISTS `Publisher`;
CREATE TABLE IF NOT EXISTS `Publisher` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` text,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `ReturnDetails`
--

DROP TABLE IF EXISTS `ReturnDetails`;
CREATE TABLE IF NOT EXISTS `ReturnDetails` (
`id` int(11) NOT NULL,
  `return_id` int(11) DEFAULT NULL,
  `loan_detail_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `Returns`
--

DROP TABLE IF EXISTS `Returns`;
CREATE TABLE IF NOT EXISTS `Returns` (
`id` int(11) NOT NULL,
  `loan_id` int(11) NOT NULL,
  `time_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `Sessions`
--

DROP TABLE IF EXISTS `Sessions`;
CREATE TABLE IF NOT EXISTS `Sessions` (
`id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `login_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `Staff`
--

DROP TABLE IF EXISTS `Staff`;
CREATE TABLE IF NOT EXISTS `Staff` (
`id` int(11) NOT NULL,
  `username` varchar(16) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `phone_number` varchar(45) DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `Staff`
--

INSERT INTO `Staff` (`id`, `username`, `email`, `password`, `name`, `phone_number`, `create_time`, `status`) VALUES
(1, 'lvduit', 'lvduit08@gmail.com', '$2a$08$DPd0cw/Dtccoclhv3ySXquq67JuHWytNVm1xsieq4I481H5WHnr/K', 'Van-Duyet Le', '01662626009', '2015-03-22 03:24:24', 1);

-- --------------------------------------------------------

--
-- Structure de la table `StaffRoles`
--

DROP TABLE IF EXISTS `StaffRoles`;
CREATE TABLE IF NOT EXISTS `StaffRoles` (
`id` int(11) NOT NULL,
  `key` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `StaffRoles`
--

INSERT INTO `StaffRoles` (`id`, `key`, `name`, `description`) VALUES
(1, 'all', 'Supper Admin', 'Supper Admin, access to add permission');

-- --------------------------------------------------------

--
-- Structure de la table `Students`
--

DROP TABLE IF EXISTS `Students`;
CREATE TABLE IF NOT EXISTS `Students` (
`student_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `subject` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `AccessLogs`
--
ALTER TABLE `AccessLogs`
 ADD PRIMARY KEY (`id`,`user_id`), ADD KEY `fk_AccessLogs_1_idx` (`user_id`);

--
-- Index pour la table `Authors`
--
ALTER TABLE `Authors`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `Books`
--
ALTER TABLE `Books`
 ADD PRIMARY KEY (`id`,`category_id`,`authors_id`,`language_id`), ADD KEY `fk_Books_1_idx` (`category_id`), ADD KEY `fk_Books_Authors1_idx` (`authors_id`), ADD KEY `fk_Books_Language_idx` (`language_id`), ADD KEY `fk_Books_Publisher_idx` (`publisher_id`);

--
-- Index pour la table `Categories`
--
ALTER TABLE `Categories`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `Languages`
--
ALTER TABLE `Languages`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `LoanDetails`
--
ALTER TABLE `LoanDetails`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_LoanDetails_load_idx` (`loan_id`), ADD KEY `fk_LoanDetails_book_idx` (`book_id`);

--
-- Index pour la table `Loans`
--
ALTER TABLE `Loans`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_Loans_studentId_idx` (`student_id`), ADD KEY `fk_Loans_staffId_idx` (`staff_id`);

--
-- Index pour la table `Permissions`
--
ALTER TABLE `Permissions`
 ADD PRIMARY KEY (`id`,`staff_id`,`role_id`), ADD KEY `fk_Permissions_1_idx` (`staff_id`), ADD KEY `fk_Permissions_2_idx` (`role_id`);

--
-- Index pour la table `Publisher`
--
ALTER TABLE `Publisher`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `ReturnDetails`
--
ALTER TABLE `ReturnDetails`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_ReturnDetails_loadDetail_idx` (`loan_detail_id`);

--
-- Index pour la table `Returns`
--
ALTER TABLE `Returns`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_Returns_loadId_idx` (`loan_id`);

--
-- Index pour la table `Sessions`
--
ALTER TABLE `Sessions`
 ADD PRIMARY KEY (`id`,`staff_id`), ADD KEY `fk_Sessions_1_idx` (`staff_id`);

--
-- Index pour la table `Staff`
--
ALTER TABLE `Staff`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `StaffRoles`
--
ALTER TABLE `StaffRoles`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `Students`
--
ALTER TABLE `Students`
 ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `AccessLogs`
--
ALTER TABLE `AccessLogs`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Authors`
--
ALTER TABLE `Authors`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Categories`
--
ALTER TABLE `Categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Languages`
--
ALTER TABLE `Languages`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `LoanDetails`
--
ALTER TABLE `LoanDetails`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Loans`
--
ALTER TABLE `Loans`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Permissions`
--
ALTER TABLE `Permissions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Publisher`
--
ALTER TABLE `Publisher`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ReturnDetails`
--
ALTER TABLE `ReturnDetails`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Returns`
--
ALTER TABLE `Returns`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Sessions`
--
ALTER TABLE `Sessions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Staff`
--
ALTER TABLE `Staff`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `StaffRoles`
--
ALTER TABLE `StaffRoles`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `Students`
--
ALTER TABLE `Students`
MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `AccessLogs`
--
ALTER TABLE `AccessLogs`
ADD CONSTRAINT `fk_AccessLogs_1` FOREIGN KEY (`user_id`) REFERENCES `Staff` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `Books`
--
ALTER TABLE `Books`
ADD CONSTRAINT `fk_Books_Authors` FOREIGN KEY (`authors_id`) REFERENCES `Authors` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Books_Category` FOREIGN KEY (`category_id`) REFERENCES `Categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Books_Language` FOREIGN KEY (`language_id`) REFERENCES `Languages` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Books_Publisher` FOREIGN KEY (`publisher_id`) REFERENCES `Publisher` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `LoanDetails`
--
ALTER TABLE `LoanDetails`
ADD CONSTRAINT `fk_LoanDetails_book` FOREIGN KEY (`book_id`) REFERENCES `Books` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_LoanDetails_load` FOREIGN KEY (`loan_id`) REFERENCES `Loans` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `Loans`
--
ALTER TABLE `Loans`
ADD CONSTRAINT `fk_Loans_staffId` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Loans_studentId` FOREIGN KEY (`student_id`) REFERENCES `Students` (`student_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `Permissions`
--
ALTER TABLE `Permissions`
ADD CONSTRAINT `fk_Permissions_1` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Permissions_2` FOREIGN KEY (`role_id`) REFERENCES `StaffRoles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `ReturnDetails`
--
ALTER TABLE `ReturnDetails`
ADD CONSTRAINT `fk_ReturnDetails_loadDetail` FOREIGN KEY (`loan_detail_id`) REFERENCES `LoanDetails` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_ReturnDetails_return` FOREIGN KEY (`loan_detail_id`) REFERENCES `Returns` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `Returns`
--
ALTER TABLE `Returns`
ADD CONSTRAINT `fk_Returns_loadId` FOREIGN KEY (`loan_id`) REFERENCES `Loans` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `Sessions`
--
ALTER TABLE `Sessions`
ADD CONSTRAINT `fk_Sessions_1` FOREIGN KEY (`staff_id`) REFERENCES `Staff` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
